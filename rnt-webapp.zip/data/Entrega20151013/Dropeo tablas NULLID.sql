select 'drop table '||rtrim(tabschema)||'.'||rtrim(tabname) || ';' from syscat.tables where tabschema = 'NULLID'and (TABNAME not like '%_VIEW%' AND TABNAME not like '%HIST_V') 
union all
select 'drop view '||rtrim(tabschema)||'.'||rtrim(tabname) || ';' from syscat.tables where tabschema = 'NULLID' and (TABNAME like '%_VIEW%' or TABNAME like '%HIST_V') ;
