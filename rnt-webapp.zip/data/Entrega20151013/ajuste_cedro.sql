use rntpp_migra
GO

IF not exists(SELECT 1 FROM sys.indexes WHERE name = 'RegistroCivil_migra_indx' AND object_id = OBJECT_ID('RegistroCivil'))
BEGIN
	CREATE   INDEX RegistroCivil_migra_indx ON RegistroCivil ( "rut","fecha_nac" )
END
GO

IF not exists(SELECT 1 FROM sys.indexes WHERE name = 'RegistroCivil_migra_indx2' AND object_id = OBJECT_ID('RegistroCivil'))
BEGIN
    CREATE INDEX RegistroCivil_migra_indx2 ON RegistroCivil ( "rut" )
END
GO

---- ajuste comunas -------------------------------------------------------------------------------------
update comuna set nombre_comuna = 'Paiguano' where id_comuna = 34 
GO
update comuna set nombre_comuna = 'Llaillay' where id_comuna = 112 
GO
update comuna set nombre_comuna = 'Isla de Pascua' where id_comuna = 133 
GO
update comuna set nombre_comuna = 'San Fernando' where id_comuna = 151 
GO
update comuna set nombre_comuna = 'Puerto Montt' where id_comuna = 299 
GO
update comuna set nombre_comuna = 'Puerto Varas' where id_comuna = 300 
GO
update comuna set nombre_comuna = 'O' + '''' + 'Higgins' where id_comuna = 330 
GO
update comuna set nombre_comuna = 'Ais�n' where id_comuna = 324 
GO
update comuna set nombre_comuna = 'Punta Arenas' where id_comuna = 334 
GO
update comuna set nombre_comuna = 'Tiltil' where id_comuna = 94
GO
update comuna set nombre_comuna = 'Alto Biob�o' where id_comuna = 346 
GO
update comuna set nombre_comuna = 'Coihaique' where id_comuna = 322
GO
update comuna set nombre_comuna = 'Calera' where id_comuna = 116
GO


-------------------------------------------------------------------------------------------------------------


update hist_vehiculo set patente_vehiculo = ltrim(rtrim(upper(patente_vehiculo)))
GO

update vehiculo set patente_vehiculo = ltrim(rtrim(upper(patente_vehiculo)))
GO

update hist_vehiculo set reemplazado_por = ltrim(rtrim(upper(reemplazado_por)))
GO

update vehiculo set reemplazado_por = ltrim(rtrim(upper(reemplazado_por)))
GO


update hist_vehiculo set patente_reemplaza = ltrim(rtrim(upper(patente_reemplaza)))
GO

update vehiculo set patente_reemplaza = ltrim(rtrim(upper(patente_reemplaza)))
GO



IF OBJECT_ID('TMP_MIGRA_PROPIETARIO', 'U') IS NOT NULL
BEGIN
  DROP TABLE TMP_MIGRA_PROPIETARIO
END
GO



-----------------------------------------------------------------------------------------------------------------------

IF object_id('TMP_PATENTES_MOVE_ALL') IS NOT NULL
    EXEC ('drop table TMP_PATENTES_MOVE_ALL')
GO

  SELECT * INTO TMP_PATENTES_MOVE_ALL FROM (
  select      row_number() over(order by h.patente_vehiculo,h.fecha_operacion) row_id
                  ,h.fecha_operacion as fecha_cancelado,  
                  s.id_servicio id_servicio,
                  h.patente_vehiculo,
                  s.linea, 
                  es.descripcion as estado_vehiculo,
                  tc.descripcion tipo_cancelacion,
                  tc.id id_tipocancelacion,
                  h.region_destino as region_destino,
                  h.patente_reemplaza as reemplaza_a ,
                  h.reemplazado_por ,
                  case isnull(vl.patente,'1') when '1' then '0'  else  '1'  end as ley,
                  es.codigo as cod_estado_vehiculo,
                  h.usuario,
                  tc.codigo cod_tipocancelacion
        from      hist_vehiculo h
                  right       join servicio s                    on h.id_servicio              = s.id_servicio 
                  left        join vehiculo_ley vl         on upper(h.patente_vehiculo)= upper(vl.patente)
                  left join   tipo_cancelacion tc     on h.tipo_cancelacion        = tc.codigo
                  right       join estado_vehiculo es      on h.estado_vehiculo         = es.codigo

	union all   
      select distinct 10000000 row_id,
                  case when convert(varchar(10), v.fecha_cancelado, 103) = '01/01/1900' then v.fecha_entrada else v.fecha_cancelado end
                  as fecha_cancelado,
                  s.id_servicio id_servicio,
                  v.patente_vehiculo,
                  s.linea, 
                  es.descripcion as estado_vehiculo,
                  tc.descripcion tipo_cancelacion ,
                  tc.id id_tipocancelacion,
                  v.region_destino as region_destino,
                  v.patente_reemplaza as reemplaza_a  ,
                  v.reemplazado_por,
                  case isnull(vl.patente,'1') when '1' then '0' else  '1'   end as ley,
                  es.codigo as cod_estado_vehiculo,
                  v.usuario,
                  tc.codigo cod_tipocancelacion
        from      vehiculo v
                  right       join servicio s              on v.id_servicio             = s.id_servicio 
    left        join vehiculo_ley vl         on upper(v.patente_vehiculo)= upper(vl.patente)
                  left        join tipo_cancelacion tc     on v.tipo_cancelacion        = tc.codigo
                  right       join estado_vehiculo es      on v.estado_vehiculo         = es.codigo) ALLMOVS
GO

update TMP_PATENTES_MOVE_ALL set reemplaza_a = null where len(reemplaza_a) < 5
GO
update TMP_PATENTES_MOVE_ALL set reemplazado_por = null where len(reemplazado_por) < 5
GO

IF object_id('TMP_PATENTES_MOVE_ALL_INDX') IS NOT NULL
    EXEC ('drop index TMP_PATENTES_MOVE_ALL_INDX')
GO

create index TMP_PATENTES_MOVE_ALL_INDX on TMP_PATENTES_MOVE_ALL (patente_vehiculo,row_id)
GO

update TMP_PATENTES_MOVE_ALL set row_id = row_id + 1 - (select min(row_id) from TMP_PATENTES_MOVE_ALL aux where aux.patente_vehiculo = TMP_PATENTES_MOVE_ALL.patente_vehiculo)
  where row_id < 10000000update TMP_PATENTES_MOVE_ALL set reemplaza_a = null where len(reemplaza_a) < 5
update TMP_PATENTES_MOVE_ALL set reemplazado_por = null where len(reemplazado_por) < 5
GO

IF object_id('TMP_INFO_HISTORIAL_WEB') IS NOT NULL
    EXEC ('drop table TMP_INFO_HISTORIAL_WEB')
GO



create table TMP_INFO_HISTORIAL_WEB (
	row_id	int,
	fecha	datetime,
	id_servicio	bigint,
	patente_vehiculo varchar(10),
	linea	varchar(100),
	tipo_servicio	varchar(100),
	estado_vehiculo	varchar(100),
	tipo_cancelacion	varchar(100),
	id_tipocancelacion	int,
	region_destino	varchar(100),
	reemplaza_A	varchar(100),
	reemplazado_por	varchar(100),
	ley	varchar(100)
	,cod_estado_vehiculo  varchar(100)
	,usuario varchar(100)
	,cod_tipocancelacion	varchar(50)
	constraint TMP_INFO_HISTORIAL_WEB_PK primary key (row_id,id_servicio,patente_vehiculo)
)
GO


IF object_id('TMP_INFO_HIS_WEB_PROC') IS NOT NULL
    EXEC ('drop table TMP_INFO_HIS_WEB_PROC')
GO

create table TMP_INFO_HIS_WEB_PROC (
	patente_vehiculo varchar(10)
)
GO

IF object_id('TMP_INFO_HISTORIAL_WEB_SUPP') IS NOT NULL
    EXEC ('drop table TMP_INFO_HISTORIAL_WEB_SUPP')
GO


IF object_id('TMP_INFO_HISTORIAL_WEB_WS') IS NOT NULL
    EXEC ('drop table TMP_INFO_HISTORIAL_WEB_WS')
GO


IF object_id('createconsultawebordered') IS NOT NULL
    EXEC ('drop procedure createconsultawebordered')
GO

IF object_id('createtmptofix') IS NOT NULL
    EXEC ('drop procedure createtmptofix')
GO

IF object_id('TMP_INFO_HISTORIAL_TOFIX') IS NOT NULL
    EXEC ('drop table TMP_INFO_HISTORIAL_TOFIX')
GO	   

CREATE PROCEDURE [dbo].[createconsultawebordered] 
AS
begin
	/* Carga la data del historico del vehiculo */
		
	IF object_id('TMP_INFO_HISTORIAL_WEB_SORT') IS NOT NULL
	    EXEC ('drop table TMP_INFO_HISTORIAL_WEB_SORT')

	select row_number() over(order by patente_vehiculo, row_id) as actual,0 as siguiente,0 as anterior,t.*  
	INTO TMP_INFO_HISTORIAL_WEB_SORT
	from TMP_INFO_HISTORIAL_WEB t

	update TMP_INFO_HISTORIAL_WEB_SORT set anterior = actual + -1, siguiente = actual + 1 
      
end
GO

IF object_id('createvigenciasiniciales') IS NOT NULL
    EXEC ('drop procedure createvigenciasiniciales')
GO


CREATE PROCEDURE [dbo].[createvigenciasiniciales] 
AS
begin
	--tengo que eliminar las primeras inscripciones que voy a incorporar
	update TMP_INFO_HISTORIAL_WEB set fecha = (select min(h.fecha_operacion) from hist_vehiculo h where h.patente_vehiculo = TMP_INFO_HISTORIAL_WEB.patente_vehiculo)
	where
	patente_vehiculo in (select distinct f.patente_vehiculo from TMP_INFO_HISTORIAL_TOFIX f )
	and tipo_cancelacion  like '1%Inscripci%n'

	
	update TMP_INFO_HISTORIAL_WEB set tipo_cancelacion = 'Reinscripci�n'
	where
	patente_vehiculo in (select distinct f.patente_vehiculo from TMP_INFO_HISTORIAL_TOFIX f )
	and tipo_cancelacion  like '1%Inscripci%n' and estado_vehiculo = 'VIGENTE'

	update TMP_INFO_HISTORIAL_WEB set tipo_cancelacion = (select descripcion from tipo_cancelacion where id = id_tipocancelacion)
	where
	patente_vehiculo in (select distinct f.patente_vehiculo from TMP_INFO_HISTORIAL_TOFIX f )
	and tipo_cancelacion  like '1%Inscripci%n' and estado_vehiculo <> 'VIGENTE'


	
	INSERT INTO TMP_INFO_HISTORIAL_WEB (row_id,fecha,id_servicio,patente_vehiculo,linea,tipo_servicio,estado_vehiculo,tipo_cancelacion,
			id_tipocancelacion,region_destino,reemplaza_A,reemplazado_por,ley,cod_estado_vehiculo,usuario,cod_tipocancelacion) 
	select 1,null fecha_entrada,h.id_servicio,h.patente_vehiculo,null as linea,null as id_tipo_serv,'VIGENTE','1� Inscripci�n',null id_tipo_canc,null region_destino
			,null reemplazaa, null reemplazado,0 ley,'EN',h.usuario,null as cod_tipocancelacion 
	from hist_vehiculo h
	join
	(select min(fecha_operacion)  fecha_cancelacion,v.patente_vehiculo ,v.id_servicio,'hist_vehiculo' data_from from hist_vehiculo v
	join TMP_INFO_HISTORIAL_TOFIX f on f.patente_vehiculo = v.patente_vehiculo and f.id_servicio = v.id_servicio
	where v.estado_vehiculo <> 'EN'
	group by v.patente_vehiculo ,v.id_servicio)  mal on mal.fecha_cancelacion = h.fecha_operacion and h.patente_vehiculo = mal.patente_vehiculo and mal.id_servicio = h.id_servicio

      
end
GO

CREATE PROCEDURE [dbo].[createtmptofix] 
AS
begin
	/* Carga la data del historico del vehiculo */
		
	IF object_id('TMP_INFO_HISTORIAL_TOFIX') IS NOT NULL
	    EXEC ('drop table TMP_INFO_HISTORIAL_TOFIX')

	select distinct t.patente_vehiculo,t.id_servicio into TMP_INFO_HISTORIAL_TOFIX
	from  TMP_INFO_HISTORIAL_WEB  t join hist_vehiculo v on v.id_servicio = t.id_servicio and v.patente_vehiculo = t.patente_vehiculo
	where t.estado_vehiculo <> 'VIGENTE' and t.tipo_cancelacion like '1%Inscripci%n'

      
end
GO
---------------------------------------------------------------------------------------------------------------

IF object_id('getInfoHisVehiculoConsultaWeb2') IS NOT NULL
    EXEC ('drop procedure getInfoHisVehiculoConsultaWeb2')
GO

-- [dbo].[getInfoHisVehiculoConsultaWeb] 'DKZZ17' 
CREATE PROCEDURE [dbo].[getInfoHisVehiculoConsultaWeb2] 
@ppu varchar(10)
AS
 
declare           @cont             int
declare           @datenew          datetime
declare           @fechacancelado datetime


begin
/* Carga la data del historico del vehiculo */
	 select  row_number() over (order by row_id)  currow,row_id,fecha_cancelado fecha,id_servicio,patente_vehiculo,linea,estado_vehiculo,tipo_cancelacion,id_tipocancelacion 
	 ,region_destino,reemplaza_a,reemplazado_por,ley,cod_estado_vehiculo,usuario,cod_tipocancelacion   into #Table
	 from  TMP_PATENTES_MOVE_ALL v
      where   v.patente_vehiculo=upper(@ppu)
      
 
/* Reordena la fecha de operacion */
      set @cont = (select COUNT(1) from #Table)
      set @datenew = null
 
      while (@cont >= 1)
      begin 
 
                    set @datenew = (select fecha from #Table where currow = @cont - 1)
 
                  update      #Table 
                  set         fecha = @datenew
                  where currow      = @cont
                  
                  set @cont = @cont - 1
      end
 
/* Actualiza el tipo de cancelacion */
      update  #Table
      set         tipo_cancelacion =  case     when (row_id = 1) then                   '1� Inscripci�n'
                                                           when (tipo_cancelacion is null) then 'Reinscripci�n' else tipo_cancelacion
                                               end
	 insert into TMP_INFO_HISTORIAL_WEB
	 (row_id,
	fecha,
	id_servicio,
	patente_vehiculo,
	linea,
	estado_vehiculo,
	tipo_cancelacion,
	id_tipocancelacion,
	region_destino,
	reemplaza_A,
	reemplazado_por,
	ley,cod_estado_vehiculo,usuario,cod_tipocancelacion)
      select      row_id
                  ,convert(datetime,convert(varchar(10), fecha, 103),103) as fecha
                  ,id_servicio
                  ,patente_vehiculo
                  ,linea
                  ,estado_vehiculo
                  ,tipo_cancelacion
                  ,id_tipocancelacion
                  ,region_destino
                  ,reemplaza_A
                  ,reemplazado_por
                  ,ley 
                  ,cod_estado_vehiculo,usuario,cod_tipocancelacion
      from  #Table
      order by row_id

	insert into TMP_INFO_HIS_WEB_PROC (patente_vehiculo) 
	select  distinct upper(ltrim(rtrim(patente_vehiculo))) 
     from  #Table

      
      drop table #Table
      
end
GO




----------------------------------------------------------------------------------------------------------------
GO

IF object_id('TMP_PPU_QUERYLIST') IS NOT NULL
    EXEC ('drop table TMP_PPU_QUERYLIST')
GO


create table TMP_PPU_QUERYLIST (
	patente_vehiculo varchar(6)
)
GO

IF object_id('TMP_INFO_HISTORIAL_SUPPORT') IS NOT NULL
    EXEC ('drop table TMP_INFO_HISTORIAL_SUPPORT')
GO

create table TMP_INFO_HISTORIAL_SUPPORT (
	id   bigint not null,
	ordenhist  int null,
	fecha	datetime,
	id_region	int,
	no_folio	varchar	(100),
	id_servicio     bigint,
	estado_vehiculo	varchar(100),
	ppu           varchar(6),
	movimiento     varchar(100),
	cod_cancelacion   varchar(100),
	historia int,
	rut_persona_cancela	numeric,
	region_destino	int,
	usuario	varchar(100),
	patente_reemplaza	varchar(6),
	tipo_ingreso	varchar(30),
	esTaxi  smallint,
	comentario_cancelacion	varchar(2000),
	doc_cancelacion varchar(100),
	fecha_doc_cancelacion date,
	cancelado_por  varchar(100),
	constraint TMP_INFO_HISTORIAL0_SUP_PK primary key (id)
)
GO

CREATE INDEX TMP_INFO_HISTORIAL_SUPPORT_INDX1 ON TMP_INFO_HISTORIAL_SUPPORT (id_servicio,ppu)
GO
CREATE INDEX TMP_INFO_HISTORIAL_SUPPORT_INDX2 ON TMP_INFO_HISTORIAL_SUPPORT (ID,ppu)
GO
CREATE INDEX TMP_INFO_HISTORIAL_INDX1 ON TMP_INFO_HISTORIAL_SUPPORT (fecha)
GO



SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF object_id('tmp_migra_vehiculo_hist') IS NOT NULL
    EXEC ('drop procedure tmp_migra_vehiculo_hist')
GO

--tmp_migra_vehiculo_hist 'DKZZ17' 
CREATE PROCEDURE tmp_migra_vehiculo_hist (@ppulikes varchar(4))
AS
declare @init_row bigint

BEGIN

select @init_row = max(ID)  from TMP_INFO_HISTORIAL

if @init_row is null
begin 
	select @init_row = 0
end	

delete TMP_PPU_QUERYLIST

insert into TMP_PPU_QUERYLIST (patente_vehiculo)
(select distinct upper(patente_vehiculo) 
from (
	select patente_vehiculo from vehiculo where patente_vehiculo  like @ppulikes
	union 
	select patente_vehiculo from hist_vehiculo where patente_vehiculo  like @ppulikes) pts)


insert into TMP_INFO_HISTORIAL (id,fecha,ppu,estado_vehiculo,movimiento,cod_cancelacion,id_servicio
				,historia,rut_persona_cancela,region_destino,usuario,patente_reemplaza,tipo_ingreso,esTaxi,comentario_cancelacion,doc_cancelacion,fecha_doc_cancelacion,cancelado_por)    
select     
		 @init_row + row_number() over(order by patente_vehiculo,fecha_cancelado)
		 ,fecha_cancelado
		 ,upper(patente_vehiculo) patente_vehiculo
		 ,estado_vehiculo
		 ,estado_vehiculo_desc
		 ,UPPER(tipo_cancelacion)
		 ,id_servicio
		 ,historia
           ,rut_persona_cancela
           ,region_destino
           ,usuario
           ,patente_reemplaza
           ,tipo_ingreso
           ,(select count(1) from taxi where taxi.patente_vehiculo = allvehicleData.patente_vehiculo) esTaxi
           ,comentario_cancelacion
           ,doc_cancelacion,fecha_doc_cancelacion,cancelado_por
from 
(		 
select            
                  h.fecha_operacion  as fecha_cancelado,  
                  s.id_region as id_region,
                  s.no_folio as no_folio, 
              	   upper(h.patente_vehiculo) patente_vehiculo,
              	   es.descripcion as estado_vehiculo_desc,
                  tc.codigo tipo_cancelacion,
                  h.estado_vehiculo,
                  h.id_servicio,
                  0 historia,
                  h.rut_persona_cancela,
                  h.region_destino,
                  h.usuario,
                  upper(h.patente_reemplaza) patente_reemplaza,
                  case when ltrim(rtrim(isnull(h.patente_reemplaza,''))) = '' then 'nuevo_vehiculo' else 'reemplazo_de_vehiculo' end  tipo_ingreso,
                  h.comentario_cancelacion,
                  h.doc_cancelacion,h.fecha_doc_cancelacion
                  ,isnull('CANCELADO POR (RUT): ' + convert(varchar(20), h.rut_persona_cancela),'')   cancelado_por
        from      hist_vehiculo h
        		   join  TMP_PPU_QUERYLIST on upper(h.patente_vehiculo) = TMP_PPU_QUERYLIST.patente_vehiculo
                  right       join servicio s                    on h.id_servicio              = s.id_servicio 
                  left        join vehiculo_ley vl         on upper(h.patente_vehiculo)= upper(vl.patente)
                  left join tipo_servicio ts        on s.id_tipo_servicio        = ts.id_tipo_servicio
                  left join tipo_cancelacion tc     on h.tipo_cancelacion        = tc.codigo
                  right       join estado_vehiculo es      on h.estado_vehiculo         = es.codigo
  union all
/* Carga la data del vehiculo */
      select 
                  case when convert(varchar(10), v.fecha_cancelado, 103) = '01/01/1900' then v.fecha_entrada  else  CONVERT(DATETIME, CONVERT(VARCHAR, v.fecha_cancelado, 112) + ' 23:59:59', 112) end
                  as fecha_cancelado,
                  s.id_region  ,
                  s.no_folio as no_folio, 
			   upper(v.patente_vehiculo) patente_vehiculo,
                  es.descripcion as estado_vehiculo_desc,
                  tc.codigo tipo_cancelacion ,
            	   v.estado_vehiculo,
                  v.id_servicio,
                  1 historia, 
                  v.rut_persona_cancela,
                  v.region_destino,
                  v.usuario,
                  upper(v.patente_reemplaza) patente_reemplaza,
                  case when ltrim(rtrim(isnull(v.patente_reemplaza,''))) = '' then 'nuevo_vehiculo' else 'reemplazo_de_vehiculo' end  tipo_ingreso,
                  v.comentario_cancelacion,
                  v.doc_cancelacion,v.fecha_doc_cancelacion
                  ,isnull('CANCELADO POR (RUT): ' + convert(varchar(20), v.rut_persona_cancela),'')   cancelado_por
        from      vehiculo v
        		   join  TMP_PPU_QUERYLIST on upper(v.patente_vehiculo) = TMP_PPU_QUERYLIST.patente_vehiculo
                  right       join servicio s              on v.id_servicio             = s.id_servicio 
                  left        join vehiculo_ley vl         on upper(v.patente_vehiculo)= upper(vl.patente)
                  left        join tipo_servicio ts        on s.id_tipo_servicio        = ts.id_tipo_servicio
                  left        join tipo_cancelacion tc     on v.tipo_cancelacion        = tc.codigo
                  right       join estado_vehiculo es      on v.estado_vehiculo         = es.codigo
    --    where 0 = 1
) allvehicleData




INSERT INTO TMP_INFO_HISTORIAL_SUPPORT (id,ordenhist,fecha,id_region,no_folio,id_servicio,estado_vehiculo,ppu,movimiento,cod_cancelacion,historia,rut_persona_cancela,region_destino,usuario,patente_reemplaza,tipo_ingreso,esTaxi)
(SELECT id,ordenhist,fecha,id_region,no_folio,id_servicio,estado_vehiculo,ppu,movimiento,cod_cancelacion,historia,rut_persona_cancela,region_destino,usuario,patente_reemplaza,tipo_ingreso,esTaxi
from TMP_INFO_HISTORIAL where ppu  like @ppulikes )


end
GO


IF object_id('tmp_migra_vehiculo_hist_close') IS NOT NULL
    EXEC ('drop procedure tmp_migra_vehiculo_hist_close')
GO


CREATE PROCEDURE tmp_migra_vehiculo_hist_close 
AS


BEGIN

update TMP_INFO_HISTORIAL set TMP_INFO_HISTORIAL.fecha = 
(select fecha from TMP_INFO_HISTORIAL_SUPPORT t2 where t2.id = TMP_INFO_HISTORIAL.id-1 and t2.ppu = TMP_INFO_HISTORIAL.ppu)


      update  TMP_INFO_HISTORIAL
      set  movimiento =  case     when (ID = (SELECT min(id) FROM TMP_INFO_HISTORIAL_SUPPORT T2 WHERE T2.ppu = TMP_INFO_HISTORIAL.PPU  ))
                                    then 'PRIMERA INSCRIPCION'
                                    when (movimiento is null) then 'REINSCRIPCION' else movimiento end


 UPDATE TMP_INFO_HISTORIAL SET ordenhist = id +1 - (SELECT MIN(ID) FROM TMP_INFO_HISTORIAL_SUPPORT T2 
									   WHERE  T2.ppu = TMP_INFO_HISTORIAL.ppu)  

  ----support sirve para sacar los que van a la vs
EXEC ('truncate table TMP_INFO_HISTORIAL_SUPPORT')


INSERT INTO TMP_INFO_HISTORIAL_SUPPORT (id,id_servicio,ppu)
(SELECT max(id),id_servicio,ppu
from TMP_INFO_HISTORIAL
group by id_servicio,ppu)

end
GO








IF object_id('DTtoUnixTS') IS NOT NULL
    EXEC ('drop FUNCTION DTtoUnixTS')
GO


CREATE FUNCTION dbo.DTtoUnixTS 
( 
    @dt DATETIME 
) 
RETURNS BIGINT 
AS 
BEGIN 
    DECLARE @diff BIGINT 
    IF @dt >= '20380101' 
    BEGIN 
        SET @diff = CONVERT(BIGINT, DATEDIFF(dd, '19700101', '20380101')) 
            + CONVERT(BIGINT, DATEDIFF(dd, '20380101', @dt)) 
    END 
    ELSE 
        SET @diff = DATEDIFF(dd, '19700101', @dt) 
        SET @diff = @diff * 86400000
    RETURN @diff 
END

GO
--------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------
IF object_id('tmp_itinerario') IS NOT NULL
    EXEC ('drop table tmp_itinerario')
GO

select *  into tmp_itinerario
from itinerario
GO


update tmp_itinerario set hora_inicio = (ltrim(rtrim(hora_inicio)))
GO

update tmp_itinerario set hora_inicio = replace(replace(replace(replace(replace(replace(replace(replace(hora_inicio,'....',''),'.',';'),';',':'),'-',':'),'_',':'),' ',''),'/',':'),'::',':')
where len(replace(replace(replace(replace(replace(replace(replace(replace(hora_inicio,'....',''),'.',';'),';',':'),'-',':'),'_',':'),' ',''),'/',':'),'::',':')) = 5
and CHARINDEX (':',replace(replace(replace(replace(replace(replace(replace(replace(hora_inicio,'....',''),'.',';'),';',':'),'-',':'),'_',':'),' ',''),'/',':'),'::',':')) = 3
GO

update tmp_itinerario set hora_inicio = replace(replace(replace(replace(replace(replace(replace(replace(hora_inicio,'....',''),'.',';'),';',':'),'-',':'),'_',':'),' ',''),'/',':'),'::',':')
where  not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
GO

update tmp_itinerario set hora_inicio = SUBSTRING ( hora_inicio ,1 , 2 ) + ':' +SUBSTRING (hora_inicio ,3 , 2 )
where not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
and len(hora_inicio) = 4 and ISNUMERIC(hora_inicio) = 1
GO

update tmp_itinerario set hora_inicio = '0'+hora_inicio+':00'
where len(hora_inicio) < 2 and ISNUMERIC(hora_inicio) = 1
GO

update tmp_itinerario set hora_inicio = '00:00'
where len(hora_inicio) < 2 
GO

update tmp_itinerario set hora_inicio = '00:00'
where hora_inicio = 'null' 
GO

update tmp_itinerario set hora_inicio = '00:00'
where hora_inicio = 'LIBRE' 
GO

update tmp_itinerario set hora_inicio = '00:00'
where hora_inicio = 'TURNO' 
GO

update tmp_itinerario set hora_inicio = '00:00'
where hora_inicio = 'optat' 
GO

update tmp_itinerario set hora_inicio = '0'+hora_inicio
where not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
and len(hora_inicio) = 4 and  CHARINDEX (':',hora_inicio) =  2
GO

update tmp_itinerario set hora_inicio = hora_inicio+'0'
where not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
and len(hora_inicio) = 4 and  CHARINDEX (':',hora_inicio) =  3
GO

update tmp_itinerario set hora_inicio = hora_inicio+':00'
where not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
and len(hora_inicio) = 2 and ISNUMERIC(hora_inicio) = 1
GO

update tmp_itinerario set hora_inicio = hora_inicio+':00'
where not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
and len(hora_inicio) = 2 and ISNUMERIC(hora_inicio) = 1
GO

update tmp_itinerario set hora_inicio = hora_inicio+'00'
where not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
and CHARINDEX (':',hora_inicio) =  3 and len(hora_inicio) = 3
GO

update tmp_itinerario set hora_inicio = '0'+hora_inicio+'0'
where not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
and CHARINDEX (':',hora_inicio) =  2 and len(hora_inicio) = 3
GO

update tmp_itinerario set hora_inicio = '0' + SUBSTRING ( hora_inicio ,1 , 1 ) + ':' +SUBSTRING ( hora_inicio ,2 , 2 ) 
where not(len(hora_inicio) = 5 and CHARINDEX (':',hora_inicio) =  3)
and ISNUMERIC(hora_inicio) = 1 and len(hora_inicio) = 3
GO

update tmp_itinerario set hora_inicio = '07:00' where hora_inicio = ':007+'
GO
update tmp_itinerario set hora_inicio = '07:30' where hora_inicio = '007:3'
GO
update tmp_itinerario set hora_inicio = '06:00' where hora_inicio = '06HR'
GO
update tmp_itinerario set hora_inicio = '09:00' where hora_inicio = '098:0'
GO
update tmp_itinerario set hora_inicio = '08:15' where hora_inicio = '8:15,'
GO
update tmp_itinerario set hora_inicio = '06:30' where hora_inicio = '|06:3'
GO
update tmp_itinerario set hora_inicio = '05:20' where hora_inicio = '058:2'
GO
update tmp_itinerario set hora_inicio = '08:30' where hora_inicio = '8:300'
GO
update tmp_itinerario set hora_inicio = '07:00' where hora_inicio = '�7:00'
GO
update tmp_itinerario set hora_inicio = '07:00' where hora_inicio = '07:0�'
GO
update tmp_itinerario set hora_inicio = '07:30' where hora_inicio = '|7:30'
GO



-------------------------------------------------------------------------------------------------------------


update tmp_itinerario set hora_fin = (ltrim(rtrim(hora_fin)));

update tmp_itinerario set hora_fin = replace(replace(replace(replace(replace(replace(replace(replace(hora_fin,'....',''),'.',';'),';',':'),'-',':'),'_',':'),' ',''),'/',':'),'::',':')
where len(replace(replace(replace(replace(replace(replace(replace(replace(hora_fin,'....',''),'.',';'),';',':'),'-',':'),'_',':'),' ',''),'/',':'),'::',':')) = 5
and CHARINDEX (':',replace(replace(replace(replace(replace(replace(replace(replace(hora_fin,'....',''),'.',';'),';',':'),'-',':'),'_',':'),' ',''),'/',':'),'::',':'))  = 3
GO

update tmp_itinerario set hora_fin = replace(replace(replace(replace(replace(replace(replace(replace(hora_fin,'....',''),'.',';'),';',':'),'-',':'),'_',':'),' ',''),'/',':'),'::',':')
where  not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
GO

update tmp_itinerario set hora_fin = SUBSTRING ( hora_fin ,1 , 2 ) + ':' +SUBSTRING (hora_fin ,3 , 2 )
where not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
and len(hora_fin) = 4 and ISNUMERIC(hora_fin) = 1
GO

update tmp_itinerario set hora_fin = '0'+hora_fin+':00'
where len(hora_fin) < 2 and ISNUMERIC(hora_fin) = 1
GO

update tmp_itinerario set hora_fin = '00:00'
where len(hora_fin) < 2 
GO

update tmp_itinerario set hora_fin = '00:00'
where hora_fin = 'null' 
GO

update tmp_itinerario set hora_fin = '23:59'
where hora_fin = 'LIBRE'
GO

update tmp_itinerario set hora_fin = '00:00'
where hora_fin = 'TURNO' 
GO

update tmp_itinerario set hora_fin = '00:00'
where hora_fin = 'optat'
GO

update tmp_itinerario set hora_fin = '0'+hora_fin
where not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
and len(hora_fin) = 4 and  CHARINDEX (':',hora_fin) =  2
GO

update tmp_itinerario set hora_fin = hora_fin+'0'
where not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
and len(hora_fin) = 4 and  CHARINDEX (':',hora_fin) =  3
GO

update tmp_itinerario set hora_fin = hora_fin+':00'
where not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
and len(hora_fin) = 2 and ISNUMERIC(hora_fin) = 1
GO

update tmp_itinerario set hora_fin = hora_fin+':00'
where not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
and len(hora_fin) = 2 and ISNUMERIC(hora_fin) = 1
GO

update tmp_itinerario set hora_fin = hora_fin+'00'
where not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
and CHARINDEX (':',hora_fin) =  3 and len(hora_fin) = 3
GO

update tmp_itinerario set hora_fin = '0'+hora_fin+'0'
where not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
and CHARINDEX (':',hora_fin) =  2 and len(hora_fin) = 3
GO

update tmp_itinerario set hora_fin = '0' + SUBSTRING ( hora_fin ,1 , 1 ) + ':' +SUBSTRING ( hora_fin ,2 , 2 ) 
where not(len(hora_fin) = 5 and CHARINDEX (':',hora_fin) =  3)
and ISNUMERIC(hora_fin) = 1 and len(hora_fin) = 3
GO


update tmp_itinerario set hora_fin = '22:00' where hora_fin = '|22:0'
GO
update tmp_itinerario set hora_fin = '16:30' where hora_fin = '16300'
GO
update tmp_itinerario set hora_fin = '18:00' where hora_fin = '18HR'
GO
update tmp_itinerario set hora_fin = '19:45' where hora_fin = '19,45'
GO
update tmp_itinerario set hora_fin = '23:59' where hora_fin = '29Hrs,'
GO
update tmp_itinerario set hora_fin = '23:59' where hora_fin = '29Hrs'
GO
update tmp_itinerario set hora_fin = '17:00' where hora_fin = '17:;0'
GO
update tmp_itinerario set hora_fin = '21:00' where hora_fin = '21:OO'
GO

