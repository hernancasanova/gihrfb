package cl.mtt.rnt.admin.bean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;

@ManagedBean
@ViewScoped
public class AdministracionTablasBean {

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	/**
	 * @return el valor de currentSessionBean
	 */
	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	/**
	 * @return el valor de messageBean
	 */
	public MessageBean getMessageBean() {
		return messageBean;
	}

}