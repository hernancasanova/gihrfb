package cl.mtt.rnt.admin.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.bean.controller.AutorizacionMovimientoController;
import cl.mtt.rnt.admin.bean.controller.GrupoController;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.service.AutorizacionManager;
import cl.mtt.rnt.commons.service.ConductorManager;
import cl.mtt.rnt.commons.service.GrupoManager;
import cl.mtt.rnt.commons.service.NotificacionService;
import cl.mtt.rnt.commons.service.PasajeroManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.UsuarioManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.service.impl.MailSenderImpl;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class AutorizacionBean implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	
	@ManagedProperty(value = "#{usuarioManager}")
	private UsuarioManager usuarioManager;
	
	@ManagedProperty(value = "#{grupoManager}")
	private  GrupoManager grupoManager;
	
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;
	
	@ManagedProperty(value = "#{notificacionManager}")
	private  NotificacionService notificacionManager;
	
	@ManagedProperty(value = "#{vehiculoManagerRnt}")
	private  VehiculoManagerRnt vehiculoManagerRnt;
	
	@ManagedProperty(value = "#{mailSenderService}")
	private MailSenderImpl mailSenderService;
	
	@ManagedProperty(value = "#{autorizacionManager}")
	private AutorizacionManager autorizacionManager;
	
	@ManagedProperty(value = "#{reglamentacionManager}")
    private ReglamentacionManager reglamentacionManager;
	
	@ManagedProperty(value = "#{conductorManager}")
    private ConductorManager conductorManager;
    
    
    
    @ManagedProperty(value = "#{pasajeroManager}")
    private PasajeroManager pasajeroManager;
	
	
	private AutorizacionMovimientoController autorizacionMovimientoController;
	private GrupoController grupoController;
	
	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public MailSenderImpl getMailSenderService() {
		return mailSenderService;
	}



	public void setMailSenderService(MailSenderImpl mailSenderService) {
		this.mailSenderService = mailSenderService;
	}



	public AutorizacionManager getAutorizacionManager() {
		return autorizacionManager;
	}



	public void setAutorizacionManager(AutorizacionManager autorizacionManager) {
		this.autorizacionManager = autorizacionManager;
	}



	public VehiculoManagerRnt getVehiculoManagerRnt() {
		return vehiculoManagerRnt;
	}


	public void setVehiculoManagerRnt(VehiculoManagerRnt vehiculoManagerRnt) {
		this.vehiculoManagerRnt = vehiculoManagerRnt;
	}

	public GrupoController getGrupoController() {
		return grupoController;
	}
	
	public void setGrupoController(GrupoController grupoController) {
		this.grupoController = grupoController;
	}


	public AutorizacionMovimientoController getAutorizacionMovimientoController() {
		return autorizacionMovimientoController;
	}

	public void setAutorizacionMovimientoController(
			AutorizacionMovimientoController autorizacionMovimientoController) {
		this.autorizacionMovimientoController = autorizacionMovimientoController;
	}

	public NotificacionService getNotificacionManager() {
		return notificacionManager;
	}

	public void setNotificacionManager(NotificacionService notificacionManager) {
		this.notificacionManager = notificacionManager;
	}

	public UbicacionGeograficaManager getUbicacionGeograficaManager() {
		return ubicacionGeograficaManager;
	}


	public void setUbicacionGeograficaManager(
			UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	
	public UsuarioManager getUsuarioManager() {
		return usuarioManager;
	}

	public void setUsuarioManager(UsuarioManager usuarioManager) {
		this.usuarioManager = usuarioManager;
	}

	
	public GrupoManager getGrupoManager() {
		return grupoManager;
	}

	public void setGrupoManager(GrupoManager grupoManager) {
		this.grupoManager = grupoManager;
	}

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}
	
	


	public String prepareListados(){
		try{
			autorizacionMovimientoController = new AutorizacionMovimientoController(this);
			autorizacionMovimientoController.estimarTablaInicial();
			grupoController = new GrupoController(this);
			grupoController.searchGrupos();
			sessionCacheManager.saveState(this);
			return "success_to_admin_autorizacion";
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}	
		return null;
	}

    /**
     * @return el valor de reglamentacionManager
     */
    public ReglamentacionManager getReglamentacionManager() {
        return reglamentacionManager;
    }

    /**
     * @param setea el parametro reglamentacionManager al campo reglamentacionManager
     */
    public void setReglamentacionManager(ReglamentacionManager reglamentacionManager) {
        this.reglamentacionManager = reglamentacionManager;
    }

    /**
     * @return el valor de pasajeroManager
     */
    public PasajeroManager getPasajeroManager() {
        return pasajeroManager;
    }

    /**
     * @param setea el parametro pasajeroManager al campo pasajeroManager
     */
    public void setPasajeroManager(PasajeroManager pasajeroManager) {
        this.pasajeroManager = pasajeroManager;
    }

    /**
     * @return el valor de conductorManager
     */
    public ConductorManager getConductorManager() {
        return conductorManager;
    }

    /**
     * @param setea el parametro conductorManager al campo conductorManager
     */
    public void setConductorManager(ConductorManager conductorManager) {
        this.conductorManager = conductorManager;
    }
	
	
	
	
	
	
}
