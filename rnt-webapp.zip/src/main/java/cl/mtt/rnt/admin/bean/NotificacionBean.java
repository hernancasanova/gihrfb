package cl.mtt.rnt.admin.bean;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.model.DataModel;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;

import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.CertificadoNotFoundException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.VehiculoServicioRemplazadoException;
import cl.mtt.rnt.commons.model.core.Conductor;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Pasajero;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.model.core.autorizacion.Notificacion;
import cl.mtt.rnt.commons.model.core.autorizacion.UsuarioGrupo;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.UserContext;
import cl.mtt.rnt.commons.service.AutorizacionManager;
import cl.mtt.rnt.commons.service.ConductorManager;
import cl.mtt.rnt.commons.service.GrupoManager;
import cl.mtt.rnt.commons.service.NotificacionService;
import cl.mtt.rnt.commons.service.PasajeroManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.service.impl.MailSenderImpl;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.gui.PagedListDataModel;

@ManagedBean
@ViewScoped
public class NotificacionBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6028414654118292917L;
	
	
	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	
	@ManagedProperty(value = "#{notificacionManager}")
	private  NotificacionService notificacionManager;
	
	@ManagedProperty(value = "#{grupoManager}")
	private  GrupoManager grupoManager;
	
	@ManagedProperty(value = "#{vehiculoManagerRnt}")
	private VehiculoManagerRnt vehiculoManagerRnt;
	
	@ManagedProperty(value = "#{conductorManager}")
	private ConductorManager conductorManager;
	
	@ManagedProperty(value = "#{mailSenderService}")
	private MailSenderImpl mailSenderService;
	
	@ManagedProperty(value = "#{autorizacionManager}")
	private AutorizacionManager autorizacionManager;

	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@ManagedProperty(value = "#{reglamentacionManager}")
	private ReglamentacionManager reglamentacionManager;
	
	
	@ManagedProperty(value = "#{pasajeroManager}")
    private PasajeroManager pasajeroManager;
	
	private PagedListDataModel pagedListDataModelNotificacion;
	private Notificacion notificacion;
	private String observacionRespuesta;
	private long totalListSizeNotificacion;
	private int currentPageNotificacion = 1;
	private Map<String, Boolean> sortersNotificacion;
	private String sortingFieldNotificacion;
	private boolean sortingAscNotificacion;
//	private int page=1;
	private String trsClasses;
	private String folder;


	private int totalListSize;
	private int totalNewListSize;


	private Notificacion notificacionInfo;
	private List<Grupo> gruposDisponibles;
	private ArrayList<Grupo> gruposSeleccionados;
	private boolean enviarMail = false;
	
	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
		estimarTablaInicial();
	}

	public void setConductorManager(ConductorManager conductorManager) {
		this.conductorManager = conductorManager;
	}




	public void setAutorizacionManager(AutorizacionManager autorizacionManager) {
		this.autorizacionManager = autorizacionManager;
	}




	public void setMailSenderService(MailSenderImpl mailSenderService) {
		this.mailSenderService = mailSenderService;
	}



	public void setVehiculoManagerRnt(VehiculoManagerRnt vehiculoManagerRnt) {
		this.vehiculoManagerRnt = vehiculoManagerRnt;
	}



	public String getFolder() {
		return folder;
	}



	public void setFolder(String folder) {
		this.folder = folder;
	}



//	public int getPage() {
//		return page;
//	}
//
//	public void setPage(int page) {
//		this.page = page;
//	}
	
	public Notificacion getNotificacion() {
		return notificacion;
	}

	public void setNotificacion(Notificacion notificacion) {
		this.notificacion = notificacion;
	}

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public NotificacionService getNotificacionManager() {
		return notificacionManager;
	}

	public void setNotificacionManager(NotificacionService notificacionManager) {
		this.notificacionManager = notificacionManager;
	}
	
	
	public int getCurrentPageNotificacion() {
		return currentPageNotificacion;
	}

	public void setCurrentPageNotificacion(int currentPageNotificacion) {
		this.currentPageNotificacion = currentPageNotificacion;
	}

	public long getTotalListSizeNotificacion() {
		return totalListSizeNotificacion;
	}

	public void setTotalListSizeNotificacion(long totalListSizeNotificacion) {
		this.totalListSizeNotificacion = totalListSizeNotificacion;
	}
	
	
	public PagedListDataModel getPagedListDataModelNotificacion() {
		return pagedListDataModelNotificacion;
	}

	public void setPagedListDataModelNotificacion(
			PagedListDataModel pagedListDataModelNotificacion) {
		this.pagedListDataModelNotificacion = pagedListDataModelNotificacion;
	}

	@SuppressWarnings("rawtypes")
	public DataModel getNotificacionPagedDataModel() {
//		if (pagedListDataModelNotificacion== null)
			this.cargarDataModelNotificaciones();
		return this.pagedListDataModelNotificacion;

	}
	
	
	
	public String getObservacionRespuesta() {
		return observacionRespuesta;
	}


	public void setObservacionRespuesta(String observacionRespuesta) {
		this.observacionRespuesta = observacionRespuesta;
	}


	public void resetPage(){
		pagedListDataModelNotificacion=null;
		this.currentPageNotificacion=1;
	}
	
	public void estimarTablaInicial() {
		try {
			setTotalListSizeNotificacion(new Long(notificacionManager.getNotificacionesCount(this.currentSessionBean.getUser(), null)));

		} catch (GeneralDataAccessException e) {
			pagedListDataModelNotificacion = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModelNotificacion = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void cargarDataModelNotificaciones() {
		try {
			totalListSize = new Long(notificacionManager.getNotificacionesCount(this.currentSessionBean.getUser(),null)).intValue();
			setTotalListSizeNotificacion(totalListSize);

			int rows = getCurrentSessionBean().getTablaPaginacion().get(Constants.TABLA_LISTADO_NOTIFICACION).intValue();
			int first = (this.getCurrentPageNotificacion() - 1) * rows;

			// Si sucede esto es que hay menos elementos que páginas
			if ((first / rows) > (Math.ceil(totalListSize / rows))) {
				first = 0;
				setCurrentPageNotificacion(1);
			}

			List<String> order = new ArrayList<String>();
			if (this.sortingFieldNotificacion != null && !this.sortingFieldNotificacion.equals("")) {
				order.add(this.sortingFieldNotificacion + ((this.sortingAscNotificacion) ? "" : " desc"));
			}

			List<Notificacion> data = notificacionManager.getNotificacionesPag(this.currentSessionBean.getUser(), null, first, rows, order);
			setRowClass(data);
			pagedListDataModelNotificacion = new PagedListDataModel(new ArrayList(data), totalListSize, rows);

			// sessionCacheManager.saveState(this);

		} catch (GeneralDataAccessException e) {
			pagedListDataModelNotificacion = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModelNotificacion = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}
	
	public void sortCollectionNotificacion(String currentFieldOrder) {
		if(sortersNotificacion == null){
			sortersNotificacion = new HashMap<String, Boolean>();
		}
		Boolean lastOrderIsAsc = sortersNotificacion.get(currentFieldOrder);
		
		lastOrderIsAsc = lastOrderIsAsc == null || !lastOrderIsAsc.booleanValue();
		
		sortersNotificacion.put(currentFieldOrder, lastOrderIsAsc);
		this.sortingFieldNotificacion = currentFieldOrder;
		this.sortingAscNotificacion = lastOrderIsAsc;
		this.cargarDataModelNotificaciones();		
	}

	public String prepararListarNotificacion(){
		cargarDataModelNotificaciones();
		sessionCacheManager.saveState(this);
		return "go_to_admin_home";
	}
	
	
	public void setRowClass(List<Notificacion> notificaciones) {
		
		String odd = "dataTableOddRow";
		String even = "dataTableEvenRow";		
		String leidaOdd = "dataTableLeidaOddRow"; //background-color: #FFFFCC;
		String leidaEven = "dataTableLeidaEvenRow"; //background-color: #FFFFBB;
		String clases = "";
		int contador = 0;
		for (Notificacion n : notificaciones) {
			if (n.getEstado().equals(Notificacion.ESTADO_LEIDO)) {
				if ((contador % 2) == 0)
					clases += leidaEven + ",";
				else
					clases += leidaOdd + ",";
			}
			else {
				if ((contador % 2) == 0)
					clases += even + ",";
				else
					clases += odd + ",";
			}
			contador++;
		}
		trsClasses=clases;
	}
	
	
  public void setTrsClasses(String trsClasses) {
		this.trsClasses = trsClasses;
	}

	public String getTrsClasses() {
			return trsClasses;
	}
	
	public String viewNotificacion(Notificacion noti){
		try{
			if(noti.getEstado().equals(Notificacion.ESTADO_NO_LEIDO)){
				noti.setEstado(Notificacion.ESTADO_LEIDO);
				noti.setDbAction(GenericModelObject.ACTION_UPDATE);
				notificacionManager.updateNotificacion(noti);
			}
			observacionRespuesta="";
			notificacion = noti;
			sessionCacheManager.saveState(this);
			return "success_ver_notificacion";
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		noti.setEstado(Notificacion.ESTADO_NO_LEIDO);
		noti.setDbAction(GenericModelObject.ACTION_NOACTION);
		return "";
	}
	
	public String volverAdminHome(){
		return "go_to_"+folder+"_home";
	}



	/**
	 * @return el valor de totalListSize
	 */
	public int getTotalListSize() {
		return totalListSize;
	}



	/**
	 * @param setea el parametro totalListSize al campo totalListSize
	 */
	public void setTotalListSize(int totalListSize) {
		this.totalListSize = totalListSize;
	}



	/**
	 * @return el valor de totalNewListSize
	 */
	public int getTotalNewListSize() {
		if (totalNewListSize == 0) {
			try {
				totalNewListSize = new Long(notificacionManager.getNuevasNotificacionesCount(this.currentSessionBean.getUser(), null)).intValue();
			} catch (GeneralDataAccessException e) {
				totalNewListSize = 0;
			}
		}
		return totalNewListSize;
	}



	/**
	 * @param setea el parametro totalNewListSize al campo totalNewListSize
	 */
	public void setTotalNewListSize(int totalNewListSize) {
		this.totalNewListSize = totalNewListSize;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public String prepararNuevaNotificacionInfo() {
		try {
			notificacionInfo = new Notificacion();
			notificacionInfo.setTipo(Notificacion.NOTIFICACION_MENSAJE_INF);
			UserContext userc = currentSessionBean.getUser().getContext();
			
			List<Region> regionesConsulta = new ArrayList<Region>();
			
			if ((currentSessionBean.getUser().getAplicaNacion()!=null)&&(currentSessionBean.getUser().getAplicaNacion().booleanValue())) { 
				regionesConsulta.add(new Region("","",""));
			}
			
			//PARA QUE TRAIGA LOS GRUPOS DE TODAS LAS REGIONES
			regionesConsulta.add(new Region("00","00","00"));
			
			regionesConsulta.addAll(userc.getRegionesDisponibles());
			
			gruposDisponibles = grupoManager.getGruposByRegionesAndCategorias(regionesConsulta, userc.getAllIdsTiposTransportes(), userc.getAllIdsMediosTransporte(), userc.getAllIdsCategoriasTransporte());
			gruposSeleccionados = new ArrayList<Grupo>();
			return "success_to_new_info_notify";
		}
		catch (Exception ex) {
			Logger.getLogger(this.getClass()).error(ex.getMessage(),ex);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_info_notify";
		}
		finally {
			sessionCacheManager.saveState(this);
		}
		
	}


	public String volverDeInfoNoti() {

		sessionCacheManager.saveState(this);
		return "success_back";
	}
	
	
	public String enviarNotificacion() {
		
		try {
			if (gruposSeleccionados.isEmpty()) {
				messageBean.addMessage(Resources.getString("notificaciones.info.nogrupo"), FacesMessage.SEVERITY_ERROR);
				sessionCacheManager.saveState(this);
				return "error_new_info_notify";
			}
			
			for (Grupo gr : gruposSeleccionados) {
				List<UsuarioGrupo> usuariosGrupoByIdGrupo = grupoManager.getUsuariosGrupoByIdGrupo(gr.getId());
				for (UsuarioGrupo ug : usuariosGrupoByIdGrupo) {
					
					Notificacion noti = new Notificacion();
					noti.setAutorizacionMovimiento(null);
					noti.setUsuarioDestino(ug.getUser());
					noti.setDescripcion(this.notificacionInfo.getDescripcion());
					noti.setEstado(Notificacion.ESTADO_NO_LEIDO);
					noti.setTipo(Notificacion.NOTIFICACION_MENSAJE_INF);
					noti.setObservacion(null);
					noti.setTitulo(this.notificacionInfo.getTitulo());
					noti.setUsuarioDestino(ug.getUser());
					notificacionManager.saveNotificacion(noti);
					if (this.enviarMail) {
						try {
							
							String message = noti.getDescripcion();
							message += "\n\n" + "ENVIADO POR " + currentSessionBean.getUser().getNombreCompleto(); 
							String subject = "NOTIFICACION RNT - " +noti.getTitulo();
							notificacionManager.sendEmail(subject, message, ug.getUser().getEmail());
						}
						catch (AddressException e) {
							Logger.getLogger(this.getClass()).error(e.getMessage(),e);
						}
						catch (MessagingException e) {
							Logger.getLogger(this.getClass()).error(e.getMessage(),e);
						} 
						catch (UnsupportedEncodingException e) {
							Logger.getLogger(this.getClass()).error(e.getMessage(),e);
						}
						catch (Exception e) {
							Logger.getLogger(this.getClass()).error(e.getMessage(),e);
						}
					}
				}
			}
			
		} catch (Exception e) {
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			sessionCacheManager.saveState(this);
			return "error_new_info_notify";
		}
		
		sessionCacheManager.saveState(this);
		messageBean.addMessage(Resources.getString("notificaciones.info.sent"), FacesMessage.SEVERITY_INFO);
		return "success_back";
	}

	/**
	 * @return el valor de notificacionInfo
	 */
	public Notificacion getNotificacionInfo() {
		return notificacionInfo;
	}



	/**
	 * @param setea el parametro notificacionInfo al campo notificacionInfo
	 */
	public void setNotificacionInfo(Notificacion notificacionInfo) {
		this.notificacionInfo = notificacionInfo;
	}



	/**
	 * @return el valor de gruposDisponibles
	 */
	public List<Grupo> getGruposDisponibles() {
		return gruposDisponibles;
	}



	/**
	 * @param setea el parametro gruposDisponibles al campo gruposDisponibles
	 */
	public void setGruposDisponibles(List<Grupo> gruposDisponibles) {
		this.gruposDisponibles = gruposDisponibles;
	}



	/**
	 * @return el valor de gruposSeleccionados
	 */
	public ArrayList<Grupo> getGruposSeleccionados() {
		return gruposSeleccionados;
	}



	/**
	 * @param setea el parametro gruposSeleccionados al campo gruposSeleccionados
	 */
	public void setGruposSeleccionados(ArrayList<Grupo> gruposSeleccionados) {
		this.gruposSeleccionados = gruposSeleccionados;
	}



	/**
	 * @param setea el parametro grupoManager al campo grupoManager
	 */
	public void setGrupoManager(GrupoManager grupoManager) {
		this.grupoManager = grupoManager;
	}



	/**
	 * @return el valor de enviarMail
	 */
	public boolean isEnviarMail() {
		return enviarMail;
	}



	/**
	 * @param setea el parametro enviarMail al campo enviarMail
	 */
	public void setEnviarMail(boolean enviarMail) {
		this.enviarMail = enviarMail;
	}
	
	private VehiculoServicio getVehiculoServicio() throws GeneralDataAccessException{
		VehiculoServicio vs = vehiculoManagerRnt.getVehiculoAllData(notificacion.getAutorizacionMovimiento().getIdMovimiento(),null);
		return vs;
	}
	
	private ConductorServicio getConductorServicio() throws GeneralDataAccessException{
		ConductorServicio cs = conductorManager.getConductorServicio(notificacion.getAutorizacionMovimiento().getIdMovimiento());
		return cs;
	}
	
	private ConductorVehiculo getConductorVehiculo() throws GeneralDataAccessException{
		ConductorVehiculo cs = conductorManager.getConductorVehiculo(notificacion.getAutorizacionMovimiento().getIdMovimiento());
		return cs;
	}
	
	
	public String rechazarAutorizacion(){
		try{
			if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL)){
				rechazarIngresoVehiculo();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO)){
				rechazarIngresoConductor();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_SERVICIO)){
				rechazarIngresoConductor();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO)){
				rechazarIngresoConductorVehiculo();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_VEHICULO)){
				rechazarIngresoConductorVehiculo();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION)){
                rechazarReversionMovimientoVehiculo();
            }
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		pagedListDataModelNotificacion=null;
		return volverAdminHome();
	}
	
	

    public String aceptarAutorizacion(){
		try{
			if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL)){
				aceptarIngresoVehiculo();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO)){
				aceptarIngresoConductor();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_SERVICIO)){
				aceptarIngresoConductor();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO)){
				aceptarIngresoConductorVehiculo();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_VEHICULO)){
				aceptarIngresoConductorVehiculo();
			}else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION)){
                aceptarRevertirMovimientoVehiculo();
            }
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		pagedListDataModelNotificacion=null;
		return volverAdminHome();
	}
	
	
	
	
	  private void setDBactionVehiculoServRev(VehiculoServicio rev, VehiculoServicio actual) throws GeneralDataAccessException{
          rev.setDbAction(GenericModelObject.ACTION_UPDATE);
          //CONDUCTOR
          if(rev.getConductoresVehiculo() != null){
              for(ConductorVehiculo rv : rev.getConductoresVehiculo()){
                   ConductorVehiculo cv = conductorManager.getConductorVehiculo(rv.getId());
                   if(cv != null)
                       rv.setDbAction(GenericModelObject.ACTION_UPDATE);
                   else
                       rv.setDbAction(GenericModelObject.ACTION_SAVE);
               }
          }
          
           if(actual.getConductoresVehiculo() != null){
               for(ConductorVehiculo act : actual.getConductoresVehiculo()){
                   boolean encontrado = false;
                   
                   if(rev.getConductoresVehiculo() != null){
                       for(ConductorVehiculo rv : rev.getConductoresVehiculo()){
                              if(rv.equals(act)){
                                  encontrado = true;
                                  break;
                              }
                           }
                   }
                  
                   if(!encontrado){
                       act.setDbAction(GenericModelObject.ACTION_DELETE);
                       rev.getConductoresVehiculo().add(act);
                   }
               } 
           }
           
           
           //PASAJEROS
           if(rev.getPasajeros() != null){
               for(Pasajero p : rev.getPasajeros()){
                   Pasajero pasajero = pasajeroManager.getPasajeroById(p.getId());
                   
                   if(pasajero != null)
                       p.setDbAction(GenericModelObject.ACTION_UPDATE);
                   else
                       p.setDbAction(GenericModelObject.ACTION_SAVE);
               }
           }
          
           
           if(actual.getPasajeros() != null && Hibernate.isInitialized(actual.getPasajeros())){
               for(Pasajero p : this.getVehiculoServicio().getPasajeros()){
                   boolean encontrado = false;
                   
                   if(rev.getPasajeros() != null){
                       for(Pasajero rvp : rev.getPasajeros()){
                              if(rvp.equals(p)){
                                  encontrado = true;
                                  break;
                              }
                           } 
                   }
                   
                   if(!encontrado){
                       p.setDbAction(GenericModelObject.ACTION_DELETE);
                       rev.getPasajeros().add(p);
                   }
               }
           }
          
           
   }
	
	
	
	private String aceptarRevertirMovimientoVehiculo() {
        
	    try{           
	        AutorizacionMovimiento amov = notificacion.getAutorizacionMovimiento();
	        VehiculoServicio vsActual = vehiculoManagerRnt.getVehiculoAllData(amov.getIdMovimiento());
	        if (amov.getIdMovimientoAux()==null) {
	            vehiculoManagerRnt.eliminarVehiculoServicio(vsActual.getId());
	        }
	        else {
                VehiculoServicio vsRev = vehiculoManagerRnt.getVehiculoServicioHistoricoByRevision(amov.getIdMovimiento(), amov.getIdMovimientoAux());
 			    Integer estadoActual = vsActual.getEstado();
                setDBactionVehiculoServRev(vsRev,vsActual);
                vsRev.setObservacion(Resources.getString("vehiculo.revertir.vs.bservacion")+" "+amov.getIdMovimientoAux());
                vehiculoManagerRnt.revertVehiculoServicio(vsRev, amov.getIdMovimientoAux());
                if (vsRev.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE) && !estadoActual.equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
                    vehiculoManagerRnt.recuperarCertificadoAnterior(vsRev.getId());
                }
                else {
                    vehiculoManagerRnt.eliminarCertificadoAnterior(vsRev.getId());
                }
	        }
            
            String[] parametros =  new String[4];
            parametros[0] = vsActual.getVehiculo().getPpu();
            parametros[1] = vsActual.getServicio().getIdentServicio().toString();
            if (vsActual.getServicio().getRegion()==null) {
                parametros[2] = ubicacionGeograficaManager.getRegionById(vsActual.getServicio().getCodigoRegion()).getNombre();
            }
            else {
                parametros[2] = vsActual.getServicio().getRegion().getNombre();
            }
           
            Notificacion notificacionRespuesta= new Notificacion();
            notificacionRespuesta.setObservacion(observacionRespuesta);
            notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
            notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.revertir.aceptada", parametros));
            notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
            notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
            notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
            notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
            notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
            notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
            autorizacionManager.aceptarAutorizacionMovimiento(vsActual, notificacion, notificacionRespuesta);
            enviarMail(notificacionRespuesta);
            
            
            messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
            return volverAdminHome();
        }catch(VehiculoServicioRemplazadoException e){
            messageBean.addMessage(e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }catch (GeneralDataAccessException e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
            messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
         }catch (Exception e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
            messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
        }
        return null;
        
    }
	
	
	private String rechazarReversionMovimientoVehiculo() {
	    try{           
            AutorizacionMovimiento amov = notificacion.getAutorizacionMovimiento();
            if (amov.getIdMovimientoAux()==null) {
                return rechazarReversionEliminarVehiculoServicio();
            }
            VehiculoServicio vsActual = vehiculoManagerRnt.getVehiculoAllData(amov.getIdMovimiento());
            Long revisionRechazo = vehiculoManagerRnt.getRevisionRechazoReversion(amov.getIdMovimiento(),amov.getIdMovimientoAux());
            VehiculoServicio vsRev = vehiculoManagerRnt.getVehiculoServicioHistoricoByRevision(amov.getIdMovimiento(), revisionRechazo);
            setDBactionVehiculoServRev(vsRev,vsActual);
            vsRev.setObservacion("");
            vehiculoManagerRnt.revertVehiculoServicio(vsRev, revisionRechazo);
//            if (vsRev.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
//                try {
//                    vehiculoManagerRnt.recuperarCertificadoAnterior(vsRev.getId());
//                }
//                catch (CertificadoNotFoundException ce){
//                    Logger.getLogger(this.getClass()).info("El vehiculo id: " + vsActual.getId() + " . No posee certificados");
//                }
//            }
//            else {
//                vehiculoManagerRnt.eliminarCertificadoAnterior(vsRev.getId());
//            }
            
            String[] parametros =  new String[4];
            parametros[0] = vsActual.getVehiculo().getPpu();
            parametros[1] = vsActual.getServicio().getIdentServicio().toString();
            if (vsActual.getServicio().getRegion()==null) {
                parametros[2] = ubicacionGeograficaManager.getRegionById(vsActual.getServicio().getCodigoRegion()).getNombre();
            }
            else {
                parametros[2] = vsActual.getServicio().getRegion().getNombre();
            }
            Notificacion notificacionRespuesta= new Notificacion();
            notificacionRespuesta.setObservacion(observacionRespuesta);
            notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
            notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.revertir.rechazada", parametros));
            notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
            notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
            notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
            notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
            notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
            notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
            autorizacionManager.rechazarAutorizacionMovimiento(vsActual, notificacion, notificacionRespuesta);
            enviarMail(notificacionRespuesta);
            
            
            messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
            return volverAdminHome();
        }catch(VehiculoServicioRemplazadoException e){
            messageBean.addMessage(e.getMessage(), FacesMessage.SEVERITY_ERROR);
        }catch (GeneralDataAccessException e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
            messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
         }catch (Exception e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
            messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
        }
        return null;
        
    }
	
	

    private String rechazarReversionEliminarVehiculoServicio() throws GeneralDataAccessException, VehiculoServicioRemplazadoException {
        AutorizacionMovimiento amov = notificacion.getAutorizacionMovimiento();
        VehiculoServicio vsActual = vehiculoManagerRnt.getVehiculoAllData(amov.getIdMovimiento());
        Long revisionRechazo = vehiculoManagerRnt.getRevisionRechazoReversion(amov.getIdMovimiento(),-1L);
        VehiculoServicio vsRev = vehiculoManagerRnt.getVehiculoServicioHistoricoByRevision(amov.getIdMovimiento(), revisionRechazo);
        setDBactionVehiculoServRev(vsRev,vsActual);
        vsRev.setObservacion("");
        vehiculoManagerRnt.revertVehiculoServicio(vsRev, revisionRechazo);
//        if (vsRev.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
//            try {
//                vehiculoManagerRnt.recuperarCertificadoAnterior(vsRev.getId());
//            }
//            catch (CertificadoNotFoundException ce){
//                Logger.getLogger(this.getClass()).info("El vehiculo id: " + vsActual.getId() + " . No posee certificados");
//            }
//        }
//        else {
//            vehiculoManagerRnt.eliminarCertificadoAnterior(vsRev.getId());
//        }
        
        String[] parametros =  new String[4];
        parametros[0] = vsActual.getVehiculo().getPpu();
        parametros[1] = vsActual.getServicio().getIdentServicio().toString();
        if (vsActual.getServicio().getRegion()==null) {
            parametros[2] = ubicacionGeograficaManager.getRegionById(vsActual.getServicio().getCodigoRegion()).getNombre();
        }
        else {
            parametros[2] = vsActual.getServicio().getRegion().getNombre();
        }
        Notificacion notificacionRespuesta= new Notificacion();
        notificacionRespuesta.setObservacion(observacionRespuesta);
        notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
        notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.revertir.rechazada", parametros));
        notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
        notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
        notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
        notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
        notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
        notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
        autorizacionManager.rechazarAutorizacionMovimiento(vsActual, notificacion, notificacionRespuesta);
        enviarMail(notificacionRespuesta);
        
        
        messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
        return volverAdminHome();
    }

    private void aceptarIngresoVehiculo() throws GeneralDataAccessException{
		VehiculoServicio vs = getVehiculoServicio();
		vs.setEstado(VehiculoServicio.ESTADO_VIGENTE);
		Notificacion notificacionRespuesta= new Notificacion();
		notificacionRespuesta.setObservacion(observacionRespuesta);
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		String[] parametros =  new String[4];
		parametros[0] = vs.getVehiculo().getPpu();
		parametros[1] = vs.getServicio().getIdentServicio().toString();
		parametros[2] = vs.getServicio().getRegion().getNombre();
		String nombreReglamentacion ="";
		if(vs.getReglamentacion() != null)
			nombreReglamentacion=vs.getReglamentacion().getNombre();
		else
			nombreReglamentacion=vs.getServicio().getReglamentacion().getNombre();
		parametros[3] = nombreReglamentacion;
		notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.aceptada", parametros));
		notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
		notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
		notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
		notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
		autorizacionManager.aceptarAutorizacionMovimiento(vs, notificacion, notificacionRespuesta);
		enviarMail(notificacionRespuesta);
	}
	
	private void rechazarIngresoVehiculo() throws GeneralDataAccessException{
		VehiculoServicio vs = getVehiculoServicio();
		Notificacion notificacionRespuesta= new Notificacion();
		notificacionRespuesta.setObservacion(observacionRespuesta);
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		String[] parametros =  new String[4];
		parametros[0] = vs.getVehiculo().getPpu();
		parametros[1] = vs.getServicio().getIdentServicio().toString();
		parametros[2] = vs.getServicio().getRegion().getNombre();
		String nombreReglamentacion ="";
		if(vs.getReglamentacion() != null)
			nombreReglamentacion=vs.getReglamentacion().getNombre();
		else
			nombreReglamentacion=vs.getServicio().getReglamentacion().getNombre();
		parametros[3] = nombreReglamentacion;
		notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.rechazada", parametros));
		notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
		notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
		notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
		notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		autorizacionManager.rechazarAutorizacionMovimiento(vs, notificacion, notificacionRespuesta);
		enviarMail(notificacionRespuesta);
	}
	
	
	private void aceptarIngresoConductor() throws GeneralDataAccessException{
		ConductorServicio cs = getConductorServicio();
		cs.setEstado(ConductorServicio.ESTADO_VIGENTE);
		Notificacion notificacionRespuesta= new Notificacion();
		notificacionRespuesta.setObservacion(observacionRespuesta);
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		String[] parametros =  new String[5];
		parametros[0] = cs.getConductor().getPersona().getRut();
		parametros[1] = cs.getServicio().getIdentServicio().toString();
		parametros[2] = ubicacionGeograficaManager.getRegionById(cs.getServicio().getCodigoRegion()).getNombre();
		String nombreReglamentacion ="";
		if(!Hibernate.isInitialized(cs.getServicio().getReglamentacion())){
			cs.getServicio().setReglamentacion(reglamentacionManager.getReglamentacionByServicio(cs.getServicio().getId()));
		}
		nombreReglamentacion=cs.getServicio().getReglamentacion().getNombre();
		parametros[3] = nombreReglamentacion;
		parametros[4] = (cs.getConductor().getTipoConductor().equals(Conductor.TIPO_CONDUCTOR))?"Conductor":"Auxiliar";
		if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO))
			notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.servicio.aceptada", parametros));
		else
			notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.servicio.aceptada.modificacion", parametros));
		notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
		notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
		notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
		notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
		autorizacionManager.aceptarAutorizacionMovimiento(cs, notificacion, notificacionRespuesta);
		enviarMail(notificacionRespuesta);
	}
	
	private void rechazarIngresoConductor() throws GeneralDataAccessException{
		ConductorServicio cs = getConductorServicio();
		Notificacion notificacionRespuesta= new Notificacion();
		notificacionRespuesta.setObservacion(observacionRespuesta);
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		String[] parametros =  new String[5];
		parametros[0] = cs.getConductor().getPersona().getRut();
		parametros[1] = cs.getServicio().getIdentServicio().toString();
		parametros[2] = ubicacionGeograficaManager.getRegionById(cs.getServicio().getCodigoRegion()).getNombre();
		String nombreReglamentacion ="";
		if(!Hibernate.isInitialized(cs.getServicio().getReglamentacion())){
			cs.getServicio().setReglamentacion(reglamentacionManager.getReglamentacionByServicio(cs.getServicio().getId()));
		}
		nombreReglamentacion=cs.getServicio().getReglamentacion().getNombre();
		parametros[3] = nombreReglamentacion;
		parametros[4] = (cs.getConductor().getTipoConductor().equals(Conductor.TIPO_CONDUCTOR))?"Conductor":"Auxiliar";
		if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO))
			notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.servicio.rechazada", parametros));
		else
			notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.servicio.rechazada.modificacion", parametros));
		notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
		notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
		notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
		notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		autorizacionManager.rechazarAutorizacionMovimiento(cs, notificacion, notificacionRespuesta);
		enviarMail(notificacionRespuesta);
	}
	
	
	private void aceptarIngresoConductorVehiculo() throws GeneralDataAccessException{
		ConductorVehiculo cv = getConductorVehiculo();
		cv.setEstado(ConductorServicio.ESTADO_VIGENTE);
		Notificacion notificacionRespuesta= new Notificacion();
		notificacionRespuesta.setObservacion(observacionRespuesta);
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		String[] parametros =  new String[6];
		parametros[0] = cv.getConductorServicio().getConductor().getPersona().getRut();
		parametros[1] = cv.getVehiculoServicio().getVehiculo().getPpu();
		parametros[2] = cv.getConductorServicio().getServicio().getIdentServicio().toString();
		parametros[3] = ubicacionGeograficaManager.getRegionById(cv.getConductorServicio().getServicio().getCodigoRegion()).getNombre();
		String nombreReglamentacion ="";
		if(!Hibernate.isInitialized(cv.getVehiculoServicio().getServicio().getReglamentacion())){
			cv.getVehiculoServicio().getServicio().setReglamentacion(reglamentacionManager.getReglamentacionByServicio(cv.getVehiculoServicio().getServicio().getId()));
		}
		nombreReglamentacion=cv.getConductorServicio().getServicio().getReglamentacion().getNombre();
		parametros[4] = nombreReglamentacion;
		parametros[5] = (cv.getConductorServicio().getConductor().getTipoConductor().equals(Conductor.TIPO_CONDUCTOR))?"Conductor":"Auxiliar";
		if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO))
			notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.vehiculo.aceptada", parametros));
		else
			notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.vehiculo.aceptada.modificacion", parametros));
		notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
		notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
		notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
		notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
		autorizacionManager.aceptarAutorizacionMovimiento(cv, notificacion, notificacionRespuesta);
		enviarMail(notificacionRespuesta);
	}
	
	private void rechazarIngresoConductorVehiculo() throws GeneralDataAccessException{
		ConductorVehiculo cv = getConductorVehiculo();
		Notificacion notificacionRespuesta= new Notificacion();
		notificacionRespuesta.setObservacion(observacionRespuesta);
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		String[] parametros =  new String[6];
		parametros[0] = cv.getConductorServicio().getConductor().getPersona().getRut();
		parametros[1] = cv.getVehiculoServicio().getVehiculo().getPpu();
		parametros[2] = cv.getConductorServicio().getServicio().getIdentServicio().toString();
		parametros[3] = ubicacionGeograficaManager.getRegionById(cv.getConductorServicio().getServicio().getCodigoRegion()).getNombre();
		if(!Hibernate.isInitialized(cv.getVehiculoServicio().getServicio().getReglamentacion())){
			cv.getVehiculoServicio().getServicio().setReglamentacion(reglamentacionManager.getReglamentacionByServicio(cv.getVehiculoServicio().getServicio().getId()));
		}
		String nombreReglamentacion=cv.getConductorServicio().getServicio().getReglamentacion().getNombre();
		parametros[4] = nombreReglamentacion;
		parametros[5] = (cv.getConductorServicio().getConductor().getTipoConductor().equals(Conductor.TIPO_CONDUCTOR))?"Conductor":"Auxiliar";
		if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO))
			notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.vehiculo.rechazada", parametros));
		else
			notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.vehiculo.rechazada.modificacion", parametros));
		notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
		notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
		notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
		notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
		notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
		autorizacionManager.rechazarAutorizacionMovimiento(cv, notificacion, notificacionRespuesta);
		enviarMail(notificacionRespuesta);
	}
	
	private void enviarMail(Notificacion notificacionRespuesta){
		try {
			String message = notificacionRespuesta.getDescripcion();
			if(notificacionRespuesta.getObservacion() != null)
				message += "\n" + notificacionRespuesta.getObservacion();
			message += "\n\n" + "ENVIADO POR " + currentSessionBean.getUser().getNombreCompleto(); 
			String subject = "NOTIFICACION RNT - " +notificacionRespuesta.getTitulo();
			notificacionManager.sendEmail(subject, message, notificacionRespuesta.getUsuarioDestino().getEmail());
		}
		catch (AddressException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(),e);
		}
		catch (MessagingException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(),e);
		} 
		catch (UnsupportedEncodingException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(),e);
		}
		catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(),e);
		}
	}


	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}


	public void setReglamentacionManager(ReglamentacionManager reglamentacionManager) {
		this.reglamentacionManager = reglamentacionManager;
	}

    /**
     * @param setea el parametro pasajeroManager al campo pasajeroManager
     */
    public void setPasajeroManager(PasajeroManager pasajeroManager) {
        this.pasajeroManager = pasajeroManager;
    }

	
	
}
