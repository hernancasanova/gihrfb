package cl.mtt.rnt.admin.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Documentacion;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoZona;
import cl.mtt.rnt.commons.model.core.Tramite;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.service.DocumentacionManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.service.TramiteManager;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class TramiteBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5821141570313763342L;
	
	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	
	@ManagedProperty(value = "#{tramiteManager}")
	private TramiteManager tramiteManager;
	
	@ManagedProperty(value = "#{tipoServicioManager}")
	private TipoServicioManager tipoServicioManager;
	
	@ManagedProperty(value = "#{documentacionManager}")
	private DocumentacionManager documentacionManager;
	
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;
	
	@ManagedProperty(value = "#{zonaManager}")
	private ZonaManager zonaManager;
	
	private List<Tramite> tramites;
	private Tramite tramite;
	private int page=1; 
	private List<TipoServicio> tiposServicio;
	private List<Documentacion> documentacion;
	private Map<String, Object> filters = new HashMap<String, Object>();
	private MarcoGeograficoSource marcoGeograficoFilterSource;
	
	private String idRegionFiltro;
	private String aplicaAFiltro;
	private String idZonaFiltro; 
	private TipoZona tipoZonaFilter;
	
	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}
	
	public String prepareListadoTramite(){
		try {			
			tramites=tramiteManager.getAllTramites(this.currentSessionBean.getUser());
			tramite=null;
			if(tramites != null)
				Collections.sort(tramites);
			resetPage();
			marcoGeograficoFilterSource = new MarcoGeograficoSource();
			marcoGeograficoFilterSource.updateData(ubicacionGeograficaManager, zonaManager, new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL,
					MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser());
			this.sessionCacheManager.saveState(this);
		}
		catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "success_go_to_tramites";
	}
	
	public String prepararNuevoTramite(){
		try{
			tramite = new Tramite();
			tramite.setMarcoGeografico(new MarcoGeografico(MarcoGeograficoSource.AMBITO_REGIONAL));
			MarcoGeograficoSource source = new MarcoGeograficoSource();
			source.updateData(ubicacionGeograficaManager, zonaManager, new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser());
			tramite.getMarcoGeografico().setSource(source);
			tramite.getMarcoGeografico().setTipoZonaSelected(tramite.getMarcoGeografico().getSource().getTiposZona().get(0));
			tramite.setDocumentacion(new ArrayList<Documentacion>());
			tramite.setTiposServicio(new ArrayList<TipoServicio>());
			sessionCacheManager.saveState(this);
			return "success_go_to_add_tramite";
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "";
	}
	
	public String guardarNuevoTramite(){
		try{
			tramiteManager.saveTramite(this.tramite);
			if(tramites == null)
				tramites = new ArrayList<Tramite>();
			tramites.add(tramite);
			Collections.sort(tramites);
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			tramite = null;
			resetPage();
			sessionCacheManager.saveState(this);
		}
		return "success_return_from_add_tramite";
	}
	
	public String prepareEditarTramite(Tramite t){
		try{
			if(t.getMarcoGeografico() == null){
				t.setMarcoGeografico(new MarcoGeografico(MarcoGeograficoSource.AMBITO_REGIONAL));
			}
			if (!validateMarcosGeograficosUsuario(t)) {
				this.sessionCacheManager.saveState(this);
				return "";
			}
			tramite = t;
			MarcoGeograficoSource source = new MarcoGeograficoSource();
			source.updateData(ubicacionGeograficaManager, zonaManager, new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser());
			tramite.getMarcoGeografico().setSource(source);
			tramite.getMarcoGeografico().setTipoZonaSelected(tramite.getMarcoGeografico().getSource().getTiposZona().get(0));
			if(tramite.getDocumentacion() == null)
				tramite.setDocumentacion(new ArrayList<Documentacion>());
			if(tramite.getTiposServicio() == null)
				tramite.setTiposServicio(new ArrayList<TipoServicio>());
			sessionCacheManager.saveState(this);
			return "success_go_to_edit_tramite";
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "";
	}
	
	
	private boolean validateMarcosGeograficosUsuario(Tramite t) {
		User user = currentSessionBean.getUser();
		if (t.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL)) {
			if ((user.getAplicaNacion() == null) || (!user.getAplicaNacion().booleanValue())) {
				messageBean.addMessage(Resources.getString("tramite.error.nacional.nopermitido"), FacesMessage.SEVERITY_ERROR);
				return false;
			}
		} else {
			if (t.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_REGIONAL)) {
				List<Region> regiones = t.getMarcoGeografico().getRegiones();
				for (Region region : regiones) {
					if (!user.getContext().getRegionesDisponibles().contains(region)) {
						messageBean.addMessage(Resources.getString("tramite.error.regiones.nopermitidas"), FacesMessage.SEVERITY_ERROR);
						return false;
					}
				}
			} else {
				if (t.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL)) {
					List<Zona> zonas = t.getMarcoGeografico().getZonas();
					for (Zona zona : zonas) {
						if (!user.getContext().getRegionesDisponibles().contains(zona.getRegionResponsable())) {
							messageBean.addMessage(Resources.getString("tramite.error.zonas.nopermitidas"), FacesMessage.SEVERITY_ERROR);
							return false;
						}
					}
				}
			}
		}
		return true;
	}
	
	public String modificarTramite(){
		try{
			tramiteManager.updateTramite(this.tramite);
			Collections.sort(tramites);
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			tramite = null;
			resetPage();
			sessionCacheManager.saveState(this);
		}
		return "success_return_from_edit_tramite";
	}
	
	public void eliminarTramite(){
		try{
			if (!validateMarcosGeograficosUsuario(tramite)) {
				return;
			}
			tramiteManager.deleteTramite(this.tramite);
			tramites.remove(this.tramite);
			messageBean.addMessage(Resources.getString("messages.removeSuccess"), FacesMessage.SEVERITY_INFO);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			tramite = null;
		}
	}
	
	public void resetPage(){
		page=1;
	}
	
	private void updateFiltros() {

		filters.remove("marcoGeografico.aplicableA");
		filters.remove("marcoGeografico.marcosGeograficoslocalizables.idLocalizable");
		if (this.aplicaAFiltro != null) {
			if (this.aplicaAFiltro.equals(MarcoGeograficoSource.AMBITO_NACIONAL)){
				filters.put("marcoGeografico.aplicableA", MarcoGeograficoSource.AMBITO_NACIONAL);
			} else if(this.aplicaAFiltro.equals(MarcoGeograficoSource.AMBITO_REGIONAL)){
				filters.put("marcoGeografico.aplicableA", MarcoGeograficoSource.AMBITO_REGIONAL);
				if (this.idRegionFiltro != null) {
					filters.put("marcoGeografico.marcosGeograficoslocalizables.idLocalizable", this.idRegionFiltro);
				}
			} else if(this.aplicaAFiltro.equals(MarcoGeograficoSource.AMBITO_ZONAL)){
				filters.put("marcoGeografico.aplicableA", MarcoGeograficoSource.AMBITO_ZONAL);
				if (this.idZonaFiltro != null) {
					filters.put("marcoGeografico.marcosGeograficoslocalizables.idLocalizable", this.idZonaFiltro);
				}else{
					List<Zona> zonas = marcoGeograficoFilterSource.getZonasFiltradasPorRegion(idRegionFiltro, tipoZonaFilter);
					List<String> ids = new ArrayList<String>(zonas.size());
					for (Zona z : zonas) {
						ids.add(z.getIdentifier());
					}
					filters.put("marcoGeografico.marcosGeograficoslocalizables.idLocalizable", ids);
				}
			}	
		}

		if (filters.get(".nombre") == null || filters.get(".nombre").toString().trim().isEmpty())
			filters.remove(".nombre");
		
		if (filters.get("documentacion.id") == null)
			filters.remove("documentacion.id");
		
		if (filters.get("tiposServicio.id") == null)
			filters.remove("tiposServicio.id");

	}
	
	public void filtrar(){
		try{
			updateFiltros();
			tramites = tramiteManager.getTramitesFiltrados(this.getFilters());
			if(tramites != null)
				Collections.sort(tramites);
			resetPage();
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		
	}
	
	public void limpiarFiltro(){
		try{
			this.filters = new HashMap<String, Object>();
			this.idRegionFiltro = null;
			this.aplicaAFiltro = null;
			this.idZonaFiltro = null;
			tramites=tramiteManager.getAllTramites(this.currentSessionBean.getUser());
			if(tramites != null)
				Collections.sort(tramites);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			resetPage();
		}
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public void setTramiteManager(TramiteManager tramiteManager) {
		this.tramiteManager = tramiteManager;
	}

	public void setTipoServicioManager(TipoServicioManager tipoServicioManager) {
		this.tipoServicioManager = tipoServicioManager;
	}
	
	public void setDocumentacionManager(DocumentacionManager documentacionManager) {
		this.documentacionManager = documentacionManager;
	}

	public void setUbicacionGeograficaManager(
			UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public void setZonaManager(ZonaManager zonaManager) {
		this.zonaManager = zonaManager;
	}

	public List<Tramite> getTramites() {
		return tramites;
	}

	public void setTramites(List<Tramite> tramites) {
		this.tramites = tramites;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public Tramite getTramite() {
		return tramite;
	}

	public void setTramite(Tramite tramite) {
		this.tramite = tramite;
	}
	
	public List<TipoServicio> getTiposServicio() {
		try{
			if(tiposServicio == null || tiposServicio.isEmpty())
				tiposServicio = tipoServicioManager.getAllTiposServicioByUsuario(currentSessionBean.getUser());
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	public List<Documentacion> getDocumentacion() {
		try{
			if(documentacion == null || documentacion.isEmpty())
				documentacion = documentacionManager.getDocumentaciones();
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return documentacion;
	}

	public void setDocumentacion(List<Documentacion> documentacion) {
		this.documentacion = documentacion;
	}
	
	public Map<String, Object> getFilters() {
		return filters;
	}

	public void setFilters(Map<String, Object> filters) {
		this.filters = filters;
	}
	
	public MarcoGeograficoSource getMarcoGeograficoFilterSource() {
		return marcoGeograficoFilterSource;
	}

	public void setMarcoGeograficoFilterSource(MarcoGeograficoSource marcoGeograficoFilterSource) {
		this.marcoGeograficoFilterSource = marcoGeograficoFilterSource;
	}

	public String getAplicaAFiltro() {
		return aplicaAFiltro;
	}

	public void setAplicaAFiltro(String aplicaAFiltro) {
		this.aplicaAFiltro = aplicaAFiltro;
	}

	public String getIdRegionFiltro() {
		return idRegionFiltro;
	}

	public void setIdRegionFiltro(String idRegionFiltro) {
		this.idRegionFiltro = idRegionFiltro;
	}

	public String getIdZonaFiltro() {
		return idZonaFiltro;
	}

	public void setIdZonaFiltro(String idZonaFiltro) {
		this.idZonaFiltro = idZonaFiltro;
	}

	public TipoZona getTipoZonaFilter() {
		return tipoZonaFilter;
	}

	public void setTipoZonaFilter(TipoZona tipoZonaFilter) {
		this.tipoZonaFilter = tipoZonaFilter;
	}
	
	
}
