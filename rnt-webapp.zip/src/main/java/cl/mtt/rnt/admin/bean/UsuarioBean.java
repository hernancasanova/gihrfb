package cl.mtt.rnt.admin.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.comparator.UserComparator;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.userrol.UserContext;
import cl.mtt.rnt.commons.service.CategoriaTransporteManager;
import cl.mtt.rnt.commons.service.MedioTransporteManager;
import cl.mtt.rnt.commons.service.TipoTransporteManager;
import cl.mtt.rnt.commons.service.UsuarioManager;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.StringUtil;

@ManagedBean
@ViewScoped
public class UsuarioBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8100536736512518603L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{usuarioManager}")
	private UsuarioManager usuarioManager;

	@ManagedProperty(value = "#{tipoTransporteManager}")
	private TipoTransporteManager tipoTransporteManager;
	@ManagedProperty(value = "#{medioTransporteManager}")
	private MedioTransporteManager medioTransporteManager;
	@ManagedProperty(value = "#{categoriaTransporteManager}")
	private CategoriaTransporteManager categoriaTransporteManager;

	private List<User> usuarios;
	private User usuarioSeleccionado;
	private String usuarioADesactivar;
	private List<CategoriaTransporte> categoriasSeleccionables;
	private List<MedioTransporte> mediosTransporteSeleccionables;
	private List<TipoTransporte> tiposTransporteSeleccionables;

	private Boolean estadoAnterior;

	private String nombreUsuarioFilter;
	private String nombreCompletoFilter;
	
	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareListadoUsuarios() {

		try {
			updateDataTable();
			sessionCacheManager.saveState(this);
			return RedirectConstants.TO_ADMIN_USER_LIST;
		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return RedirectConstants.NO_REDIRECT;
	}

	public String reloadListadoUsuarios() {

		try {
			updateDataTable();
			sessionCacheManager.saveState(this);
			return RedirectConstants.TO_ADMIN_USER_LIST_NO_REDIRECT;
		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return RedirectConstants.NO_REDIRECT;
	}

	/**
	 * @throws GeneralDataAccessException
	 */
	private void updateDataTable() throws GeneralDataAccessException {
		this.usuarios = usuarioManager.getUsuarios(nombreUsuarioFilter,nombreCompletoFilter);
		Collections.sort(this.usuarios, new UserComparator());
	}

	public String prepareNuevoUsuario() {
		try {
			this.usuarioSeleccionado = new User();
			usuarioSeleccionado.setContext(new UserContext());
			usuarioSeleccionado.getContext().setCategorias(new ArrayList<CategoriaTransporte>());
			usuarioSeleccionado.getContext().setMediosTransporte(new ArrayList<MedioTransporte>());
			usuarioSeleccionado.getContext().setTiposTransporte(new ArrayList<TipoTransporte>());
			usuarioSeleccionado.getContext().setRoles(new ArrayList<String>());
			usuarioSeleccionado.setAplicaNacion(Boolean.FALSE);
			this.categoriasSeleccionables = getCategoriasSeleccionables();
			this.mediosTransporteSeleccionables = getMediosTransporteSeleccionables();
			this.tiposTransporteSeleccionables = getTiposTransporteSeleccionables();
			sessionCacheManager.saveState(this);
			return RedirectConstants.USERLIST_TO_NEW_USER;
		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return RedirectConstants.NO_REDIRECT;
	}

	public String agregarUsuario() {

		sessionCacheManager.saveState(this);
		
		// usuarioSeleccionado.setRoles(new ArrayList<String>());
		usuarioSeleccionado.setPassword("");
		usuarioSeleccionado.setFechaEstado(new Timestamp(new Date().getTime()));
		for (User user : this.getUsuarios()) {
			String desc = StringUtil.makeDescriptor(user.getNombreUsuario());
			String descSel = StringUtil.makeDescriptor(usuarioSeleccionado.getNombreUsuario());
			if (desc.equals(descSel)) {
				messageBean.addMessage(Resources.getString("usuario.error.existente"), FacesMessage.SEVERITY_ERROR);
				return RedirectConstants.NO_REDIRECT;
			}
		}
		try {
			
			usuarioManager.saveUsuario(usuarioSeleccionado);
			messageBean.addMessage(Resources.getString("usuario.consulta.agregar.exito"), FacesMessage.SEVERITY_INFO);
			return reloadListadoUsuarios();
		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

		return RedirectConstants.NO_REDIRECT;
	}

	public String prepareModificarUsuario(User usuario) {
		try {
			this.usuarioSeleccionado = usuarioManager.getUsuarioById(usuario.getId());
			if (usuarioSeleccionado.getContext() == null) {
				usuarioSeleccionado.setContext(new UserContext());
			}
			this.estadoAnterior = usuario.getEstado();
			this.categoriasSeleccionables = getCategoriasSeleccionables();
			this.mediosTransporteSeleccionables = getMediosTransporteSeleccionables();
			this.tiposTransporteSeleccionables = getTiposTransporteSeleccionables();
			sessionCacheManager.saveState(this);
			return RedirectConstants.USERLIST_TO_EDIT_USER;
		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return RedirectConstants.NO_REDIRECT;
	}

	public String modificarUsuario() {

		sessionCacheManager.saveState(this);
		if (!estadoAnterior.equals(usuarioSeleccionado.getEstado())) {
			usuarioSeleccionado.setFechaEstado(new Timestamp(new Date().getTime()));
		}
		try {
			if (usuarioSeleccionado.getContext().getId() != null) {
				usuarioManager.updateUsuarioContext(usuarioSeleccionado.getContext());
			} else {
				usuarioManager.saveUsuarioContext(usuarioSeleccionado.getContext());
			}
			usuarioManager.updateUsuario(usuarioSeleccionado);
			messageBean.addMessage(Resources.getString("usuario.consulta.modificar.exito"), FacesMessage.SEVERITY_INFO);
			return reloadListadoUsuarios();
		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

		return RedirectConstants.NO_REDIRECT;
	}

	public String desactivarUsuario() {
		try {
			for (User adesact : this.getUsuarios()) {
				if (adesact.getId().toString().equals(usuarioADesactivar)) {
					if (!adesact.getEstado().booleanValue()) {
						messageBean.addMessage(Resources.getString("usuario.eliminar.yaeliminado"), FacesMessage.SEVERITY_ERROR);
						return RedirectConstants.NO_REDIRECT;
					} else {
						adesact.setEstado(Boolean.FALSE);
						adesact.setFechaEstado(new Timestamp(new Date().getTime()));
						usuarioManager.updateUsuario(adesact);
						messageBean.addMessage(Resources.getString("usuario.eliminar.exito"), FacesMessage.SEVERITY_INFO);
						return prepareListadoUsuarios();
					}
				}
			}

		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

		return RedirectConstants.NO_REDIRECT;
	}

	public String volverListado() {
		sessionCacheManager.saveState(this);
		return RedirectConstants.TO_ADMIN_USER_LIST;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	/**
	 * @return el valor de usuarios
	 */
	public List<User> getUsuarios() {
		return usuarios;
	}

	/**
	 * @param setea
	 *            el parametro usuarios al campo usuarios
	 */
	public void setUsuarios(List<User> usuarios) {
		this.usuarios = usuarios;
	}

	/**
	 * @return el valor de usuarioSeleccionado
	 */
	public User getUsuarioSeleccionado() {
		return usuarioSeleccionado;
	}

	/**
	 * @param setea
	 *            el parametro usuarioSeleccionado al campo usuarioSeleccionado
	 */
	public void setUsuarioSeleccionado(User usuarioSeleccionado) {
		this.usuarioSeleccionado = usuarioSeleccionado;
	}

	/**
	 * @param setea
	 *            el parametro sessionCacheManager al campo sessionCacheManager
	 */
	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	/**
	 * @param setea
	 *            el parametro usuarioManager al campo usuarioManager
	 */
	public void setUsuarioManager(UsuarioManager usuarioManager) {
		this.usuarioManager = usuarioManager;
	}

	/**
	 * @return el valor de categoriasSeleccionables
	 */
	public List<CategoriaTransporte> getCategoriasSeleccionables() {
		if (categoriasSeleccionables == null) {
			try {
				this.categoriasSeleccionables = categoriaTransporteManager.getAllCategoriasTrasporte();
			} catch (Exception e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			}
		}
		return categoriasSeleccionables;
	}

	/**
	 * @param setea
	 *            el parametro categoriasSeleccionables al campo
	 *            categoriasSeleccionables
	 */
	public void setCategoriasSeleccionables(List<CategoriaTransporte> categoriasSeleccionables) {
		this.categoriasSeleccionables = categoriasSeleccionables;
	}

	/**
	 * @return el valor de estadoAnterior
	 */
	public Boolean getEstadoAnterior() {
		return estadoAnterior;
	}

	/**
	 * @param setea
	 *            el parametro estadoAnterior al campo estadoAnterior
	 */
	public void setEstadoAnterior(Boolean estadoAnterior) {
		this.estadoAnterior = estadoAnterior;
	}

	/**
	 * @return el valor de usuarioADesactivar
	 */
	public String getUsuarioADesactivar() {
		return usuarioADesactivar;
	}

	/**
	 * @param setea
	 *            el parametro usuarioADesactivar al campo usuarioADesactivar
	 */
	public void setUsuarioADesactivar(String usuarioADesactivar) {
		this.usuarioADesactivar = usuarioADesactivar;
	}

	/**
	 * @param setea
	 *            el parametro tipoTransporteManager al campo
	 *            tipoTransporteManager
	 */
	public void setTipoTransporteManager(TipoTransporteManager tipoTransporteManager) {
		this.tipoTransporteManager = tipoTransporteManager;
	}

	/**
	 * @param setea
	 *            el parametro medioTransporteManager al campo
	 *            medioTransporteManager
	 */
	public void setMedioTransporteManager(MedioTransporteManager medioTransporteManager) {
		this.medioTransporteManager = medioTransporteManager;
	}

	/**
	 * @return el valor de serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return el valor de mediosTransporteSeleccionables
	 */
	public List<MedioTransporte> getMediosTransporteSeleccionables() throws GeneralDataAccessException {
		if (mediosTransporteSeleccionables == null) {
			this.mediosTransporteSeleccionables = medioTransporteManager.getAllMediosTrasporte();
		}
		return mediosTransporteSeleccionables;
	}

	/**
	 * @return el valor de tiposTransporteSeleccionables
	 * @throws GeneralDataAccessException
	 */
	public List<TipoTransporte> getTiposTransporteSeleccionables() throws GeneralDataAccessException {
		if (tiposTransporteSeleccionables == null) {
			this.tiposTransporteSeleccionables = tipoTransporteManager.getAllTiposTransporte();
		}
		return tiposTransporteSeleccionables;
	}

	/**
	 * @param setea
	 *            el parametro tiposTransporteSeleccionables al campo
	 *            tiposTransporteSeleccionables
	 */
	public void setTiposTransporteSeleccionables(List<TipoTransporte> tiposTransporteSeleccionables) {
		this.tiposTransporteSeleccionables = tiposTransporteSeleccionables;
	}

	/**
	 * @param setea
	 *            el parametro categoriaTransporteManager al campo
	 *            categoriaTransporteManager
	 */
	public void setCategoriaTransporteManager(CategoriaTransporteManager categoriaTransporteManager) {
		this.categoriaTransporteManager = categoriaTransporteManager;
	}

	/**
	 * @return el valor de currentSessionBean
	 */
	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public String getNombreUsuarioFilter() {
		return nombreUsuarioFilter;
	}

	public void setNombreUsuarioFilter(String nombreUsuarioFilter) {
		this.nombreUsuarioFilter = nombreUsuarioFilter;
	}

	public String getNombreCompletoFilter() {
		return nombreCompletoFilter;
	}

	public void setNombreCompletoFilter(String nombreCompletoFilter) {
		this.nombreCompletoFilter = nombreCompletoFilter;
	}
	
	public void filtrar(){
		try {
			updateDataTable();
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public void limpiarFiltro(){
		try {
			nombreCompletoFilter=null;
			nombreUsuarioFilter=null;
			updateDataTable();
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

}