package cl.mtt.rnt.admin.bean.controller;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.model.DataModel;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;

import cl.mtt.rnt.admin.bean.AutorizacionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.exception.CertificadoNotFoundException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.VehiculoServicioRemplazadoException;
import cl.mtt.rnt.commons.model.core.Conductor;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Pasajero;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.autorizacion.Notificacion;
import cl.mtt.rnt.commons.service.AutorizacionManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.gui.PagedListDataModel;

public class AutorizacionMovimientoController implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6337130375669509169L;
	private AutorizacionBean autorizacionBean;
	private PagedListDataModel pagedListDataModelAutorizacion;
	private long totalListSizeAutorizacion;
	private int currentPageAutorizacion = 1;
	private Map<String, Boolean> sortersAutorizacion;
	private String sortingFieldAutorizacion;
	private boolean sortingAscAutorizacion;
	private int page=1;
	private Notificacion notificacion;
	private String observacionRespuesta;
	
	public  AutorizacionMovimientoController (AutorizacionBean bean){
		autorizacionBean = bean;
	}
	
	
	public String getObservacionRespuesta() {
		return observacionRespuesta;
	}



	public void setObservacionRespuesta(String observacionRespuesta) {
		this.observacionRespuesta = observacionRespuesta;
	}



	public Notificacion getNotificacion() {
		return notificacion;
	}


	public void setNotificacion(Notificacion notificacion) {
		this.notificacion = notificacion;
	}


	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public AutorizacionBean getAutorizacionBean() {
		return autorizacionBean;
	}

	public void setAutorizacionBean(AutorizacionBean autorizacionBean) {
		this.autorizacionBean = autorizacionBean;
	}
	
	
	public int getCurrentPageAutorizacion() {
		return currentPageAutorizacion;
	}

	public void setCurrentPageAutorizacion(int currentPageAutorizacion) {
		this.currentPageAutorizacion = currentPageAutorizacion;
	}
	
	
	public PagedListDataModel getPagedListDataModelAutorizacion() {
		return pagedListDataModelAutorizacion;
	}

	public long getTotalListSizeAutorizacion() {
		return totalListSizeAutorizacion;
	}

	public void setTotalListSizeAutorizacion(long totalListSizeAutorizacion) {
		this.totalListSizeAutorizacion = totalListSizeAutorizacion;
	}

	public void setPagedListDataModelAutorizacion(
			PagedListDataModel pagedListDataModelAutorizacion) {
		this.pagedListDataModelAutorizacion = pagedListDataModelAutorizacion;
	}
	
	
	@SuppressWarnings("rawtypes")
	public DataModel getAutorizacionPagedDataModel() {
		if (pagedListDataModelAutorizacion== null)
			this.cargarDataModelAutorizaciones();
		return this.pagedListDataModelAutorizacion;

	}
	
	public void resetPage(){
		pagedListDataModelAutorizacion=null;
		this.page=1;
	}
	
	public void estimarTablaInicial() {
		try {
			setTotalListSizeAutorizacion(new Long(this.getAutorizacionBean().getNotificacionManager().getNotificacionesCount(this.getAutorizacionBean().getCurrentSessionBean().getUser(), Notificacion.NOTIFICACION_AUTORIZACION)));
		} catch (GeneralDataAccessException e) {
			pagedListDataModelAutorizacion = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModelAutorizacion = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
    private void cargarDataModelAutorizaciones() {
		try {
			int totalListSize = new Long(this.getAutorizacionBean().getNotificacionManager().getNotificacionesCount(this.autorizacionBean.getCurrentSessionBean().getUser(), Notificacion.NOTIFICACION_AUTORIZACION)).intValue();
			setTotalListSizeAutorizacion(totalListSize);

			int rows = this.autorizacionBean.getCurrentSessionBean().getTablaPaginacion().get(Constants.TABLA_LISTADO_AUTORIZACION).intValue();
			int first = (this.getCurrentPageAutorizacion() - 1) * rows;

			// Si sucede esto es que hay menos elementos que páginas
			if ((first / rows) > (Math.ceil(totalListSize / rows))) {
				first = 0;
				setCurrentPageAutorizacion(1);
			}

			List<String> order = new ArrayList<String>();
			if (this.sortingFieldAutorizacion != null && !this.sortingFieldAutorizacion.equals("")) {
				order.add(this.sortingFieldAutorizacion + ((this.sortingAscAutorizacion) ? "" : " desc"));
			}

			List<Notificacion> data = this.autorizacionBean.getNotificacionManager().getNotificacionesPag(this.autorizacionBean.getCurrentSessionBean().getUser(), Notificacion.NOTIFICACION_AUTORIZACION, first, rows, order);

			pagedListDataModelAutorizacion = new PagedListDataModel(new ArrayList(data), totalListSize, rows);

			// sessionCacheManager.saveState(this);

		} catch (GeneralDataAccessException e) {
			pagedListDataModelAutorizacion = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModelAutorizacion = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}
	
	public void sortCollectionAutorizacion(String currentFieldOrder) {
		if(sortersAutorizacion == null){
			sortersAutorizacion = new HashMap<String, Boolean>();
		}
		Boolean lastOrderIsAsc = sortersAutorizacion.get(currentFieldOrder);
		
		lastOrderIsAsc = lastOrderIsAsc == null || !lastOrderIsAsc.booleanValue();
		
		sortersAutorizacion.put(currentFieldOrder, lastOrderIsAsc);
		this.sortingFieldAutorizacion = currentFieldOrder;
		this.sortingAscAutorizacion = lastOrderIsAsc;
		this.cargarDataModelAutorizaciones();		
	}
	
	public void updateDataModels(){
		this.cargarDataModelAutorizaciones();
	}
	
	public String viewNotificacion(Notificacion noti){
		try{
			if(noti.getEstado().equals(Notificacion.ESTADO_NO_LEIDO)){
				noti.setEstado(Notificacion.ESTADO_LEIDO);
				noti.setDbAction(GenericModelObject.ACTION_UPDATE);
				this.autorizacionBean.getNotificacionManager().updateNotificacion(noti);
			}
			observacionRespuesta="";
			notificacion = noti;
			this.autorizacionBean.getSessionCacheManager().saveState(this.autorizacionBean);
			return "success_ver_noti";
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		noti.setEstado(Notificacion.ESTADO_NO_LEIDO);
		noti.setDbAction(GenericModelObject.ACTION_NOACTION);
		return "";
	}
	
	public String volverAdmin(){
		resetPage();
		this.autorizacionBean.getSessionCacheManager().saveState(this.autorizacionBean);
		return "success_to_admin_autorizacion";
	}
	
	public void limpiar() {

		try {
			this.currentPageAutorizacion=1;
			cargarDataModelAutorizaciones();;
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
	
	private VehiculoServicio getVehiculoServicio() throws GeneralDataAccessException{
		VehiculoServicio vs = this.autorizacionBean.getVehiculoManagerRnt().getVehiculoAllData(notificacion.getAutorizacionMovimiento().getIdMovimiento(),null);
		return vs;
	}
		
	
    private ConductorServicio getConductorServicio() throws GeneralDataAccessException{
        ConductorServicio cs = autorizacionBean.getConductorManager().getConductorServicio(notificacion.getAutorizacionMovimiento().getIdMovimiento());
        return cs;
    }
    
    private ConductorVehiculo getConductorVehiculo() throws GeneralDataAccessException{
        ConductorVehiculo cs = autorizacionBean.getConductorManager().getConductorVehiculo(notificacion.getAutorizacionMovimiento().getIdMovimiento());
        return cs;
    }
    
    
    
    
    public String rechazarAutorizacion(){
        try{
            if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL)){
                rechazarIngresoVehiculo();
            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO)){
                rechazarIngresoConductor();
            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_SERVICIO)){
                rechazarIngresoConductor();
            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO)){
                rechazarIngresoConductorVehiculo();
            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_VEHICULO)){
                rechazarIngresoConductorVehiculo();
            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION)){
                rechazarReversionMovimientoVehiculo();
            }
        }catch (GeneralDataAccessException e) {
            Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
            this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
        } catch (Exception e) {
            Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
            this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
        }
        pagedListDataModelAutorizacion=null;
        return volverAdmin();
    }
    
	/*
	public String rechazarAutorizacion(){
		try{
			if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL)){
				VehiculoServicio vs = getVehiculoServicio();
				Notificacion notificacionRespuesta= new Notificacion();
				notificacionRespuesta.setObservacion(observacionRespuesta);
				notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
				String[] parametros =  new String[4];
				parametros[0] = vs.getVehiculo().getPpu();
				parametros[1] = vs.getServicio().getIdentServicio().toString();
				parametros[2] = vs.getServicio().getRegion().getNombre();
				String nombreReglamentacion ="";
				if(vs.getReglamentacion() != null)
					nombreReglamentacion=vs.getReglamentacion().getNombre();
				else
					nombreReglamentacion=vs.getServicio().getReglamentacion().getNombre();
				parametros[3] = nombreReglamentacion;
				notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.rechazada", parametros));
				notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
				notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
				notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
				notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
				notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
				notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_CANCELADO);
				this.autorizacionBean.getAutorizacionManager().rechazarAutorizacionMovimiento(vs, notificacion, notificacionRespuesta);
				try {
					String message = notificacionRespuesta.getDescripcion();
					if(notificacionRespuesta.getObservacion() != null)
						message += "\n" + notificacionRespuesta.getObservacion();
					message += "\n\n" + "ENVIADO POR " + this.autorizacionBean.getCurrentSessionBean().getUser().getNombreCompleto(); 
					String subject = "NOTIFICACION RNT - " +notificacionRespuesta.getTitulo();
					this.autorizacionBean.getMailSenderService().sendEmail(subject, message, notificacionRespuesta.getUsuarioDestino().getEmail());
					
				}
				catch (AddressException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
				catch (MessagingException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				} 
				catch (UnsupportedEncodingException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
				catch (Exception e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
			}
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		pagedListDataModelAutorizacion=null;
		return volverAdmin();
	}*/
	
	
	 public String aceptarAutorizacion(){
	        try{
	            if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL)){
	                aceptarIngresoVehiculo();
	            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO)){
	                aceptarIngresoConductor();
	            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_SERVICIO)){
	                aceptarIngresoConductor();
	            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO)){
	                aceptarIngresoConductorVehiculo();
	            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_VEHICULO)){
	                aceptarIngresoConductorVehiculo();
	            }else if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION)){
	                aceptarRevertirMovimientoVehiculo();
	            }
	        }catch (GeneralDataAccessException e) {
	            Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
	            this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
	        } catch (Exception e) {
	            Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
	            this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
	        }
	        pagedListDataModelAutorizacion=null;
	        return volverAdmin();
	    }
	
	 
	 private void setDBactionVehiculoServRev(VehiculoServicio rev, VehiculoServicio actual) throws GeneralDataAccessException{
         rev.setDbAction(GenericModelObject.ACTION_UPDATE);
         //CONDUCTOR
         if(rev.getConductoresVehiculo() != null){
             for(ConductorVehiculo rv : rev.getConductoresVehiculo()){
                  ConductorVehiculo cv = autorizacionBean.getConductorManager().getConductorVehiculo(rv.getId());
                  if(cv != null)
                      rv.setDbAction(GenericModelObject.ACTION_UPDATE);
                  else
                      rv.setDbAction(GenericModelObject.ACTION_SAVE);
              }
         }
         
          if(actual.getConductoresVehiculo() != null){
              for(ConductorVehiculo act : actual.getConductoresVehiculo()){
                  boolean encontrado = false;
                  
                  if(rev.getConductoresVehiculo() != null){
                      for(ConductorVehiculo rv : rev.getConductoresVehiculo()){
                             if(rv.equals(act)){
                                 encontrado = true;
                                 break;
                             }
                          }
                  }
                 
                  if(!encontrado){
                      act.setDbAction(GenericModelObject.ACTION_DELETE);
                      rev.getConductoresVehiculo().add(act);
                  }
              } 
          }
          
          
          //PASAJEROS
          if(rev.getPasajeros() != null){
              for(Pasajero p : rev.getPasajeros()){
                  Pasajero pasajero = autorizacionBean.getPasajeroManager().getPasajeroById(p.getId());
                  
                  if(pasajero != null)
                      p.setDbAction(GenericModelObject.ACTION_UPDATE);
                  else
                      p.setDbAction(GenericModelObject.ACTION_SAVE);
              }
          }
         
          
          if(actual.getPasajeros() != null && Hibernate.isInitialized(actual.getPasajeros())){
              for(Pasajero p : this.getVehiculoServicio().getPasajeros()){
                  boolean encontrado = false;
                  
                  if(rev.getPasajeros() != null){
                      for(Pasajero rvp : rev.getPasajeros()){
                             if(rvp.equals(p)){
                                 encontrado = true;
                                 break;
                             }
                          } 
                  }
                  
                  if(!encontrado){
                      p.setDbAction(GenericModelObject.ACTION_DELETE);
                      rev.getPasajeros().add(p);
                  }
              }
          }
         
          
  }
   
   
   
   private String aceptarRevertirMovimientoVehiculo() {
       MessageBean messageBean = autorizacionBean.getMessageBean();
       VehiculoManagerRnt vehiculoManagerRnt = autorizacionBean.getVehiculoManagerRnt();
       UbicacionGeograficaManager ubicacionGeograficaManager = autorizacionBean.getUbicacionGeograficaManager();
       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
    try{           
           
           
           AutorizacionMovimiento amov = notificacion.getAutorizacionMovimiento();
           VehiculoServicio vsActual = autorizacionBean.getVehiculoManagerRnt().getVehiculoAllData(amov.getIdMovimiento());
           if (amov.getIdMovimientoAux()==null) {
               vehiculoManagerRnt.eliminarVehiculoServicio(vsActual.getId());
           }
           else {
               VehiculoServicio vsRev = vehiculoManagerRnt.getVehiculoServicioHistoricoByRevision(amov.getIdMovimiento(), amov.getIdMovimientoAux());
			   Integer estadoActual = vsActual.getEstado();
               setDBactionVehiculoServRev(vsRev,vsActual);
               vsRev.setObservacion(Resources.getString("vehiculo.revertir.vs.bservacion")+" "+amov.getIdMovimientoAux());
               vehiculoManagerRnt.revertVehiculoServicio(vsRev, amov.getIdMovimientoAux());
               if (vsRev.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE) && !estadoActual.equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
                   vehiculoManagerRnt.recuperarCertificadoAnterior(vsRev.getId());
               }
               else {
                   vehiculoManagerRnt.eliminarCertificadoAnterior(vsRev.getId());
               }
           }
           
           String[] parametros =  new String[4];
           parametros[0] = vsActual.getVehiculo().getPpu();
           parametros[1] = vsActual.getServicio().getIdentServicio().toString();
           if (vsActual.getServicio().getRegion()==null) {
               parametros[2] = ubicacionGeograficaManager.getRegionById(vsActual.getServicio().getCodigoRegion()).getNombre();
           }
           else {
               parametros[2] = vsActual.getServicio().getRegion().getNombre();
           }
          
           Notificacion notificacionRespuesta= new Notificacion();
           notificacionRespuesta.setObservacion(observacionRespuesta);
           notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.revertir.aceptada", parametros));
           notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
           notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
           notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
           notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
           notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
           notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
           autorizacionManager.aceptarAutorizacionMovimiento(vsActual, notificacion, notificacionRespuesta);
           enviarMail(notificacionRespuesta);
           
           
           messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
           return volverAdmin();
       }catch(VehiculoServicioRemplazadoException e){
           messageBean.addMessage(e.getMessage(), FacesMessage.SEVERITY_ERROR);
       }catch (GeneralDataAccessException e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(), e);
           messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
        }catch (Exception e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(), e);
           messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
       }
       return null;
       
   }
   
   
   private String rechazarReversionMovimientoVehiculo() {
       MessageBean messageBean = autorizacionBean.getMessageBean();
       VehiculoManagerRnt vehiculoManagerRnt = autorizacionBean.getVehiculoManagerRnt();
       UbicacionGeograficaManager ubicacionGeograficaManager = autorizacionBean.getUbicacionGeograficaManager();
       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
       try{           
           AutorizacionMovimiento amov = notificacion.getAutorizacionMovimiento();
           if (amov.getIdMovimientoAux()==null) {
               return rechazarReversionEliminarVehiculoServicio();
           }
           VehiculoServicio vsActual = vehiculoManagerRnt.getVehiculoAllData(amov.getIdMovimiento());
           Long revisionRechazo = vehiculoManagerRnt.getRevisionRechazoReversion(amov.getIdMovimiento(),amov.getIdMovimientoAux());
           VehiculoServicio vsRev = vehiculoManagerRnt.getVehiculoServicioHistoricoByRevision(amov.getIdMovimiento(), revisionRechazo);
           setDBactionVehiculoServRev(vsRev,vsActual);
           vsRev.setObservacion("");
           vehiculoManagerRnt.revertVehiculoServicio(vsRev, revisionRechazo);
           
//           if (vsRev.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
//               try {
//                   vehiculoManagerRnt.recuperarCertificadoAnterior(vsRev.getId());
//               }
//               catch (CertificadoNotFoundException ce){
//                   Logger.getLogger(this.getClass()).info("El vehiculo id: " + vsActual.getId() + " . No posee certificados");
//               }
//           }
//           else {
//               vehiculoManagerRnt.eliminarCertificadoAnterior(vsRev.getId());
//           }
           
           String[] parametros =  new String[4];
           parametros[0] = vsActual.getVehiculo().getPpu();
           parametros[1] = vsActual.getServicio().getIdentServicio().toString();
           if (vsActual.getServicio().getRegion()==null) {
               parametros[2] = ubicacionGeograficaManager.getRegionById(vsActual.getServicio().getCodigoRegion()).getNombre();
           }
           else {
               parametros[2] = vsActual.getServicio().getRegion().getNombre();
           }
           Notificacion notificacionRespuesta= new Notificacion();
           notificacionRespuesta.setObservacion(observacionRespuesta);
           notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.revertir.rechazada", parametros));
           notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
           notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
           notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
           notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
           notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
           notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
           autorizacionManager.rechazarAutorizacionMovimiento(vsActual, notificacion, notificacionRespuesta);
           enviarMail(notificacionRespuesta);
           
           
           messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
           return volverAdmin();
       }catch(VehiculoServicioRemplazadoException e){
           messageBean.addMessage(e.getMessage(), FacesMessage.SEVERITY_ERROR);
       }catch (GeneralDataAccessException e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(), e);
           messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
        }catch (Exception e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(), e);
           messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
       }
       return null;
       
   }
   
   

   private String rechazarReversionEliminarVehiculoServicio() throws GeneralDataAccessException, VehiculoServicioRemplazadoException {
       MessageBean messageBean = autorizacionBean.getMessageBean();
       VehiculoManagerRnt vehiculoManagerRnt = autorizacionBean.getVehiculoManagerRnt();
       UbicacionGeograficaManager ubicacionGeograficaManager = autorizacionBean.getUbicacionGeograficaManager();
       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
       
       AutorizacionMovimiento amov = notificacion.getAutorizacionMovimiento();
       VehiculoServicio vsActual = vehiculoManagerRnt.getVehiculoAllData(amov.getIdMovimiento());
       Long revisionRechazo = vehiculoManagerRnt.getRevisionRechazoReversion(amov.getIdMovimiento(),-1L);
       VehiculoServicio vsRev = vehiculoManagerRnt.getVehiculoServicioHistoricoByRevision(amov.getIdMovimiento(), revisionRechazo);
       setDBactionVehiculoServRev(vsRev,vsActual);
       vsRev.setObservacion("");
       vehiculoManagerRnt.revertVehiculoServicio(vsRev, revisionRechazo);

//       if (vsRev.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
//           try {
//               vehiculoManagerRnt.recuperarCertificadoAnterior(vsRev.getId());
//           }
//           catch (CertificadoNotFoundException ce){
//               Logger.getLogger(this.getClass()).info("El vehiculo id: " + vsActual.getId() + " . No posee certificados");
//           }
//       }
//       else {
//           vehiculoManagerRnt.eliminarCertificadoAnterior(vsRev.getId());
//       }
       
       String[] parametros =  new String[4];
       parametros[0] = vsActual.getVehiculo().getPpu();
       parametros[1] = vsActual.getServicio().getIdentServicio().toString();
       if (vsActual.getServicio().getRegion()==null) {
           parametros[2] = ubicacionGeograficaManager.getRegionById(vsActual.getServicio().getCodigoRegion()).getNombre();
       }
       else {
           parametros[2] = vsActual.getServicio().getRegion().getNombre();
       }
       Notificacion notificacionRespuesta= new Notificacion();
       notificacionRespuesta.setObservacion(observacionRespuesta);
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.revertir.rechazada", parametros));
       notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
       notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
       notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
       notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
       autorizacionManager.rechazarAutorizacionMovimiento(vsActual, notificacion, notificacionRespuesta);
       enviarMail(notificacionRespuesta);
       
       
       messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
       return volverAdmin();
   }

   private void aceptarIngresoVehiculo() throws GeneralDataAccessException{

       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
       
       VehiculoServicio vs = getVehiculoServicio();
       vs.setEstado(VehiculoServicio.ESTADO_VIGENTE);
       Notificacion notificacionRespuesta= new Notificacion();
       notificacionRespuesta.setObservacion(observacionRespuesta);
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       String[] parametros =  new String[4];
       parametros[0] = vs.getVehiculo().getPpu();
       parametros[1] = vs.getServicio().getIdentServicio().toString();
       parametros[2] = vs.getServicio().getRegion().getNombre();
       String nombreReglamentacion ="";
       if(vs.getReglamentacion() != null)
           nombreReglamentacion=vs.getReglamentacion().getNombre();
       else
           nombreReglamentacion=vs.getServicio().getReglamentacion().getNombre();
       parametros[3] = nombreReglamentacion;
       notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.aceptada", parametros));
       notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
       notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
       notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
       notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
       autorizacionManager.aceptarAutorizacionMovimiento(vs, notificacion, notificacionRespuesta);
       enviarMail(notificacionRespuesta);
   }
   
   private void rechazarIngresoVehiculo() throws GeneralDataAccessException{
       
       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
       
       
       VehiculoServicio vs = getVehiculoServicio();
       Notificacion notificacionRespuesta= new Notificacion();
       notificacionRespuesta.setObservacion(observacionRespuesta);
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       String[] parametros =  new String[4];
       parametros[0] = vs.getVehiculo().getPpu();
       parametros[1] = vs.getServicio().getIdentServicio().toString();
       parametros[2] = vs.getServicio().getRegion().getNombre();
       String nombreReglamentacion ="";
       if(vs.getReglamentacion() != null)
           nombreReglamentacion=vs.getReglamentacion().getNombre();
       else
           nombreReglamentacion=vs.getServicio().getReglamentacion().getNombre();
       parametros[3] = nombreReglamentacion;
       notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.rechazada", parametros));
       notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
       notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
       notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
       notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       autorizacionManager.rechazarAutorizacionMovimiento(vs, notificacion, notificacionRespuesta);
       enviarMail(notificacionRespuesta);
   }
   
   
   private void aceptarIngresoConductor() throws GeneralDataAccessException{
     
       UbicacionGeograficaManager ubicacionGeograficaManager = autorizacionBean.getUbicacionGeograficaManager();
       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
       
       ConductorServicio cs = getConductorServicio();
       cs.setEstado(ConductorServicio.ESTADO_VIGENTE);
       Notificacion notificacionRespuesta= new Notificacion();
       notificacionRespuesta.setObservacion(observacionRespuesta);
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       String[] parametros =  new String[5];
       parametros[0] = cs.getConductor().getPersona().getRut();
       parametros[1] = cs.getServicio().getIdentServicio().toString();
       parametros[2] = ubicacionGeograficaManager.getRegionById(cs.getServicio().getCodigoRegion()).getNombre();
       String nombreReglamentacion ="";
       if(!Hibernate.isInitialized(cs.getServicio().getReglamentacion())){
           cs.getServicio().setReglamentacion(autorizacionBean.getReglamentacionManager().getReglamentacionByServicio(cs.getServicio().getId()));
       }
       nombreReglamentacion=cs.getServicio().getReglamentacion().getNombre();
       parametros[3] = nombreReglamentacion;
       parametros[4] = (cs.getConductor().getTipoConductor().equals(Conductor.TIPO_CONDUCTOR))?"Conductor":"Auxiliar";
       if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO))
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.servicio.aceptada", parametros));
       else
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.servicio.aceptada.modificacion", parametros));
       notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
       notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
       notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
       notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
       autorizacionManager.aceptarAutorizacionMovimiento(cs, notificacion, notificacionRespuesta);
       enviarMail(notificacionRespuesta);
   }
   
   private void rechazarIngresoConductor() throws GeneralDataAccessException{
       
       
       UbicacionGeograficaManager ubicacionGeograficaManager = autorizacionBean.getUbicacionGeograficaManager();
       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
       autorizacionBean.getReglamentacionManager();
       
       ConductorServicio cs = getConductorServicio();
       Notificacion notificacionRespuesta= new Notificacion();
       notificacionRespuesta.setObservacion(observacionRespuesta);
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       String[] parametros =  new String[5];
       parametros[0] = cs.getConductor().getPersona().getRut();
       parametros[1] = cs.getServicio().getIdentServicio().toString();
       parametros[2] = ubicacionGeograficaManager.getRegionById(cs.getServicio().getCodigoRegion()).getNombre();
       String nombreReglamentacion ="";
       if(!Hibernate.isInitialized(cs.getServicio().getReglamentacion())){
           cs.getServicio().setReglamentacion(autorizacionBean.getReglamentacionManager().getReglamentacionByServicio(cs.getServicio().getId()));
       }
       nombreReglamentacion=cs.getServicio().getReglamentacion().getNombre();
       parametros[3] = nombreReglamentacion;
       parametros[4] = (cs.getConductor().getTipoConductor().equals(Conductor.TIPO_CONDUCTOR))?"Conductor":"Auxiliar";
       if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO))
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.servicio.rechazada", parametros));
       else
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.servicio.rechazada.modificacion", parametros));
       notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
       notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
       notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
       notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       autorizacionManager.rechazarAutorizacionMovimiento(cs, notificacion, notificacionRespuesta);
       enviarMail(notificacionRespuesta);
   }
   
   
   private void aceptarIngresoConductorVehiculo() throws GeneralDataAccessException{
       
      
       UbicacionGeograficaManager ubicacionGeograficaManager = autorizacionBean.getUbicacionGeograficaManager();
       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
       ReglamentacionManager reglamentacionManager = autorizacionBean.getReglamentacionManager();
       
       ConductorVehiculo cv = getConductorVehiculo();
       cv.setEstado(ConductorServicio.ESTADO_VIGENTE);
       Notificacion notificacionRespuesta= new Notificacion();
       notificacionRespuesta.setObservacion(observacionRespuesta);
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       String[] parametros =  new String[6];
       parametros[0] = cv.getConductorServicio().getConductor().getPersona().getRut();
       parametros[1] = cv.getVehiculoServicio().getVehiculo().getPpu();
       parametros[2] = cv.getConductorServicio().getServicio().getIdentServicio().toString();
       parametros[3] = ubicacionGeograficaManager.getRegionById(cv.getConductorServicio().getServicio().getCodigoRegion()).getNombre();
       String nombreReglamentacion ="";
       if(!Hibernate.isInitialized(cv.getVehiculoServicio().getServicio().getReglamentacion())){
           cv.getVehiculoServicio().getServicio().setReglamentacion(reglamentacionManager.getReglamentacionByServicio(cv.getVehiculoServicio().getServicio().getId()));
       }
       nombreReglamentacion=cv.getConductorServicio().getServicio().getReglamentacion().getNombre();
       parametros[4] = nombreReglamentacion;
       parametros[5] = (cv.getConductorServicio().getConductor().getTipoConductor().equals(Conductor.TIPO_CONDUCTOR))?"Conductor":"Auxiliar";
       if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO))
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.vehiculo.aceptada", parametros));
       else
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.vehiculo.aceptada.modificacion", parametros));
       notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
       notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
       notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
       notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
       autorizacionManager.aceptarAutorizacionMovimiento(cv, notificacion, notificacionRespuesta);
       enviarMail(notificacionRespuesta);
   }
   
   private void rechazarIngresoConductorVehiculo() throws GeneralDataAccessException{
     
       UbicacionGeograficaManager ubicacionGeograficaManager = autorizacionBean.getUbicacionGeograficaManager();
       AutorizacionManager autorizacionManager = autorizacionBean.getAutorizacionManager();
       ReglamentacionManager reglamentacionManager = autorizacionBean.getReglamentacionManager();
       
       
       ConductorVehiculo cv = getConductorVehiculo();
       Notificacion notificacionRespuesta= new Notificacion();
       notificacionRespuesta.setObservacion(observacionRespuesta);
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       String[] parametros =  new String[6];
       parametros[0] = cv.getConductorServicio().getConductor().getPersona().getRut();
       parametros[1] = cv.getVehiculoServicio().getVehiculo().getPpu();
       parametros[2] = cv.getConductorServicio().getServicio().getIdentServicio().toString();
       parametros[3] = ubicacionGeograficaManager.getRegionById(cv.getConductorServicio().getServicio().getCodigoRegion()).getNombre();
       if(!Hibernate.isInitialized(cv.getVehiculoServicio().getServicio().getReglamentacion())){
           cv.getVehiculoServicio().getServicio().setReglamentacion(reglamentacionManager.getReglamentacionByServicio(cv.getVehiculoServicio().getServicio().getId()));
       }
       String nombreReglamentacion=cv.getConductorServicio().getServicio().getReglamentacion().getNombre();
       parametros[4] = nombreReglamentacion;
       parametros[5] = (cv.getConductorServicio().getConductor().getTipoConductor().equals(Conductor.TIPO_CONDUCTOR))?"Conductor":"Auxiliar";
       if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO))
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.vehiculo.rechazada", parametros));
       else
           notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.conductor.vehiculo.rechazada.modificacion", parametros));
       notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
       notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
       notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
       notificacionRespuesta.setTitulo(Resources.getString("notificaciones.rechazada.message"));
       notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
       autorizacionManager.rechazarAutorizacionMovimiento(cv, notificacion, notificacionRespuesta);
       enviarMail(notificacionRespuesta);
   }
   
   private void enviarMail(Notificacion notificacionRespuesta){
       
       try {
           String message = notificacionRespuesta.getDescripcion();
           if(notificacionRespuesta.getObservacion() != null)
               message += "\n" + notificacionRespuesta.getObservacion();
           message += "\n\n" + "ENVIADO POR " + autorizacionBean.getCurrentSessionBean().getUser().getNombreCompleto(); 
           String subject = "NOTIFICACION RNT - " +notificacionRespuesta.getTitulo();
           autorizacionBean.getNotificacionManager().sendEmail(subject, message, notificacionRespuesta.getUsuarioDestino().getEmail());
       }
       catch (AddressException e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(),e);
       }
       catch (MessagingException e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(),e);
       } 
       catch (UnsupportedEncodingException e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(),e);
       }
       catch (Exception e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(),e);
       }
   }
	
	/*
	
	
	
	public String aceptarAutorizacion(){
		try{
			if(notificacion.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL)){
				VehiculoServicio vs = getVehiculoServicio();
				vs.setEstado(VehiculoServicio.ESTADO_VIGENTE);
				Notificacion notificacionRespuesta= new Notificacion();
				notificacionRespuesta.setObservacion(observacionRespuesta);
				notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
				String[] parametros =  new String[4];
				parametros[0] = vs.getVehiculo().getPpu();
				parametros[1] = vs.getServicio().getIdentServicio().toString();
				parametros[2] = vs.getServicio().getRegion().getNombre();
				String nombreReglamentacion ="";
				if(vs.getReglamentacion() != null)
					nombreReglamentacion=vs.getReglamentacion().getNombre();
				else
					nombreReglamentacion=vs.getServicio().getReglamentacion().getNombre();
				parametros[3] = nombreReglamentacion;
				notificacionRespuesta.setDescripcion(Resources.getString("notificacion.descripcion.vehiculo.aceptada", parametros));
				notificacionRespuesta.setUsuarioDestino(notificacion.getUserCreation());
				notificacionRespuesta.setEstado(Notificacion.ESTADO_NO_LEIDO);
				notificacionRespuesta.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
				notificacionRespuesta.setTitulo(Resources.getString("notificaciones.aceptada.message"));
				notificacionRespuesta.setAutorizacionMovimiento(notificacion.getAutorizacionMovimiento());
				notificacion.getAutorizacionMovimiento().setEstado(AutorizacionMovimiento.ESTADO_ACEPTADO);
				this.autorizacionBean.getAutorizacionManager().aceptarAutorizacionMovimiento(vs, notificacion, notificacionRespuesta);
				try {
					String message = notificacionRespuesta.getDescripcion();
					if(notificacionRespuesta.getObservacion() != null)
						message += "\n" + notificacionRespuesta.getObservacion();
					message += "\n\n" + "ENVIADO POR " + this.autorizacionBean.getCurrentSessionBean().getUser().getNombreCompleto(); 
					String subject = "NOTIFICACION RNT - " +notificacionRespuesta.getTitulo();
					this.autorizacionBean.getMailSenderService().sendEmail(subject, message, notificacionRespuesta.getUsuarioDestino().getEmail());
					
				}
				catch (AddressException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
				catch (MessagingException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				} 
				catch (UnsupportedEncodingException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
				catch (Exception e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
			}
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.autorizacionBean.getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		pagedListDataModelAutorizacion=null;
		return volverAdmin();
	}
	*/
	
}
