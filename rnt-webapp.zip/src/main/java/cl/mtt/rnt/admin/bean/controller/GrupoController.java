package cl.mtt.rnt.admin.bean.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.faces.application.FacesMessage;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.bean.AutorizacionBean;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.model.core.autorizacion.UsuarioGrupo;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class GrupoController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8726278871440431861L;
	private AutorizacionBean autorizacionBean;
	private List<Grupo> grupos;
	private List<UsuarioGrupo> usuariosGrupo ;
	private Grupo grupo;
	private List<User> usuariospickList;
	private List<User> allUsuarios;
	private List<Region> aplicaA;
	private String region;
	private List<CategoriaTransporteSeleccionble> categorias;
	private CategoriaTransporteSeleccionble categoria;
	private int page=1;
	
	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public GrupoController (AutorizacionBean bean){
		autorizacionBean = bean;
	}

	public AutorizacionBean getAutorizacionBean() {
		return autorizacionBean;
	}

	public void setAutorizacionBean(AutorizacionBean autorizacionBean) {
		this.autorizacionBean = autorizacionBean;
	}
	
	public CategoriaTransporteSeleccionble getCategoria() {
		return categoria;
	}


	public void setCategoria(CategoriaTransporteSeleccionble categoria) {
		this.categoria = categoria;
	}


	public List<CategoriaTransporteSeleccionble> getCategorias(){
		try{
			if(categorias == null)
				categorias= this.autorizacionBean.getCurrentSessionBean().getCategoriasSeleccionables();
		}catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return categorias;
	}
	
	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}
	
	public List<Region> getAplicaA() {
		try{
			if(aplicaA == null ){
				aplicaA = new ArrayList<Region>();
				Region r = new Region();
				r.setCodigo("00");
				r.setNombre(Resources.getString("grupos.todas.regiones"));
				aplicaA.add(r);
				Region r2= new Region();
				r2.setCodigo("");
				r2.setNombre(Resources.getString("grupos.aplica.nacion"));
				aplicaA.add(r2);
				List<Region> regiones =	this.autorizacionBean.getUbicacionGeograficaManager().getAllRegiones();
				if(regiones != null){
					aplicaA.addAll(regiones);
				}
			}
			
		}catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return aplicaA;
	}

	public void setAplicaA(List<Region> aplicaA) {
		this.aplicaA = aplicaA;
	}
	
	public List<User> getAllUsuarios() {
		if(allUsuarios == null)
			allUsuarios = new ArrayList<User>();
		return allUsuarios;
	}

	public void setAllUsuarios(List<User> allUsuarios) {
		this.allUsuarios = allUsuarios;
	}

	public List<UsuarioGrupo> getUsuariosGrupo() {
		if(usuariosGrupo == null){
			usuariosGrupo= new ArrayList<UsuarioGrupo>();
		}
		return usuariosGrupo;
	}

	public void setUsuariosGrupo(List<UsuarioGrupo> usuariosGrupo) {
		this.usuariosGrupo = usuariosGrupo;
	}

	public List<User> getUsuariospickList() {
		if(usuariospickList == null){
			usuariospickList= new ArrayList<User>();
		}
		return usuariospickList;
	}

	public void setUsuariospickList(List<User> usuariospickList) {
		this.usuariospickList = usuariospickList;
	}

	public Grupo getGrupo() {
		return grupo;
	}

	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}
	
	public List<Grupo> getGrupos() {
		if(grupos == null)
			grupos= new ArrayList<Grupo>();
		return grupos;
	}

	public void setGrupos(List<Grupo> grupos) {
		this.grupos = grupos;
	}
	
	public void  searchGrupos() throws GeneralDataAccessException{
			 this.grupos=this.getAutorizacionBean().getGrupoManager().getGrupos();
			 if(grupos != null)
				 Collections.sort(grupos);
	 }
	
	
	public String prepareNuevoGrupo(){
		grupo=new Grupo();
		this.getAllUsuarios().clear();
		this.getUsuariospickList().clear();
		this.autorizacionBean.getSessionCacheManager().saveState(autorizacionBean);
		return "success_prepare_nuevo_grupo";
	}
	
	public String prepareModificarGrupo(Grupo grupo){
		try{
			this.grupo=grupo;
			this.getAllUsuarios().clear();
			this.getUsuariospickList().clear();
			usuariosGrupo=this.autorizacionBean.getGrupoManager().getUsuariosGrupoByIdGrupo(grupo.getId());
			aplicaAChanged();
			if(usuariosGrupo != null){
				for( UsuarioGrupo  ug :usuariosGrupo){
					this.getUsuariospickList().add(ug.getUser());
				}
			}
			this.autorizacionBean.getSessionCacheManager().saveState(autorizacionBean);
			return"success_prepare_modificar_grupo";
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}	
		return null;
	}
	
	public String volver(){
		this.grupo=null;
		this.region=null;
		this.categoria=null;
		this.getAllUsuarios().clear();
		this.getUsuariospickList().clear();
		this.getUsuariosGrupo().clear();
        resetPage();
		this.getAutorizacionBean().prepareListados();
		return "success_return_from_grupo";
	}
	
	public String crearGrupo(){
		try{
			this.getGrupo().setDbAction(GenericModelObject.ACTION_SAVE);
			this.getGrupo().setCodRegion(this.grupo.getRegion().getCodigo());
			this.getGrupo().setCategoriaTransporte(this.grupo.getCategoriaTransporteSeleccionble().getCategoria());
			this.getGrupo().setTipoTransporte(this.grupo.getCategoriaTransporteSeleccionble().getTipoTransporte());
			this.getGrupo().setMedioTransporte(this.grupo.getCategoriaTransporteSeleccionble().getMedio());
			List<UsuarioGrupo> usuarios = new ArrayList<UsuarioGrupo>();
			for(User  u : this.getUsuariospickList()){
				UsuarioGrupo ugnuevo = new UsuarioGrupo();
				ugnuevo.setDbAction(GenericModelObject.ACTION_SAVE);
				ugnuevo.setGrupo(this.grupo);
				ugnuevo.setUser(u);
				usuarios.add(ugnuevo);
			}
			this.autorizacionBean.getGrupoManager().saveGrupo(this.grupo, usuarios);
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}	
		return volver();
	}
	
	public String modificarGrupo(){
		try{
			this.getGrupo().setDbAction(GenericModelObject.ACTION_UPDATE);
			this.getGrupo().setCodRegion(this.grupo.getRegion().getCodigo());
			this.getGrupo().setCategoriaTransporte(this.grupo.getCategoriaTransporteSeleccionble().getCategoria());
			this.getGrupo().setTipoTransporte(this.grupo.getCategoriaTransporteSeleccionble().getTipoTransporte());
			this.getGrupo().setMedioTransporte(this.grupo.getCategoriaTransporteSeleccionble().getMedio());
			List<UsuarioGrupo> usuariosNuevos = new ArrayList<UsuarioGrupo>();
			for(User  u : this.getUsuariospickList()){
				boolean persistente =false;
				for( UsuarioGrupo  ug :usuariosGrupo){
					if(u.equals(ug.getUser())){
						persistente=true;
						break;
					}
				}
				if(!persistente){
					UsuarioGrupo ugnuevo = new UsuarioGrupo();
					ugnuevo.setDbAction(GenericModelObject.ACTION_SAVE);
					ugnuevo.setGrupo(this.grupo);
					ugnuevo.setUser(u);
					usuariosNuevos.add(ugnuevo);
				}
			}
			
			
			for(UsuarioGrupo  ug :usuariosGrupo){
				boolean borrar =true;
				for(User  u : this.getUsuariospickList()){
					if(ug.getUser().equals(u)){
						borrar =false;
						break;
					}
				}
				if(borrar){
					ug.setDbAction(GenericModelObject.ACTION_DELETE);
					usuariosNuevos.add(ug);
				}
			}
			this.autorizacionBean.getGrupoManager().updateGRupo(this.grupo, usuariosNuevos);
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		}catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return volver();
	}
	
	public void removeGrupo(){
		try{
			List <UsuarioGrupo> users =this.autorizacionBean.getGrupoManager().getUsuariosGrupoByIdGrupo(grupo.getId());
			this.autorizacionBean.getGrupoManager().removeGRupo(this.grupo,users);
			this.grupos.remove(this.grupo);
			this.grupo=null;
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("messages.removeSuccess"), FacesMessage.SEVERITY_INFO);
		}catch(IntegrityViolationException e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.constraint.violation.grupo"), FacesMessage.SEVERITY_ERROR);
		}
		catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	public void aplicaAChanged(){
		try{
			if( this.grupo.getCategoriaTransporteSeleccionble()== null  || (this.grupo.getRegion() == null || this.grupo.getRegion().getCodigo() == null) ){
				return;
			}
			if(this.region == null || !this.region.equals(this.getGrupo().getRegion().getCodigo()) || !this.categoria.equals(this.grupo.getCategoriaTransporteSeleccionble())){
				this.getUsuariospickList().clear();
				if(this.grupo.getRegion().getCodigo() == null || this.grupo.getRegion().getCodigo().isEmpty()){
					this.allUsuarios = this.autorizacionBean.getUsuarioManager().getUsuariosAplicaNacionyCategoriaTransporte(true,this.grupo.getCategoriaTransporteSeleccionble());
				}
				else if (this.grupo.getRegion().getCodigo().equals("00")){
					this.allUsuarios = this.autorizacionBean.getUsuarioManager().getUsuariosByCategoriaTransporte(this.grupo.getCategoriaTransporteSeleccionble());
				}
				else{
					this.allUsuarios = this.autorizacionBean.getUsuarioManager().getUsuariosByRegionyCategoriaTransporte(this.grupo.getRegion().getCodigo(),this.grupo.getCategoriaTransporteSeleccionble());
				}
				region=this.grupo.getRegion().getCodigo();
				categoria = this.grupo.getCategoriaTransporteSeleccionble();
			}
		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			this.getAutorizacionBean().getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
	public void resetPage(){
		this.page=1;
	}

}
