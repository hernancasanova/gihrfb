package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.service.CategoriaTransporteManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantCategoriaTransporteBean implements Serializable {

	private static final long serialVersionUID = 2912710549550611385L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{categoriaTransporteManager}")
	private CategoriaTransporteManager categoriaTransporteManager;

	private Long idCategoriaTransporte;
	private String categoriaTransporteNuevo;

	private List<CategoriaTransporte> categoriasTransporte;
	private CategoriaTransporte categoriaTransporte = new CategoriaTransporte();

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public CategoriaTransporteManager getCategoriaTransporteManager() {
		return categoriaTransporteManager;
	}

	public void setCategoriaTransporteManager(CategoriaTransporteManager categoriaTransporteManager) {
		this.categoriaTransporteManager = categoriaTransporteManager;
	}

	public Long getIdCategoriaTransporte() {
		return idCategoriaTransporte;
	}

	public void setIdCategoriaTransporte(Long idCategoriaTransporte) {
		this.idCategoriaTransporte = idCategoriaTransporte;
	}

	public String getCategoriaTransporteNuevo() {
		return categoriaTransporteNuevo;
	}

	public void setCategoriaTransporteNuevo(String categoriaTransporteNuevo) {
		this.categoriaTransporteNuevo = categoriaTransporteNuevo;
	}

	public List<CategoriaTransporte> getCategoriasTransporte() {
		return categoriasTransporte;
	}

	public void setCategoriasTransporte(List<CategoriaTransporte> categoriasTransporte) {
		this.categoriasTransporte = categoriasTransporte;
	}

	public CategoriaTransporte getCategoriaTransporte() {
		return categoriaTransporte;
	}

	public void setCategoriaTransporte(CategoriaTransporte categoriaTransporte) {
		this.categoriaTransporte = categoriaTransporte;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		try {
			this.categoriasTransporte = categoriaTransporteManager.getAllCategoriasTrasporte();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_CATEGORIATRANSPORTE;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	public String guardarCategoriaTransporte() {
		try {
			categoriaTransporteManager.saveCategoriaTransporte(categoriaTransporte);
			this.categoriasTransporte = categoriaTransporteManager.getAllCategoriasTrasporte();
			this.getSessionCacheManager().saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_CategoriaTransporteExistente_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("categoriaTransporte.error.existeCategoriaTransporte"), FacesMessage.SEVERITY_ERROR);
			return "error_CategoriaTransporte_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarCategoriaTransporte";
	}

	public String prepararModificarCategoriaTransporte(CategoriaTransporte categoriaTransporte) {
		try {
			this.setCategoriaTransporte(categoriaTransporte);
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarCategoriaTransporte";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarCategoriaTransporte";
	}

	public String modificarCategoriaTransporte() {
		try {
			categoriaTransporteManager.updateCategoriaTransporte(categoriaTransporte);
			this.sessionCacheManager.saveState(this);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("categoriaTransporte.error.existeCategoriaTransporte"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_CategoriaTransporteExistente_modificar";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_CategoriaTransporte_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarCategoriaTransporte";
	}

	public String revertirModificarCategoriaTransporte() {
		try {
			int index = categoriasTransporte.indexOf(categoriaTransporte);
			this.setCategoriaTransporte(this.getCategoriaTransporteManager().getCategoriaTransporteById(categoriaTransporte.getId()));
			categoriasTransporte.set(index, categoriaTransporte);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_revertirModificarCategoriaTransporte";
		}
		this.sessionCacheManager.saveState(this);
		return "success_revertirModificarCategoriaTransporte";

	}

	public String eliminarCategoriaTransporte() {
		try {
			CategoriaTransporte categoriaTransporte = this.getCategoriaTransporteManager().getCategoriaTransporteById(this.getIdCategoriaTransporte());
			this.getCategoriaTransporteManager().removeCategoriaTransporte(categoriaTransporte);
			this.categoriasTransporte = categoriaTransporteManager.getAllCategoriasTrasporte();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_CategoriaTransporte_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("categoriaTransporte.error.eliminarCategoriaTransporte"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_CategoriaTransporte_eliminarNoPermitido";
		}

		messageBean.addMessage(Resources.getString("categoriaTransporte.messages.eliminarCategoriaTransporte"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarCategoriaTransporte";
	}

}
