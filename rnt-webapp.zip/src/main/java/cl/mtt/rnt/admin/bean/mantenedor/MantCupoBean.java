package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.util.ItemCupo;
import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantCupoBean implements Serializable {

	private static final long serialVersionUID = 2912710549550611385L;

	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;

	@ManagedProperty(value = "#{reglamentacionManager}")
	private ReglamentacionManager reglamentacionManager;

	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;

	@ManagedProperty(value = "#{tipoServicioManager}")
	private TipoServicioManager tipoServicioManager;

	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@ManagedProperty(value = "#{zonaManager}")
	private ZonaManager zonaManager;

	private Map<Long, String> tiposServicioMap = new HashMap<Long, String>();
	private Map<String, String> regionesMap = new HashMap<String, String>();
	private Map<Long, String> zonasMap = new HashMap<Long, String>();

	private Long idReglamentacion;
	private List<Reglamentacion> reglamentaciones;
	private Long idTipoServicio;
	private List<TipoServicio> tiposServicio;
	private String codigoRegion;
	private List<Region> regiones;
	private Long idZona;
	private List<Zona> zonas;

	private List<ItemCupo> cupos;
	private String buscarPor = "REGION";

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	private List<ItemCupo> getCuposFiltrados() throws GeneralDataAccessException {
		List<ItemCupo> cs = reglamentacionManager.getItemsCupo(getIdReglamentacion(), getIdTipoServicio(), getCodigoRegion(), getIdZona());

		for (ItemCupo item : cs) {
			item.setNombreTipoServicio(getNombreTipoServicio(item.getIdTipoServicio()));
			item.setNombreRegionZona(getNombreZonaRegion(item.getIdZona(), item.getCodigoRegion()));
		}
		return cs;
	}

	private void clear() {
		idTipoServicio = null;
		idReglamentacion = null;
		codigoRegion = null;
		idZona = null;
	}

	public void limpiarFiltro() {
		clear();
		filtrar();

	}

	public String prepareMantenedor() {
		try {
			reglamentaciones = reglamentacionManager.getReglamentaciones();
			tiposServicio = tipoServicioManager.getTiposServicio();
			regiones = ubicacionGeograficaManager.getAllRegiones();
			zonas = zonaManager.getAllZonas();

			clear();

			cupos = getCuposFiltrados();

			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_CUPOS;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	public void setReglamentacionManager(ReglamentacionManager reglamentacionManager) {
		this.reglamentacionManager = reglamentacionManager;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public List<ItemCupo> getCupos() {
		return cupos;
	}

	public void setCupos(List<ItemCupo> cupos) {
		this.cupos = cupos;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public Long getIdReglamentacion() {
		return idReglamentacion;
	}

	public void setIdReglamentacion(Long idReglamentacion) {
		this.idReglamentacion = idReglamentacion;
	}

	public List<Reglamentacion> getReglamentaciones() {
		return reglamentaciones;
	}

	public void setReglamentaciones(List<Reglamentacion> reglamentaciones) {
		this.reglamentaciones = reglamentaciones;
	}

	public void setTipoServicioManager(TipoServicioManager tipoServicioManager) {
		this.tipoServicioManager = tipoServicioManager;
	}

	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public void setZonaManager(ZonaManager zonaManager) {
		this.zonaManager = zonaManager;
	}

	public Long getIdTipoServicio() {
		return idTipoServicio;
	}

	public void setIdTipoServicio(Long idTipoServicio) {
		this.idTipoServicio = idTipoServicio;
	}

	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	public void filtrar() {
		try {
			cupos = getCuposFiltrados();
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public String getNombreTipoServicio(Long idTipoServicio) {
		if (!tiposServicioMap.containsKey(idTipoServicio)) {
			for (TipoServicio ts : tiposServicio) {
				if (ts.getId().equals(idTipoServicio)) {
					tiposServicioMap.put(idTipoServicio, ts.getName());
					return ts.getName();
				}
			}
		}
		return tiposServicioMap.get(idTipoServicio);
	}

	public String getNombreZonaRegion(Long idZona, String codigoRegion) {
		if (idZona == null) {// region
			if (!regionesMap.containsKey(codigoRegion)) {
				for (Region reg : regiones) {
					if (reg.getCodigo().equals(codigoRegion)) {
						regionesMap.put(codigoRegion, reg.getNombre());
						return reg.getNombre();
					}
				}
			}
			return regionesMap.get(codigoRegion);
		} else {// zona
			if (!zonasMap.containsKey(idZona)) {
				for (Zona zon : zonas) {
					if (zon.getId().equals(idZona)) {
						zonasMap.put(idZona, zon.getNombre());
						return zon.getNombre();
					}
				}
			}
			return zonasMap.get(idZona);
		}
	}

	public Map<Long, String> getTiposServicioMap() {
		return tiposServicioMap;
	}

	public void setTiposServicioMap(Map<Long, String> tiposServicioMap) {
		this.tiposServicioMap = tiposServicioMap;
	}

	public Map<String, String> getRegionesMap() {
		return regionesMap;
	}

	public void setRegionesMap(Map<String, String> regionesMap) {
		this.regionesMap = regionesMap;
	}

	public Map<Long, String> getZonasMap() {
		return zonasMap;
	}

	public void setZonasMap(Map<Long, String> zonasMap) {
		this.zonasMap = zonasMap;
	}

	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	public List<Region> getRegiones() {
		return regiones;
	}

	public void setRegiones(List<Region> regiones) {
		this.regiones = regiones;
	}

	public Long getIdZona() {
		return idZona;
	}

	public void setIdZona(Long idZona) {
		this.idZona = idZona;
	}

	public List<Zona> getZonas() {
		return zonas;
	}

	public void setZonas(List<Zona> zonas) {
		this.zonas = zonas;
	}

	public String getBuscarPor() {
		return buscarPor;
	}

	public void setBuscarPor(String buscarPor) {
		this.buscarPor = buscarPor;
	}

	public void buscarPorListener(AjaxBehaviorEvent ae) {
		codigoRegion = null;
		idZona = null;
	}

}
