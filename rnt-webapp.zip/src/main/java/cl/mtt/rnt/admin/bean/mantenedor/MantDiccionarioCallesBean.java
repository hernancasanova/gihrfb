package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.model.DataModel;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.bean.UbicacionGeograficaBean;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.impl.GenericDAOImpl;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.TipoVia;
import cl.mtt.rnt.commons.model.core.recorrido.CalleHomologada;
import cl.mtt.rnt.commons.model.core.recorrido.DatoDiccionario;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.gui.PagedListDataModel;

@ManagedBean
@ViewScoped
public class MantDiccionarioCallesBean implements Serializable {

	private static final long serialVersionUID = 2912710549550611385L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{ubicacionGeograficaBean}")
	private UbicacionGeograficaBean ubicacionGeograficaBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{generalDataManager}")
	private GeneralDataManager generalDataManager;
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	private Long idDatoDiccionario;
	private DatoDiccionario datoDiccionario;
	private PagedListDataModel pagedListDataModel;
	private int currentPage = 1;
	private int totalListSize;
	// Variables para el ordenamiento
	private String sortingField;
	private Boolean sortingAsc;
	private HashMap<String,Boolean> sorters;

	

	// filtros
	private String codigoComunaFilter;

	private String filtroNombre;

	public void setUbicacionGeograficaBean(UbicacionGeograficaBean ubicacionGeograficaBean) {
		this.ubicacionGeograficaBean = ubicacionGeograficaBean;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public void setGeneralDataManager(GeneralDataManager generalDataManager) {
		this.generalDataManager = generalDataManager;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		this.sessionCacheManager.clearSession();
		this.ubicacionGeograficaBean.setIdRegionSeleccionada(null);
		this.codigoComunaFilter = null;
		pagedListDataModel = null;
		estimarTablaInicial();

		this.sessionCacheManager.saveState(this);
		return RedirectConstants.SEL_TABLA_TO_MANT_DICCIONARIO;
	}

	public Long getIdDatoDiccionario() {
		return idDatoDiccionario;
	}

	public void setIdDatoDiccionario(Long idDatoDiccionario) {
		this.idDatoDiccionario = idDatoDiccionario;
	}

	private HashMap<String, Object> getFiltros() throws GeneralDataAccessException {
		HashMap<String, Object> filters = new HashMap<String, Object>();

		// // Filtro Region
		if (ubicacionGeograficaBean.getIdRegionSeleccionada() != null && !ubicacionGeograficaBean.getIdRegionSeleccionada().equals("")) {
			// TODO mejorar la búsqueda del geniricDAO para los casos de las
			// colecciones de dos y además para que no tengamos que mandar desde
			// aca
			// la lista (en este caso de comunas)
			List<String> codigosComuna = ubicacionGeograficaManager.getAllCodigosComunasByIdRegion(ubicacionGeograficaBean.getIdRegionSeleccionada());
			filters.put("codigoComuna", codigosComuna);
			
			
		}
		// // Filtro Provincia
		// if (this.idProvinciaFiltro!=null &&
		// !this.idProvinciaFiltro.equals("") ){
		// List<String> codigosComuna =
		// this.getUbicacionGeograficaManager().getAllCodigosComunasByIdProvincia(idProvinciaFiltro);
		// filters.put("codigoComuna", codigosComuna);
		// }
		// Filtro Comuna
		if (this.codigoComunaFilter != null && !this.codigoComunaFilter.equals("")) {
			filters.put("codigoComuna", codigoComunaFilter);
		}
		// // Filtro Tipo Terminal
		// if (this.idTipoTerminalFiltro!=null && this.idTipoTerminalFiltro!=0
		// ){
		// filters.put("tipoTerminal.id", idTipoTerminalFiltro);
		// }
		// // Filtro Categoría
		// if (this.categoria!=null && !this.categoria.equals("")){
		// filters.put("categoria", categoria);
		// }
		if (this.filtroNombre != null) {
			//el prfijo ILIKE modifica el critero de busqueda del filtro
			filters.put(GenericDAO.CRITERION_PREFIX_ILIKE+".calle1", this.filtroNombre);
		}
		
		return filters;
	}

	public void actualizarFilas() {
		this.filtrarCalles();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void updateListaCalles() {
		// this.calles = generalDataManager.getAllDatosDiccionario();

		try {
			HashMap<String, Object> filters = getFiltros();

			int totalListSize = new Long(generalDataManager.getDatosDiccionarioCount(filters)).intValue();

			setTotalListSize(totalListSize);

			int rows = currentSessionBean.getTablaPaginacion().get(Constants.TABLA_LISTADO_CALLES);
			int first = (this.getCurrentPage() - 1) * rows;

			// Si sucede esto es que hay menos elementos que páginas
			if ((first / rows) > (Math.ceil(totalListSize / rows))) {
				first = 0;
				setCurrentPage(1);
			}

			// this.getCallesTable().setFirst(0);
			List<String> order = new ArrayList<String>();
			if (this.getSortingField() != null && !this.getSortingField().equals("")) {
				order.add(this.getSortingField() + ((this.getSortingAsc()) ? "" : " desc"));
			} else {
				order.add("calle1");
			}

			List<DatoDiccionario> dds = generalDataManager.getCallesPage(first, rows, filters, order);

			pagedListDataModel = new PagedListDataModel(new ArrayList(dds), totalListSize, rows);

			// sessionCacheManager.saveState(this);

		} catch (GeneralDataAccessException e) {
			pagedListDataModel = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModel = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}

	private void estimarTablaInicial() {
		try {

			HashMap<String, Object> filters = getFiltros();
			int totalListSize = new Long(generalDataManager.getDatosDiccionarioCount(filters)).intValue();
			setTotalListSize(totalListSize);

		} catch (GeneralDataAccessException e) {
			pagedListDataModel = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModel = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	@SuppressWarnings("rawtypes")
	public DataModel getCallesPagedDataModel() {
		if (pagedListDataModel == null)
			this.updateListaCalles();
		return this.pagedListDataModel;

	}

	public void limpiarFiltro() {
		this.ubicacionGeograficaBean.setIdRegionSeleccionada(null);
		this.codigoComunaFilter = null;
		this.filtroNombre = null;
		this.updateListaCalles();
	}

	public PagedListDataModel getPagedListDataModel() {
		return pagedListDataModel;
	}

	public void setPagedListDataModel(PagedListDataModel pagedListDataModel) {
		this.pagedListDataModel = pagedListDataModel;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		if (this.currentPage != currentPage) {
			this.currentPage = currentPage;
			this.updateListaCalles();
		}
	}

	public void filtrarCalles() {
		this.updateListaCalles();
	}

	public int getTotalListSize() {
		return totalListSize;
	}

	public void setTotalListSize(int totalListSize) {
		this.totalListSize = totalListSize;
	}

	public String eliminarCalle() {
		try {
			DatoDiccionario dd = generalDataManager.getDatoDiccionarioById(this.getIdDatoDiccionario());
			generalDataManager.eliminarDatoDiccionario(dd);
			updateListaCalles();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_calle_eliminar";
		}

		messageBean.addMessage(Resources.getString("diccionarioCalles.messages.eliminarCalle"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarCalle";

	}

	public DatoDiccionario getDatoDiccionario() {
		return datoDiccionario;
	}

	public void setDatoDiccionario(DatoDiccionario datoDiccionario) {
		this.datoDiccionario = datoDiccionario;
	}

	public String prepararAgregarCalle() {
		datoDiccionario = new DatoDiccionario();
		this.sessionCacheManager.saveState(this);
		return "agregarDatoDiccionario";
	}

	public String guardarCalle() {
		try {
			// Verifico que no exista ya la calle
			DatoDiccionario dic = generalDataManager.getDatosDiccionario(datoDiccionario.getCalle1(), datoDiccionario.getCodigoComuna());
			if (dic != null) {
				messageBean.addMessage(Resources.getString("terminal.message.calle.existente"), FacesMessage.SEVERITY_ERROR);
				return "error_calles_guardar";
			}
			datoDiccionario.pisarDatosPersistentes();
			generalDataManager.saveDatoDiccionario(datoDiccionario);
			//limpiarFiltro();
			sessionCacheManager.saveState(this);
			sessionCacheManager.saveState(this.ubicacionGeograficaBean);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_calles_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarCalle";
	}

	public String prepararModificarCalle(DatoDiccionario dd) {
		try {
			this.setDatoDiccionario(dd);
			dd.tomarDatosPersistentes();
			dd.setCallesHomologadas(generalDataManager.getCallesHomologadasByDatoDiccionario(dd));
			// aca debo poner la region
			ubicacionGeograficaBean.setIdRegionSeleccionada(dd.getComuna().getProvincia().getRegion().getCodigo());
			ubicacionGeograficaBean.actualizarComunasFromRegion(null);
			this.sessionCacheManager.saveState(ubicacionGeograficaBean);
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarCalle";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarCalle";
	}
	
	public String cancelarModificarCalle() {
		this.sessionCacheManager.saveState(ubicacionGeograficaBean);
		this.sessionCacheManager.saveState(this);
		return "mantenedor_diccionario";
	}
	
	
	public String cancelarAgregarCalle() {
		this.sessionCacheManager.saveState(ubicacionGeograficaBean);
		this.sessionCacheManager.saveState(this);
		return "mantenedor_diccionario";
	}
	
	public void switchQuitarHomologacion(CalleHomologada calleHomologada){
		if (GenericModelObject.ACTION_DELETE == calleHomologada.getDbAction())
			calleHomologada.setDbAction(GenericModelObject.ACTION_NOACTION);
		else
			calleHomologada.setDbAction(GenericModelObject.ACTION_DELETE);
	}

	public String modificarCalle() {
		try {
			// Verifico que no exista ya la calle
			DatoDiccionario dic = generalDataManager.getDatosDiccionario(datoDiccionario.getCalle1(), datoDiccionario.getCodigoComuna());
			if (dic != null && !dic.getId().equals(datoDiccionario.getId())) {
				messageBean.addMessage(Resources.getString("terminal.message.calle.existente"), FacesMessage.SEVERITY_ERROR);
				return "error_prepararModificarCalle";
			}
			datoDiccionario.pisarDatosPersistentes();
			generalDataManager.updateDatoDiccionario(datoDiccionario);
			//limpiarFiltro();
			this.sessionCacheManager.saveState(this);
			sessionCacheManager.saveState(this.ubicacionGeograficaBean);
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
			return "success_modificarCalle";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarCalle";
	}

	public String getSortingField() {
		return sortingField;
	}

	public void setSortingField(String sortingField) {
		this.sortingField = sortingField;
	}

	public Boolean getSortingAsc() {
		return sortingAsc;
	}

	public void setSortingAsc(Boolean sortingAsc) {
		this.sortingAsc = sortingAsc;
	}

	public String getCodigoComunaFilter() {
		return codigoComunaFilter;
	}

	public void setCodigoComunaFilter(String codigoComunaFilter) {
		this.codigoComunaFilter = codigoComunaFilter;
	}

	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}
	
	public List<TipoVia> getTiposVias() {
		return TipoVia.getAll();
	}

	/**
	 * @return el valor de filtroNombre
	 */
	public String getFiltroNombre() {
		return filtroNombre;
	}

	/**
	 * @param setea el parametro filtroNombre al campo filtroNombre
	 */
	public void setFiltroNombre(String filtroNombre) {
		this.filtroNombre = filtroNombre;
	}

	public void sortCollection(String currentFieldOrder) {
		if(sorters == null){
			sorters = new HashMap<String, Boolean>();
		}
		Boolean lastOrderIsAsc = sorters.get(currentFieldOrder);
		if(lastOrderIsAsc == null || !lastOrderIsAsc.booleanValue()){
			lastOrderIsAsc = true;
		}else{
			lastOrderIsAsc = false;
		}
		sorters.put(currentFieldOrder, lastOrderIsAsc);
		this.sortingField = currentFieldOrder;
		this.sortingAsc = lastOrderIsAsc;
		this.updateListaCalles();		
	}

	public HashMap<String, Boolean> getSorters() {
		return sorters;
	}

	public void setSorters(HashMap<String, Boolean> sorters) {
		this.sorters = sorters;
	}

}
