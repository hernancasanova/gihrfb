package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.Documentacion;
import cl.mtt.rnt.commons.service.DocumentacionManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantDocumentacionBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3365097243171809707L;
	
	
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;

	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	
	@ManagedProperty(value = "#{documentacionManager}")
	private DocumentacionManager documentacionManager;
	
	private List<Documentacion> documentaciones;
	private Documentacion documentacion;
	private int page=1;
	private boolean edit= false;
	private String nombre;
	
	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}
	
	public String prepareMantenedor(){
		try {			
			documentaciones=documentacionManager.getDocumentaciones();
			if(documentaciones != null)
				Collections.sort(documentaciones);
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_DOCUMENTACION;
		}
		catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}
	
	public void prepareAddDocumentacion(){
		documentacion=new Documentacion();
		edit=false;
	}
	
	public void prepareEditarDocumento(Documentacion doc){
		edit=true;
		documentacion=doc;
	}
	
	public void saveDocumentacion(){
		try{
			documentacionManager.saveDocumentacion(this.documentacion);
			if(documentaciones == null)
				documentaciones = new ArrayList<Documentacion>();
			documentaciones.add(documentacion);
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		}
		catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			documentacion=null;
			if(documentaciones != null)
				Collections.sort(documentaciones);
			resetPage();
		}
	}
	
	public void eliminarDocumento(){
		try{
			documentacionManager.deleteDocumentacion(this.documentacion);
			this.getDocumentaciones().remove(this.documentacion);
			messageBean.addMessage(Resources.getString("messages.removeSuccess"), FacesMessage.SEVERITY_INFO);
		}
		catch(IntegrityViolationException e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.constraint.violation.documentacion"), FacesMessage.SEVERITY_ERROR);
		}
		catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			documentacion=null;
			if(documentaciones != null)
				Collections.sort(documentaciones);
			resetPage();
		}
	}
	
	public void modificarDocumentacion(){
		try{
			documentacionManager.updateDocumentacion(this.documentacion);
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		}
		catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			documentacion=null;
			if(documentaciones != null)
				Collections.sort(documentaciones);
			resetPage();
		}
	}
	
	
	public void resetPage(){
		this.page=1;
	}
	
	public void filtrar(){
		try{
			if(nombre == null || nombre.trim().isEmpty())
				documentaciones=documentacionManager.getDocumentaciones();
			else
				documentaciones=documentacionManager.getDocumentacionesByName(this.nombre);
			if(documentaciones != null)
				Collections.sort(documentaciones);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			resetPage();
		}
	}
	
	public void limpiarFiltro() {
		try{
			nombre="";
			documentaciones=documentacionManager.getDocumentaciones();
			if(documentaciones != null)
				Collections.sort(documentaciones);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		catch(Exception e){
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			resetPage();
		}
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public void setDocumentacionManager(DocumentacionManager documentacionManager) {
		this.documentacionManager = documentacionManager;
	}

	public List<Documentacion> getDocumentaciones() {
		return documentaciones;
	}

	public void setDocumentaciones(List<Documentacion> documentaciones) {
		this.documentaciones = documentaciones;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public Documentacion getDocumentacion() {
		return documentacion;
	}

	public void setDocumentacion(Documentacion documentacion) {
		this.documentacion = documentacion;
	}

	public boolean isEdit() {
		return edit;
	}

	public void setEdit(boolean edit) {
		this.edit = edit;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
