package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.Gremio;
import cl.mtt.rnt.commons.model.core.GremioRegion;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.GremioManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StringUtil;

@ManagedBean
@ViewScoped
public class MantGremioBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7197733523089032219L;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{gremioManager}")
	private GremioManager gremioManager;
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;
	
	private List<Gremio> gremios;
	private Gremio gremio;
	private Map<String,Region> regionesMap;
	private List<Region> regiones;
	private List<Region> regionesSeleccionadas;
	private Long idGremio;
	private String idRegionFiltro;
	
	@PostConstruct
	public void init() {
		if (!sessionCacheManager.restoreState(this)){
			try {
				regionesMap=ubicacionGeograficaManager.getAllRegionesAsMap();
				regiones=ubicacionGeograficaManager.getAllRegiones();
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
	}

	
	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}


	public List<Gremio> getGremios() {
		return gremios;
	}
	public void setGremios(List<Gremio> gremios) {
		this.gremios = gremios;
	}
	public Gremio getGremio() {
		return gremio;
	}
	public void setGremio(Gremio gremio) {
		this.gremio = gremio;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}
	
	
	public void setGremioManager(GremioManager gremioManager) {
		this.gremioManager = gremioManager;
	}

	public void actualizarFilas(){
		
	}

	public List<Region> getRegiones() {
		return regiones;
	}

	public void setRegiones(List<Region> regiones) {
		this.regiones = regiones;
	}


	public Map<String, Region> getRegionesMap() {
		return regionesMap;
	}


	public void setRegionesMap(Map<String, Region> regionesMap) {
		this.regionesMap = regionesMap;
	}


	public String prepareMantenedor() {
		try {
			if(idRegionFiltro==null){
				this.gremios = gremioManager.getAllGremios();
			}else{
				this.gremios = gremioManager.getGremiosByRegion(idRegionFiltro);
			}
			
			this.sessionCacheManager.saveState(this);
			return "success_gremios";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_gremios";
	}
	
	public String prepareNuevoGremio(){
		gremio=new Gremio();
		regionesSeleccionadas=new ArrayList<Region>();

		this.sessionCacheManager.saveState(this);
		return "success_prepareNuevoGremio";
	}
	
	public String guardarGremio() {
		try {
			gremio.setDescriptor(StringUtil.makeDescriptor(gremio.getNombre()));
			gremio.setGremiosRegiones(new ArrayList<GremioRegion>());
			for (Region reg: regionesSeleccionadas) {
				GremioRegion gr=new GremioRegion();
				gr.setGremio(gremio);
				gr.setCodRegion(reg.getCodigo());
				gremio.getGremiosRegiones().add(gr);
			}
			gremioManager.saveGremio(gremio);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_MedioTransporteExistente_guardar";
		} 
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return prepareMantenedor();
	}

	public String prepararModificarGremio(Gremio gremio){
		this.gremio=gremio;
		regionesSeleccionadas=new ArrayList<Region>();
		for (GremioRegion gr : gremio.getGremiosRegiones()) {
			regionesSeleccionadas.add(regionesMap.get(gr.getCodRegion()));	
		}
		
		this.sessionCacheManager.saveState(this);
		return "success_prepareModificarGremio";
	}

	private boolean listaContieneRegion(GremioRegion gr,List<Region> regs){
		for (Region r : regs) {
			if(gr.getCodRegion().equals(r.getCodigo()))
				return true;
		}
		return false;
	}

	private boolean gremioContieneRegion(Gremio g,Region r){
		for (GremioRegion gr : g.getGremiosRegiones()) {
			if(gr.getCodRegion().equals(r.getCodigo()))
				return true;
		}
		return false;
	}
	
	public String modificarGremio() {
		try {
			List<GremioRegion> aeliminar=new ArrayList<GremioRegion>();
			for (GremioRegion gr : gremio.getGremiosRegiones()) {
				if(!listaContieneRegion(gr,regionesSeleccionadas)){
					aeliminar.add(gr);
				}
			}
			for (GremioRegion gremioRegion : aeliminar) {
				gremio.getGremiosRegiones().remove(gremioRegion);
			}
			for (Region reg: regionesSeleccionadas) {
				if(!gremioContieneRegion(gremio,reg)){
					GremioRegion gr=new GremioRegion();
					gr.setGremio(gremio);
					gr.setCodRegion(reg.getCodigo());
					gremio.getGremiosRegiones().add(gr);	
				}
			}
			gremioManager.updateGremio(gremio,aeliminar);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_MedioTransporteExistente_guardar";
		} 
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return prepareMantenedor();
	}

	public String eliminarGremio() {
		try {
			Gremio g = gremioManager.getGremioById(idGremio);
			gremioManager.removeGremio(g);
			
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return null;
		} catch (RemoveNotAllowedException e) {
			messageBean.addMessage(Resources.getString("gremio.error.eliminarGremio"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return null;
		}

		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return prepareMantenedor();
	}

	public List<Region> getRegionesSeleccionadas() {
		return regionesSeleccionadas;
	}


	public void setRegionesSeleccionadas(List<Region> regionesSeleccionadas) {
		this.regionesSeleccionadas = regionesSeleccionadas;
	}


	public Long getIdGremio() {
		return idGremio;
	}
	public void setIdGremio(Long idGremio) {
		this.idGremio = idGremio;
	}


	public String getIdRegionFiltro() {
		return idRegionFiltro;
	}
	public void setIdRegionFiltro(String idRegionFiltro) {
		this.idRegionFiltro = idRegionFiltro;
	}
	
	
	public void filtrarGremios(){
		try{
			if(idRegionFiltro==null){
				this.gremios = gremioManager.getAllGremios();
			}else{
				this.gremios = gremioManager.getGremiosByRegion(idRegionFiltro);
			}
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
	public void limpiarFiltro(){
		try{
			idRegionFiltro = null;
			this.gremios = gremioManager.getAllGremios();
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
}
