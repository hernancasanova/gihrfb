package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.service.MedioTransporteManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantMedioTransporteBean implements Serializable {

	private static final long serialVersionUID = 2912710549550611385L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{medioTransporteManager}")
	private MedioTransporteManager medioTransporteManager;

	private Long idMedioTransporte;
	private String medioTransporteNuevo;

	private List<MedioTransporte> mediosTransporte;
	private MedioTransporte medioTransporte = new MedioTransporte();

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public Long getIdMedioTransporte() {
		return idMedioTransporte;
	}

	public void setIdMedioTransporte(Long idMedioTransporte) {
		this.idMedioTransporte = idMedioTransporte;
	}

	public String getMedioTransporteNuevo() {
		return medioTransporteNuevo;
	}

	public void setMedioTransporteNuevo(String medioTransporteNuevo) {
		this.medioTransporteNuevo = medioTransporteNuevo;
	}

	public List<MedioTransporte> getMediosTransporte() {
		return mediosTransporte;
	}

	public void setMediosTransporte(List<MedioTransporte> mediosTransporte) {
		this.mediosTransporte = mediosTransporte;
	}

	public MedioTransporte getMedioTransporte() {
		return medioTransporte;
	}

	public void setMedioTransporte(MedioTransporte medioTransporte) {
		this.medioTransporte = medioTransporte;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public MedioTransporteManager getMedioTransporteManager() {
		return medioTransporteManager;
	}

	public void setMedioTransporteManager(MedioTransporteManager medioTransporteManager) {
		this.medioTransporteManager = medioTransporteManager;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		try {
			this.mediosTransporte = medioTransporteManager.getAllMediosTrasporte();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_MEDIOTRANSPORTE;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	public String guardarMedioTransporte() {
		try {
			medioTransporte.setNombre(this.getMedioTransporteNuevo());
			medioTransporteManager.saveMedioTransporte(medioTransporte);
			this.mediosTransporte = medioTransporteManager.getAllMediosTrasporte();
			this.getSessionCacheManager().saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_MedioTransporteExistente_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("medioTransporte.error.existeMedioTransporte"), FacesMessage.SEVERITY_ERROR);
			return "error_MedioTransporte_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarMedioTransporte";
	}

	public String prepararModificarMedioTransporte(MedioTransporte medioTransporte) {
		try {
			this.setMedioTransporte(medioTransporte);
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarMedioTransporte";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarMedioTransporte";
	}

	public String modificarMedioTransporte() {
		try {
			medioTransporteManager.updateMedioTransporte(medioTransporte);
			this.sessionCacheManager.saveState(this);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("medioTransporte.error.existeMedioTransporte"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_MedioTransporteExistente_modificar";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_MedioTransporte_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarMedioTransporte";
	}

	public String revertirModificarMedioTransporte() {
		try {

			int index = mediosTransporte.indexOf(medioTransporte);
			this.setMedioTransporte(this.getMedioTransporteManager().getMedioTransporteById(medioTransporte.getId()));
			mediosTransporte.set(index, medioTransporte);

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_revertirModificarMedioTransporte";
		}
		this.sessionCacheManager.saveState(this);
		return "success_revertirModificarMedioTransporte";

	}

	public String eliminarMedioTransporte() {
		try {
			MedioTransporte medioTransporte = this.getMedioTransporteManager().getMedioTransporteById(this.getIdMedioTransporte());
			this.getMedioTransporteManager().removeMedioTransporte(medioTransporte);
			this.mediosTransporte = medioTransporteManager.getAllMediosTrasporte();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_MedioTransporte_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("medioTransporte.error.eliminarMedioTransporte"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_MedioTransporte_eliminarNoPermitido";
		}

		messageBean.addMessage(Resources.getString("medioTransporte.messages.eliminarMedioTransporte"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarMedioTransporte";
	}

}
