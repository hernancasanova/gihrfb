package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.Modalidad;
import cl.mtt.rnt.commons.service.ModalidadManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantModalidadTransporteBean implements Serializable {

	private static final long serialVersionUID = 2912710549550611385L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{modalidadManager}")
	private ModalidadManager modalidadManager;

	private Long idModalidad;
	private String modalidadNuevo;

	private List<Modalidad> modalidades;
	private Modalidad modalidad = new Modalidad();

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public ModalidadManager getModalidadManager() {
		return modalidadManager;
	}

	public void setModalidadManager(ModalidadManager modalidadManager) {
		this.modalidadManager = modalidadManager;
	}

	public Long getIdModalidad() {
		return idModalidad;
	}

	public void setIdModalidad(Long idModalidad) {
		this.idModalidad = idModalidad;
	}

	public String getModalidadNuevo() {
		return modalidadNuevo;
	}

	public void setModalidadNuevo(String modalidadNuevo) {
		this.modalidadNuevo = modalidadNuevo;
	}

	public List<Modalidad> getModalidades() {
		return modalidades;
	}

	public void setModalidades(List<Modalidad> modalidades) {
		this.modalidades = modalidades;
	}

	public Modalidad getModalidad() {
		return modalidad;
	}

	public void setModalidad(Modalidad modalidad) {
		this.modalidad = modalidad;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		try {
			this.modalidades = modalidadManager.getAllModalidades();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_MODALIDADTRANSPORTE;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	public String guardarModalidadTransporte() {
		try {
			modalidad.setNombre(this.getModalidadNuevo());
			modalidadManager.saveModalidad(modalidad);
			this.modalidades = modalidadManager.getAllModalidades();
			this.getSessionCacheManager().saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_ModalidadTransporteExistente_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("modalidad.error.existeModalidadTransporte"), FacesMessage.SEVERITY_ERROR);
			return "error_ModalidadTransporte_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarModalidadTransporte";
	}

	public String prepararModificarModalidadTransporte(Modalidad modalidad) {
		try {
			this.setModalidad(modalidad);
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarModalidadTransporte";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarModalidadTransporte";
	}

	public String modificarModalidadTransporte() {
		try {
			modalidadManager.updateModalidad(modalidad);
			this.sessionCacheManager.saveState(this);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("modalidad.error.existeModalidadTransporte"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_ModalidadTransporteExistente_modificar";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_ModalidadTransporte_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarModalidadTransporte";
	}

	public String revertirModificarModalidadTransporte() {
		try {
			int index = modalidades.indexOf(modalidad);
			this.setModalidad(this.getModalidadManager().getModalidadById(modalidad.getId()));
			modalidades.set(index, modalidad);

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_revertirModificarModalidadTransporte";
		}
		this.sessionCacheManager.saveState(this);
		return "success_revertirModificarModalidadTransporte";

	}

	public String eliminarModalidadTransporte() {
		try {
			Modalidad modalidad = this.getModalidadManager().getModalidadById(this.getIdModalidad());
			this.getModalidadManager().removeModalidad(modalidad);
			this.modalidades = modalidadManager.getAllModalidades();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_ModalidadTransporte_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("modalidad.error.eliminarModalidadTransporte"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_ModalidadTransporte_eliminarNoPermitido";
		}

		messageBean.addMessage(Resources.getString("modalidad.messages.eliminarModalidadTransporte"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarModalidadTransporte";
	}

}
