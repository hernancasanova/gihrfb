package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.PpuAnulada;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantPpuAnuladasBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3814796628105981740L;
	
	
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;

	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;

	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@ManagedProperty(value = "#{vehiculoManagerRnt}")
	private VehiculoManagerRnt vehiculoManagerRnt;

	private List<PpuAnulada> ppuAnuladas;
	private int page=1;
	private List<Region> regiones;
	private Region region;
	private Date fechaDesde;
	private Date fechaHasta;

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}


	

	public String prepareMantenedor() {
		try {			
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			c.add(Calendar.YEAR, -1);
			fechaDesde = c.getTime();
			fechaHasta = new Date();
			ppuAnuladas=vehiculoManagerRnt.getPPUsAnuladas(null,fechaDesde,fechaHasta);
			if(ppuAnuladas != null)
				Collections.sort(ppuAnuladas);
			resetPage();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_PPU_ANULADA;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}
	
	public List<PpuAnulada> getPpuAnuladas() {
		return ppuAnuladas;
	}

	public void setPpuAnuladas(List<PpuAnulada> ppuAnuladas) {
		this.ppuAnuladas = ppuAnuladas;
	}

	public void setVehiculoManagerRnt(VehiculoManagerRnt vehiculoManagerRnt) {
		this.vehiculoManagerRnt = vehiculoManagerRnt;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	
	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}
	
	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public void resetPage(){
		this.page=1;
	}

	public List<Region> getRegiones() {
		try{
			if(regiones == null){
				regiones = ubicacionGeograficaManager.getAllRegiones();
			}
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return regiones;
	}	
	
	public void filtrar(){
		try{
			this.ppuAnuladas = new ArrayList<PpuAnulada>();
			String codRegion=null;
			if(this.region != null)
				codRegion=region.getCodigo();
			this.ppuAnuladas = vehiculoManagerRnt.getPPUsAnuladas(codRegion, this.fechaDesde, this.fechaHasta);
			if(ppuAnuladas != null)
				Collections.sort(ppuAnuladas);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			resetPage();
		}
	}
	
	public void limpiarFiltro(){
		try{
			this.region=null;
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			c.add(Calendar.YEAR, -1);
			fechaDesde = c.getTime();
			fechaHasta = new Date();
			ppuAnuladas=vehiculoManagerRnt.getPPUsAnuladas(null,fechaDesde,fechaHasta);
			if(ppuAnuladas != null)
				Collections.sort(ppuAnuladas);
		}catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}finally{
			resetPage();
		}
	}

}
