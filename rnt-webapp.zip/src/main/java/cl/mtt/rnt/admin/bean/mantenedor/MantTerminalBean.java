package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.DataModel;

import org.apache.log4j.Logger;
import org.richfaces.event.DataScrollEvent;
import org.springframework.security.authentication.AuthenticationManager;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.CategoriaTerminal;
import cl.mtt.rnt.commons.model.core.Paradero;
import cl.mtt.rnt.commons.model.core.Terminal;
import cl.mtt.rnt.commons.model.core.TipoServicioArea;
import cl.mtt.rnt.commons.model.core.TipoTerminal;
import cl.mtt.rnt.commons.model.core.UbicacionTerminal;
import cl.mtt.rnt.commons.model.core.recorrido.DatoDiccionario;
import cl.mtt.rnt.commons.model.core.recorrido.ExtremoRecorrido;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Provincia;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.TerminalManager;
import cl.mtt.rnt.commons.service.TipoServicioAreaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.ElResolver;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.gui.PagedListDataModel;
import cl.mtt.rnt.encargado.bean.ServicioBean;

@ManagedBean
@ViewScoped
public class MantTerminalBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -985016481033167659L;
	@ManagedProperty(value = "#{authenticationManager}")
	private AuthenticationManager authenticationManager;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{terminalManager}")
	private TerminalManager terminalManager;
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;
	@ManagedProperty(value = "#{generalDataManager}")
	private GeneralDataManager generalDataManager;

	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;

	// Mejoras 201409 Nro: 96
	@ManagedProperty(value = "#{tipoServicioAreaManager}")
	private TipoServicioAreaManager tipoServicioAreaManager;
	// Mejoras 201409 Nro: 96

	
	private Long idTerminal;

	private String idRegionFiltro;
	private String idProvinciaFiltro;
	private String idComunaFiltro;
	private Long idTipoTerminalFiltro;

	private String idRegionSeleccionada;
	private String idProvinciaSeleccionada;
	private Long idTipoTerminalSeleccionado;
	private Long idUbicacionTerminalSeleccionada;
	private Long idCategoriaTerminalSeleccionada;

	private List<Region> regiones;
	private List<Provincia> provincias;
	private List<Comuna> comunas;
	private List<TipoTerminal> tiposTerminal;
	private List<CategoriaTerminal> categoriasTerminal;
	private List<UbicacionTerminal> ubicacionesTerminal;

	private String categoria;

	private Terminal terminal = new Terminal();

//	private UIDataTable terminalTable; // para hacer el binding con la página
	private PagedListDataModel pagedListDataModelTerminal;
	private int currentPage = 1;
	private int totalListSize;

	// Variables para el ordenamiento
	private String sortingField;
	private Boolean sortingAsc;
	private HashMap<String,Boolean> sorters;

	private TipoTerminal tipoTermianl = new TipoTerminal();
	private List<DatoDiccionario> calles;

	// Mejoras 201409 Nro: 98
	private String fromView;
	private String extremoRecorrido;
	// Mejoras 201409 Nro: 98

	// Mejoras 201409 Nro: 96
	private List<TipoServicioArea> tiposServicioArea;
	// Mejoras 201409 Nro: 96

	
	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	// Mejoras 201409 Nro: 96
	public void setTipoServicioAreaManager(
			TipoServicioAreaManager tipoServicioAreaManager) {
		this.tipoServicioAreaManager = tipoServicioAreaManager;
	}
	// Mejoras 201409 Nro: 96

	
	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	

	// Getters and Setters
	public int getCurrentPage() {
		return currentPage;
	}

	public TerminalManager getTerminalManager() {
		return terminalManager;
	}

	public void setTerminalManager(TerminalManager terminalManager) {
		this.terminalManager = terminalManager;
	}

	public UbicacionGeograficaManager getUbicacionGeograficaManager() {
		return ubicacionGeograficaManager;
	}

	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public Long getIdTerminal() {
		return idTerminal;
	}

	public void setIdTerminal(Long idTerminal) {
		this.idTerminal = idTerminal;
	}

	public String getIdRegionFiltro() {
		return idRegionFiltro;
	}

	public void setIdRegionFiltro(String idRegionFiltro) {
		this.idRegionFiltro = idRegionFiltro;
	}

	public String getIdProvinciaFiltro() {
		return idProvinciaFiltro;
	}

	public void setIdProvinciaFiltro(String idProvinciaFiltro) {
		this.idProvinciaFiltro = idProvinciaFiltro;
	}

	public String getIdComunaFiltro() {
		return idComunaFiltro;
	}

	public void setIdComunaFiltro(String idComunaFiltro) {
		this.idComunaFiltro = idComunaFiltro;
	}

	public Long getIdTipoTerminalFiltro() {
		return idTipoTerminalFiltro;
	}

	public void setIdTipoTerminalFiltro(Long idTipoTerminalFiltro) {
		this.idTipoTerminalFiltro = idTipoTerminalFiltro;
	}

	public String getIdRegionSeleccionada() {
		return idRegionSeleccionada;
	}

	public void setIdRegionSeleccionada(String idRegionSeleccionada) {
		this.idRegionSeleccionada = idRegionSeleccionada;
	}

	public String getIdProvinciaSeleccionada() {
		return idProvinciaSeleccionada;
	}

	public void setIdProvinciaSeleccionada(String idProvinciaSeleccionada) {
		this.idProvinciaSeleccionada = idProvinciaSeleccionada;
	}

	public Long getIdTipoTerminalSeleccionado() {
		return idTipoTerminalSeleccionado;
	}

	public void setIdTipoTerminalSeleccionado(Long idTipoTerminalSeleccionado) {
		this.idTipoTerminalSeleccionado = idTipoTerminalSeleccionado;
	}

	public List<Region> getRegiones() {
		return regiones;
	}

	public void setRegiones(List<Region> regiones) {
		this.regiones = regiones;
	}

	public List<Provincia> getProvincias() {
		return provincias;
	}

	public void setProvincias(List<Provincia> provincias) {
		this.provincias = provincias;
	}

	public List<Comuna> getComunas() {
		return comunas;
	}

	public void setComunas(List<Comuna> comunas) {
		this.comunas = comunas;
	}

	public List<TipoTerminal> getTiposTerminal() {
		return tiposTerminal;
	}

	public void setTiposTerminal(List<TipoTerminal> tiposTerminal) {
		this.tiposTerminal = tiposTerminal;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public Terminal getTerminal() {
		return terminal;
	}

	public void setTerminal(Terminal terminal) {
		this.terminal = terminal;
	}

	public PagedListDataModel getPagedListDataModelTerminal() {
		return pagedListDataModelTerminal;
	}

	public void setPagedListDataModelTerminal(PagedListDataModel pagedListDataModelTerminal) {
		this.pagedListDataModelTerminal = pagedListDataModelTerminal;
	}

	public TipoTerminal getTipoTermianl() {
		return tipoTermianl;
	}

	public void setTipoTermianl(TipoTerminal tipoTermianl) {
		this.tipoTermianl = tipoTermianl;
	}

	public void setGeneralDataManager(GeneralDataManager generalDataManager) {
		this.generalDataManager = generalDataManager;
	}

	public void setCurrentPage(int currentPage) {
		if (this.currentPage != currentPage) {
			this.currentPage = currentPage;
			this.cargarDataModelTerminales();
		}
	}

	public void setPageData(ActionEvent e) {
		this.setCurrentPage(((DataScrollEvent) e).getPage());
	}

	public int getTotalListSize() {
		return totalListSize;
	}

	public void setTotalListSize(int totalListSize) {
		this.totalListSize = totalListSize;
	}

	public String getSortingField() {
		return sortingField;
	}

	public void setSortingField(String sortingField) {
		this.sortingField = sortingField;
	}

	public Boolean getSortingAsc() {
		return sortingAsc;
	}

	public void setSortingAsc(Boolean sortingAsc) {
		this.sortingAsc = sortingAsc;
	}

	public AuthenticationManager getAuthenticationManager() {
		return authenticationManager;
	}

	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public String prepareMantenedor() {
		try {
			this.sessionCacheManager.clearSession();
			estimarTablaInicial();
			this.regiones = ubicacionGeograficaManager.getAllRegiones();
			this.provincias = ubicacionGeograficaManager.getAllProvincias();
			this.comunas = ubicacionGeograficaManager.getAllComunas();
			this.tiposTerminal = terminalManager.getAllTiposTerminales();
			this.categoriasTerminal = terminalManager.getAllCategoriasTerminal();
			this.ubicacionesTerminal = terminalManager.getAllUbicacionesTerminal();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_TERMINAL;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	private HashMap<String, Object> getFiltrosTerminales() throws GeneralDataAccessException {
		HashMap<String, Object> filters = new HashMap<String, Object>();

		// Filtro Region
		if (this.idRegionFiltro != null && !this.idRegionFiltro.equals("")) {
			// TODO mejorar la búsqueda del geniricDAO para los casos de las
			// colecciones de dos y además para que no tengamos que mandar desde
			// aca
			// la lista (en este caso de comunas)
			List<String> codigosComuna = this.getUbicacionGeograficaManager().getAllCodigosComunasByIdRegion(idRegionFiltro);
			filters.put("codigoComuna", codigosComuna);
		}
		// Filtro Provincia
		if (this.idProvinciaFiltro != null && !this.idProvinciaFiltro.equals("")) {
			List<String> codigosComuna = this.getUbicacionGeograficaManager().getAllCodigosComunasByIdProvincia(idProvinciaFiltro);
			filters.put("codigoComuna", codigosComuna);
		}
		// Filtro Comuna
		if (this.idComunaFiltro != null && !this.idComunaFiltro.equals("")) {
			filters.put("codigoComuna", idComunaFiltro);
		}
		// Filtro Tipo Terminal
		if (this.idTipoTerminalFiltro != null && this.idTipoTerminalFiltro != 0) {
			filters.put("tipoTerminal.id", idTipoTerminalFiltro);
		}
		// Filtro Categoría
		if (this.categoria != null && !this.categoria.equals("")) {
			filters.put("categoriaTerminal.nombre", categoria.toUpperCase());
		}

		return filters;
	}

	private void estimarTablaInicial() {
		try {
			HashMap<String, Object> filters = getFiltrosTerminales();
			int totalListSize = new Long(terminalManager.getTerminalesCount(filters)).intValue();
			setTotalListSize(totalListSize);

		} catch (GeneralDataAccessException e) {
			pagedListDataModelTerminal = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModelTerminal = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void cargarDataModelTerminales() {
		try {
			HashMap<String, Object> filters = getFiltrosTerminales();

			int totalListSize = new Long(terminalManager.getTerminalesCount(filters)).intValue();

			setTotalListSize(totalListSize);

			int rows = currentSessionBean.getTablaPaginacion().get("TABLA_LISTADO_TERMINALES").intValue();
			
			int first = (this.getCurrentPage() - 1) * rows;

			// Si sucede esto es que hay menos elementos que páginas
			if ((first / rows) > (Math.ceil(totalListSize / rows))) {
				first = 0;
				setCurrentPage(1);
			}

//			this.getTerminalTable().setFirst(0);
			List<String> order = new ArrayList<String>();
			if (this.getSortingField() != null && !this.getSortingField().equals("")) {
				String[] orderFields = this.getSortingField().split(","); 
				for (int i = 0; i < orderFields.length; i++) {
					order.add(orderFields[i] + ((this.getSortingAsc()) ? "" : " desc"));
				}
			}

			List<Terminal> terminales = terminalManager.getTerminalesPage(first, rows, filters, order);

			pagedListDataModelTerminal = new PagedListDataModel(new ArrayList(terminales), totalListSize, rows);

			// sessionCacheManager.saveState(this);

		} catch (GeneralDataAccessException e) {
			pagedListDataModelTerminal = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModelTerminal = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}

	public void sortCollection(String currentFieldOrder) {
		if(sorters == null){
			sorters = new HashMap<String, Boolean>();
		}
		Boolean lastOrderIsAsc = sorters.get(currentFieldOrder);
		if(lastOrderIsAsc == null || !lastOrderIsAsc.booleanValue()){
			lastOrderIsAsc = true;
		}else{
			lastOrderIsAsc = false;
		}
		sorters.put(currentFieldOrder, lastOrderIsAsc);
		this.sortingField = currentFieldOrder;
		this.sortingAsc = lastOrderIsAsc;
		this.cargarDataModelTerminales();		
	}

	// Publico
	@SuppressWarnings("rawtypes")
	public DataModel getTerminalesPagedDataModel() {
		if (pagedListDataModelTerminal == null)
			this.cargarDataModelTerminales();
		return this.pagedListDataModelTerminal;

	}

	public void filtrarTerminales() {
		this.cargarDataModelTerminales();
	}

	// Mejoras 201409 Nro: 98
	public String getFromView() {
		return fromView;
	}

	public void setFromView(String fromView) {
		this.fromView = fromView;
	}

	public String getExtremoRecorrido() {
		return extremoRecorrido;
	}

	public void setExtremoRecorrido(String extremoRecorrido) {
		this.extremoRecorrido = extremoRecorrido;
	}

	public String backToRecorrido(){
		try {
			if(vieneDeRecorridos()){
				//Acomodar region de los extremos
				ServicioBean servicioBean = (ServicioBean) ElResolver.getManagedObject("servicioBean");
				acomodarRegiones(servicioBean);
				this.sessionCacheManager.saveState(servicioBean);
			} else if(vieneDeTrazadosPredeterminados()){
				TrazadosPredeterminadosBean bean = (TrazadosPredeterminadosBean) ElResolver.getManagedObject("trazadosPredeterminadosBean");
				this.sessionCacheManager.saveState(bean);
			}
			
			this.sessionCacheManager.saveState(this);
			
			return "success_backToRecorrido"+fromView;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		this.sessionCacheManager.saveState(this);
		return "error_backToRecorrido";
	}

	/**
	 * @param servicioBean
	 * @throws GeneralDataAccessException
	 */
	private void acomodarRegiones(ServicioBean servicioBean)
			throws GeneralDataAccessException {
		ExtremoRecorrido ero = servicioBean.getRecorridoController().getRecorrido().getOrigen();
		if(ero!=null && ero.getParadero()!=null && ero.getParadero().getCodigoComuna()!=null){
			Paradero o = ero.getParadero();
			o.setComuna(ubicacionGeograficaManager.getComunaById(o.getCodigoComuna()));
			o.setRegion(o.getComuna().getProvincia().getRegion());
			o.setIdRegion(o.getRegion().getCodigo());
		}
		ExtremoRecorrido erd = servicioBean.getRecorridoController().getRecorrido().getDestino();
		if(erd!=null && erd.getParadero()!=null && erd.getParadero().getCodigoComuna()!=null){
			Paradero d = erd.getParadero();
			d.setComuna(ubicacionGeograficaManager.getComunaById(d.getCodigoComuna()));
			d.setRegion(d.getComuna().getProvincia().getRegion());
			d.setIdRegion(d.getRegion().getCodigo());
		}
	}

	public String prepareAgregarTerminal(String fromView,String extremo) {
		this.fromView = fromView ;
		this.extremoRecorrido = extremo;
		if(vieneDeRecorridos()){
			this.sessionCacheManager.saveState(ElResolver.getManagedObject("servicioBean"));
		}else if(vieneDeTrazadosPredeterminados()){
			this.sessionCacheManager.saveState(ElResolver.getManagedObject("trazadosPredeterminadosBean"));
		}
		return prepareAgregarTerminal();
	}
	
	public String prepareAgregarTerminal() {
		try {
			initializeDataAgregar();
			this.sessionCacheManager.saveState(this);
			return "success_prepareAgregarTerminal";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareAgregarTerminal";
	}

	/**
	 * @throws GeneralDataAccessException
	 */
	private void initializeDataAgregar() throws GeneralDataAccessException {
		this.ubicacionesTerminal = terminalManager.getAllUbicacionesTerminal();
		this.limpiarCampos();
		this.regiones = ubicacionGeograficaManager.getAllRegiones();
		this.provincias = ubicacionGeograficaManager.getAllProvincias();
		this.comunas = ubicacionGeograficaManager.getAllComunas();
		this.tiposTerminal = terminalManager.getAllTiposTerminales();
		this.categoriasTerminal = terminalManager.getAllCategoriasTerminal();
	}
	
	private boolean vieneDeRecorridos(){
		return fromView.equals("_verMapa") || fromView.equals("_agregarRecorrido") || fromView.equals("_editarRecorrido");
	}
	private boolean vieneDeTrazadosPredeterminados(){
		return fromView.equals("_nuevoTrazadoPredeterminado") || fromView.equals("_editarTrazadoPredeterminado");
	}
		
	public String guardarTerminalRecorrido() {
		if(vieneDeRecorridos()){
			ServicioBean servicioBean = (ServicioBean) ElResolver.getManagedObject("servicioBean");
			try {
				acomodarRegiones(servicioBean);
				Terminal term = cargarDatosTerminalDB();
				term.setComuna(ubicacionGeograficaManager.getComunaById(term.getCodigoComuna()));
				term.setRegion(term.getComuna().getProvincia().getRegion());
				term.setIdRegion(term.getRegion().getCodigo());
				if ("".equals(extremoRecorrido)){
					servicioBean.getRecorridoController().getMapaUtils().agregarParaderoComoTramo(term);
				}
				else  {
				    if ("origen".equals(extremoRecorrido) || (extremoRecorrido != null && extremoRecorrido.contains("origen"))) {
				        servicioBean.getRecorridoController().getRecorrido().getOrigen().setParadero(term);
				        servicioBean.getRecorridoController().refreshListaDisponiblesPorComunaOrigen();
				    }else{
				        servicioBean.getRecorridoController().getRecorrido().getDestino().setParadero(term);
				        servicioBean.getRecorridoController().refreshListaDisponiblesPorComunaDestino();
				    }
				    
				}
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
				this.sessionCacheManager.saveState(this);
				this.sessionCacheManager.saveState(servicioBean);
				return "error_Terminal_guardar";
			} catch (DuplicatedIdException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("terminal.error.existeTerminal"), FacesMessage.SEVERITY_ERROR);
				this.sessionCacheManager.saveState(this);
				this.sessionCacheManager.saveState(servicioBean);
				return "error_TerminalExistente_guardar";
			}
			this.sessionCacheManager.saveState(servicioBean);
		}else  if(vieneDeTrazadosPredeterminados()){
			TrazadosPredeterminadosBean bean = (TrazadosPredeterminadosBean) ElResolver.getManagedObject("trazadosPredeterminadosBean");
			try {
				Terminal term = cargarDatosTerminalDB();
				term.setComuna(ubicacionGeograficaManager.getComunaById(term.getCodigoComuna()));
				term.setRegion(term.getComuna().getProvincia().getRegion());
				term.setIdRegion(term.getRegion().getCodigo());
				if ("".equals(extremoRecorrido)){
					bean.getMapaUtils().agregarParaderoComoTramo(term);
				}
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
				this.sessionCacheManager.saveState(this);
				this.sessionCacheManager.saveState(bean);
				return "error_Terminal_guardar";
			} catch (DuplicatedIdException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("terminal.error.existeTerminal"), FacesMessage.SEVERITY_ERROR);
				this.sessionCacheManager.saveState(this);
				this.sessionCacheManager.saveState(bean);
				return "error_TerminalExistente_guardar";
			}

			this.sessionCacheManager.saveState(bean);
		}
		this.sessionCacheManager.saveState(this);
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarTerminal"+fromView;
	}

	/**
	 * @throws GeneralDataAccessException
	 * @throws DuplicatedIdException
	 */
	private Terminal cargarDatosTerminalDB() throws GeneralDataAccessException,DuplicatedIdException {
		terminal.setTipoTerminal(terminalManager.getTipoTerminalById(this.idTipoTerminalSeleccionado));
		terminal.setUbicacionTerminal(terminalManager.getUbicacionTerminalById(this.idUbicacionTerminalSeleccionada));
		terminal.setCategoriaTerminal(terminalManager.getCategoriaTerminalById(this.idCategoriaTerminalSeleccionada));
		terminalManager.saveTerminal(terminal);
		return terminal;
	}

	// Mejoras 201409 Nro: 98
	
	public String guardarTerminal() {
		try {
			cargarDatosTerminalDB();
			this.cargarDataModelTerminales();

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_Terminal_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("terminal.error.existeTerminal"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TerminalExistente_guardar";
		}
		this.sessionCacheManager.saveState(this);
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarTerminal";
	}

	public String prepararModificarTerminal(Terminal terminal) {
		try {
			this.setTerminal(terminal);
			terminal.setTiposServicioArea(tipoServicioAreaManager.getTiposServicioAreaByTerminal(terminal));
			if (terminal.getComuna() != null) {
				this.setIdProvinciaSeleccionada(terminal.getComuna().getProvincia().getCodigo());
				this.setIdRegionSeleccionada(terminal.getComuna().getProvincia().getRegion().getCodigo());
			} else {
				this.setIdProvinciaSeleccionada(null);
				this.setIdRegionSeleccionada(null);
			}
			if (terminal.getTipoTerminal() != null)
				this.setIdTipoTerminalSeleccionado(terminal.getTipoTerminal().getId());
			else
				this.setIdTipoTerminalSeleccionado(null);
			if (terminal.getUbicacionTerminal() != null)
				this.setIdUbicacionTerminalSeleccionada(terminal.getUbicacionTerminal().getId());
			else
				this.setIdUbicacionTerminalSeleccionada(null);
			if (terminal.getCategoriaTerminal() != null)
				this.setIdCategoriaTerminalSeleccionada(terminal.getCategoriaTerminal().getId());
			else
				this.setIdCategoriaTerminalSeleccionada(null);
			updateCalles();
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarTerminal";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		this.sessionCacheManager.saveState(this);
		return "error_prepararModificarTerminal";
	}

	public String modificarTerminal() {
		try {
			if (!validarCalle()) {
				messageBean.addMessage(Resources.getString("terminal.message.calle.inexistente"), FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().validationFailed();
				this.sessionCacheManager.saveState(this);
				return "error_Terminal_modificar";
			}
			terminal.setTipoTerminal(terminalManager.getTipoTerminalById(this.idTipoTerminalSeleccionado));
			terminal.setUbicacionTerminal(terminalManager.getUbicacionTerminalById(this.idUbicacionTerminalSeleccionada));
			terminal.setCategoriaTerminal(terminalManager.getCategoriaTerminalById(this.idCategoriaTerminalSeleccionada));
			terminalManager.updateTerminal(terminal);
			cargarDataModelTerminales();

			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_Terminal_modificar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("terminal.error.existeTerminal"), FacesMessage.SEVERITY_ERROR);
			return "error_TerminalExistente_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarTerminal";
	}

	public String eliminarTerminal() {
		try {
			Terminal terminal = this.getTerminalManager().getTerminalById(this.getIdTerminal());
			this.terminalManager.removeTerminal(terminal);
			this.cargarDataModelTerminales();
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_Terminal_eliminar";
		} catch (RemoveNotAllowedException e) {
	//		Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			this.cargarDataModelTerminales();
			messageBean.addMessage(Resources.getString("terminal.error.eliminarTerminal"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_Terminal_eliminarNoPermitido";
		}
		messageBean.addMessage(Resources.getString("terminal.messages.eliminarTerminal"), FacesMessage.SEVERITY_INFO);
		this.sessionCacheManager.saveState(this);
		return "success_eliminarTerminal";
	}

	public void actualizarFilas() {
		this.filtrarTerminales();
	}

	public String revertirModificarTerminal() {
		try {
			this.setTerminal(this.getTerminalManager().getTerminalById(terminal.getId()));
			terminal.setTiposServicioArea(tipoServicioAreaManager.getTiposServicioAreaByTerminal(terminal));
			this.setIdProvinciaSeleccionada(terminal.getComuna().getProvincia().getCodigo());
			this.setIdRegionSeleccionada(terminal.getComuna().getProvincia().getRegion().getCodigo());
			if (terminal.getTipoTerminal() != null)
				this.setIdTipoTerminalSeleccionado(terminal.getTipoTerminal().getId());
			else
				this.setIdTipoTerminalSeleccionado(null);
			if (terminal.getUbicacionTerminal() != null)
				this.setIdUbicacionTerminalSeleccionada(terminal.getUbicacionTerminal().getId());
			else
				this.setIdUbicacionTerminalSeleccionada(null);
			if (terminal.getCategoriaTerminal() != null)
				this.setIdCategoriaTerminalSeleccionada(terminal.getCategoriaTerminal().getId());
			else
				this.setIdCategoriaTerminalSeleccionada(null);

			actualizarComunas(null);

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_revertirModificarTerminal";
		}
		this.sessionCacheManager.saveState(this);
		return "success_revertirModificarTerminal";

	}
	// Mejoras 201409 Nro: 93
	private UbicacionTerminal getDefaultUbicacionTerminal(){
		for (UbicacionTerminal ut : ubicacionesTerminal) {
			if(ut.getSigla().equals(UbicacionTerminal.SIGLA_FVP))
				return ut;
		}
		return null;
	}

	// Mejoras 201409 Nro: 93

	private void limpiarCampos() {
		this.terminal = new Terminal();
		// Mejoras 201409 Nro: 93
		this.terminal.setUbicacionTerminal(getDefaultUbicacionTerminal()); 
		// Mejoras 201409 Nro: 93
		this.idRegionSeleccionada = null;
		this.idProvinciaSeleccionada = null;
		this.idTipoTerminalSeleccionado = null;
		this.idUbicacionTerminalSeleccionada = this.terminal.getUbicacionTerminal().getId();
		this.idCategoriaTerminalSeleccionada = null;
	}

	public void actualizarComunasFiltro(AjaxBehaviorEvent event) {
		if (this.idRegionFiltro != null) {
			try {
				this.comunas = ubicacionGeograficaManager.getAllComunasByIdRegion(idRegionFiltro);
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		} else {
			this.idComunaFiltro = null;
		}
	}

	public void actualizarProvincias(AjaxBehaviorEvent event) {
		if (this.idRegionSeleccionada != null) {
			try {
				this.provincias = ubicacionGeograficaManager.getAllProvinciasByIdRegion(idRegionSeleccionada);
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		} else {
			this.idProvinciaSeleccionada = null;
		}
	}

	public void actualizarComunas(AjaxBehaviorEvent event) {
		// if (this.idProvinciaSeleccionada!=null){
		// try {
		// this.comunas =
		// ubicacionGeograficaManager.getAllComunasByIdProvincia(idProvinciaSeleccionada);
		// } catch (GeneralDataAccessException e) {
		// Logger.getLogger(this.getClass()).error(e.getMessage(),e);
		// messageBean.addMessage(Resources.getString("error.generico"),
		// FacesMessage.SEVERITY_ERROR);
		// }
		if (this.idRegionSeleccionada != null) {
			try {
				this.comunas = ubicacionGeograficaManager.getAllComunasByIdRegion(idRegionSeleccionada);
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		} else {
			this.idComunaFiltro = null;
		}
	}

	public Long getIdUbicacionTerminalSeleccionada() {
		return idUbicacionTerminalSeleccionada;
	}

	public void setIdUbicacionTerminalSeleccionada(Long idUbicacionTerminalSeleccionada) {
		this.idUbicacionTerminalSeleccionada = idUbicacionTerminalSeleccionada;
	}

	public Long getIdCategoriaTerminalSeleccionada() {
		return idCategoriaTerminalSeleccionada;
	}

	public void setIdCategoriaTerminalSeleccionada(Long idCategoriaTerminalSeleccionada) {
		this.idCategoriaTerminalSeleccionada = idCategoriaTerminalSeleccionada;
	}

	public List<CategoriaTerminal> getCategoriasTerminal() {
		return categoriasTerminal;
	}

	public void setCategoriasTerminal(List<CategoriaTerminal> categoriasTerminal) {
		this.categoriasTerminal = categoriasTerminal;
	}

	public List<UbicacionTerminal> getUbicacionesTerminal() {
		return ubicacionesTerminal;
	}

	public void setUbicacionesTerminal(List<UbicacionTerminal> ubicacionesTerminal) {
		this.ubicacionesTerminal = ubicacionesTerminal;
	}

	public void limpiarFiltro() {
		this.idRegionFiltro = null;
		this.idProvinciaFiltro = null;
		this.idComunaFiltro = null;
		this.idTipoTerminalFiltro = null;
		this.categoria = null;

		this.cargarDataModelTerminales();
	}

	public void updateCalles() {
		try {
			calles = generalDataManager.findDatosDiccionarioByComuna(getTerminal().getCodigoComuna());
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	private boolean validarCalle() {
		updateCalles();
		String calleName = terminal.getDomicilio();
		if (calles != null) {
			for (int i = 0; i < calles.size(); i++) {
				if (calles.get(i).getCalle1().equals(calleName))
					return true;
			}
		}
		return false;
	}

	public List<String> autocompleteCalle(Object object) {
		String calleName = (object == null) ? "" : (String) object;
		List<String> returnList = new ArrayList<String>();
		if (calles != null) {
			for (int i = 0; i < calles.size(); i++) {
				if (calles.get(i).getCalle1().indexOf(calleName) != -1)
					returnList.add(calles.get(i).getCalle1());
			}
		}

		return returnList;
	}

	public List<DatoDiccionario> getCalles() {
		return calles;
	}

	public void setCalles(List<DatoDiccionario> calles) {
		this.calles = calles;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public HashMap<String, Boolean> getSorters() {
		return sorters;
	}

	public void setSorters(HashMap<String, Boolean> sorters) {
		this.sorters = sorters;
	}

	// Mejoras 201409 Nro: 96
	public List<TipoServicioArea> getTiposServicioArea() {
		if(tiposServicioArea==null){
			try {
				tiposServicioArea = tipoServicioAreaManager.getAllTipoServicioArea();
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
		return tiposServicioArea;
	}

	public void setTiposServicioArea(List<TipoServicioArea> tiposServicioArea) {
		this.tiposServicioArea = tiposServicioArea;
	}
	// Mejoras 201409 Nro: 96

	
}
