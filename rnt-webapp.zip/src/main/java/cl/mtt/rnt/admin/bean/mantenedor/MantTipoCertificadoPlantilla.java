package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.swing.tree.TreeNode;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.richfaces.component.UITree;
import org.richfaces.event.TreeSelectionChangeEvent;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.CertificadoCampo;
import cl.mtt.rnt.commons.model.core.CertificadoCampoDefinition;
import cl.mtt.rnt.commons.model.core.CertificadoSeccion;
import cl.mtt.rnt.commons.model.core.CertificadoSeccionDefinition;
import cl.mtt.rnt.commons.model.core.ClaseTipoCertificado;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.NodoCertificado;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.core.TipoCertificadoReglamentado;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.service.CertificadoManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.TipoCertificadoManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.util.CertificadoXMLUtil;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.filter.CertificadoFilter;
import cl.mtt.rnt.encargado.dto.ReglamentacionDTO;

@ManagedBean
@ViewScoped
public class MantTipoCertificadoPlantilla implements Serializable {

	private static final long serialVersionUID = 6589848328842519029L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{tipoCertificadoManager}")
	private TipoCertificadoManager tipoCertificadoManager;
	@ManagedProperty(value = "#{certificadoManager}")
	private CertificadoManager certificadoManager;
	@ManagedProperty(value = "#{tipoServicioManager}")
	private TipoServicioManager tipoServicioManager;
	@ManagedProperty(value = "#{reglamentacionManager}")
	private ReglamentacionManager reglamentacionManager;
		

	private Long idTipoCertificado;
	private String TipoCertificadoNuevo;
	private Long idTipoServicio;
	
	private Long idTipoCertificadoReglamentado;

	private List<TipoCertificado> tiposCertificado;
	private TipoCertificado tipoCertificado = new TipoCertificado();
	private List<TipoServicio> tiposServicio;
	private List<ClaseTipoCertificado> clasesTipoCertificado;

	private Map<Long, List<TipoServicio>> tiposServicioPorClase = new HashMap<Long, List<TipoServicio>>();
	List<SelectItem> tiposServicioModificacion;

	private List<NodoCertificado> rootNodes = new ArrayList<NodoCertificado>();
	private TreeNode currentNodeSelection = null;

	private List<SelectItem> tiposServicioSeleccionados;

	private List<NodoCertificado> listaNodos;
	
	private List<ReglamentacionDTO> rootNodesReglamentacion;
	private Reglamentacion reglamentacion;
	private List<Reglamentacion> reglamentacionesSuperiores;

	private TipoCertificadoReglamentado tipoCertReg;
	private List<Certificado> certificados;
	private CertificadoFilter filtroCertificados = null;
	private List<String> materiasAutorizadas;
	
	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		try {
			this.tiposCertificado = tipoCertificadoManager.getAllTiposCertificado();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_TIPOCERTPLANT;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	public List<String> getMateriasAutorizadas() {
		if (materiasAutorizadas==null) {
			materiasAutorizadas=tipoCertificadoManager.getMateriasAutorizadasSelector();
		}
		return materiasAutorizadas;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public void setCertificadoManager(CertificadoManager certificadoManager) {
		this.certificadoManager = certificadoManager;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public TipoCertificadoManager getTipoCertificadoManager() {
		return tipoCertificadoManager;
	}

	public void setTipoCertificadoManager(TipoCertificadoManager tipoCertificadoManager) {
		this.tipoCertificadoManager = tipoCertificadoManager;
	}

	public TipoServicioManager getTipoServicioManager() {
		return tipoServicioManager;
	}

	public void setTipoServicioManager(TipoServicioManager tipoServicioManager) {
		this.tipoServicioManager = tipoServicioManager;
	}

	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	public Long getIdTipoCertificado() {
		return idTipoCertificado;
	}

	public void setIdTipoCertificado(Long idTipoCertificado) {
		this.idTipoCertificado = idTipoCertificado;
	}

	public String getTipoCertificadoNuevo() {
		return TipoCertificadoNuevo;
	}

	public void setTipoCertificadoNuevo(String tipoCertificadoNuevo) {
		TipoCertificadoNuevo = tipoCertificadoNuevo;
	}

	public Long getIdTipoServicio() {
		return idTipoServicio;
	}

	public void setIdTipoServicio(Long idTipoServicio) {
		this.idTipoServicio = idTipoServicio;
	}

	public List<TipoCertificado> getTiposCertificado() {
		return tiposCertificado;
	}

	public void setTiposCertificado(List<TipoCertificado> tiposCertificado) {
		this.tiposCertificado = tiposCertificado;
	}

	public TipoCertificado getTipoCertificado() {
		return tipoCertificado;
	}

	public void setTipoCertificado(TipoCertificado tipoCertificado) {
		this.tipoCertificado = tipoCertificado;
	}

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	/**
	 * @return el valor de clasesTipoCertificado
	 */
	public List<ClaseTipoCertificado> getClasesTipoCertificado() {
		return clasesTipoCertificado;
	}

	/**
	 * @param setea
	 *            el parametro clasesTipoCertificado al campo
	 *            clasesTipoCertificado
	 */
	public void setClasesTipoCertificado(List<ClaseTipoCertificado> clasesTipoCertificado) {
		this.clasesTipoCertificado = clasesTipoCertificado;
	}

	/**
	 * @return el valor de tiposServicioPorClase
	 */
	public Map<Long, List<TipoServicio>> getTiposServicioPorClase() {
		return tiposServicioPorClase;
	}

	/**
	 * @param setea
	 *            el parametro tiposServicioPorClase al campo
	 *            tiposServicioPorClase
	 */
	public void setTiposServicioPorClase(Map<Long, List<TipoServicio>> tiposServicioPorClase) {
		this.tiposServicioPorClase = tiposServicioPorClase;
	}
	
	/**
	 * @return el valor de idTipoCertificadoReglamentado
	 */
	public Long getIdTipoCertificadoReglamentado() {
		return idTipoCertificadoReglamentado;
	}

	/**
	 * @param setea el parametro idTipoCertificadoReglamentado al campo idTipoCertificadoReglamentado
	 */
	public void setIdTipoCertificadoReglamentado(Long idTipoCertificadoReglamentado) {
		this.idTipoCertificadoReglamentado = idTipoCertificadoReglamentado;
	}

	private void limpiarCampos() {
		this.idTipoServicio = null;
		this.rootNodes = new ArrayList<NodoCertificado>();
	}

	public String prepareAgregarTipoCertificado() {
		try {
			this.limpiarCampos();
			
			this.tipoCertificado = new TipoCertificado();
			this.tipoCertificado.setTiposCertificadosReglamentados(new ArrayList<TipoCertificadoReglamentado>());
			tipoCertificado.setSistema(Resources.getString("tipoCert.field.sistema.default"));
			tipoCertificado.setTipoDoc(Resources.getString("tipoCert.field.documento.default"));
			this.clasesTipoCertificado = this.tipoCertificadoManager.getAllClasesTipoCertificcado();
			try {
				this.tipoCertificado.setClaseTipoCertificado(this.clasesTipoCertificado.get(0));
			} catch (Exception e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("servicio.vehiculo.error.sinclasetipo"), FacesMessage.SEVERITY_ERROR);
				return "error_prepareAgregarTipoCertificado";
			}
			this.cargarMapaTiposServicios();

			this.rootNodes.add(tipoCertificado.getClaseTipoCertificado().getSeccionRaiz());
			this.inicializarDatosNodo(this.rootNodes.get(0));
			listaNodos = getNodoList(rootNodes.get(0));
			
			
			

			this.sessionCacheManager.saveState(this);
			return "success_prepareAgregarTipoCertificado";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareAgregarTipoCertificado";
	}

	private void cargarMapaTiposServicios() {
		for (ClaseTipoCertificado clase : this.clasesTipoCertificado) {
			try {
				this.tiposServicioPorClase.put(clase.getId(), this.getTipoServicioManager().getTiposServiciosSinTipoCertificado(clase.getId()));
			} catch (GeneralDataAccessException e) {
				this.tiposServicioPorClase.put(clase.getId(), null);
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void inicializarDatosNodo(NodoCertificado nodo) {
		nodo.setSelected(nodo.getMandatory());
		if (nodo.getChildCount() > 0) {
			for (Enumeration e = nodo.children(); e.hasMoreElements();) {
				inicializarDatosNodo((NodoCertificado) e.nextElement());
			}
		}
	}

	public String guardarTipoCertificado() {
		try {
			//FIXME
//			if(this.tipoCertificado.getReglamentacionEspecifica()!=null && this.tipoCertificado.getReglamentacionEspecifica() && this.tipoCertificado.getReglamentacion() == null){
//				messageBean.addMessage(Resources.getString("tipoCert.error.seleccionarReglamentacion"), FacesMessage.SEVERITY_ERROR);
//				sessionCacheManager.saveState(this);
//				return "error_TipoCertificado_guardar";
//			}
			// Armado de certificado secciones y campos
			tipoCertificado.setSeccion(generarEstructuraCertificado((CertificadoSeccionDefinition) this.rootNodes.get(0)));
//			if(this.tipoCertificado.getReglamentacionEspecifica()!=null && !this.tipoCertificado.getReglamentacionEspecifica())
//				this.tipoCertificado.setReglamentacion(null);
			tipoCertificadoManager.saveTipoCertificado(tipoCertificado);
			this.tiposCertificado = this.tipoCertificadoManager.getAllTiposCertificado();
			this.sessionCacheManager.saveState(this);

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoCertificado_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoCert.error.existeTipoCertificado"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoCertificadoExistente_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarTipoCertificado";
	}

	private CertificadoSeccion generarEstructuraCertificado(CertificadoSeccionDefinition seccionDef) {
		CertificadoSeccion seccion = new CertificadoSeccion();
		if (seccionDef.getUtilizaLabel())
			seccion.setEtiqueta(seccionDef.getEtiqueta());
		seccion.setSeccionDefinition(seccionDef);
		seccion.setSecciones(new ArrayList<CertificadoSeccion>());
		seccion.setCampos(new ArrayList<CertificadoCampo>());

		for (CertificadoSeccionDefinition s : seccionDef.getSecciones()) {
			if (s.getSelected()) {
				CertificadoSeccion hijo = generarEstructuraCertificado(s);
				hijo.setSeccionSuperior(seccion);
				seccion.getSecciones().add(hijo);
			}
		}

		for (CertificadoCampoDefinition c : seccionDef.getCampos()) {
			if (c.getSelected()) {
				CertificadoCampo campo = new CertificadoCampo();
				if (c.getUtilizaLabel())
					campo.setEtiqueta(c.getEtiqueta());
				if (c.getValor() != null)
					campo.setValor(c.getValor());
				campo.setCampoDefinition(c);
				campo.setSeccion(seccion);
				seccion.getCampos().add(campo);
			}
		}

		return seccion;
	}

	private void updateEstructuraCertificado(CertificadoSeccionDefinition seccionDef, CertificadoSeccion raizExistente) {
		CertificadoSeccion seccion = raizExistente;
		if (seccionDef.getUtilizaLabel())
			seccion.setEtiqueta(seccionDef.getEtiqueta());

		for (CertificadoSeccionDefinition s : seccionDef.getSecciones()) {
			if (s.getSelected()) {
				boolean encontrado = false;
				for (CertificadoSeccion csExistente : seccion.getSecciones()) {
					if (csExistente.getSeccionDefinition().getDescriptor().equals(s.getDescriptor())) {
						updateEstructuraCertificado(s, csExistente);
						csExistente.setDbAction(GenericModelObject.ACTION_UPDATE);
						encontrado = true;
					}
				}
				if (!encontrado) {
					CertificadoSeccion hijo = new CertificadoSeccion();
					hijo.setDbAction(GenericModelObject.ACTION_SAVE);
					hijo.setSeccionDefinition(s);
					hijo.setSecciones(new ArrayList<CertificadoSeccion>());
					hijo.setCampos(new ArrayList<CertificadoCampo>());
					hijo.setSeccionSuperior(seccion);
					seccion.getSecciones().add(hijo);
					updateEstructuraCertificado(s, hijo);
				}
			} else {
				for (CertificadoSeccion csExistente : seccion.getSecciones()) {
					if (csExistente.getSeccionDefinition().getDescriptor().equals(s.getDescriptor())) {
						csExistente.setDbAction(GenericModelObject.ACTION_DELETE);
						updateEstructuraCertificado(s, csExistente);
					}
				}

			}
		}

		for (CertificadoCampoDefinition c : seccionDef.getCampos()) {
			if (c.getSelected()) {

				boolean encontrado = false;
				for (CertificadoCampo csExistente : seccion.getCampos()) {
					if (csExistente.getCampoDefinition().getDescriptor().equals(c.getDescriptor())) {
						if (c.getUtilizaLabel())
							csExistente.setEtiqueta(c.getEtiqueta());
						if (c.getValor() != null)
							csExistente.setValor(c.getValor());
						csExistente.setDbAction(GenericModelObject.ACTION_UPDATE);
						encontrado = true;
					}
				}
				if (!encontrado) {
					CertificadoCampo campo = new CertificadoCampo();
					if (c.getUtilizaLabel())
						campo.setEtiqueta(c.getEtiqueta());
					if (c.getValor() != null)
						campo.setValor(c.getValor());
					campo.setCampoDefinition(c);
					campo.setSeccion(seccion);
					campo.setDbAction(GenericModelObject.ACTION_SAVE);
					seccion.getCampos().add(campo);
				}
			} else {
				for (CertificadoCampo csExistente : seccion.getCampos()) {
					if (csExistente.getCampoDefinition().getDescriptor().equals(c.getDescriptor())) {
						csExistente.setDbAction(GenericModelObject.ACTION_DELETE);

					}
				}
			}
		}
	}

	public String eliminarTipoCertificado() {
		try {
			TipoCertificado tipoCert = this.getTipoCertificadoManager().getTipoCertificadoById(this.idTipoCertificado);
			this.getTipoCertificadoManager().removeTipoCertificado(tipoCert);
			this.tiposCertificado = this.getTipoCertificadoManager().getAllTiposCertificado();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoCertificado_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoCert.error.eliminarTipoCertificado"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoCertificado_eliminarNoPermitido";
		}

		messageBean.addMessage(Resources.getString("tipoCert.messages.eliminarTipoCertificado"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarTipoCertificado";
	}

	@SuppressWarnings("rawtypes")
	private void agregarObligatoriosDatosNodo(NodoCertificado nodo) {
		if (nodo.getMandatory().booleanValue())
			nodo.setSelected(true);
		if (nodo.getChildCount() > 0) {
			for (Enumeration e = nodo.children(); e.hasMoreElements();) {
				agregarObligatoriosDatosNodo((NodoCertificado) e.nextElement());
			}
		}
	}

	public String prepararModificarTipoCertificado(TipoCertificado tipoCertificado) {
		try {
			//primero verifico mque no haya certificados sin firmar
			long cantSinFirma = certificadoManager.getCountCertificadosSinFirmar(tipoCertificado.getId());
			if(cantSinFirma>0){
				this.sessionCacheManager.saveState(this);
				messageBean.addMessage(Resources.getString("certificado.error.tieneCertSinFirmar"), FacesMessage.SEVERITY_ERROR);
				return "error_prepararModificarTipoCertificado";
			}
			
			updateCurrentTipoCertificado(tipoCertificado);
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarTipoCertificado";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarTipoCertificado";
	}

	public String prepararVerTipoCertificado(TipoCertificado tipoCertificado) {
		try {
			
			updateCurrentTipoCertificado(tipoCertificado);
			this.sessionCacheManager.saveState(this);
			return "success_prepararVerTipoCertificado";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return null;
	}

	/**
	 * @param tipoCertificado
	 * @throws GeneralDataAccessException
	 */
	private void updateCurrentTipoCertificado(TipoCertificado tipoCertificado)
			throws GeneralDataAccessException {
		tipoCertificado.setTiposCertificadosReglamentados(this.tipoCertificadoManager.getTiposCertificadosReglamentadosByTipoCertificado(tipoCertificado));
		this.setTipoCertificado(tipoCertificado);			
		this.cargarMapaTiposServiciosModificacion(tipoCertificado);
		if (!Hibernate.isInitialized(tipoCertificado.getClaseTipoCertificado().getSeccionRaiz())){
			CertificadoSeccionDefinition secc = tipoCertificadoManager.getCertificadoSeccionDefinitionById(tipoCertificado.getClaseTipoCertificado().getSeccionRaizId());
			tipoCertificado.getClaseTipoCertificado().setSeccionRaiz(secc);
		}
		this.rootNodes.clear();
		this.rootNodes.add(tipoCertificado.getClaseTipoCertificado().getSeccionRaiz());
		this.generarEstructuraCertificadoDefinition(tipoCertificado.getSeccion(), tipoCertificado.getClaseTipoCertificado().getSeccionRaiz());
		agregarObligatoriosDatosNodo(this.rootNodes.get(0));
		
		if (this.rootNodesReglamentacion == null) {
			this.rootNodesReglamentacion = new ArrayList<ReglamentacionDTO>();
		}
		
		List<ReglamentacionDTO> reglamentacionesSeleccionables = reglamentacionManager.getReglamentacionesTipoCertificado(tipoCertificado);
		this.cargarNodosRaiz(reglamentacionesSeleccionables);

		this.tiposServicioModificacion = getSelectItems(getTiposServicioPorClase().get(tipoCertificado.getClaseTipoCertificado().getId()));
		//this.tiposServicioSeleccionados = getSelectItems(tipoCertificado.getTiposServicio());

		listaNodos = getNodoList(rootNodes.get(0));
	}

	private List<SelectItem> getSelectItems(List<TipoServicio> list) {
		List<SelectItem> sitems = new ArrayList<SelectItem>(list.size());
		for (TipoServicio tipoServicio : list) {
			SelectItem si = new SelectItem();
			si.setLabel(tipoServicio.getName());
			si.setValue(tipoServicio.getId());
			sitems.add(si);
		}
		return sitems;
	}

	private void cargarMapaTiposServiciosModificacion(TipoCertificado tipoCertificado) {
		try {
			List<TipoServicio> tiposServ = new ArrayList<TipoServicio>();			
//			if(tipoCertificado.getReglamentacionEspecifica()!=null && tipoCertificado.getReglamentacionEspecifica()){
//				tiposServ = this.getTipoServicioManager().getTiposServicio();
//				tiposServ.addAll(tipoCertificado.getTiposServicio());
//			}
//			else {
//				tiposServ = this.getTipoServicioManager().getTiposServiciosSinTipoCertificado(tipoCertificado.getClaseTipoCertificado().getId());
//				tiposServ.addAll(tipoCertificado.getTiposServicio());				
//			}
			
			this.tiposServicioPorClase.put(tipoCertificado.getClaseTipoCertificado().getId(), tiposServ);
			
		} catch (Exception e) {
			this.tiposServicioPorClase.put(tipoCertificado.getClaseTipoCertificado().getId(), null);
		}
	}

	public String modificarTipoCertificado() {
		try {
		//	if(this.tipoCertificado.getReglamentacionEspecifica() && this.tipoCertificado.getReglamentacion() == null){
//				messageBean.addMessage(Resources.getString("tipoCert.error.seleccionarReglamentacion"), FacesMessage.SEVERITY_ERROR);
//				sessionCacheManager.saveState(this);
//				return "error_TipoCertificado_modificar";
//			}
//			if(this.tipoCertificado.getReglamentacionEspecifica()!=null && !this.tipoCertificado.getReglamentacionEspecifica())
//				this.tipoCertificado.setReglamentacion(null);
			updateEstructuraCertificado((CertificadoSeccionDefinition) this.rootNodes.get(0), tipoCertificado.getSeccion());
			tipoCertificadoManager.updateTipoCertificado(tipoCertificado);
			this.tiposCertificado = tipoCertificadoManager.getAllTiposCertificado();
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_TipoCertificado_modificar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoCert.error.existeTipoCertificado"), FacesMessage.SEVERITY_ERROR);
			return "error_TipoCertificadoExistente_modificar";
		}

		this.sessionCacheManager.saveState(this);
		return "success_modificarTipoCertificado";
	}

	public void actualizarFilas() {
		try {
			this.tiposCertificado = this.tipoCertificadoManager.getAllTiposCertificado();
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public String revertirModificarTipoCertificado() {

		try {

			int index = tiposCertificado.indexOf(tipoCertificado);
			TipoCertificado tipoCertificadoById = this.getTipoCertificadoManager().getTipoCertificadoById(tipoCertificado.getId());
			tiposCertificado.set(index, tipoCertificado);

			return prepararModificarTipoCertificado(tipoCertificadoById);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		sessionCacheManager.saveState(this);
		return "error_TipoCertificadoExistente_modificar";

	}

	public List<NodoCertificado> getRootNodes() {
		return rootNodes;
	}

	public void setRootNodes(List<NodoCertificado> rootNodes) {
		this.rootNodes = rootNodes;
	}

	public TreeNode getCurrentNodeSelection() {
		return currentNodeSelection;
	}

	public void setCurrentNodeSelection(TreeNode currentNodeSelection) {
		this.currentNodeSelection = currentNodeSelection;
	}

	public void selectionNodeChanged(TreeSelectionChangeEvent selectionChangeEvent) {
		// considering only single selection
		List<Object> selection = new ArrayList<Object>(selectionChangeEvent.getNewSelection());
		Object currentSelectionKey = selection.get(0);
		UITree tree = (UITree) selectionChangeEvent.getSource();

		Object storedKey = tree.getRowKey();
		tree.setRowKey(currentSelectionKey);
		currentNodeSelection = (TreeNode) tree.getRowData();
		tree.setRowKey(storedKey);
	}

	public void actualizarNodos(AjaxBehaviorEvent event) {
		if (this.tipoCertificado.getClaseTipoCertificado() != null) {
			this.rootNodes.clear();
			ClaseTipoCertificado ctc;
			try {
				ctc = this.tipoCertificadoManager.getClaseTipoCertificadoById(this.tipoCertificado.getClaseTipoCertificado().getId());
				this.rootNodes.add(ctc.getSeccionRaiz());
			//	this.tipoCertificado.setTiposServicio(new ArrayList<TipoServicio>());

				inicializarDatosNodo(this.rootNodes.get(0));
				this.listaNodos = getNodoList(this.rootNodes.get(0));

			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			}

		} else {
			this.rootNodes = new ArrayList<NodoCertificado>();
		}
	}

	public String getXsd(TipoCertificado tipoCert) {
		FacesContext context = FacesContext.getCurrentInstance();
		try {

			HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
			response.setContentType("application/xsd");
			response.setHeader("Content-Disposition", "attachment;filename=\"" + tipoCert.getMateria() + ".xsd" + "\"");

			CertificadoXMLUtil util = new CertificadoXMLUtil();
			String xsdStr = util.getCertificadoXSDasString(tipoCert.getSeccion());

			ServletOutputStream outputStream = response.getOutputStream();
			outputStream.write(xsdStr.getBytes());

			outputStream.flush();
			outputStream.close();
		} catch (IOException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (ParserConfigurationException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.tipocertificado.parse"), FacesMessage.SEVERITY_ERROR);
		}

		FacesContext.getCurrentInstance().responseComplete();
		return "";
	}

	private CertificadoSeccionDefinition generarEstructuraCertificadoDefinition(CertificadoSeccion seccion, CertificadoSeccionDefinition seccionDef) {

		if (seccionDef.getUtilizaLabel())
			seccionDef.setEtiqueta(seccion.getEtiqueta());

		seccion.getSeccionDefinition().setSelected(true);

		for (CertificadoSeccion s : seccion.getSecciones()) {
			s.setSeccionDefinition(generarEstructuraCertificadoDefinition(s, s.getSeccionDefinition()));

		}

		for (CertificadoCampo c : seccion.getCampos()) {
			c.getCampoDefinition().setSelected(true);
			if (c.getCampoDefinition().getUtilizaLabel())
				c.getCampoDefinition().setEtiqueta(c.getEtiqueta());
			if (c.getValor() != null) {
				c.getCampoDefinition().setValor(c.getValor());
			}
		}

		return seccionDef;
	}

	/**
	 * @return el valor de tiposServicioModificacion
	 */
	public List<SelectItem> getTiposServicioModificacion() {
		return tiposServicioModificacion;
	}

	/**
	 * @param setea
	 *            el parametro tiposServicioModificacion al campo
	 *            tiposServicioModificacion
	 */
	public void setTiposServicioModificacion(List<SelectItem> tiposServicioModificacion) {
		this.tiposServicioModificacion = tiposServicioModificacion;
	}

	/**
	 * @return el valor de tiposServicioSeleccionados
	 */
	public List<SelectItem> getTiposServicioSeleccionados() {
		return tiposServicioSeleccionados;
	}

	/**
	 * @param setea
	 *            el parametro tiposServicioSeleccionados al campo
	 *            tiposServicioSeleccionados
	 */
	public void setTiposServicioSeleccionados(List<SelectItem> tiposServicioSeleccionados) {
		this.tiposServicioSeleccionados = tiposServicioSeleccionados;
	}

	private List<NodoCertificado> getNodoList(NodoCertificado nc) {
		List<NodoCertificado> reto = new ArrayList<NodoCertificado>();
		buildNodoList(reto, nc, 0);
		return reto;
	}

	private void buildNodoList(List<NodoCertificado> lista, NodoCertificado nc, int level) {
		if (nc != null) {
			nc.setDeep(level);
			lista.add(nc);
			for (int i = 0; i < nc.getChildCount(); i++) {
				buildNodoList(lista, (NodoCertificado) nc.getChildAt(i), level + 1);
			}
		}
	}

	/**
	 * @return el valor de listaNodos
	 */
	public List<NodoCertificado> getListaNodos() {
		return listaNodos;
	}

	/**
	 * @param setea
	 *            el parametro listaNodos al campo listaNodos
	 */
	public void setListaNodos(List<NodoCertificado> listaNodos) {
		this.listaNodos = listaNodos;
	}

	
	public List<ReglamentacionDTO> getRootNodesReglamentacion() {		
		return rootNodesReglamentacion;
	}
	
	private void cargarNodosRaiz(List<ReglamentacionDTO> reglamentaciones) {
		for (Iterator<ReglamentacionDTO> iterator = reglamentaciones.iterator(); iterator.hasNext();) {
			ReglamentacionDTO reglamentacionDTO = iterator.next();
			if (!reglamentacionDTO.getTienePadre())
				rootNodesReglamentacion.add(reglamentacionDTO);
		}
	}
	
	public void cargarReglamentacion(Reglamentacion reg) {
		try {
			this.reglamentacion = reg;
			updateReglamentacionesSuperiores(reglamentacion);
			this.tipoCertReg.setReglamentacion(reglamentacion);
			actualizarTiposServicios();
		//	this.tipoCertificado.setReglamentacion(reglamentacion);			
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		sessionCacheManager.saveState(this);
	}


	public void setRootNodesReglamentacion(List<ReglamentacionDTO> rootNodesReglamentacion) {
		this.rootNodesReglamentacion = rootNodesReglamentacion;
	}

	/**
	 * @return el valor de reglamentacionManager
	 */
	public ReglamentacionManager getReglamentacionManager() {
		return reglamentacionManager;
	}

	/**
	 * @param setea el parametro reglamentacionManager al campo reglamentacionManager
	 */
	public void setReglamentacionManager(ReglamentacionManager reglamentacionManager) {
		this.reglamentacionManager = reglamentacionManager;
	}

	/**
	 * @return el valor de reglamentacion
	 */
	public Reglamentacion getReglamentacion() {
		return reglamentacion;
	}

	/**
	 * @param setea el parametro reglamentacion al campo reglamentacion
	 */
	public void setReglamentacion(Reglamentacion reglamentacion) {
		this.reglamentacion = reglamentacion;
	}
	
	private void updateReglamentacionesSuperiores(Reglamentacion reglamentacionInicial) throws GeneralDataAccessException {
		reglamentacionesSuperiores = new ArrayList<Reglamentacion>();
		Reglamentacion reg = reglamentacionInicial;
		while (reg != null) {
			reglamentacionesSuperiores.add(reg);
			if (reg.getEspecificadaSobreExistente()) {
			    if (reg.getIdReglamentacionSuperior()!=null) {
                    reg.setReglamentacionDeQueDepende(reglamentacionManager.getReglamentacionById(reg.getIdReglamentacionSuperior()));
                }
				reg = reg.getReglamentacionDeQueDepende();
			} else {
				reg = null;
			}
		}
		Collections.reverse(reglamentacionesSuperiores);
	}

	/**
	 * @return el valor de reglamentacionesSuperiores
	 */
	public List<Reglamentacion> getReglamentacionesSuperiores() {
		return reglamentacionesSuperiores;
	}

	/**
	 * @param setea el parametro reglamentacionesSuperiores al campo reglamentacionesSuperiores
	 */
	public void setReglamentacionesSuperiores(List<Reglamentacion> reglamentacionesSuperiores) {
		this.reglamentacionesSuperiores = reglamentacionesSuperiores;
	}
	
	public void actualizarTiposServicios(){
		try {		
			List<TipoServicio> tiposServ = new ArrayList<TipoServicio>();
			
			//Es seleccionado como default
			if (this.tipoCertReg.getAplicaTodasReglamentaciones()!=null && 
					(this.tipoCertReg.getAplicaTodasReglamentaciones())) {
				tiposServ = this.getTipoServicioManager().getTiposServiciosSinTipoCertificado(tipoCertificado.getClaseTipoCertificado().getId());
				tiposServ.addAll(tipoCertReg.getTiposServicio());
			}
			else {
				//si tengo reglamentacion Seleccionada
				tiposServ = this.getTipoServicioManager().getTiposServiciosDisponiblesCertificadoReglamentacion(tipoCertificado.getClaseTipoCertificado().getId(),tipoCertReg.getReglamentacion().getId());
				tiposServ.addAll(tipoCertReg.getTiposServicio());
			}			
			this.tiposServicioPorClase.put(tipoCertificado.getClaseTipoCertificado().getId(), tiposServ);
			
						
		} catch (Exception e) {
			this.tiposServicioPorClase.put(tipoCertificado.getClaseTipoCertificado().getId(), null);
		}
	}
		
	public void eliminarTipoCertificadoReglamentado(TipoCertificadoReglamentado tcr) {
		tcr.setDbActionAnterior(tcr.getDbAction());
		if (tcr.getDbAction() != GenericModelObject.ACTION_SAVE) {
			tcr.setDbAction(GenericModelObject.ACTION_DELETE);
		} else {
			tipoCertificado.getTiposCertificadosReglamentados().remove(tcr);
		}
	}
	
	public void revertirEliminar(TipoCertificadoReglamentado tcr) {
		tcr.setDbAction(tcr.getDbActionAnterior());		
	}
		
	public String prepararModificarTipoCertificadoReglamentado(TipoCertificadoReglamentado tcr){
		if(tcr.getReglamentacion()==null)
			tcr.setAplicaTodasReglamentaciones(Boolean.TRUE);
		this.setTipoCertReg(tcr);
		this.actualizarTiposServicios();
		sessionCacheManager.saveState(this);
		return "success_prepararModificarTipoCertificadoReglamentado";
	}
	
	/**
	 * Prepara la pagina par la carga de tipos.
	 * @return
	 */
	public String prepararConfigurarTc() {
		try {
			tipoCertReg = new TipoCertificadoReglamentado();
			tipoCertReg.setTipoCertificado(tipoCertificado);
			tipoCertReg.setTiposServicio(new ArrayList<TipoServicio>());
			tipoCertReg.setAplicaTodasReglamentaciones(Boolean.TRUE);
			tipoCertReg.setAplicaHijas(Boolean.TRUE);
			reglamentacionesSuperiores = null;
			reglamentacion = null;
			actualizarTiposServicios();
			this.rootNodesReglamentacion = new ArrayList<ReglamentacionDTO>();
			List<ReglamentacionDTO> reglamentacionesSeleccionables = reglamentacionManager.getReglamentacionesTipoCertificado(tipoCertificado);
			marcarSeleccionables(reglamentacionesSeleccionables,null);
			this.cargarNodosRaiz(reglamentacionesSeleccionables);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "errors_prepararConfigurar";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "errors_prepararConfigurar";
		}
		
		finally {
			sessionCacheManager.saveState(this);
		}
		return "success_prepararConfigurar";
	}

	private void marcarSeleccionables(List<ReglamentacionDTO> reglamentacionesSeleccionables, Reglamentacion regTcr) {
		if (reglamentacionesSeleccionables != null) {
			for (ReglamentacionDTO reglamentacionDTO : reglamentacionesSeleccionables) {
				if (this.tipoCertificado.getTiposCertificadosReglamentados()!=null) {
					for (TipoCertificadoReglamentado tcrList : this.tipoCertificado.getTiposCertificadosReglamentados()) {
						
						///modificacion
						if (regTcr!=null) {
							//si esta en otro TCR no se puede elegir
							if (!regTcr.equals(tcrList)){
								if ((tcrList.getReglamentacion()!=null)&&(reglamentacionDTO.getReglamentacion().getId().equals(tcrList.getReglamentacion().getId()))) {
									reglamentacionDTO.setSeleccionable(Boolean.FALSE);
								}
							}
						}
						//add
						else {
							//si esta en otro TCR no se puede elegir
							if ((tcrList.getReglamentacion()!=null)&&(reglamentacionDTO.getReglamentacion().getId().equals(tcrList.getReglamentacion().getId()))) {
								reglamentacionDTO.setSeleccionable(Boolean.FALSE);
							}
						}
					}
				}
			}
		}
		
	}

	/**
	 * @return el valor de tipoCertReg
	 */
	public TipoCertificadoReglamentado getTipoCertReg() {
		return tipoCertReg;
	}

	/**
	 * @param setea el parametro tipoCertReg al campo tipoCertReg
	 */
	public void setTipoCertReg(TipoCertificadoReglamentado tipoCertReg) {
		this.tipoCertReg = tipoCertReg;
	}
	
	
	public String agregarReglaTc() {
		if (!validarTipoCertificadoReglamentado(tipoCertReg)) {
			sessionCacheManager.saveState(this);
			return "error_reglaAsignacion";
		}
		if (this.tipoCertificado.getTiposCertificadosReglamentados()==null) {
			this.tipoCertificado.setTiposCertificadosReglamentados(new ArrayList<TipoCertificadoReglamentado>());
		}
		this.tipoCertReg.setDbAction(GenericModelObject.ACTION_SAVE);
		this.tipoCertificado.getTiposCertificadosReglamentados().add(this.tipoCertReg);
		sessionCacheManager.saveState(this);
		//error   error_reglaAsignacion
		
		if (this.tipoCertificado.getId()!= null) {
			return "success_reglaAsignacion_fromedit";
		}
		else {
			return "success_reglaAsignacion_fromadd";
		}
		
	}
	
	private boolean validarTipoCertificadoReglamentado(TipoCertificadoReglamentado tipoCertRegValidar) {
		//valido que no existe una regla con aplica a todas
		if (tipoCertRegValidar.getAplicaTodasReglamentaciones()) {
			for (TipoCertificadoReglamentado tcr : tipoCertificado.getTiposCertificadosReglamentados()) {
				if (!tcr.equals(tipoCertRegValidar)) {
					if ((tcr.getAplicaTodasReglamentaciones()!= null) && (tcr.getAplicaTodasReglamentaciones().booleanValue())) {
						messageBean.addMessage(Resources.getString("tipoCert.error.existeTipoCertificadoReglamentadoDefault"), FacesMessage.SEVERITY_ERROR);
						return false;
					}
				}
			}
		}
		return true;
	}

	public String modificarReglaTc() {
		if(this.getTipoCertReg().getDbAction()!= GenericModelObject.ACTION_SAVE)
			this.getTipoCertReg().setDbAction(GenericModelObject.ACTION_UPDATE);
		sessionCacheManager.saveState(this);
		if (this.tipoCertificado.getId()!= null) {
			return "success_reglaAsignacion_fromedit";
		}
		else {
			return "success_reglaAsignacion_fromadd";
		}		
	}
	
	public String cancelarReglaTc() {
		sessionCacheManager.saveState(this);
		if (this.tipoCertificado.getId()!= null) {
			return "success_reglaAsignacion_fromedit";
		}
		else {
			return "success_reglaAsignacion_fromadd";
		}
		
	}
		
	public List<Certificado> getCertificados() {
		return certificados;
	}

	public void setCertificados(List<Certificado> certificados) {
		this.certificados = certificados;
	}

	public void filtrar(){
		try {
			certificados=certificadoManager.getCertificadosFiltrados(filtroCertificados);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
	public void limpiar(){
		filtroCertificados=new CertificadoFilter();
		filtroCertificados.setTipoCertificado(tipoCertificado.getId());
		filtroCertificados.generarEstadosFirma(false);
		filtroCertificados.check("sinFirmar", true);
		try {
			certificados=certificadoManager.getCertificadosFiltrados(filtroCertificados);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
	public String verCertificados(TipoCertificado tipoCert){
		try {
			tipoCertificado=tipoCert;
			filtroCertificados=new CertificadoFilter();
			filtroCertificados.setTipoCertificado(tipoCertificado.getId());
			filtroCertificados.generarEstadosFirma(false);
			filtroCertificados.check("sinFirmar", true);
			certificados=certificadoManager.getCertificadosFiltrados(filtroCertificados);

			sessionCacheManager.saveState(this);
			return "success_verCertificados";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		sessionCacheManager.saveState(this);
		return null;
	}

	public CertificadoFilter getFiltroCertificados() {
		return filtroCertificados;
	}

	public void setFiltroCertificados(CertificadoFilter filtroCertificados) {
		this.filtroCertificados = filtroCertificados;
	}
	
	
	
}