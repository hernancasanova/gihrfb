package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;

@ManagedBean
@ViewScoped
public class MantTipoDocReqBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2098560791218393472L;
	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;

	private String categoriaNueva;

	public String getCategoriaNueva() {
		return categoriaNueva;
	}

	public String prepareMantenedor() {

		return RedirectConstants.SEL_TABLA_TO_MANT_TIPODOC;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

}