package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.TipoServicioArea;
import cl.mtt.rnt.commons.service.TipoServicioAreaManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantTipoServicioAreaBean implements Serializable {

	private static final long serialVersionUID = 2912710549550611385L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{tipoServicioAreaManager}")
	private TipoServicioAreaManager tipoServicioAreaManager;

	private Long idTipoServicioArea;
	private String tipoServicioAreaNuevo;

	private List<TipoServicioArea> tiposServicioArea;
	private TipoServicioArea tipoServicioArea = new TipoServicioArea();

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public TipoServicioAreaManager getTipoServicioAreaManager() {
		return tipoServicioAreaManager;
	}

	public void setTipoServicioAreaManager(TipoServicioAreaManager tipoServicioAreaManager) {
		this.tipoServicioAreaManager = tipoServicioAreaManager;
	}

	public Long getIdTipoServicioArea() {
		return idTipoServicioArea;
	}

	public void setIdTipoServicioArea(Long idTipoServicioArea) {
		this.idTipoServicioArea = idTipoServicioArea;
	}

	public String getTipoServicioAreaNuevo() {
		return tipoServicioAreaNuevo;
	}

	public void setTipoServicioAreaNuevo(String tipoServicioAreaNuevo) {
		this.tipoServicioAreaNuevo = tipoServicioAreaNuevo;
	}

	public List<TipoServicioArea> getTiposServicioArea() {
		return tiposServicioArea;
	}

	public void setTiposServicioArea(List<TipoServicioArea> tiposServicioArea) {
		this.tiposServicioArea = tiposServicioArea;
	}

	public TipoServicioArea getTipoServicioArea() {
		return tipoServicioArea;
	}

	public void setTipoServicioArea(TipoServicioArea tipoServicioArea) {
		this.tipoServicioArea = tipoServicioArea;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		try {
			this.tiposServicioArea = tipoServicioAreaManager.getAllTipoServicioArea();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_TIPOSERVICIOAREA;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	public String guardarTipoServicioArea() {
		try {
			tipoServicioArea.setNombre(this.getTipoServicioAreaNuevo());
			tipoServicioAreaManager.saveTipoServicioArea(tipoServicioArea);
			this.tiposServicioArea = tipoServicioAreaManager.getAllTipoServicioArea();
			this.getSessionCacheManager().saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_TipoServicioAreaExistente_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoServicioArea.error.existeTipoServicioArea"), FacesMessage.SEVERITY_ERROR);
			return "error_TipoServicioArea_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarTipoServicioArea";
	}

	public String prepararModificarTipoServicioArea(TipoServicioArea tipoServicioArea) {
		try {
			this.setTipoServicioArea(tipoServicioArea);
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarTipoServicioArea";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarTipoServicioArea";
	}

	public String modificarTipoServicioArea() {
		try {
			tipoServicioAreaManager.updateTipoServicioArea(tipoServicioArea);
			this.sessionCacheManager.saveState(this);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoServicioArea.error.existeTipoServicioArea"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoServicioAreaExistente_modificar";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoServicioArea_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarTipoServicioArea";
	}

	public String revertirModificarTipoServicioArea() {
		try {
			int index = tiposServicioArea.indexOf(tipoServicioArea);
			this.setTipoServicioArea(this.getTipoServicioAreaManager().getTipoServicioAreaById(tipoServicioArea.getId()));
			tiposServicioArea.set(index, tipoServicioArea);

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_revertirModificarTipoServicioArea";
		}
		this.sessionCacheManager.saveState(this);
		return "success_revertirModificarTipoServicioArea";

	}

	public String eliminarTipoServicioArea() {
		try {
			TipoServicioArea tipoServicioArea = this.getTipoServicioAreaManager().getTipoServicioAreaById(this.getIdTipoServicioArea());
			this.getTipoServicioAreaManager().removeTipoServicioArea(tipoServicioArea);
			this.tiposServicioArea = tipoServicioAreaManager.getAllTipoServicioArea();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoServicioArea_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoServicioArea.error.eliminarTipoServicioArea"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoServicioArea_eliminarNoPermitido";
		}

		messageBean.addMessage(Resources.getString("tipoServicioArea.messages.eliminarTipoServicioArea"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarTipoServicioArea";
	}
}
