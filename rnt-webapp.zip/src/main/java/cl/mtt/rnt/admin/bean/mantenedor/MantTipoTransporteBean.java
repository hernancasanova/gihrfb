package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.service.TipoTransporteManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantTipoTransporteBean implements Serializable {

	private static final long serialVersionUID = 2912710549550611385L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{tipoTransporteManager}")
	private TipoTransporteManager tipoTransporteManager;

	private Long idTipoTransporte;
	private String tipoTransporteNuevo;

	private List<TipoTransporte> tiposTransporte;
	private TipoTransporte tipoTransporte = new TipoTransporte();

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public String getTipoTransporteNuevo() {
		return tipoTransporteNuevo;
	}

	public void setTipoTransporteNuevo(String tipoTransporteNuevo) {
		this.tipoTransporteNuevo = tipoTransporteNuevo;
	}

	public List<TipoTransporte> getTiposTransporte() {
		return tiposTransporte;
	}

	public void setTiposTransporte(List<TipoTransporte> tiposTransporte) {
		this.tiposTransporte = tiposTransporte;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public TipoTransporteManager getTipoTransporteManager() {
		return tipoTransporteManager;
	}

	public void setTipoTransporteManager(TipoTransporteManager tipoTransporteManager) {
		this.tipoTransporteManager = tipoTransporteManager;
	}

	public Long getIdTipoTransporte() {
		return idTipoTransporte;
	}

	public void setIdTipoTransporte(Long idTipoTransporte) {
		this.idTipoTransporte = idTipoTransporte;
	}

	public TipoTransporte getTipoTransporte() {
		return tipoTransporte;
	}

	public void setTipoTransporte(TipoTransporte tipoTransporte) {
		this.tipoTransporte = tipoTransporte;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		try {
			this.tiposTransporte = tipoTransporteManager.getAllTiposTransporte();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_TIPOTRANSPORTE;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	public String guardarTipoTransporte() {
		try {
			tipoTransporte.setNombre(this.getTipoTransporteNuevo());
			tipoTransporteManager.saveTipoTransporte(tipoTransporte);
			this.tiposTransporte = tipoTransporteManager.getAllTiposTransporte();
			this.getSessionCacheManager().saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_TipoTransporteExistente_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoTransporte.error.existeTipoTransporte"), FacesMessage.SEVERITY_ERROR);
			return "error_TipoTransporte_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarTipoTransporte";
	}

	public String prepararModificarTipoTransporte(TipoTransporte tipoTransporte) {
		try {
			this.setTipoTransporte(tipoTransporte);
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarTipoTransporte";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarTipoTransporte";
	}

	public String modificarTipoTransporte() {
		try {
			tipoTransporteManager.updateTipoTransporte(tipoTransporte);
			this.sessionCacheManager.saveState(this);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoTransporte.error.existeTipoTransporte"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoTransporteExistente_modificar";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoTransporte_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarTipoTransporte";
	}

	public String revertirModificarTipoTransporte() {
		try {
			int index = tiposTransporte.indexOf(tipoTransporte);
			this.setTipoTransporte(this.getTipoTransporteManager().getTipoTransporteById(tipoTransporte.getId()));
			tiposTransporte.set(index, tipoTransporte);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_revertirModificarTipoTransporte";
		}
		this.sessionCacheManager.saveState(this);
		return "success_revertirModificarTipoTransporte";

	}

	public String eliminarTipoTransporte() {
		try {
			TipoTransporte tipoTransporte = this.getTipoTransporteManager().getTipoTransporteById(this.getIdTipoTransporte());
			this.getTipoTransporteManager().removeTipoTransporte(tipoTransporte);
			this.tiposTransporte = tipoTransporteManager.getAllTiposTransporte();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoTransporte_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoTransporte.error.eliminarTipoTransporte"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoTransporte_eliminarNoPermitido";
		}

		messageBean.addMessage(Resources.getString("tipoTransporte.messages.eliminarTipoTransporte"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarTipoTransporte";
	}

}
