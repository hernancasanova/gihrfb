package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.TipoVehiculoServicio;
import cl.mtt.rnt.commons.service.TipoVehiculoServicioManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class MantTipoVehiculoServicioBean implements Serializable {

	private static final long serialVersionUID = 7338359063590794706L;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{tipoVehiculoServicioManager}")
	private TipoVehiculoServicioManager tipoVehiculoServicioManager;

	private Long idTipoVehiculoServicio;
	private String tipoVehiculoServicioNuevo;

	private List<TipoVehiculoServicio> tiposVehiculoServicio;
	private TipoVehiculoServicio tipoVehiculoServicio = new TipoVehiculoServicio();

	/**
	 * @return el valor de currentSessionBean
	 */
	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	/**
	 * @param setea
	 *            el parametro currentSessionBean al campo currentSessionBean
	 */
	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	/**
	 * @return el valor de messageBean
	 */
	public MessageBean getMessageBean() {
		return messageBean;
	}

	/**
	 * @param setea
	 *            el parametro messageBean al campo messageBean
	 */
	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	/**
	 * @return el valor de sessionCacheManager
	 */
	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	/**
	 * @param setea
	 *            el parametro sessionCacheManager al campo sessionCacheManager
	 */
	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	/**
	 * @return el valor de tipoVehiculoServicioManager
	 */
	public TipoVehiculoServicioManager getTipoVehiculoServicioManager() {
		return tipoVehiculoServicioManager;
	}

	/**
	 * @param setea
	 *            el parametro tipoVehiculoServicioManager al campo
	 *            tipoVehiculoServicioManager
	 */
	public void setTipoVehiculoServicioManager(TipoVehiculoServicioManager tipoVehiculoServicioManager) {
		this.tipoVehiculoServicioManager = tipoVehiculoServicioManager;
	}

	/**
	 * @return el valor de idtipoVehiculoServicio
	 */
	public Long getIdTipoVehiculoServicio() {
		return idTipoVehiculoServicio;
	}

	/**
	 * @param setea
	 *            el parametro idtipoVehiculoServicio al campo
	 *            idtipoVehiculoServicio
	 */
	public void setIdTipoVehiculoServicio(Long idTipoVehiculoServicio) {
		this.idTipoVehiculoServicio = idTipoVehiculoServicio;
	}

	/**
	 * @return el valor de tipoVehiculoServicioNuevo
	 */
	public String getTipoVehiculoServicioNuevo() {
		return tipoVehiculoServicioNuevo;
	}

	/**
	 * @param setea
	 *            el parametro tipoVehiculoServicioNuevo al campo
	 *            tipoVehiculoServicioNuevo
	 */
	public void setTipoVehiculoServicioNuevo(String tipoVehiculoServicioNuevo) {
		this.tipoVehiculoServicioNuevo = tipoVehiculoServicioNuevo;
	}

	/**
	 * @return el valor de tiposVehiculoServicio
	 */
	public List<TipoVehiculoServicio> getTiposVehiculoServicio() {
		return tiposVehiculoServicio;
	}

	/**
	 * @param setea
	 *            el parametro tiposVehiculoServicio al campo
	 *            tiposVehiculoServicio
	 */
	public void setTiposVehiculoServicio(List<TipoVehiculoServicio> tiposVehiculoServicio) {
		this.tiposVehiculoServicio = tiposVehiculoServicio;
	}

	/**
	 * @return el valor de tipoVehiculoServicio
	 */
	public TipoVehiculoServicio getTipoVehiculoServicio() {
		return tipoVehiculoServicio;
	}

	/**
	 * @param setea
	 *            el parametro tipoVehiculoServicio al campo
	 *            tipoVehiculoServicio
	 */
	public void setTipoVehiculoServicio(TipoVehiculoServicio tipoVehiculoServicio) {
		this.tipoVehiculoServicio = tipoVehiculoServicio;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		try {
			this.tiposVehiculoServicio = tipoVehiculoServicioManager.getAllTiposVehiculoServicio();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_TIPOVEHICULOSERVICIO;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	public String prepareAgregarTipoVehiculoServicio() {
		try {
			this.limpiarCampos();
			this.sessionCacheManager.saveState(this);
			return "success_prepareAgregarTipoVehiculoServicio";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareAgregarTipoVehiculoServicio";
	}

	public String guardarTipoVehiculoServicio() {
		try {
			tipoVehiculoServicio.setNombre(this.getTipoVehiculoServicioNuevo());
			tipoVehiculoServicioManager.saveTipoVehiculoServicio(tipoVehiculoServicio);
			this.tiposVehiculoServicio = tipoVehiculoServicioManager.getAllTiposVehiculoServicio();
			this.getSessionCacheManager().saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_TipoVehiculoServicioExistente_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoVehiculoServicio.error.existeTipoVehiculoServicio"), FacesMessage.SEVERITY_ERROR);
			return "error_TipoVehiculoServicio_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarTipoVehiculoServicio";
	}

	public String prepararModificarTipoVehiculoServicio(TipoVehiculoServicio tipoVehiculoServicio) {
		try {
			this.setTipoVehiculoServicio(tipoVehiculoServicio);
			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarTipoVehiculoServicio";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarTipoVehiculoServicio";
	}

	public String modificarTipoVehiculoServicio() {
		try {
			tipoVehiculoServicioManager.updateTipoVehiculoServicio(tipoVehiculoServicio);
			this.sessionCacheManager.saveState(this);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoVehiculoServicio.error.existeTipoVehiculoServicio"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoVehiculoServicioExistente_modificar";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoVehiculoServicio_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarTipoVehiculoServicio";
	}

	public String revertirModificarTipoVehiculoServicio() {
		try {
			int index = tiposVehiculoServicio.indexOf(tipoVehiculoServicio);
			this.setTipoVehiculoServicio(this.getTipoVehiculoServicioManager().getTipoVehiculoServicioById(tipoVehiculoServicio.getId()));
			tiposVehiculoServicio.set(index, tipoVehiculoServicio);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_revertirModificarTipoVehiculoServicio";
		}
		this.sessionCacheManager.saveState(this);
		return "success_revertirModificarTipoVehiculoServicio";

	}

	public String eliminarTipoVehiculoServicio() {
		try {
			TipoVehiculoServicio tipoVehiculoServicio = this.getTipoVehiculoServicioManager().getTipoVehiculoServicioById(this.getIdTipoVehiculoServicio());
			this.getTipoVehiculoServicioManager().removeTipoVehiculoServicio(tipoVehiculoServicio);
			this.tiposVehiculoServicio = tipoVehiculoServicioManager.getAllTiposVehiculoServicio();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoVehiculoServicio_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("tipoVehiculoServicio.error.eliminarTipoVehiculoServicio"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_TipoVehiculoServicio_eliminarNoPermitido";
		}

		messageBean.addMessage(Resources.getString("tipoVehiculoServicio.messages.eliminarTipoVehiculoServicio"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarTipoVehiculoServicio";
	}

	private void limpiarCampos() {
		this.tipoVehiculoServicio = new TipoVehiculoServicio();
		this.idTipoVehiculoServicio = null;
		this.tipoVehiculoServicioNuevo = null;
	}
}
