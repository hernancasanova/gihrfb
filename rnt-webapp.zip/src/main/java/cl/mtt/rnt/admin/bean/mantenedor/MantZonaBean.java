package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.TipoZona;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Localidad;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.MarcoGeograficoManager;
import cl.mtt.rnt.commons.service.TipoZonaManager;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;

@ManagedBean
@ViewScoped
public class MantZonaBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1718367025053182189L;

	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;
	@ManagedProperty(value = "#{marcoGeograficoManager}")
	private MarcoGeograficoManager marcoGeograficoManager;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{zonaManager}")
	private ZonaManager zonaManager;
	@ManagedProperty(value = "#{tipoZonaManager}")
	private TipoZonaManager tipoZonaManager;

	private String idRegionFiltro;
	private Long idTipoZonaFiltro;

	private String idRegionSeleccionada;
	private Long idTipoZonaSeleccionado;
	private String idRegionComuna;
	private String idRegionLocalidad;
	private String idComunaLocalidad;

	private List<Region> regiones;
	private List<Comuna> comunas;
	private List<Comuna> comunasSeleccion;
	private List<Localidad> localidades;
	private List<TipoZona> tiposZona;
	private List<Region> regionesSeleccionadas;
	private List<Comuna> comunasSeleccionadas;
	private List<Localidad> localidadesSeleccionadas;
	private String[] idsComunasSeleccionadas;
	private String[] idsLocalidadessSeleccionadas;

	private Zona zona;
	private Long idZona;
	private List<Zona> zonas;

	private int totalListSize;
	private Map<Long, Boolean> removableZones;

	private String descriptorTipoZonaFiltro;

	public MarcoGeograficoManager getMarcoGeograficoManager() {
		return marcoGeograficoManager;
	}

	public void setMarcoGeograficoManager(MarcoGeograficoManager marcoGeograficoManager) {
		this.marcoGeograficoManager = marcoGeograficoManager;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public UbicacionGeograficaManager getUbicacionGeograficaManager() {
		return ubicacionGeograficaManager;
	}

	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public ZonaManager getZonaManager() {
		return zonaManager;
	}

	public void setZonaManager(ZonaManager zonaManager) {
		this.zonaManager = zonaManager;
	}

	public TipoZonaManager getTipoZonaManager() {
		return tipoZonaManager;
	}

	public void setTipoZonaManager(TipoZonaManager tipoZonaManager) {
		this.tipoZonaManager = tipoZonaManager;
	}

	public String getIdRegionFiltro() {
		return idRegionFiltro;
	}

	public void setIdRegionFiltro(String idRegionFiltro) {
		this.idRegionFiltro = idRegionFiltro;
	}

	public String getIdRegionSeleccionada() {
		return idRegionSeleccionada;
	}

	public void setIdRegionSeleccionada(String idRegionSeleccionada) {
		this.idRegionSeleccionada = idRegionSeleccionada;
	}

	public Long getIdTipoZonaFiltro() {
		return idTipoZonaFiltro;
	}

	public void setIdTipoZonaFiltro(Long idTipoZonaFiltro) {
		this.idTipoZonaFiltro = idTipoZonaFiltro;
	}

	public Long getIdTipoZonaSeleccionado() {
		return idTipoZonaSeleccionado;
	}

	public void setIdTipoZonaSeleccionado(Long idTipoZonaSeleccionado) {
		this.idTipoZonaSeleccionado = idTipoZonaSeleccionado;
	}

	public String getIdRegionComuna() {
		return idRegionComuna;
	}

	public void setIdRegionComuna(String idRegionComuna) {
		this.idRegionComuna = idRegionComuna;
	}

	public String getIdRegionLocalidad() {
		return idRegionLocalidad;
	}

	public void setIdRegionLocalidad(String idRegionLocalidad) {
		this.idRegionLocalidad = idRegionLocalidad;
	}

	public String getIdComunaLocalidad() {
		return idComunaLocalidad;
	}

	public void setIdComunaLocalidad(String idComunaLocalidad) {
		this.idComunaLocalidad = idComunaLocalidad;
	}

	public String[] getIdsLocalidadessSeleccionadas() {
		return idsLocalidadessSeleccionadas;
	}

	public void setIdsLocalidadessSeleccionadas(String[] idsLocalidadessSeleccionadas) {
		this.idsLocalidadessSeleccionadas = idsLocalidadessSeleccionadas;
	}

	public List<Region> getRegiones() {
		return regiones;
	}

	public void setRegiones(List<Region> regiones) {
		this.regiones = regiones;
	}

	public List<Comuna> getComunas() {
		return comunas;
	}

	public void setComunas(List<Comuna> comunas) {
		this.comunas = comunas;
	}

	public List<Comuna> getComunasSeleccion() {
		return comunasSeleccion;
	}

	public void setComunasSeleccion(List<Comuna> comunasSeleccion) {
		this.comunasSeleccion = comunasSeleccion;
	}

	public List<Localidad> getLocalidades() {
		return localidades;
	}

	public void setLocalidades(List<Localidad> localidades) {
		this.localidades = localidades;
	}

	public List<TipoZona> getTiposZona() {
		return tiposZona;
	}

	public void setTiposZona(List<TipoZona> tiposZona) {
		this.tiposZona = tiposZona;
	}

	public List<Region> getRegionesSeleccionadas() {
		return regionesSeleccionadas;
	}

	public void setRegionesSeleccionadas(List<Region> regionesSeleccionadas) {
		this.regionesSeleccionadas = regionesSeleccionadas;
	}

	public List<Comuna> getComunasSeleccionadas() {
		return comunasSeleccionadas;
	}

	public List<Localidad> getLocalidadesSeleccionadas() {
		return localidadesSeleccionadas;
	}

	public void setLocalidadesSeleccionadas(List<Localidad> localidadesSeleccionadas) {
		this.localidadesSeleccionadas = localidadesSeleccionadas;
	}

	public void setComunasSeleccionadas(List<Comuna> comunasSeleccionadas) {
		this.comunasSeleccionadas = comunasSeleccionadas;
	}

	public String[] getIdsComunasSeleccionadas() {
		return idsComunasSeleccionadas;
	}

	public void setIdsComunasSeleccionadas(String[] idsComunasSeleccionadas) {
		this.idsComunasSeleccionadas = idsComunasSeleccionadas;
	}

	public Zona getZona() {
		return zona;
	}

	public void setZona(Zona zona) {
		this.zona = zona;
	}

	public Long getIdZona() {
		return idZona;
	}

	public void setIdZona(Long idZona) {
		this.idZona = idZona;
	}

	public List<Zona> getZonas() {
		return zonas;
	}

	public void setZonas(List<Zona> zonas) {
		this.zonas = zonas;
	}

	public int getTotalListSize() {
		return totalListSize;
	}

	public void setTotalListSize(int totalListSize) {
		this.totalListSize = totalListSize;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public String prepareMantenedor() {
		try {
			this.sessionCacheManager.clearSession();
			this.regiones = ubicacionGeograficaManager.getAllRegiones();
			this.tiposZona = tipoZonaManager.getAllTiposZonaMant();
			this.estimarTablaInicial();
			this.cargarZonas();
			this.sessionCacheManager.saveState(this);
			return RedirectConstants.SEL_TABLA_TO_MANT_ZONA;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}

	private HashMap<String, Object> getFiltrosZonas() throws GeneralDataAccessException {
		HashMap<String, Object> filters = new HashMap<String, Object>();

		// Filtro Region
		if (this.idRegionFiltro != null && !this.idRegionFiltro.equals("")) {
			// filters.put("zonaRegiones.idRegion", idRegionFiltro);
			filters.put("idRegion", idRegionFiltro);
		}
		// Filtro tipo de Zona
		if (this.idTipoZonaFiltro != null && !this.idTipoZonaFiltro.equals("")) {
			filters.put("tipoZona.id", idTipoZonaFiltro);
		}

		// Filtro tipo de Zona by descriptor
		if (this.descriptorTipoZonaFiltro != null && !this.descriptorTipoZonaFiltro.equals("")) {
			filters.put("tipoZona.descriptor", descriptorTipoZonaFiltro);
		}

		return filters;
	}

	private void estimarTablaInicial() {
		try {
			HashMap<String, Object> filters = getFiltrosZonas();
			int totalListSize = new Long(zonaManager.getZonasCountMant(filters)).intValue();
			setTotalListSize(totalListSize);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	private void cargarZonas() {
		try {
			// solo se debenlas que no son de subsidio
			// this.descriptorTipoZonaFiltro = Constants.TIPO_ZONA_OPERACIONES;
			HashMap<String, Object> filters = getFiltrosZonas();
			zonas = zonaManager.getZonasByFiltersMant(filters);
			sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}

	public String prepareAgregarZona() {
		try {
			this.limpiarCampos();
			this.zona = new Zona();
			this.regiones = ubicacionGeograficaManager.getAllRegiones();
			this.regionesSeleccionadas = new ArrayList<Region>();
			this.comunasSeleccionadas = new ArrayList<Comuna>();
			this.localidadesSeleccionadas = new ArrayList<Localidad>();
			this.idsComunasSeleccionadas = new String[] {};
			this.idsComunasSeleccionadas = new String[] {};
			this.comunas = new ArrayList<Comuna>();
			this.localidades = new ArrayList<Localidad>();
			this.idComunaLocalidad = null;
			this.idRegionComuna = null;
			this.idRegionLocalidad = null;
			this.idRegionSeleccionada = null;
			this.sessionCacheManager.saveState(this);
			return "success_prepareAgregarZona";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareAgregarZona";
	}

	public String guardarZona() {
		try {
			this.zona.setTipoZona(tipoZonaManager.getTipoZonaById(idTipoZonaSeleccionado));
			this.zona.setIdRegion(idRegionSeleccionada);
			zonaManager.saveZona(zona, this.getRegionesSeleccionadas(), this.getComunasSeleccionadas(), this.localidadesSeleccionadas);
			this.estimarTablaInicial();
			this.cargarZonas();
			this.sessionCacheManager.saveState(this);

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_Zona_guardar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("zona.error.existeZona"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_ZonaExistente_guardar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarZona";
	}

	public String prepararModificarZona(Zona zona) {
		try {
			this.setZona(zona);
			this.regiones = ubicacionGeograficaManager.getAllRegiones();
			this.idsComunasSeleccionadas = new String[] {};
			this.idsComunasSeleccionadas = new String[] {};
			this.comunas = new ArrayList<Comuna>();
			this.localidades = new ArrayList<Localidad>();
			this.regionesSeleccionadas = zonaManager.getRegionesByZona(zona);
			this.comunasSeleccionadas = zonaManager.getComunasByZona(zona);
			this.localidadesSeleccionadas = zonaManager.getLocalidadesByZona(zona);
			this.idRegionSeleccionada = zona.getRegionResponsable().getCodigo();
			this.idTipoZonaSeleccionado = zona.getTipoZona().getId();
			this.sessionCacheManager.saveState(this);

			this.idComunaLocalidad = null;
			this.idRegionComuna = null;
			this.idRegionLocalidad = null;

			return "success_prepararModificarZona";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarZona";
	}

	public String modificarZona() {
		try {
			this.zona.setTipoZona(tipoZonaManager.getTipoZonaById(idTipoZonaSeleccionado));
			this.zona.setIdRegion(idRegionSeleccionada);
			zonaManager.updateZona(zona, this.getRegionesSeleccionadas(), this.getComunasSeleccionadas(), this.localidadesSeleccionadas);
			this.cargarZonas();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_Zona_modificar";
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("terminal.error.existeTerminal"), FacesMessage.SEVERITY_ERROR);
			return "error_ZonaExistente_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarZona";
	}

	public String eliminarZona() {
		try {
		    
			Zona zona = this.getZonaManager().getZonaById(this.getIdZona());
			if (!this.removable(zona)) {
			    messageBean.addMessage(Resources.getString("zona.error.eliminarZona"), FacesMessage.SEVERITY_ERROR);
	            return "error_Zona_eliminarNoPermitido";
            }
			this.zonaManager.removeZona(zona);
			this.estimarTablaInicial();
			this.cargarZonas();
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_Zona_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("zona.error.eliminarZona"), FacesMessage.SEVERITY_ERROR);
			return "error_Zona_eliminarNoPermitido";
		}
		messageBean.addMessage(Resources.getString("zona.messages.eliminarZona"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarZona";
	}

	public void filtrarZonas() {
		this.cargarZonas();
	}

	public void actualizarFilas() {
		this.filtrarZonas();
	}

	public String revertirModificarZona() {
		try {
			int index = zonas.indexOf(zona);

			this.setZona(this.getZonaManager().getZonaByIdWithAllLists(zona.getId()));
			// this.regiones = ubicacionGeograficaManager.getAllRegiones();
			// this.idsComunasSeleccionadas = new String[]{};
			// this.idsComunasSeleccionadas = new String[]{};
			// this.comunas = new ArrayList<Comuna>();
			// this.localidades = new ArrayList<Localidad>();
			// this.regionesSeleccionadas = zonaManager.getRegionesByZona(zona);
			// this.comunasSeleccionadas = zonaManager.getComunasByZona(zona);
			// this.localidadesSeleccionadas =
			// zonaManager.getLocalidadesByZona(zona);
			// this.idRegionSeleccionada =
			// zona.getRegionResponsable().getCodigo();
			// this.idTipoZonaSeleccionado = zona.getTipoZona().getId();

			zonas.set(index, zona);
			return prepararModificarZona(zona);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_revertirModificarZona";
		}
		// this.sessionCacheManager.saveState(this);
		// return "success_revertirModificarZona";
		//
	}

	public void actualizarComunas(AjaxBehaviorEvent event) {
		if (this.idRegionComuna != null) {
			try {
				this.comunas = ubicacionGeograficaManager.getAllComunasByIdRegion(idRegionComuna);
				if (this.comunasSeleccionadas != null && this.comunasSeleccionadas.size() > 0) {
					this.comunas.removeAll(this.comunasSeleccionadas);
				}

			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
	}

	public void seleccionarComunas() {
		try {
			for (String idComuna : this.getIdsComunasSeleccionadas()) {
				Comuna comuna = this.ubicacionGeograficaManager.getComunaById(idComuna);
				this.comunasSeleccionadas.add(comuna);
				this.comunas.remove(comuna);
			}

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}

	public void eliminarComunaSeleccionada(Comuna comuna) {
		this.comunasSeleccionadas.remove(comuna);
		if (this.idRegionComuna != null && this.idRegionComuna.equals(comuna.getRegionIdentifier()))
			this.comunas.add(comuna);

	}

	public void actualizarComunasSeleccionLocalidad(AjaxBehaviorEvent event) {
		if (this.idRegionLocalidad != null) {
			try {
				this.comunasSeleccion = ubicacionGeograficaManager.getAllComunasByIdRegion(idRegionLocalidad);
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
	}

	public void actualizarLocalidades(AjaxBehaviorEvent event) {
		if (this.idComunaLocalidad != null) {
			try {
				// falta que la tabla de localidad este relacionada con las
				// comunas y no con provincia por ahora traigo localidades
				this.localidades = ubicacionGeograficaManager.getAllLocalidadesByIdComuna(idComunaLocalidad);
				if (this.localidadesSeleccionadas != null && this.localidadesSeleccionadas.size() > 0) {
					this.localidades.removeAll(this.localidadesSeleccionadas);
				}
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
	}

	public void seleccionarLocalidades() {
		try {
			for (String idLocalidad : this.getIdsLocalidadessSeleccionadas()) {
				Localidad localidad = this.ubicacionGeograficaManager.getLocalidadById(Integer.parseInt(idLocalidad));
				this.localidadesSeleccionadas.add(localidad);
			}

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}

	public void eliminarLocalidadSeleccionada(Localidad localidad) {
		this.localidadesSeleccionadas.remove(localidad);
		if (this.idRegionComuna != null && this.idRegionComuna.equals(localidad.getComuna().getProvincia().getRegion().getCodigo()))
			this.localidades.add(localidad);
	}

	private void limpiarCampos() {
		this.idTipoZonaSeleccionado = null;
		this.idRegionSeleccionada = null;
	}

	public void limpiarFiltro() {
		this.idRegionFiltro = null;
		this.idTipoZonaFiltro = null;

		this.sessionCacheManager.saveState(this);

		this.cargarZonas();
	}

	public boolean removable(Zona zona) {
		try {
			if (removableZones == null)
				removableZones = new HashMap<Long, Boolean>();
			if (!removableZones.containsKey(zona.getId())) {
				removableZones.put(zona.getId(), !marcoGeograficoManager.getZonaUsada(zona));
			}
			return removableZones.get(zona.getId());
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return false;
	}
}
