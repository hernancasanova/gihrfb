package cl.mtt.rnt.admin.bean.mantenedor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ValueChangeEvent;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cl.mtt.rnt.admin.util.RedirectConstants;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.SessionCacheManager;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.TipoVehiculoServicio;
import cl.mtt.rnt.commons.model.core.recorrido.BloquePredeterminado;
import cl.mtt.rnt.commons.model.core.recorrido.Tramo;
import cl.mtt.rnt.commons.model.core.recorrido.Trazado;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.RecorridoManager;
import cl.mtt.rnt.commons.service.TerminalManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.encargado.bean.util.MapaUtils;

@ManagedBean
@ViewScoped
public class TrazadosPredeterminadosBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{recorridoManager}")
	private RecorridoManager recorridoManager;
	@ManagedProperty(value = "#{generalDataManager}")
	private GeneralDataManager generalDataManager;
	@ManagedProperty(value = "#{terminalManager}")
	private TerminalManager terminalManager;
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;
	
	
	MapaUtils mapaUtils; 
	
	public List<BloquePredeterminado> bloques;
	public List<Tramo> tramos;
	public BloquePredeterminado bloque;
	public long idTrazadoPredeterminado;
	
	
	
	public void setTerminalManager(TerminalManager terminalManager) {
		this.terminalManager = terminalManager;
	}

	public MapaUtils getMapaUtils() {
		return mapaUtils;
	}

	public void setMapaUtils(MapaUtils mapaUtils) {
		this.mapaUtils = mapaUtils;
	}

	public void setGeneralDataManager(GeneralDataManager generalDataManager) {
		this.generalDataManager = generalDataManager;
	}

	public void setUbicacionGeograficaManager(
			UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public void setRecorridoManager(RecorridoManager recorridoManager) {
		this.recorridoManager = recorridoManager;
	}

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}
	
	public List<BloquePredeterminado> getBloques() {
		return bloques;
	}

	public void setBloques(List<BloquePredeterminado> bloques) {
		this.bloques = bloques;
	}

	public BloquePredeterminado getBloque() {
		return bloque;
	}

	public void setBloque(BloquePredeterminado bloque) {
		this.bloque = bloque;
	}
	
	
	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	
	public List<Tramo> getTramos() {
		return tramos;
	}

	public void setTramos(List<Tramo> tramos) {
		this.tramos = tramos;
	}

	public String prepareMantenedor() {
		try {
			this.bloques = recorridoManager.getAllbloquesPredeterminados();
			this.sessionCacheManager.saveState(this);
			return "success_trazadosPredeterminados";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareMantenedor";
	}
	
	public String prepareAgregarTrazadoPredeterminado(){
		try {
			bloque=new BloquePredeterminado();
			bloque.setTramos(new ArrayList<Tramo>());
			bloque.setUsaMapa(true);
			mapaUtils=new MapaUtils(bloque, ubicacionGeograficaManager, generalDataManager,terminalManager,sessionCacheManager,recorridoManager);
			
			this.sessionCacheManager.saveState(this);
			return "success_prepareAgregarTrazadoPredeterminado";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepareAgregarTrazadoPredeterminado";
	}
	
	public String guardarNuevoTrazado(){
		try {
			recorridoManager.saveBloquePredeterminado(bloque);
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
			return prepareMantenedor();
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("trazadoPredeterminado.error.existeTrazadoPredeterminado"), FacesMessage.SEVERITY_ERROR);
			return null;
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return null;
		}

	}
	
	public String getBloqueJS() {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		Collections.sort(bloque.getTramos());
		
		return gson.toJson(bloque);
	}

	public long getIdTrazadoPredeterminado() {
		return idTrazadoPredeterminado;
	}

	public void setIdTrazadoPredeterminado(long idTrazadoPredeterminado) {
		this.idTrazadoPredeterminado = idTrazadoPredeterminado;
	}

	public String eliminarTrazadoPredeterminado(){
		try {
			BloquePredeterminado bl=null;
			for (BloquePredeterminado bloquePredeterminado : bloques) {
				if (bloquePredeterminado.getId().equals(idTrazadoPredeterminado)){
					bl=bloquePredeterminado;
				}
			}
			if(bl!=null){
				if(recorridoManager.cantTramosConteniendoBloque(bl)>0){
					messageBean.addMessage(Resources.getString("trazadoPredeterminado.error.esUsadoPorTramos"), FacesMessage.SEVERITY_ERROR);
					this.sessionCacheManager.saveState(this);
					return "error_eliminarTrazadoPredeterminado";
				}
				recorridoManager.removeTrazadoPredeterminado(bl);
				bloques = recorridoManager.getAllbloquesPredeterminados();
			}
			this.sessionCacheManager.saveState(this);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_eliminarTrazadoPredeterminado";
		}

		messageBean.addMessage(Resources.getString("trazadoPredeterminado.messages.eliminado"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarTrazadoPredeterminado";

	}
	public String prepararModificar(BloquePredeterminado bloquePredeterminado){
		try {
			this.setBloque(bloquePredeterminado);
			bloquePredeterminado.setTramos(recorridoManager.getTramosByBloquePredeterminado(bloquePredeterminado));
			for (Tramo tr : bloquePredeterminado.getTramos()) {
				tr.setBloquePadre(bloquePredeterminado);
				tr.setComuna(ubicacionGeograficaManager.getComunaById(tr.getCodigoComuna()));
			}
			mapaUtils=new MapaUtils(bloque, ubicacionGeograficaManager, generalDataManager,terminalManager,sessionCacheManager,recorridoManager);

			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarBloquePredeterminado";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificar";
	}
	
	public String modificarTrazadoPredeterminado() {
		try {
			recorridoManager.updateTrazadoPredeterminado(bloque,mapaUtils.getTramosEliminados());
			this.sessionCacheManager.saveState(this);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("trazadoPredeterminado.error.existeTrazadoPredeterminado"), FacesMessage.SEVERITY_ERROR);
			return "error_modificarTrazadoPredeterminado";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			this.sessionCacheManager.saveState(this);
			return "error_modificarTrazadoPredeterminado";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarTrazadoPredeterminado";
	}

	public void cambioUsaMapa(ValueChangeEvent parameter){
		System.out.println(bloque.getUsaMapa());
	} 
	
	public void cambioDeAplicaMapa(){
		if (getBloque().getUsaMapa()) {
			mapaUtils.clearTramos();
		}
	}
	
}
