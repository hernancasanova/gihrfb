package cl.mtt.rnt.admin.reglamentacion;

import cl.mtt.rnt.commons.model.core.VehiculoServicio;

public interface ConVehiculoServicioEvent {
	
	/**
	 * Retorna el Vehiculo Servicio Entrante, dependiendo del evento especifico.
	 * @return
	 */
	public VehiculoServicio getVehiculoServicio();
}
