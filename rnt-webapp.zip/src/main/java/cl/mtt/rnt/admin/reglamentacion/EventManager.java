package cl.mtt.rnt.admin.reglamentacion;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.el.ELContext;
import javax.faces.context.FacesContext;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;

import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo.SubGrupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo.SubGrupo.Norma;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.ReglamentacionInvalidaTipoVehiculos;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

public class EventManager {

//	private ReglamentacionXML reglamentacionxml;
	private Reglamentacion reglamentacion;
//	private ReglamentacionManager reglamentacionManager;
//	private TipoServicioManager tipoServicioManager;
//	private List<GenericNormativa> normativas;
//	private ReglamentacionBean reglamentacionBeanAux = null;

	public EventManager(Reglamentacion reg){
		super();
		this.reglamentacion = reg;
	}
	
//	public EventManager(Reglamentacion reg, ReglamentacionManager reglamentacionManager, TipoServicioManager tipoServicioManager,
//			ReglamentacionBean reglamentacionBeanAux) throws JAXBException, GeneralDataAccessException {
//		super();
//		this.reglamentacionBeanAux = reglamentacionBeanAux;
//		reglamentacionBeanAux.setReglamentacionDB(reg);
//		
//		constructor(reg, reglamentacionManager, tipoServicioManager);
//		
//	}
	
//	public EventManager(Reglamentacion reg, ReglamentacionManager reglamentacionManager, TipoServicioManager tipoServicioManager) throws JAXBException, GeneralDataAccessException {
//		super();
//		constructor(reg, reglamentacionManager, tipoServicioManager);
//	}

//	/**
//	 * @param reg
//	 * @param reglamentacionManager
//	 * @param tipoServicioManager
//	 * @throws GeneralDataAccessException
//	 * @throws JAXBException
//	 */
//	@Deprecated
//	private void constructor(Reglamentacion reg,
//			ReglamentacionManager reglamentacionManager,
//			TipoServicioManager tipoServicioManager)
//			throws GeneralDataAccessException, JAXBException {
//		this.reglamentacion = reg;
//		this.reglamentacionManager = reglamentacionManager;
//		this.tipoServicioManager = tipoServicioManager;
//
//		while (reglamentacion != null
//				&& (!"estadoReglamentacion.activa".equals(reglamentacion.getEstado()) || !ValidacionHelper.esFechaEntreRango(new Date(), reglamentacion.getVigenciaDesde(),
//						reglamentacion.getVigenciaHasta()))) {
//			if (reglamentacion.getEspecificadaSobreExistente()) {
//			    if (reglamentacion.getIdReglamentacionSuperior()!=null) {
//			        reglamentacion.setReglamentacionDeQueDepende(reglamentacionManager.getReglamentacionById(reglamentacion.getIdReglamentacionSuperior()));
//                }
//				reglamentacion = reglamentacion.getReglamentacionDeQueDepende();
//			} else {
//				reglamentacion = null;
//			}
//		}
//
//		if (reglamentacion != null) {
//
//			JAXBContext context = JAXBContext.newInstance(ReglamentacionXML.class);
//			reglamentacionxml = (ReglamentacionXML) context.createUnmarshaller().unmarshal(ReglamentacionXML.class.getResourceAsStream("/normativas.xml"));
//
//			normativas = new ArrayList<GenericNormativa>();
//
//			reglamentacionManager.initializeNormativas(reglamentacion);
//			updateNormas();
//		}
//	}

//	@Deprecated
//	private ReglamentacionBean getReglamentacionBean() {
//		if (reglamentacionBeanAux == null) {
//			ELContext elContext = FacesContext.getCurrentInstance().getELContext();
//			ReglamentacionBean reglamentacionBean = (ReglamentacionBean) elContext.getELResolver().getValue(elContext, null, "reglamentacionBean");
//			reglamentacionBeanAux =  reglamentacionBean;
//		}
//		return reglamentacionBeanAux;
//	}

	public EventResult evalEvent(GenericEvent event) throws EventEvalException {
		return evalEvent(event,null);
	}
	
	public EventResult evalEvent(GenericEvent event,List<Normativa> normativasAprobadas) throws EventEvalException {
		EventResult result = new EventResult();
		if (reglamentacion == null) {
			result.setResult(false);
			result.setMessage(Resources.getString("validation.message.event.noReglamentacion"));
			return result;
		}
		
		List<GenericNormativa> normativas = NormativaAccess.getInstance().getNormativas(reglamentacion,event);
		
		for (GenericNormativa norma : normativas) {
				if(normativasAprobadas==null || !normativasAprobadas.contains(norma.getNormativa())){
						try {
							RntEventResultItem it = getResult(norma, event);
							if (it != null && !"".equals(it.getMessage()) && it.getMessage() != null) {
								result.getEventResultItems().add(it);
								result.setResult(result.getResult() && it.isResult());
							}
						} catch (Exception e) {
							Logger.getLogger(norma.getClass()).error(e.getMessage(), e);
							throw new EventEvalException("Norma: " + norma.getNormativa().getLabel() + " - Evento: " + event.getClass().getName() + " - Exception: " + e.getMessage(), e.getCause(),norma);
						}
						
				}
		}
		return result;
	}

	private RntEventResultItem getResult(GenericNormativa norma, GenericEvent event) throws GeneralDataAccessException, IllegalArgumentException, SecurityException, InstantiationException,
			IllegalAccessException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException {

		if ("validacion.especificada".equals(norma.getNormativa().getValidacion())) {
			Reglamentacion reg = norma.getNormativa().getReglamentacion();
//			if (!Hibernate.isInitialized(reg.getMarcoGeografico())) {
//				reg.setMarcoGeografico(reglamentacionManager.getMarcoGeograficoByIdReglamentacion(reg.getId()));
//			}
//			if (!Hibernate.isInitialized(reg.getTiposServicio())) {
//				reg.setTiposServicio(tipoServicioManager.getTiposServicioByReglamentacion(reg.getId()));
//			}
//			ReglamentacionBean rb = getReglamentacionBean();
//			rb.setReglamentacionDB(reg);
			try {
				
				NormativaAccess.getInstance().populateNorma(norma);
			} catch (ReglamentacionInvalidaTipoVehiculos e) {
				return new RntEventResultItem(false, norma, e.getMessage());
			}
			return norma.validate(event);
		}
		if ("validacion.noSeReglamenta".equals(norma.getNormativa().getValidacion())) {
			Reglamentacion reg = norma.getNormativa().getReglamentacion();
			if (reg.getEspecificadaSobreExistente()) {
//			    if (reg.getIdReglamentacionSuperior()!=null) {
//                    reg.setReglamentacionDeQueDepende(reglamentacionManager.getReglamentacionById(reg.getIdReglamentacionSuperior()));
//                }
				Reglamentacion regPadre = reg.getReglamentacionDeQueDepende();
				if (regPadre != null) {
//					Normativa n = reglamentacionManager.getNormativaByReglamentacionAndDescriptor(regPadre.getId(), norma.getNormativa().getDescriptor());
//					if (n == null)
//						return null;
					GenericNormativa norPadre = NormativaAccess.getInstance().getNormativa(regPadre, norma.getNormativa().getDescriptor());
					return getResult(norPadre, event);
				}
			} else {
				return null;
			}
		}
		return null;
	}

//	@Deprecated
//	public void updateNormas() {
//		try {
//		    List<Normativa> normativasByReglamentacion = reglamentacionManager.getNormativasByReglamentacion(reglamentacion);
//            HashMap<String, Normativa> normativasHash = new HashMap<String, Normativa>();
//            for (Normativa normativa : normativasByReglamentacion) {
//                normativa.setReglamentacion(reglamentacion);
//                normativasHash.put(normativa.getDescriptor(), normativa);
//            }
//            for (Grupo grupo : reglamentacionxml.getGrupo()) {
//                for (SubGrupo subGrupo : grupo.getSubGrupo()) {
//                    for (Norma norma : subGrupo.getNorma()) {
//                        Normativa n = normativasHash.get(norma.getDescriptor());
//                        GenericNormativa normativa = (GenericNormativa) Class.forName(norma.getImplementacion().getClassName()).getConstructor(Normativa.class).newInstance(n);
//                        normativa.setPermiteAutorizacionXML(norma.getPermiteExcepcion());
//                        if(norma.getImplementacion().getEvent() != null)
//                            normativa.setEvents(Arrays.asList(norma.getImplementacion().getEvent().split(",")));
//                        normativas.add(normativa);
//                    }
//                }
//            }
//		} catch (InstantiationException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (IllegalAccessException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (ClassNotFoundException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (GeneralDataAccessException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (IllegalArgumentException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (SecurityException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (InvocationTargetException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (NoSuchMethodException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		}
//	}

//	@Deprecated
//	public ArrayList<GenericNormativa> updateNormas(Reglamentacion reg, ReglamentacionXML regXml) {
//		ArrayList<GenericNormativa> normativasLocal = new ArrayList<GenericNormativa>();
//		try {
//		    List<Normativa> normativasByReglamentacion = reglamentacionManager.getNormativasByReglamentacion(reg);
//            HashMap<String, Normativa> normativasHash = new HashMap<String, Normativa>();
//            for (Normativa normativa : normativasByReglamentacion) {
//                normativa.setReglamentacion(reglamentacion);
//                normativasHash.put(normativa.getDescriptor(), normativa);
//            }
//            for (Grupo grupo : reglamentacionxml.getGrupo()) {
//                for (SubGrupo subGrupo : grupo.getSubGrupo()) {
//                    for (Norma norma : subGrupo.getNorma()) {
//                        Normativa n = normativasHash.get(norma.getDescriptor());
//                        GenericNormativa normativa = (GenericNormativa) Class.forName(norma.getImplementacion().getClassName()).getConstructor(Normativa.class).newInstance(n);
//                        if(norma.getImplementacion().getEvent() != null)
//                            normativa.setEvents(Arrays.asList(norma.getImplementacion().getEvent().split(",")));
//                        normativa.setPermiteAutorizacionXML(norma.getPermiteExcepcion());
//                        normativasLocal.add(normativa);
//                    }
//                }
//            }
//		} catch (InstantiationException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (IllegalAccessException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (ClassNotFoundException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (GeneralDataAccessException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (IllegalArgumentException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (SecurityException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (InvocationTargetException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (NoSuchMethodException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		}
//		return normativasLocal;
//	}



}
