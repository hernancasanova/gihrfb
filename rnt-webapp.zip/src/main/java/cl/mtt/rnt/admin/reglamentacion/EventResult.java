package cl.mtt.rnt.admin.reglamentacion;

import java.util.ArrayList;
import java.util.List;

public class EventResult {

	private Boolean result = true;
	private List<RntEventResultItem> eventResultItems = new ArrayList<RntEventResultItem>();
	private String message;

	public EventResult(Boolean result, String message) {
		super();
		this.result = result;
		this.message = message;
	}

	public EventResult() {
		super();
	}

	public Boolean getResult() {
		return result;
	}

	public void setResult(Boolean result) {
		this.result = result;
	}

	public List<RntEventResultItem> getEventResultItems() {
		return eventResultItems;
	}

	public void setEventResultItems(List<RntEventResultItem> eventResultItems) {
		this.eventResultItems = eventResultItems;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
