package cl.mtt.rnt.admin.reglamentacion;

public abstract class GenericEvent {

}
