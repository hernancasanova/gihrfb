package cl.mtt.rnt.admin.reglamentacion;

import java.util.ArrayList;
import java.util.List;

import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.ReglamentacionInvalidaTipoVehiculos;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.autorizacion.Autorizacion;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;

public abstract class GenericNormativa {

	protected Normativa normativa;
	protected boolean loaded = false;
	protected List<String> events;
	protected Boolean permiteAutorizacionXML;

	public GenericNormativa(Normativa normativa) {
		super();
		this.normativa = normativa;
		if(this.normativa.getAutorizacion() == null){
			this.normativa.setAutorizacion(new Autorizacion());
			this.normativa.getAutorizacion().setGrupoResponsable(new ArrayList<Grupo>());
			this.normativa.getAutorizacion().setNormativa(this.normativa);
		}
		
	}

	public List<String> getEvents() {
		return events;
	}

	public void setEvents(List<String> events) {
		this.events = events;
	}

	public abstract RntEventResultItem validate(GenericEvent event);

//	public void populate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException, ReglamentacionInvalidaTipoVehiculos {
//		populatePrivate(reglamentacionManager, normativa);
//		loaded = true;
//	}

//	public void populateIfNotLoaded(ReglamentacionBean reglamentacionBean, Normativa normativa) throws GeneralDataAccessException, ReglamentacionInvalidaTipoVehiculos {
//		if (!loaded) {
//			populatePrivate(reglamentacionBean, normativa);
//			loaded = true;
//		}
//	}
	public void populateIfNotLoaded(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException, ReglamentacionInvalidaTipoVehiculos {
		if (!loaded) {
			populatePrivate(reglamentacionManager, normativa);
			loaded = true;
		}
	}
	protected abstract void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException, ReglamentacionInvalidaTipoVehiculos;

	protected abstract void updateNormativa();

	protected abstract Normativa getNormativaForSaving();

	public Normativa getNormativaDataForSaving() {
		if (isLoaded())
			return getNormativaForSaving();
		return normativa;
	}

	protected abstract boolean validateForSaving();

	public boolean validateDataForSaving() {
		if (isLoaded())
			return validateForSaving();
		return true;
	}

	public Normativa getNormativa() {
		return normativa;
	}

	public void setNormativa(Normativa normativa) {
		this.normativa = normativa;
	}

	public boolean isLoaded() {
		return loaded;
	}
	
	public Boolean getPermiteAutorizacionXML() {
		return permiteAutorizacionXML;
	}

	public void setPermiteAutorizacionXML(Boolean permiteAutorizacionXML) {
		this.permiteAutorizacionXML = permiteAutorizacionXML;
	}

	public void initializeAutorizacion(){
		if(normativa.getAutorizacion() == null){
			normativa.setAutorizacion(new Autorizacion());
			normativa.getAutorizacion().setGrupoResponsable(new ArrayList<Grupo>());
			normativa.getAutorizacion().setNormativa(normativa);
		}
	}
	public void limpiarAutorizacion(){
		if(normativa.getAutorizacion().getId() == null){
			if(!normativa.getTipoNormativa().equals("tipoNorma.bloqueante") ||  !normativa.getValidacion().equals("validacion.especificada")){
				normativa.setPermiteAutorizacion(false);
				normativa.getAutorizacion().getGrupoResponsable().clear();
				normativa.getAutorizacion().setEstado(false);
			}
			else if(!normativa.getPermiteAutorizacion()){
				normativa.getAutorizacion().getGrupoResponsable().clear();
				normativa.getAutorizacion().setEstado(false);
			}
		}
		
	}
	
	
	public NormativaItem getNormativaItemByKey(List<NormativaItem> items,String key) {
	    if (items!=null) {
	        for (NormativaItem normativaItem : items) {
                if ((normativaItem.getKey()!=null)&&(normativaItem.getKey().equals(key))) {
                    return normativaItem;
                }
            }
	    }
	    return null;
	}
	

}
