package cl.mtt.rnt.admin.reglamentacion;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.impl.NormasTiposVehiculoPermitido;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo.SubGrupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo.SubGrupo.Norma;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.ReglamentacionInvalidaTipoVehiculos;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.service.ReglamentacionManager;

public class NormativaAccess {
    
    ReglamentacionManager reglamentacionManager;
    
    Map<Long,List<GenericNormativa>> normativasMap;
    ReglamentacionXML reglamentacionXML;
    Map<Long,NormativasDataCache> normativasDataCacheMap;
    
    
    private static NormativaAccess me;
    
    private  NormativaAccess(ReglamentacionManager reglamentacionManager) {
        this.reglamentacionManager = reglamentacionManager;
        
        normativasMap = new HashMap<Long,List<GenericNormativa>>();
        normativasDataCacheMap = new HashMap<Long, NormativasDataCache>();
        try {
        	reglamentacionXML = getReglamentacionXML();
			List<Reglamentacion> reglamentaciones = reglamentacionManager.getActiveReglamentaciones();
			for (Reglamentacion reglamentacion : reglamentaciones) {
				normativasMap.put(reglamentacion.getId(),getUpdatedNormas(reglamentacion));
				addDataCacheToReglamentacion(reglamentacion);
			}
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (JAXBException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}  
    }

    private ReglamentacionXML getReglamentacionXML() throws JAXBException {
		JAXBContext context = JAXBContext.newInstance(ReglamentacionXML.class);
		ReglamentacionXML reglamentacionxml = (ReglamentacionXML) context.createUnmarshaller().unmarshal(ReglamentacionXML.class.getResourceAsStream("/normativas.xml"));
		return reglamentacionxml;
	}

	public static void build(ReglamentacionManager reglamentacionManager) {
        if (me == null) {
            me = new NormativaAccess(reglamentacionManager);
        }
        
    }
    
    public static NormativaAccess getInstance() {
        return me;
    }

	public List<GenericNormativa> getNormativas(Reglamentacion reglamentacion, GenericEvent event) {
		List<GenericNormativa> ret = new ArrayList<GenericNormativa>();
		List<GenericNormativa> normativas = getNormativas(reglamentacion);
		for (GenericNormativa norma : normativas) {
			if(norma.getEvents() != null && event != null){
				if (norma.getEvents().contains(event.getClass().getSimpleName())) {
					ret.add(norma);
				}
			}
		}
		return ret;
	}

	public GenericNormativa getNormativa(Reglamentacion reglamentacion, String descriptor) throws GeneralDataAccessException {
		List<GenericNormativa> normativas = getNormativas(reglamentacion);
		for (GenericNormativa norma : normativas) {
			if(norma.getNormativa().getDescriptor().equals(descriptor)){
				try {
					norma.populateIfNotLoaded(reglamentacionManager, norma.getNormativa());
					return norma;
				} catch (ReglamentacionInvalidaTipoVehiculos e) {
					return null;
				}
			}
		}
		return null;
	}

	public NormativasDataCache getNormativasDataCache(Reglamentacion reglamentacion) throws GeneralDataAccessException{
		if(!normativasDataCacheMap.containsKey(reglamentacion.getId())){
			addDataCacheToReglamentacion(reglamentacion);
		}
		return normativasDataCacheMap.get(reglamentacion.getId());
	}

	/**
	 * @param reglamentacion
	 * @throws GeneralDataAccessException
	 */
	private void addDataCacheToReglamentacion(Reglamentacion reglamentacion)
			throws GeneralDataAccessException {
		NormativasDataCache dataCache=new NormativasDataCache();
		
		NormasTiposVehiculoPermitido normaTipoVehiculos = (NormasTiposVehiculoPermitido) getNormativa(reglamentacion, Normativa.descriptorTiposVehiculosPermitidos);
		getNormativa(reglamentacion, Normativa.descriptorVehiculosPrestandoOtrosServicios);
		
		dataCache.setNormaTipoVehiculosData(normaTipoVehiculos, reglamentacionManager);
		normativasDataCacheMap.put(reglamentacion.getId(), dataCache);
	}
	
	/**
	 * @param reglamentacion
	 */
	private List<GenericNormativa> getNormativas(Reglamentacion reglamentacion) {
		if(!normativasMap.containsKey(reglamentacion.getId())){
			normativasMap.put(reglamentacion.getId(),getUpdatedNormas(reglamentacion)); 
		}
		return normativasMap.get(reglamentacion.getId());
	}
    
	public GenericNormativa getNormativaAplicada(Reglamentacion reglamentacion, String descriptor) throws EventEvalException {
		try {
			if (descriptor != null && reglamentacion != null) {
				
				List<GenericNormativa> norms = getNormativas(reglamentacion);

				for (GenericNormativa norma : norms) {
					if (descriptor.equals(norma.getNormativa().getDescriptor())) {
						try {
							if ("validacion.noSeReglamenta".equals(norma.getNormativa().getValidacion())) {
								return getNormativaAplicada(reglamentacion.getReglamentacionDeQueDepende(), descriptor);
							}
							return getNorma(norma);
						} catch (Exception e) {
							throw new EventEvalException("Norma: " + norma.getNormativa().getLabel() + " - Exception: " + e.getMessage(), e.getCause(),norma);
						}
					}
				}
			}
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}

	private GenericNormativa getNorma(GenericNormativa norma) throws GeneralDataAccessException, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException,
		InvocationTargetException, NoSuchMethodException, ClassNotFoundException, ReglamentacionInvalidaTipoVehiculos {
		if ("validacion.especificada".equals(norma.getNormativa().getValidacion())) {
			Reglamentacion reg = norma.getNormativa().getReglamentacion();
			norma.populateIfNotLoaded(reglamentacionManager, norma.getNormativa());
			return norma;
		}
		if ("validacion.noSeReglamenta".equals(norma.getNormativa().getValidacion())) {
			Reglamentacion reg = norma.getNormativa().getReglamentacion();
			if (reg.getEspecificadaSobreExistente()) {
			   Reglamentacion regPadre = reg.getReglamentacionDeQueDepende();
				if (regPadre != null) {
					return getNormativa(regPadre, norma.getNormativa().getDescriptor());
				}
			} else {
				return null;
			}
		}
		return null;
	}

	private List<GenericNormativa> getUpdatedNormas(Reglamentacion reglamentacion) {
		try {
			List<GenericNormativa> normativas = new ArrayList<GenericNormativa>();
		    List<Normativa> normativasByReglamentacion = reglamentacion.getNormativas();
	        HashMap<String, Normativa> normativasHash = new HashMap<String, Normativa>();
	        for (Normativa normativa : normativasByReglamentacion) {
	            normativa.setReglamentacion(reglamentacion);
	            normativasHash.put(normativa.getDescriptor(), normativa);
	        }
	        for (Grupo grupo : reglamentacionXML.getGrupo()) {
	            for (SubGrupo subGrupo : grupo.getSubGrupo()) {
	                for (Norma norma : subGrupo.getNorma()) {
	                    Normativa n = normativasHash.get(norma.getDescriptor());
	                    if(n==null){
	                    	n=new Normativa();
	                    }
	                    GenericNormativa normativa = (GenericNormativa) Class.forName(norma.getImplementacion().getClassName()).getConstructor(Normativa.class).newInstance(n);
	                    normativa.setPermiteAutorizacionXML(norma.getPermiteExcepcion());
	                    if(norma.getImplementacion().getEvent() != null)
	                        normativa.setEvents(Arrays.asList(norma.getImplementacion().getEvent().split(",")));
	                    normativas.add(normativa);
	                }
	            }
	        }
	        return normativas;
		} catch (InstantiationException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (IllegalAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (ClassNotFoundException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (IllegalArgumentException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (SecurityException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (InvocationTargetException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (NoSuchMethodException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}

	public void populateNorma(GenericNormativa norma) throws GeneralDataAccessException, ReglamentacionInvalidaTipoVehiculos {
		norma.populateIfNotLoaded(reglamentacionManager, norma.getNormativa());
		
	}

	public void updateCacheDataReglamentacion(Reglamentacion reglamentacion) throws GeneralDataAccessException {
		normativasMap.put(reglamentacion.getId(),getUpdatedNormas(reglamentacion));
		addDataCacheToReglamentacion(reglamentacion);
	}

}
