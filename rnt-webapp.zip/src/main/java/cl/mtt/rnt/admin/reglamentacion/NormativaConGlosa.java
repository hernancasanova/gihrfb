package cl.mtt.rnt.admin.reglamentacion;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.hibernate.id.CompositeNestedGeneratedValueGenerator.GenerationPlan;

import cl.mtt.rnt.admin.reglamentacion.eventImpl.SeleccionMotivoCancelacionEvent;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.util.Resources;

public abstract class NormativaConGlosa extends GenericNormativa {

	protected boolean ninguna = false;

	private boolean plazoMeses = false;
	private Integer cantMeses; 
	private String mesesDesde; 
	
	private boolean glosaVehiculo = false;
	private String tipoGlosaVehiculo; 
	private String textoGlosaVehiculo; 

	private boolean glosaCertificado = false;
	private String tipoGlosaCertificado; 
	private String textoGlosaCertificado; 

	public NormativaConGlosa(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return el valor de cantMeses
	 */
	public Integer getCantMeses() {
		return cantMeses;
	}

	/**
	 * @param setea el parametro cantMeses al campo cantMeses
	 */
	public void setCantMeses(Integer cantMeses) {
		this.cantMeses = cantMeses;
	}

	/**
	 * @return el valor de mesesDesde
	 */
	public String getMesesDesde() {
		return mesesDesde;
	}

	/**
	 * @param setea el parametro mesesDesde al campo mesesDesde
	 */
	public void setMesesDesde(String mesesDesde) {
		this.mesesDesde = mesesDesde;
	}

	/**
	 * @return el valor de plazoMeses
	 */
	public boolean isPlazoMeses() {
		return plazoMeses;
	}

	/**
	 * @param setea el parametro plazoMeses al campo plazoMeses
	 */
	public void setPlazoMeses(boolean plazoMeses) {
		this.plazoMeses = plazoMeses;
	}

	/**
	 * @return el valor de glosaVehiculo
	 */
	public boolean isGlosaVehiculo() {
		return glosaVehiculo;
	}

	/**
	 * @param setea el parametro glosaVehiculo al campo glosaVehiculo
	 */
	public void setGlosaVehiculo(boolean glosaVehiculo) {
		this.glosaVehiculo = glosaVehiculo;
	}

	/**
	 * @return el valor de tipoGlosaVehiculo
	 */
	public String getTipoGlosaVehiculo() {
		return tipoGlosaVehiculo;
	}

	/**
	 * @param setea el parametro tipoGlosaVehiculo al campo tipoGlosaVehiculo
	 */
	public void setTipoGlosaVehiculo(String tipoGlosaVehiculo) {
		this.tipoGlosaVehiculo = tipoGlosaVehiculo;
	}

	/**
	 * @return el valor de textoGlosaVehiculo
	 */
	public String getTextoGlosaVehiculo() {
		return textoGlosaVehiculo;
	}

	/**
	 * @param setea el parametro textoGlosaVehiculo al campo textoGlosaVehiculo
	 */
	public void setTextoGlosaVehiculo(String textoGlosaVehiculo) {
		this.textoGlosaVehiculo = textoGlosaVehiculo;
	}

	/**
	 * @return el valor de glosaCertificado
	 */
	public boolean isGlosaCertificado() {
		return glosaCertificado;
	}

	/**
	 * @param setea el parametro glosaCertificado al campo glosaCertificado
	 */
	public void setGlosaCertificado(boolean glosaCertificado) {
		this.glosaCertificado = glosaCertificado;
	}

	/**
	 * @return el valor de tipoGlosaCertificado
	 */
	public String getTipoGlosaCertificado() {
		return tipoGlosaCertificado;
	}

	/**
	 * @param setea el parametro tipoGlosaCertificado al campo tipoGlosaCertificado
	 */
	public void setTipoGlosaCertificado(String tipoGlosaCertificado) {
		this.tipoGlosaCertificado = tipoGlosaCertificado;
	}

	/**
	 * @return el valor de textoGlosaCertificado
	 */
	public String getTextoGlosaCertificado() {
		return textoGlosaCertificado;
	}

	/**
	 * @param setea el parametro textoGlosaCertificado al campo textoGlosaCertificado
	 */
	public void setTextoGlosaCertificado(String textoGlosaCertificado) {
		this.textoGlosaCertificado = textoGlosaCertificado;
	}
	
	protected RntEventResultItem validateSeleccionMotivoCancelacion(GenericEvent event) {
		VehiculoServicio vehiculoServicioNuevo = null;
		SeleccionMotivoCancelacionEvent e=(SeleccionMotivoCancelacionEvent)event;
		vehiculoServicioNuevo = e.getVehiculoServicio();
		TipoCancelacion tc = e.getTipoCancelaccion();
		if("TRASLADO DE SERVICIO DENTRO DE LA MISMA REGIÓN".equalsIgnoreCase(tc.getNombre())){
			if(!isPlazoMeses()){
				return new RntEventResultItem(true, this, Resources.getString("validation.message.event.translado.plazoMeses.indefinido"));
			}else{
				if(getValidarFechas()) {
					Date fechaLimite = getFechaLimiteInicio();
				    Date fechaVehiculo = getFechaVehiculo(vehiculoServicioNuevo);
				    if(fechaLimite!=null && fechaVehiculo != null){
				    	if(fechaVehiculo.before(fechaLimite)){
					    	SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy"); 
					    	 Date fechaTraslado =  getPosibleTraslado(fechaVehiculo);
					    	return new RntEventResultItem(true, this, Resources.getString("validation.message.event.translado.plazoMeses.definido",new String[]{String.valueOf(getCantMeses()),getGlosaFechaDesde(getMesesDesde()),"("+sdf.format(fechaTraslado)+")"}));
				    	}else{
				    		return new RntEventResultItem(true, this, null);
				    	}
				    }else{
						return new RntEventResultItem(true, this, Resources.getString("validation.message.event.translado.plazoMeses.definido",new String[]{String.valueOf(getCantMeses()),getGlosaFechaDesde(getMesesDesde()),""}));
					}
				}
			}
		}
		return new RntEventResultItem(true, this, null);
	}

	private boolean getValidarFechas() {
		if("trasladoPlazoDesde.postulacion".equals(getMesesDesde()) || "trasladoPlazoDesde.otorgamiento".equals(getMesesDesde())){
			return false;
		}
		return true;
	}

	private String getGlosaFechaDesde(String key){
		if("trasladoPlazoDesde.otorgamiento".equals(key)){
			return "Fecha de otorgamiento del beneficio";
		}
		if("trasladoPlazoDesde.postulacion".equals(key)){
			return "Fecha de Postulación";
		}
		if("trasladoPlazoDesde.ingresoRegistro".equals(key)){
			return "Fecha de ingreso al registro";
		}
		if("trasladoPlazoDesde.ingresoServicio".equals(key)){
			return "Fecha de ingreso al servicio ";
		}
		return "indefinida"; 
	}
	
	/**
	 * @param valid
	 * @param messageBean
	 * @return
	 */
	protected boolean validateGlosas(boolean ninguna,MessageBean messageBean) {
		boolean valid = true;
		if (normativa.getValidacion().equals("validacion.especificada") && !ninguna && plazoMeses && (cantMeses==null || mesesDesde==null)) {
			messageBean.addMessage(Resources.getString("reglamentacion.normativa.field.translado.noCantMeses", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && !ninguna && glosaVehiculo && (tipoGlosaVehiculo==null || textoGlosaVehiculo==null)) {
			messageBean.addMessage(Resources.getString("reglamentacion.normativa.field.translado.noGlosaVehiculo", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && !ninguna && glosaCertificado && (tipoGlosaCertificado==null || textoGlosaCertificado==null)) {
			messageBean.addMessage(Resources.getString("reglamentacion.normativa.field.translado.noGlosaCertificado", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}
	public String getGlosaVehiculo() {
		if(glosaVehiculo){
			return textoGlosaVehiculo;
		}
		return null;
	}

	public String getGlosaCertificado() {
		if(glosaCertificado){
			return textoGlosaCertificado;
		}
		return null;
	}

	protected void updateNormativaGlosas(NormativaRegistro normativaRegistro) {
		normativaRegistro.getItemsAsMap().get("plazoMeses").setValues(Arrays.asList(new String[] { String.valueOf(isPlazoMeses()) }));
		normativaRegistro.getItemsAsMap().get("cantMeses").setValues(Arrays.asList(new String[] { String.valueOf(getCantMeses()) }));
		normativaRegistro.getItemsAsMap().get("mesesDesde").setValues(Arrays.asList(new String[] { getMesesDesde() }));
		
		normativaRegistro.getItemsAsMap().get("glosaVehiculo").setValues(Arrays.asList(new String[] { String.valueOf(isGlosaVehiculo()) }));
		normativaRegistro.getItemsAsMap().get("tipoGlosaVehiculo").setValues(Arrays.asList(new String[] { getTipoGlosaVehiculo() }));
		normativaRegistro.getItemsAsMap().get("textoGlosaVehiculo").setValues(Arrays.asList(new String[] { getTextoGlosaVehiculo() }));

		normativaRegistro.getItemsAsMap().get("glosaCertificado").setValues(Arrays.asList(new String[] { String.valueOf(isGlosaCertificado()) }));
		normativaRegistro.getItemsAsMap().get("tipoGlosaCertificado").setValues(Arrays.asList(new String[] { getTipoGlosaCertificado() }));
		normativaRegistro.getItemsAsMap().get("textoGlosaCertificado").setValues(Arrays.asList(new String[] { getTextoGlosaCertificado() }));
	}

	/**
	 * @param keyItem
	 * @param valueOf
	 */
	protected void addNewNormativaItem(NormativaRegistro normativaRegistro,String keyItem, String valueOf) {
		NormativaItem ni = new NormativaItem(keyItem, valueOf);
		ni.setRegistro(normativaRegistro);
		normativaRegistro.getItems().add(ni);
	}

	/**
	 * @param itemsAsMap
	 * @throws NumberFormatException
	 */
	protected void addGlosaPopulateValues(NormativaRegistro normativaRegistro,Map<String, NormativaItem> itemsAsMap) throws NumberFormatException {
		if(itemsAsMap.containsKey("plazoMeses")){
			setPlazoMeses(Boolean.valueOf(itemsAsMap.get("plazoMeses").getValue()));
			if(itemsAsMap.get("cantMeses").getValue()!=null && !itemsAsMap.get("cantMeses").getValue().equals("null")){
				setCantMeses(Integer.valueOf(itemsAsMap.get("cantMeses").getValue()));
			}
			setMesesDesde(itemsAsMap.get("mesesDesde").getValue());
			
			setGlosaVehiculo(Boolean.valueOf(itemsAsMap.get("glosaVehiculo").getValue()));
			setTipoGlosaVehiculo(itemsAsMap.get("tipoGlosaVehiculo").getValue()); 
			setTextoGlosaVehiculo(itemsAsMap.get("textoGlosaVehiculo").getValue()); 

			setGlosaCertificado(Boolean.valueOf(itemsAsMap.get("glosaCertificado").getValue()));
			setTipoGlosaCertificado(itemsAsMap.get("tipoGlosaCertificado").getValue()); 
			setTextoGlosaCertificado(itemsAsMap.get("textoGlosaCertificado").getValue()); 
		}else{
			
			addGlosaNewValues(normativaRegistro);
		}
	}

	/**
	 * @param normativaRegistro
	 */
	protected void addGlosaNewValues(NormativaRegistro normativaRegistro) {
		addNewNormativaItem(normativaRegistro,"plazoMeses", String.valueOf(isPlazoMeses()));
		addNewNormativaItem(normativaRegistro,"cantMeses", String.valueOf(getCantMeses()));
		addNewNormativaItem(normativaRegistro,"mesesDesde", getMesesDesde());

		addNewNormativaItem(normativaRegistro,"glosaVehiculo", String.valueOf(isGlosaVehiculo()));
		addNewNormativaItem(normativaRegistro,"tipoGlosaVehiculo", getTipoGlosaVehiculo());
		addNewNormativaItem(normativaRegistro,"textoGlosaVehiculo", getTextoGlosaVehiculo());

		addNewNormativaItem(normativaRegistro,"glosaCertificado", String.valueOf(isGlosaCertificado()));
		addNewNormativaItem(normativaRegistro,"tipoGlosaCertificado", getTipoGlosaCertificado());
		addNewNormativaItem(normativaRegistro,"textoGlosaCertificado", getTextoGlosaCertificado());
	}

	/**
	 * @return
	 */
	public Date getFechaLimiteInicio() {
		if(getCantMeses()==null){
			return null;
		}
		Calendar fechaLimite = GregorianCalendar.getInstance();
		fechaLimite.add(Calendar.MONTH, -getCantMeses());
		return fechaLimite.getTime();
	}
	
	public Date getPosibleTraslado(Date fechaVehiculo) {
		if(getCantMeses()==null){
			return null;
		}
		Calendar fechaLimite = GregorianCalendar.getInstance();
		fechaLimite.setTime(fechaVehiculo);
		fechaLimite.add(Calendar.MONTH, +getCantMeses());
		return fechaLimite.getTime();
	}
	
	/**
	 * @param vehiculoServicioNuevo
	 * @return
	 */
	public Date getFechaVehiculo(VehiculoServicio vehiculoServicio) {
		Date fechaVehiculo = null ;
		if("trasladoPlazoDesde.postulacion".equals(getMesesDesde())){
			fechaVehiculo = vehiculoServicio.getFechaPostulacion();
		}else if("trasladoPlazoDesde.ingresoRegistro".equals(getMesesDesde())){
			fechaVehiculo = vehiculoServicio.getFechaIngreso();
		}else if("trasladoPlazoDesde.ingresoServicio".equals(getMesesDesde())){
			fechaVehiculo = vehiculoServicio.getFechaIngresoServicio();
		}else if("trasladoPlazoDesde.otorgamiento".equals(getMesesDesde())){
			fechaVehiculo = vehiculoServicio.getFechaOtorgamientoBeneficio();
		}
		return fechaVehiculo;
	}
	
	public boolean isNinguna() {
		return ninguna;
	}

	public void setNinguna(boolean ninguna) {
		this.ninguna = ninguna;
	}
	
}
