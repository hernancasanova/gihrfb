package cl.mtt.rnt.admin.reglamentacion;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.autorizacion.Autorizacion;
import cl.mtt.rnt.encargado.bean.CrossContextAccessBean;


public class RntEventResultItem {

	private boolean result;
	private GenericNormativa norma;
	private String message;
	private boolean autorizable;
	private Autorizacion autorizacion;
	private boolean autorizacionCreada;
	
	

	public RntEventResultItem(boolean result, GenericNormativa norma, String message) {
		super();
		this.result = result;
		this.norma = norma;
		this.message = message;
		this.autorizable = false;
		this.autorizacionCreada = false;
		try {
			autorizacion = CrossContextAccessBean.getAutorizacionManager().getAutorizacionByNormativa(this.norma.getNormativa().getId());
			if ((autorizacion != null)&&(!result)) {
				this.autorizable = true;
				this.autorizacion.setNormativa(norma.getNormativa());
			}
			
		}
		catch (GeneralDataAccessException gdae) {
			Logger.getLogger(this.getClass()).error(gdae.getMessage(),gdae);
		}
	}

	public boolean isResult() {
		return result;
	}

	public GenericNormativa getNorma() {
		return norma;
	}

	public String getMessage() {
		return message;
	}

	/**
	 * @return el valor de autorizable
	 */
	public boolean isAutorizable() {
		return autorizable;
	}

	/**
	 * @param setea el parametro autorizable al campo autorizable
	 */
	public void setAutorizable(boolean autorizable) {
		this.autorizable = autorizable;
	}

	

	/**
	 * @return el valor de autorizacion
	 */
	public Autorizacion getAutorizacion() {
		return autorizacion;
	}

	/**
	 * @return el valor de autorizacionCreada
	 */
	public boolean isAutorizacionCreada() {
		return autorizacionCreada;
	}

	/**
	 * @param setea el parametro autorizacionCreada al campo autorizacionCreada
	 */
	public void setAutorizacionCreada(boolean autorizacionCreada) {
		this.autorizacionCreada = autorizacionCreada;
	}

}
