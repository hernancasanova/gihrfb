package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.Tarifa;

public class CambioTarifaEvent extends GenericEvent {

	private Tarifa tarifa;

	public CambioTarifaEvent(Tarifa tarifa) {
		super();
		this.tarifa = tarifa;
	}

	public Tarifa getTarifa() {
		return tarifa;
	}

	public void setTarifa(Tarifa tarifa) {
		this.tarifa = tarifa;
	}

}
