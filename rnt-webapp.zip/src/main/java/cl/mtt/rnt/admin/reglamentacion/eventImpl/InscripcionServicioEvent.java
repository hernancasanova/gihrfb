package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.Servicio;

public class InscripcionServicioEvent extends GenericEvent {

	private Servicio servicio;

	public InscripcionServicioEvent(Servicio servicio) {
		super();
		this.servicio = servicio;
	}

	public Servicio getServicio() {
		return servicio;
	}

	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}

}
