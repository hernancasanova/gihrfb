package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;

public class ModificarVechiculoEvent extends GenericEvent implements ConVehiculoServicioEvent {

	private VehiculoServicio vehiculoServicio;

	public ModificarVechiculoEvent(VehiculoServicio vehiculoServicio) {
		super();
		this.vehiculoServicio = vehiculoServicio;
	}

	public VehiculoServicio getVehiculoServicio() {
		return vehiculoServicio;
	}

	public void setVehiculoServicio(VehiculoServicio vehiculoServicio) {
		this.vehiculoServicio = vehiculoServicio;
	}

}
