package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.Conductor;

public class NuevoAuxiliarEvent extends GenericEvent {

	private Conductor auxiliar;

	public NuevoAuxiliarEvent(Conductor auxiliar) {
		super();
		this.auxiliar = auxiliar;
	}

	public Conductor getAuxiliar() {
		return auxiliar;
	}

	public void setAuxiliar(Conductor auxiliar) {
		this.auxiliar = auxiliar;
	}

}
