package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.Conductor;

public class NuevoConductorEvent extends GenericEvent {

	private Conductor conductor;

	public NuevoConductorEvent(Conductor conductor) {
		super();
		this.conductor = conductor;
	}

	public Conductor getConductor() {
		return conductor;
	}

	public void setConductor(Conductor conductor) {
		this.conductor = conductor;
	}

}
