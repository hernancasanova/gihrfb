package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.PeriodoVigencia;
import cl.mtt.rnt.commons.model.core.Servicio;

public class NuevosPeriodosEnServicioEvent_deprecated extends GenericEvent {

	private Servicio servicio;
	private PeriodoVigencia periodoVigencia;

	public NuevosPeriodosEnServicioEvent_deprecated(Servicio servicio, PeriodoVigencia nuevoPeriodo) {
		super();
		this.servicio = servicio;
		this.periodoVigencia = nuevoPeriodo;
	}

	public Servicio getServicio() {
		return servicio;
	}

	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}

	/**
	 * @return el valor de periodoVigencia
	 */
	public PeriodoVigencia getPeriodoVigencia() {
		return periodoVigencia;
	}

	/**
	 * @param setea el parametro periodoVigencia al campo periodoVigencia
	 */
	public void setPeriodoVigencia(PeriodoVigencia periodoVigencia) {
		this.periodoVigencia = periodoVigencia;
	}

}
