package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;

public class ReemplazoTrasladoVehiculoEvent extends GenericEvent implements ConVehiculoServicioEvent {

	private VehiculoServicio vehiculoServicioAnterior;
	private VehiculoServicio vehiculoServicioEntrante;
	private VehiculoServicio vehiculoServicioSaliente;

	public ReemplazoTrasladoVehiculoEvent(VehiculoServicio vehiculoServicioEntrante, VehiculoServicio vehiculoServicioSaliente, VehiculoServicio vehiculoServicioAnterior) {
		super();
		this.vehiculoServicioEntrante = vehiculoServicioEntrante;
		this.vehiculoServicioSaliente = vehiculoServicioSaliente;
		this.vehiculoServicioAnterior = vehiculoServicioAnterior;
	}

	public VehiculoServicio getVehiculoServicioEntrante() {
		return vehiculoServicioEntrante;
	}

	public void setVehiculoServicioEntrante(VehiculoServicio vehiculoServicioEntrante) {
		this.vehiculoServicioEntrante = vehiculoServicioEntrante;
	}

	public VehiculoServicio getVehiculoServicioSaliente() {
		return vehiculoServicioSaliente;
	}

	public void setVehiculoServicioSaliente(VehiculoServicio vehiculoServicioSaliente) {
		this.vehiculoServicioSaliente = vehiculoServicioSaliente;
	}

	public VehiculoServicio getVehiculoServicioAnterior() {
		return vehiculoServicioAnterior;
	}

	public void setVehiculoServicioAnterior(VehiculoServicio vehiculoServicioAnterior) {
		this.vehiculoServicioAnterior = vehiculoServicioAnterior;
	}

	@Override
	public VehiculoServicio getVehiculoServicio() {
		return vehiculoServicioEntrante;
	}

}
