package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;

public class SeleccionMotivoCancelacionEvent extends GenericEvent implements ConVehiculoServicioEvent {

	private VehiculoServicio vehiculoServicio;
	private TipoCancelacion tipoCancelaccion;

	public SeleccionMotivoCancelacionEvent(VehiculoServicio vehiculoServicio,TipoCancelacion tipoCancelaccion) {
		super();
		this.vehiculoServicio = vehiculoServicio;
		this.tipoCancelaccion = tipoCancelaccion;
	}

	public VehiculoServicio getVehiculoServicio() {
		return vehiculoServicio;
	}

	public void setVehiculoServicio(VehiculoServicio vehiculoServicio) {
		this.vehiculoServicio = vehiculoServicio;
	}

	/**
	 * @return el valor de tipoCancelaccion
	 */
	public TipoCancelacion getTipoCancelaccion() {
		return tipoCancelaccion;
	}

	/**
	 * @param setea el parametro tipoCancelaccion al campo tipoCancelaccion
	 */
	public void setTipoCancelaccion(TipoCancelacion tipoCancelaccion) {
		this.tipoCancelaccion = tipoCancelaccion;
	}

}
