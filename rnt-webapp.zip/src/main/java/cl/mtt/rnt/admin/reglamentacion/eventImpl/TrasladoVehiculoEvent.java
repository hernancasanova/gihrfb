package cl.mtt.rnt.admin.reglamentacion.eventImpl;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;

public class TrasladoVehiculoEvent extends GenericEvent implements ConVehiculoServicioEvent {

	private VehiculoServicio vehiculoServicioNuevo;
	private VehiculoServicio vehiculoServicioAnterior;

	public TrasladoVehiculoEvent(VehiculoServicio vehiculoServicioNuevo, VehiculoServicio vehiculoServicioAnterior) {
		super();
		this.vehiculoServicioNuevo = vehiculoServicioNuevo;
		this.vehiculoServicioAnterior = vehiculoServicioAnterior;
	}

	public VehiculoServicio getVehiculoServicioNuevo() {
		return vehiculoServicioNuevo;
	}

	public void setVehiculoServicioNuevo(VehiculoServicio vehiculoServicioNuevo) {
		this.vehiculoServicioNuevo = vehiculoServicioNuevo;
	}

	public VehiculoServicio getVehiculoServicioAnterior() {
		return vehiculoServicioAnterior;
	}

	public void setVehiculoServicioAnterior(VehiculoServicio vehiculoServicioAnterior) {
		this.vehiculoServicioAnterior = vehiculoServicioAnterior;
	}

	@Override
	public VehiculoServicio getVehiculoServicio() {
		return vehiculoServicioNuevo;
	}

}
