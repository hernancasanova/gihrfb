package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.ReglamentacionInvalidaTipoVehiculos;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoZona;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;

public class AntiguedadMarcoGeograficoTipoVehiculo extends GenericNormativa {

	public AntiguedadMarcoGeograficoTipoVehiculo(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String defaultAmbitoMarcoGeografico = MarcoGeograficoSource.AMBITO_REGIONAL;
	private MarcoGeografico marcoGeografico;
	private Integer antiguedadMaxima;
	private List<NormativaRecordUI> recordGroup;

	private List<TipoVehiculo> tiposVehiculo;
	// Ahora se va a permitir seleccionar un unico tipo de vehiculo
	private List<TipoVehiculo> selectedTiposVehiculo;
//	private TipoVehiculo selectedTipoVehiculo;
	private Map<Integer, TipoVehiculo> tiposVehiculoMap;

	private Map<String, MarcoGeograficoSource> marcoGeograficoSourcePorVeh;

	private Map<String, Zona> zonas = new HashMap<String, Zona>();
	private boolean marcosGeograficosCompatibles = true;
    private List<TipoZona> tiposZonas = new ArrayList<TipoZona>(); 
	
	@Override
	public RntEventResultItem validate(GenericEvent event) {

		boolean r = true;
		String m = null;
		VehiculoServicio vehiculoServicio = null;
		// Mejoras 201409 Nro: 47
		if (event instanceof ConVehiculoServicioEvent) {
			vehiculoServicio = ((ConVehiculoServicioEvent) event).getVehiculoServicio();
		}
		// Mejoras 201409 Nro: 47
		Integer tipoVehiculo = vehiculoServicio.getVehiculo().getTipoVehiculo();
		Region region = vehiculoServicio.getServicio().getRegion();

		boolean nivelZonal = vehiculoServicio.getReglamentacion().getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL);
		Zona zonaVehiculo = null;
		if (nivelZonal)
			zonaVehiculo = vehiculoServicio.getZonaVehiculo();

		if (vehiculoServicio != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				List<String> tiposVehNorma = mapItem.getItemsMap().get("tipos_vehiculo").getValues();

				if (tiposVehNorma.contains(tipoVehiculo.toString())) {

					String aplicaA = mapItem.getItemsMap().get("marco_geografico_aplicable_a").getValue();
					Integer antiguedadMax = Integer.parseInt(mapItem.getItemsMap().get("antiguedad_maxima").getValue());
					boolean cumpleAntiguedad = antiguedadMax >= vehiculoServicio.getVehiculo().getAntiguedadAlaFecha((vehiculoServicio.getFechaIngreso()==null)?new Date():vehiculoServicio.getFechaIngreso());

					if (MarcoGeograficoSource.AMBITO_NACIONAL.equals(aplicaA)) {
						if (!cumpleAntiguedad) {
							r = false;
							m = Resources.getString("validation.message.event.antiguedadMaxima", new String[] { String.valueOf(antiguedadMax) });
							return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
						}
					} else {
						List<String> marcoGeog = mapItem.getItemsMap().get("marco_geografico").getValues();
						if (MarcoGeograficoSource.AMBITO_REGIONAL.equals(aplicaA)) {
							if (marcoGeog.contains(region.getCodigo()))
								if (!cumpleAntiguedad) {
									r = false;
									m = Resources.getString("validation.message.event.antiguedadMaxima", new String[] { String.valueOf(antiguedadMax) });
									return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
								}
						} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaA) && !nivelZonal) {
							for (String idZona : marcoGeog) {
								Zona zona = zonas.get(idZona);
								if (region.getCodigo().equals(zona.getIdRegion()))
									if (!cumpleAntiguedad) {
										r = false;
										m = Resources.getString("validation.message.event.antiguedadMaxima", new String[] { String.valueOf(antiguedadMax) });
										return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
									}

							}
						} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaA) && nivelZonal) {
							for (String idZona : marcoGeog) {
								if (zonaVehiculo!=null && zonaVehiculo.getId().equals(Long.parseLong(idZona)))
									if (!cumpleAntiguedad) {
										r = false;
										m = Resources.getString("validation.message.event.antiguedadMaxima", new String[] { String.valueOf(antiguedadMax) });
										return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
									}

							}
						}

					}

				}

			}
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);

	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException, ReglamentacionInvalidaTipoVehiculos {
		marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico);
		MarcoGeograficoSource marcoGeograficoSource = new MarcoGeograficoSource();
        marcoGeograficoSource.updateData(reglamentacionManager.getUbicacionGeograficaManager(), reglamentacionManager.getZonaManager(), new String[] { MarcoGeograficoSource.AMBITO_NACIONAL,
                MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, normativa.getReglamentacion().getMarcoGeografico());
        marcoGeografico.setSource(marcoGeograficoSource);
        marcoGeografico.setTipoZonaSelected(marcoGeografico.getSource().getTiposZona().get(0));
        
		zonas = reglamentacionManager.getZonaManager().getAllZonasMap();
		tiposZonas  = reglamentacionManager.getUbicacionGeograficaManager().getAllTiposZonas();

		NormativasDataCache cacheNorm = NormativaAccess.getInstance().getNormativasDataCache(normativa.getReglamentacion());
		tiposVehiculoMap = new HashMap<Integer, TipoVehiculo>();

		
		if (cacheNorm.getMarcoGeograficoSourcePorTipoVehiculo() != null) {
			this.marcoGeograficoSourcePorVeh = cacheNorm.getMarcoGeograficoSourcePorTipoVehiculo();
			if (tiposVehiculo == null)
				tiposVehiculo = new ArrayList<TipoVehiculo>();
			for (TipoVehiculo tipoVeh : cacheNorm.getTiposVehiculos()) {
				tiposVehiculo.add(tipoVeh);
				tiposVehiculoMap.put(tipoVeh.getId(), tipoVeh);
			}
		} else {
			tiposVehiculo = cacheNorm.getAllTiposVehiculos();
			for (TipoVehiculo ts : tiposVehiculo) {
				tiposVehiculoMap.put(ts.getId(), ts);
			}
		}

		this.normativa = normativa;
		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "vhiculos_permitidos");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);
			String tsString = "";
			boolean registroValido = true;
						
			for (String key : recordUI.getItemsMap().get("tipos_vehiculo").getValues()) {
			    if (tiposVehiculoMap.get(Integer.parseInt(key))!=null) {
			        tsString += tiposVehiculoMap.get(Integer.parseInt(key)).getDescripcion() + ", ";
			    }
			    else {
			        registroValido = false;
			    }
			}
			if (registroValido) {
			recordUI.getItemsMap().get("tipos_vehiculo").setTextualValue(tsString.substring(0, tsString.lastIndexOf(",")));
			recordUI.getItemsMap().get("marco_geografico_aplicable_a").setTextualValue(MarcoGeograficoSource.getAmbitoName(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue()));

			tsString = "";
			for (String key : recordUI.getItemsMap().get("marco_geografico").getValues()) {
				Localizable descripcionById = marcoGeografico.getSource().getDescripcionById(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue(), key);
				if (descripcionById != null)
					tsString += descripcionById.getLabel() + ", ";
			}
			recordUI.getItemsMap().get("marco_geografico").setTextualValue(!tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString);
			recordGroup.add(recordUI);
			}
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (!marcoGeografico.getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL) && marcoGeografico.getLocalizables().isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.marcoGeografico") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if(selectedTiposVehiculo.isEmpty()){
//		if (selectedTipoVehiculo == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposVehiculo") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (antiguedadMaxima == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.antiguedadMaxima") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public void addItem() {
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		List<String> ts = new ArrayList<String>();
		String tsString = "";
		for (Localizable item : marcoGeografico.getLocalizables()) {
			ts.add(String.valueOf(item.getIdentifier()));
			tsString += item.getLabel() + ", ";
		}
		recordItem.put("marco_geografico", new NormativaItem("marco_geografico", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		ts = new ArrayList<String>();
		tsString = "";
		 for (TipoVehiculo item : selectedTiposVehiculo) {
		 ts.add(String.valueOf(item.getId()));
		 tsString+=item.getDescripcion()+", ";
		 }

//		ts.add(String.valueOf(selectedTipoVehiculo.getId()));
//		tsString += selectedTipoVehiculo.getDescripcion() + ", ";

		recordItem.put("tipos_vehiculo", new NormativaItem("tipos_vehiculo", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		recordItem.put("marco_geografico_aplicable_a",
				new NormativaItem("marco_geografico_aplicable_a", marcoGeografico.getAplicableA(), MarcoGeograficoSource.getAmbitoName(marcoGeografico.getAplicableA())));

		recordItem.put("antiguedad_maxima", new NormativaItem("antiguedad_maxima", String.valueOf(antiguedadMaxima)));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "vhiculos_permitidos", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		 selectedTiposVehiculo=new ArrayList<TipoVehiculo>();
//		selectedTipoVehiculo = null;
		marcoGeografico.setAplicableA(defaultAmbitoMarcoGeografico);
		marcoGeografico.setLocalizables(new ArrayList<Localizable>());
		antiguedadMaxima = null;
		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public Integer getAntiguedadMaxima() {
		return antiguedadMaxima;
	}

	public void setAntiguedadMaxima(Integer antiguedadMaxima) {
		this.antiguedadMaxima = antiguedadMaxima;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public List<TipoVehiculo> getTiposVehiculo() {
		return tiposVehiculo;
	}

	public void setTiposVehiculo(List<TipoVehiculo> tiposVehiculo) {
		this.tiposVehiculo = tiposVehiculo;
	}

	 public List<TipoVehiculo> getSelectedTiposVehiculo() {
	 return selectedTiposVehiculo;
	 }
	
	 public void setSelectedTiposVehiculo(List<TipoVehiculo>
	 selectedTiposVehiculo) {
	 this.selectedTiposVehiculo = selectedTiposVehiculo;
	 }

	public MarcoGeografico getMarcoGeografico() {
		return marcoGeografico;
	}

//	/**
//	 * @return el valor de selectedTipoVehiculo
//	 */
//	public TipoVehiculo getSelectedTipoVehiculo() {
//		return selectedTipoVehiculo;
//	}
//
//	/**
//	 * @param setea
//	 *            el parametro selectedTipoVehiculo al campo
//	 *            selectedTipoVehiculo
//	 */
//	public void setSelectedTipoVehiculo(TipoVehiculo selectedTipoVehiculo) {
//		this.selectedTipoVehiculo = selectedTipoVehiculo;
//	}

	public void setMarcoGeografico(MarcoGeografico marcoGeografico) {
		this.marcoGeografico = marcoGeografico;
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	/**
	 * @return el valor de marcoGeograficoSourcePorVeh
	 */
	public Map<String, MarcoGeograficoSource> getMarcoGeograficoSourcePorVeh() {
		return marcoGeograficoSourcePorVeh;
	}

	/**
	 * @param setea
	 *            el parametro marcoGeograficoSourcePorVeh al campo
	 *            marcoGeograficoSourcePorVeh
	 */
	public void setMarcoGeograficoSourcePorVeh(Map<String, MarcoGeograficoSource> marcoGeograficoSourcePorVeh) {
		this.marcoGeograficoSourcePorVeh = marcoGeograficoSourcePorVeh;
	}

	public void generarMarcoGeografico() {
		//Para seleccion de multiples tipos de vehículo
		if (marcoGeograficoSourcePorVeh != null && selectedTiposVehiculo != null && selectedTiposVehiculo.size()>0) {
			marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico);
			MarcoGeograficoSource marcoGeograficoSource = this.marcoGeograficoSourcePorVeh.get(String.valueOf(this.selectedTiposVehiculo.get(0).getId()));
			for (int i = 1; i < selectedTiposVehiculo.size(); i++) {
				MarcoGeograficoSource newMCS = this.marcoGeograficoSourcePorVeh.get(String.valueOf(this.selectedTiposVehiculo.get(i).getId()));
				marcoGeograficoSource = MarcoGeograficoSource.intersectSources(marcoGeograficoSource, newMCS);
			}
			marcoGeograficoSource.setTiposZona(this.tiposZonas);
			marcoGeografico.setSource(marcoGeograficoSource);
			marcoGeografico.setTipoZonaSelected(marcoGeografico.getSource().getTiposZona().get(0));
			marcosGeograficosCompatibles = !marcoGeograficoSource.isEmpty();
		}
		
//		//Para seleccion de un solo tipo de vehículo
//		for (TipoVehiculo selectedTipoVehiculo : selectedTiposVehiculo) {
//			if (marcoGeograficoSourcePorVeh != null && selectedTipoVehiculo != null) {
//				marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico);
//				MarcoGeograficoSource marcoGeograficoSource = this.marcoGeograficoSourcePorVeh.get(String.valueOf(this.selectedTipoVehiculo.getId()));
//				marcoGeografico.setSource(marcoGeograficoSource);
//				marcoGeografico.setTipoZonaSelected(marcoGeografico.getSource().getTiposZona().get(0));
//			}
//		}
	}

	/**
	 * @return el valor de zonas
	 */
	public Map<String, Zona> getZonas() {
		return zonas;
	}

	/**
	 * @param setea
	 *            el parametro zonas al campo zonas
	 */
	public void setZonas(Map<String, Zona> zonas) {
		this.zonas = zonas;
	}

	public boolean isMarcosGeograficosCompatibles() {
		return marcosGeograficosCompatibles;
	}

	public void setMarcosGeograficosCompatibles(boolean marcosGeograficosCompatibles) {
		this.marcosGeograficosCompatibles = marcosGeograficosCompatibles;
	}
	
	public Integer getMenorAntiguedad(){
		Integer ret=null;
		for (NormativaRecordUI mapItem : recordGroup) {
			Integer antiguedadMax = Integer.parseInt(mapItem.getItemsMap().get("antiguedad_maxima").getValue());
			if(ret==null || ret.intValue()>antiguedadMax.intValue()){
				ret=antiguedadMax;
			}
		}
		return ret;
	}
}
