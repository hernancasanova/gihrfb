package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.BusquedaReemplazoVehiculoEvent;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class CancelacionPermiteReemplazo extends GenericNormativa {

	public CancelacionPermiteReemplazo(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private boolean cancelacionPermiteReemplazo = false;
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		BusquedaReemplazoVehiculoEvent e = (BusquedaReemplazoVehiculoEvent) event;
		int estadoVehiculo = e.getVehiculoServicio().getEstado().intValue();

		boolean r = true;
		String m = null;

		if (!cancelacionPermiteReemplazo && estadoVehiculo != GenericCancellableModelObject.ESTADO_VIGENTE && estadoVehiculo != GenericCancellableModelObject.ESTADO_PENDIENTE_INGRESO) // No
																																														// se
																																														// puede
																																														// reemplazar
																																														// uno
																																														// cancelado
			r = false;

		if (!r) {
			m = Resources.getString("validation.message.event.cancelacionNoPermiteReemplazo");
		}
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "restriccion_permiso");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			cancelacionPermiteReemplazo = Boolean.parseBoolean(items.get("cancelacion_permite_reemplazo").getValue());

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("restriccion_permiso");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("cancelacion_permite_reemplazo", String.valueOf(cancelacionPermiteReemplazo)));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("cancelacion_permite_reemplazo").setValues(Arrays.asList(new String[] { String.valueOf(cancelacionPermiteReemplazo) }));

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		return valid;
	}

	public boolean isCancelacionPermiteReemplazo() {
		return cancelacionPermiteReemplazo;
	}

	public void setCancelacionPermiteReemplazo(boolean cancelacionPermiteReemplazo) {
		this.cancelacionPermiteReemplazo = cancelacionPermiteReemplazo;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

}
