package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.reglamentacion.util.PropertiesManager;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.sgprt.CaracteristicaVehiculo;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class CancelacionPorCaracteristica extends GenericNormativa {
	public CancelacionPorCaracteristica(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private Integer tipoVehiculoId;
	private Integer caracteristicaVehiculoId;
	private List<TipoVehiculo> tiposVehiculo;
	private List<CaracteristicaVehiculo> caracteristicasVehiculo;
	private String operador;
	private String valor;

	private List<NormativaRecordUI> recordGroup;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		NormativasDataCache cacheNorm = NormativaAccess.getInstance().getNormativasDataCache(normativa.getReglamentacion());

		if (cacheNorm.getTiposVehiculos() != null) {
			tiposVehiculo = cacheNorm.getTiposVehiculos();
		} else {
			tiposVehiculo = cacheNorm.getAllTiposVehiculos();
		}
		caracteristicasVehiculo = reglamentacionManager.getVehiculoManager().getAllCaracteristicasVehiculo();

		this.normativa = normativa;

		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "caracteristicas_vehiculo");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);
			recordUI.getItemsMap().get("tipo_vehiculo")
					.setTextualValue(reglamentacionManager.getVehiculoManager().getTipoVehiculoById(Integer.valueOf(recordUI.getItemsMap().get("tipo_vehiculo").getValue())).getDescripcion());
			recordUI.getItemsMap()
					.get("caracteristica_vehiculo")
					.setTextualValue(
							reglamentacionManager.getVehiculoManager().getCaracteristicaVehiculoById(Integer.valueOf(recordUI.getItemsMap().get("caracteristica_vehiculo").getValue())).getDescripcion());
			recordUI.getItemsMap().get("operador").setTextualValue(PropertiesManager.getProperty(recordUI.getItemsMap().get("operador").getValue()));

			recordGroup.add(recordUI);
		}
		updateNormativa();

	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (operador == null || operador.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.operador") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (valor == null || valor.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.valor") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (tipoVehiculoId == null) {
			messageBean
					.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tipoVehiculo") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (caracteristicaVehiculoId == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.caracteristicaVehiculo") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public void addItem() {
		// List<Map<String, NormativaItem>> recordGroup =
		// recordGroups.get("tipos_servicio");
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		for (TipoVehiculo tipoVehiculo : tiposVehiculo) {
			if (tipoVehiculo.getId().equals(tipoVehiculoId))
				recordItem.put("tipo_vehiculo", new NormativaItem("tipo_vehiculo", String.valueOf(tipoVehiculoId), tipoVehiculo.getDescripcion()));
		}
		for (CaracteristicaVehiculo caracteristicaVehiculo : caracteristicasVehiculo) {
			if (caracteristicaVehiculo.getId().equals(caracteristicaVehiculoId))
				recordItem.put("caracteristica_vehiculo", new NormativaItem("caracteristica_vehiculo", String.valueOf(caracteristicaVehiculoId), caracteristicaVehiculo.getDescripcion()));
		}
		recordItem.put("operador", new NormativaItem("operador", operador, PropertiesManager.getProperty(operador)));
		recordItem.put("valor", new NormativaItem("valor", valor));
		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "caracteristicas_vehiculo", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);
		// recordGroups.put("tipos_servicio",recordGroup);

		// reseteo los datos
		operador = null;
		valor = null;
		tipoVehiculoId = null;
		caracteristicaVehiculoId = null;
		updateNormativa();
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public List<TipoVehiculo> getTiposVehiculo() {
		return tiposVehiculo;
	}

	public void setTiposVehiculo(List<TipoVehiculo> tiposVehiculo) {
		this.tiposVehiculo = tiposVehiculo;
	}

	public List<CaracteristicaVehiculo> getCaracteristicasVehiculo() {
		return caracteristicasVehiculo;
	}

	public void setCaracteristicasVehiculo(List<CaracteristicaVehiculo> caracteristicasVehiculo) {
		this.caracteristicasVehiculo = caracteristicasVehiculo;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public Integer getTipoVehiculoId() {
		return tipoVehiculoId;
	}

	public void setTipoVehiculoId(Integer tipoVehiculoId) {
		this.tipoVehiculoId = tipoVehiculoId;
	}

	public Integer getCaracteristicaVehiculoId() {
		return caracteristicaVehiculoId;
	}

	public void setCaracteristicaVehiculoId(Integer caracteristicaVehiculoId) {
		this.caracteristicaVehiculoId = caracteristicaVehiculoId;
	}

	public String getOperador() {
		return operador;
	}

	public void setOperador(String operador) {
		this.operador = operador;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

}
