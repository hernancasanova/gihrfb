package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.CancelacionVehiculoEvent;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class CancelacionTipoVehiculo extends GenericNormativa {

	public CancelacionTipoVehiculo(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private List<TipoVehiculo> tiposVehiculo;
	private List<TipoVehiculo> selectedTiposVehiculo;
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		CancelacionVehiculoEvent e = (CancelacionVehiculoEvent) event;

		boolean r = true;
		String m = null;
		String nombre = null;

		for (TipoVehiculo tv : selectedTiposVehiculo) {
			if (tv.equals(e.getVehiculoServicio().getVehiculo().getTipoVehiculo())) {
				r = false;
				nombre = tv.getDescripcion();
			}
		}
		if (!r) {
			m = Resources.getString("validation.message.event.cancelacionTipoVehiculo", new String[] { nombre });
		}
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);

	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		NormativasDataCache cacheNorm = NormativaAccess.getInstance().getNormativasDataCache(normativa.getReglamentacion());

		if (cacheNorm.getTiposVehiculos() != null) {
			tiposVehiculo = cacheNorm.getTiposVehiculos();
		} else {
			tiposVehiculo = cacheNorm.getAllTiposVehiculos();
		}

		selectedTiposVehiculo = new ArrayList<TipoVehiculo>();

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "tipos_vehiculo");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			List<Integer> idsClase = new ArrayList<Integer>();
			for (String value : items.get("tipos_vehiculo").getValues()) {
				idsClase.add(Integer.valueOf(value));
			}
			selectedTiposVehiculo = reglamentacionManager.getVehiculoManager().getTiposVehiculoByIds(idsClase);

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("tipos_vehiculo");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("tipos_vehiculo", new ArrayList<String>()));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		List<String> idsClase = new ArrayList<String>();
		for (TipoVehiculo item : selectedTiposVehiculo) {
			idsClase.add(String.valueOf(item.getId()));
		}
		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("tipos_vehiculo").setValues(idsClase);

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (normativa.getValidacion().equals("validacion.especificada") && selectedTiposVehiculo.size() == 0) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public List<TipoVehiculo> getTiposVehiculo() {
		return tiposVehiculo;
	}

	public void setTiposVehiculo(List<TipoVehiculo> tiposVehiculo) {
		this.tiposVehiculo = tiposVehiculo;
	}

	public List<TipoVehiculo> getSelectedTiposVehiculo() {
		return selectedTiposVehiculo;
	}

	public void setSelectedTiposVehiculo(List<TipoVehiculo> selectedTiposVehiculo) {
		this.selectedTiposVehiculo = selectedTiposVehiculo;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

}
