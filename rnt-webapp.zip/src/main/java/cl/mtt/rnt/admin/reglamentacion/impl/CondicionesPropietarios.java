package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.PropertiesManager;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.Persona;
import cl.mtt.rnt.commons.model.core.Propietario;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class CondicionesPropietarios extends GenericNormativa {

	public CondicionesPropietarios(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String propietarioDebeSer = "propietarioDebeSer.ambos";
	private String propietarioDebeSerResponsable = "propietarioDebeSerResponsable.indistinto";
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// propietarioDebeSer.personaNatural=Persona Natural
		// propietarioDebeSer.personaJuridica=Persona Jurídica
		// propietarioDebeSer.ambos=Ambos
//		propietarioDebeSerResponsable.indistinto=INDISTINTO
//		propietarioDebeSerResponsable.si=SI
//		propietarioDebeSerResponsable.no=NO
		List<Propietario> props = null;
		VehiculoServicio vs = null;
		if (event instanceof NuevoVehiculoEvent) {
			NuevoVehiculoEvent e = (NuevoVehiculoEvent) event;
			vs = e.getVehiculoServicio();
			props = vs.getVehiculo().getAdquisicion().getPropietarios();
		} else if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			vs = e.getVehiculoServicioEntrante();
			props = vs.getVehiculo().getAdquisicion().getPropietarios();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			vs = e.getVehiculoServicioEntrante();
			props = vs.getVehiculo().getAdquisicion().getPropietarios();
		} else if (event instanceof TrasladoVehiculoEvent) {
			TrasladoVehiculoEvent e = (TrasladoVehiculoEvent) event;
			vs = e.getVehiculoServicioNuevo();
			props = vs.getVehiculo().getAdquisicion().getPropietarios();
		}

		for (Propietario propietario : props) {
			String m = null;
			boolean r = true;
			if ("propietarioDebeSer.personaNatural".equals(propietarioDebeSer)){
				r = Persona.TIPO_PERSONA_NATURAL.equals(propietario.getPersona().getTipoPersona());
			}else if ("propietarioDebeSer.personaJuridica".equals(propietarioDebeSer)){
				r = Persona.TIPO_PERSONA_JURIDICA.equals(propietario.getPersona().getTipoPersona());
			}
			if (!r) {
				m = Resources.getString("validation.message.event.condicionPropietario", new String[] { PropertiesManager.getProperty(propietarioDebeSer) });
				return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
			}
			if ("propietarioDebeSerResponsable.si".equals(propietarioDebeSerResponsable)){
				String rut = propietario.getPersona().getRut();
				r = rut.equals(vs.getServicio().getResponsable().getPersona().getRut());
			}else if ("propietarioDebeSerResponsable.no".equals(propietarioDebeSerResponsable)){
				String rut = propietario.getPersona().getRut();
				r = !rut.equals(vs.getServicio().getResponsable().getPersona().getRut());
			}
			if (!r) {
				String mess = ("propietarioDebeSerResponsable.si".equals(propietarioDebeSerResponsable))?"Responsable del Servicio":"NO Responsable del Servicio";
				m = Resources.getString("validation.message.event.condicionPropietario", new String[] { mess });
				return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
			}
		}
		return new RntEventResultItem(true, this, null);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "propietario_debe_ser");
		if (ems != null && ems.size() > 0) {
			propietarioDebeSer = ems.get(0).getItems().get(0).getValue();
			normativaRegistro = ems.get(0);
			if (ems.get(0).getItems().size() > 1) {
				propietarioDebeSerResponsable = ems.get(0).getItems().get(1).getValue();
			}else{
				NormativaItem ni2 = new NormativaItem("propietario_debe_ser_Responsable", propietarioDebeSerResponsable);
				ni2.setRegistro(normativaRegistro);
				normativaRegistro.getItems().add(ni2);
			}
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("propietario_debe_ser");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			NormativaItem ni1 = new NormativaItem("propietario_debe_ser", propietarioDebeSer);
			ni1.setRegistro(normativaRegistro);
			normativaRegistro.getItems().add(ni1);
			NormativaItem ni2 = new NormativaItem("propietario_debe_ser_Responsable", propietarioDebeSerResponsable);
			ni2.setRegistro(normativaRegistro);
			normativaRegistro.getItems().add(ni2);
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);
		normativaRegistro.getItems().get(0).setValues(Arrays.asList(new String[] { propietarioDebeSer }));
		if(normativaRegistro.getItems().size()>1){
			normativaRegistro.getItems().get(1).setValues(Arrays.asList(new String[] { propietarioDebeSerResponsable }));
		}else{
			NormativaItem ni2 = new NormativaItem("propietario_debe_ser_Responsable", propietarioDebeSerResponsable);
			ni2.setRegistro(normativaRegistro);
			normativaRegistro.getItems().add(ni2);
		}
		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		return valid;
	}

	public String getPropietarioDebeSer() {
		return propietarioDebeSer;
	}

	public void setPropietarioDebeSer(String propietarioDebeSer) {
		this.propietarioDebeSer = propietarioDebeSer;
	}

	/**
	 * @return el valor de propietarioDebeSerResponsable
	 */
	public String getPropietarioDebeSerResponsable() {
		return propietarioDebeSerResponsable;
	}

	/**
	 * @param setea el parametro propietarioDebeSerResponsable al campo propietarioDebeSerResponsable
	 */
	public void setPropietarioDebeSerResponsable(
			String propietarioDebeSerResponsable) {
		this.propietarioDebeSerResponsable = propietarioDebeSerResponsable;
	}

}
