package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.ReglamentacionInvalidaTipoVehiculos;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;

public class CondicionesRetiroVehiculos extends GenericNormativa {

	public CondicionesRetiroVehiculos(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String defaultAmbitoMarcoGeografico = MarcoGeograficoSource.AMBITO_REGIONAL;
	private MarcoGeografico marcoGeografico;

	private List<NormativaRecordUI> recordGroup;

	private List<TipoVehiculo> tiposVehiculo;
	// private List<TipoVehiculo> selectedTiposVehiculo;
	private TipoVehiculo selectedTipoVehiculo;
	private Map<Integer, TipoVehiculo> tiposVehiculoMap;
	private Map<String, MarcoGeograficoSource> marcoGeograficoSourcePorVeh;

	private Integer modeloDesde;
	private Integer modeloHasta;
	private Date fechaRetiro;
	private Integer antiguedadMaxima;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException, ReglamentacionInvalidaTipoVehiculos {
		marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico);

		NormativasDataCache cacheNorm = NormativaAccess.getInstance().getNormativasDataCache(normativa.getReglamentacion());

		tiposVehiculoMap = new HashMap<Integer, TipoVehiculo>();

		marcoGeografico.setSource(cacheNorm.getMarcoGeograficoCompleto());

		if (cacheNorm.getMarcoGeograficoSourcePorTipoVehiculo() != null) {
			this.marcoGeograficoSourcePorVeh = cacheNorm.getMarcoGeograficoSourcePorTipoVehiculo();
			if (tiposVehiculo == null)
				tiposVehiculo = new ArrayList<TipoVehiculo>();
			for (TipoVehiculo tipoVeh : cacheNorm.getTiposVehiculos()) {
				tiposVehiculo.add(tipoVeh);
				tiposVehiculoMap.put(tipoVeh.getId(), tipoVeh);
			}
		} else {
			tiposVehiculo = cacheNorm.getAllTiposVehiculos();
			for (TipoVehiculo ts : tiposVehiculo) {
				tiposVehiculoMap.put(ts.getId(), ts);
			}
		}

		// MarcoGeograficoSource marcoGeograficoSource = new
		// MarcoGeograficoSource();
		// marcoGeograficoSource.updateData(reglamentacionBean.getUbicacionGeograficaManager(),reglamentacionBean.getZonaManager(),new
		// String[]{MarcoGeograficoSource.AMBITO_NACIONAL
		// ,MarcoGeograficoSource.AMBITO_REGIONAL,
		// MarcoGeograficoSource.AMBITO_ZONAL},reglamentacionBean.getReglamentacionDB().getMarcoGeografico());
		// marcoGeografico.setSource(marcoGeograficoSource);
		//
		// tiposVehiculoMap=new HashMap<Integer, TipoVehiculo>();
		// tiposVehiculo=reglamentacionBean.getVehiculoManager().getAllTiposVehiculo();
		// for (TipoVehiculo ts : tiposVehiculo) {
		// tiposVehiculoMap.put(ts.getId(), ts);
		// }

		this.normativa = normativa;
		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "condiciones_retiro");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);
			String tsString = "";
			for (String key : recordUI.getItemsMap().get("tipos_vehiculo").getValues()) {
				tsString += tiposVehiculoMap.get(Integer.parseInt(key)).getDescripcion() + ", ";
			}
			recordUI.getItemsMap().get("tipos_vehiculo").setTextualValue(!tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString);
			recordUI.getItemsMap().get("marco_geografico_aplicable_a").setTextualValue(MarcoGeograficoSource.getAmbitoName(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue()));

			tsString = "";
			for (String key : recordUI.getItemsMap().get("marco_geografico").getValues()) {
				Localizable descripcionById = marcoGeografico.getSource().getDescripcionById(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue(), key);
				if (descripcionById != null)
					tsString += descripcionById.getLabel() + ", ";
			}
			recordUI.getItemsMap().get("marco_geografico").setTextualValue(!tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString);

			recordGroup.add(recordUI);
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (!marcoGeografico.getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL) && marcoGeografico.getLocalizables().isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.marcoGeografico") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		// if(selectedTiposVehiculo.isEmpty()){
		if (selectedTipoVehiculo == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposVehiculo") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (fechaRetiro == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.fechaRetiro") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (antiguedadMaxima == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.antiguedadMaxima") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		if (modeloDesde != null && modeloHasta != null && modeloDesde > modeloHasta) {
			messageBean.addMessage(
					Resources.getString("validation.message.ordered",
							new String[] { Resources.getString("reglamentacion.normativa.field.modeloDesde"), Resources.getString("reglamentacion.normativa.field.modeloHasta") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public void addItem() {
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		List<String> ts = new ArrayList<String>();
		String tsString = "";
		for (Localizable item : marcoGeografico.getLocalizables()) {
			ts.add(String.valueOf(item.getIdentifier()));
			tsString += item.getLabel() + ", ";
		}
		recordItem.put("marco_geografico", new NormativaItem("marco_geografico", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		ts = new ArrayList<String>();
		tsString = "";

		ts.add(String.valueOf(selectedTipoVehiculo.getId()));
		tsString += selectedTipoVehiculo.getDescripcion() + ", ";

		// for (TipoVehiculo item : selectedTiposVehiculo) {
		// ts.add(String.valueOf(item.getId()));
		// tsString+=item.getDescripcion()+", ";
		// }
		recordItem.put("tipos_vehiculo", new NormativaItem("tipos_vehiculo", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		recordItem.put("marco_geografico_aplicable_a",
				new NormativaItem("marco_geografico_aplicable_a", marcoGeografico.getAplicableA(), MarcoGeograficoSource.getAmbitoName(marcoGeografico.getAplicableA())));
		recordItem.put("modelo_desde", new NormativaItem("modelo_desde", (modeloDesde != null) ? String.valueOf(modeloDesde) : null));
		recordItem.put("modelo_hasta", new NormativaItem("modelo_hasta", (modeloHasta != null) ? String.valueOf(modeloHasta) : null));
		recordItem.put("fecha_retiro", new NormativaItem("fecha_retiro", (fechaRetiro != null) ? Constants.dateFormat.format(fechaRetiro) : null));
		recordItem.put("antiguedad_maxima", new NormativaItem("antiguedad_maxima", (antiguedadMaxima != null) ? String.valueOf(antiguedadMaxima) : null));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "condiciones_retiro", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		// selectedTiposVehiculo=new ArrayList<TipoVehiculo>();
		selectedTipoVehiculo = null;
		marcoGeografico.setAplicableA(defaultAmbitoMarcoGeografico);
		marcoGeografico.setLocalizables(new ArrayList<Localizable>());
		modeloDesde = null;
		modeloHasta = null;
		fechaRetiro = null;
		antiguedadMaxima = null;

		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public List<TipoVehiculo> getTiposVehiculo() {
		return tiposVehiculo;
	}

	public void setTiposVehiculo(List<TipoVehiculo> tiposVehiculo) {
		this.tiposVehiculo = tiposVehiculo;
	}

	// public List<TipoVehiculo> getSelectedTiposVehiculo() {
	// return selectedTiposVehiculo;
	// }
	//
	// public void setSelectedTiposVehiculo(List<TipoVehiculo>
	// selectedTiposVehiculo) {
	// this.selectedTiposVehiculo = selectedTiposVehiculo;
	// }

	public MarcoGeografico getMarcoGeografico() {
		return marcoGeografico;
	}

	public void setMarcoGeografico(MarcoGeografico marcoGeografico) {
		this.marcoGeografico = marcoGeografico;
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	public Integer getModeloDesde() {
		return modeloDesde;
	}

	public void setModeloDesde(Integer modeloDesde) {
		this.modeloDesde = modeloDesde;
	}

	public Integer getModeloHasta() {
		return modeloHasta;
	}

	public void setModeloHasta(Integer modeloHasta) {
		this.modeloHasta = modeloHasta;
	}

	public Date getFechaRetiro() {
		return fechaRetiro;
	}

	public void setFechaRetiro(Date fechaRetiro) {
		this.fechaRetiro = fechaRetiro;
	}

	public Integer getAntiguedadMaxima() {
		return antiguedadMaxima;
	}

	public void setAntiguedadMaxima(Integer antiguedadMaxima) {
		this.antiguedadMaxima = antiguedadMaxima;
	}

	/**
	 * @return el valor de selectedTipoVehiculo
	 */
	public TipoVehiculo getSelectedTipoVehiculo() {
		return selectedTipoVehiculo;
	}

	/**
	 * @param setea
	 *            el parametro selectedTipoVehiculo al campo
	 *            selectedTipoVehiculo
	 */
	public void setSelectedTipoVehiculo(TipoVehiculo selectedTipoVehiculo) {
		this.selectedTipoVehiculo = selectedTipoVehiculo;
	}

	/**
	 * @return el valor de marcoGeograficoSourcePorVeh
	 */
	public Map<String, MarcoGeograficoSource> getMarcoGeograficoSourcePorVeh() {
		return marcoGeograficoSourcePorVeh;
	}

	/**
	 * @param setea
	 *            el parametro marcoGeograficoSourcePorVeh al campo
	 *            marcoGeograficoSourcePorVeh
	 */
	public void setMarcoGeograficoSourcePorVeh(Map<String, MarcoGeograficoSource> marcoGeograficoSourcePorVeh) {
		this.marcoGeograficoSourcePorVeh = marcoGeograficoSourcePorVeh;
	}

	public void generarMarcoGeografico() {
		if (marcoGeograficoSourcePorVeh != null && selectedTipoVehiculo != null) {
			marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico);
			MarcoGeograficoSource marcoGeograficoSource = this.marcoGeograficoSourcePorVeh.get(String.valueOf(this.selectedTipoVehiculo.getId()));
			marcoGeografico.setSource(marcoGeograficoSource);
			marcoGeografico.setTipoZonaSelected(marcoGeografico.getSource().getTiposZona().get(0));
		}

	}

}
