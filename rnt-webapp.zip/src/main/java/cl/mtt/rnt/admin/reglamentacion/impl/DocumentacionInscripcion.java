package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoDocumentoGrupo;
import cl.mtt.rnt.commons.model.core.TipoDocumentoRequerido;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class DocumentacionInscripcion extends GenericNormativa {

	public DocumentacionInscripcion(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private Map<String, List<TipoDocumentoRequerido>> tiposDocumentoMap;
	private List<TipoDocumentoGrupo> tiposDocumentoGrupos;
	// private List<TipoDocumentoRequerido> tiposDocumento;
	private List<TipoDocumentoRequerido> selectedTiposDocumento;
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// Norma no validada, solo mensaje

		String m = Resources.getString("validation.message.event.documentacionInscripcion");
		for (TipoDocumentoRequerido item : selectedTiposDocumento) {
			m += "<br/>" + item.getNombre();
		}

		return new RntEventResultItem(true, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		tiposDocumentoMap = getTiposDocumentoMap(reglamentacionManager);
		selectedTiposDocumento = new ArrayList<TipoDocumentoRequerido>();

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "tipos_documento");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			List<Long> idsClase = new ArrayList<Long>();
			for (String value : items.get("tipos_documento").getValues()) {
				idsClase.add(Long.valueOf(value));
			}
			if ((idsClase != null) && (!idsClase.isEmpty()))
				selectedTiposDocumento = reglamentacionManager.getGeneralDataManager().getTiposDocumentoRequeridoByIds(idsClase);
			else
				selectedTiposDocumento = new ArrayList<TipoDocumentoRequerido>();
			updateTiposDocumentoMap(selectedTiposDocumento);
			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("tipos_documento");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("tipos_documento", new ArrayList<String>()));
		}
		updateTiposDocumentoMap(selectedTiposDocumento);
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		List<String> idsClase = new ArrayList<String>();
		for (TipoDocumentoRequerido item : selectedTiposDocumento) {
			idsClase.add(String.valueOf(item.getId()));
		}
		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("tipos_documento").setValues(idsClase);

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		selectedTiposDocumento = getSelectedItems(tiposDocumentoMap);
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		selectedTiposDocumento = getSelectedItems(tiposDocumentoMap);
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (normativa.getValidacion().equals("validacion.especificada") && selectedTiposDocumento.size() == 0) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	private Map<String, List<TipoDocumentoRequerido>> getTiposDocumentoMap(ReglamentacionManager reglamentacionManager) throws GeneralDataAccessException {
		Map<String, List<TipoDocumentoRequerido>> map = new HashMap<String, List<TipoDocumentoRequerido>>();

		tiposDocumentoGrupos = reglamentacionManager.getGeneralDataManager().getAllTipoDocumentoGrupo();
		for (TipoDocumentoGrupo tipoDocumentoGrupo : tiposDocumentoGrupos) {
			map.put(tipoDocumentoGrupo.getNombre(), new ArrayList<TipoDocumentoRequerido>());
		}
		List<TipoDocumentoRequerido> tipos = reglamentacionManager.getGeneralDataManager().getAllTipoDocumentoRequerido(false);
		for (TipoDocumentoRequerido tipoDocumentoRequerido : tipos) {
			map.get(tipoDocumentoRequerido.getGrupo().getNombre()).add(tipoDocumentoRequerido);
		}
		return map;

	}

	private void updateTiposDocumentoMap(List<TipoDocumentoRequerido> selectedTiposDocumento) {
		for (Map.Entry<String, List<TipoDocumentoRequerido>> entry : tiposDocumentoMap.entrySet()) {
			for (TipoDocumentoRequerido tipoDocumentoRequerido : entry.getValue()) {
				tipoDocumentoRequerido.setSelected(selectedTiposDocumento.contains(tipoDocumentoRequerido));
			}
		}
	}

	private List<TipoDocumentoRequerido> getSelectedItems(Map<String, List<TipoDocumentoRequerido>> map) {
		List<TipoDocumentoRequerido> selected = new ArrayList<TipoDocumentoRequerido>();

		for (Map.Entry<String, List<TipoDocumentoRequerido>> entry : map.entrySet()) {
			for (TipoDocumentoRequerido tipoDocumentoRequerido : entry.getValue()) {
				if (tipoDocumentoRequerido.isSelected())
					selected.add(tipoDocumentoRequerido);
			}
		}

		return selected;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public List<TipoDocumentoRequerido> getSelectedTiposDocumento() {
		return selectedTiposDocumento;
	}

	public void setSelectedTiposDocumento(List<TipoDocumentoRequerido> selectedTiposDocumento) {
		this.selectedTiposDocumento = selectedTiposDocumento;
	}

	public Map<String, List<TipoDocumentoRequerido>> getTiposDocumentoMap() {
		return tiposDocumentoMap;
	}

	public void setTiposDocumentoMap(Map<String, List<TipoDocumentoRequerido>> tiposDocumentoMap) {
		this.tiposDocumentoMap = tiposDocumentoMap;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

	public List<TipoDocumentoGrupo> getTiposDocumentoGrupos() {
		return tiposDocumentoGrupos;
	}

	public void setTiposDocumentoGrupos(List<TipoDocumentoGrupo> tiposDocumentoGrupos) {
		this.tiposDocumentoGrupos = tiposDocumentoGrupos;
	}

}
