package cl.mtt.rnt.admin.reglamentacion.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;

public class FechasEmisionLicencias_acompaniantes extends GenericNormativa {

	public FechasEmisionLicencias_acompaniantes(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private Date emitidaDesde;
	private Date emitidaHasta;
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		try {
			this.normativa = normativa;
			List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "fechas_emisiones_licencias");
			if (ems != null && ems.size() > 0) {
				Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
				emitidaDesde = (items.get("emitida_desde").getValue() != null) ? Constants.dateFormat.parse(items.get("emitida_desde").getValue()) : null;
				emitidaHasta = (items.get("emitida_hasta").getValue() != null) ? Constants.dateFormat.parse(items.get("emitida_hasta").getValue()) : null;

				normativaRegistro = ems.get(0);
			} else {
				normativaRegistro = new NormativaRegistro();
				normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
				normativaRegistro.setDescriptor("fechas_emisiones_licencias");
				normativaRegistro.setItems(new ArrayList<NormativaItem>());
				normativaRegistro.addNormativaItem(new NormativaItem("emitida_desde", (emitidaDesde != null) ? Constants.dateFormat.format(emitidaDesde) : null));
				normativaRegistro.addNormativaItem(new NormativaItem("emitida_hasta", (emitidaHasta != null) ? Constants.dateFormat.format(emitidaHasta) : null));
			}
		} catch (ParseException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("emitida_desde").setValues(Arrays.asList(new String[] { (emitidaDesde != null) ? Constants.dateFormat.format(emitidaDesde) : null }));
		items.get("emitida_hasta").setValues(Arrays.asList(new String[] { (emitidaHasta != null) ? Constants.dateFormat.format(emitidaHasta) : null }));

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (normativa.getValidacion().equals("validacion.especificada")) {
			if (emitidaDesde == null) {
				messageBean.addMessage(
						Resources.getString("validation.message.specificItemRequired", new String[] { normativa.getLabel(), Resources.getString("reglamentacion.normativa.field.emitidaDesde") }),
						FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
			if (emitidaHasta == null) {
				messageBean.addMessage(
						Resources.getString("validation.message.specificItemRequired", new String[] { normativa.getLabel(), Resources.getString("reglamentacion.normativa.field.emitidaHasta") }),
						FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
			if (emitidaDesde != null && emitidaHasta != null && emitidaHasta.before(emitidaDesde)) {
				messageBean.addMessage(
						Resources.getString("validation.message.norma.orderedDates", new String[] { this.getNormativa().getLabel(), Resources.getString("reglamentacion.normativa.field.emitidaDesde"),
								Resources.getString("reglamentacion.normativa.field.emitidaHasta") }), FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
		}

		return valid;
	}

	public Date getEmitidaDesde() {
		return emitidaDesde;
	}

	public void setEmitidaDesde(Date emitidaDesde) {
		this.emitidaDesde = emitidaDesde;
	}

	public Date getEmitidaHasta() {
		return emitidaHasta;
	}

	public void setEmitidaHasta(Date emitidaHasta) {
		this.emitidaHasta = emitidaHasta;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

}
