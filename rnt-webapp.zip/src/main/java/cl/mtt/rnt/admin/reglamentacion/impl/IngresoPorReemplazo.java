package cl.mtt.rnt.admin.reglamentacion.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.codehaus.groovy.transform.sc.transformers.CompareToNullExpression;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.reglamentacion.util.PropertiesManager;
import cl.mtt.rnt.admin.reglamentacion.util.SelectionItem;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.ElResolver;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

public class IngresoPorReemplazo extends GenericNormativa {

	public IngresoPorReemplazo(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	protected static final Map<String,Integer> sortMap = new HashMap<String, Integer>();
	static {
		sortMap.put("sePermiteIngresar_porReemplazo.soloNuevosNuevoEnRegistro", 1);
		sortMap.put("sePermiteIngresar_porReemplazo.soloNuevosExistenteEnRegistro", 2);
		sortMap.put("sePermiteIngresar_porReemplazo.soloNuevos", 3);
		sortMap.put("sePermiteIngresar_porReemplazo.ingresoDirectoVehiculoExistenteOtraCategoria", 4);
		sortMap.put("sePermiteIngresar_porReemplazo.soloReemplazoNuevoEnRegistro", 5);
		sortMap.put("sePermiteIngresar_porReemplazo.soloReemplazoExistenteEnRegistro", 6);
		sortMap.put("sePermiteIngresar_porReemplazo.soloReemplazo", 7);
		sortMap.put("sePermiteIngresar_porReemplazo.ambosCasosNuevoEnRegistro", 8);
		sortMap.put("sePermiteIngresar_porReemplazo.ambosCasosExistenteEnRegistro", 9);
		sortMap.put("sePermiteIngresar_porReemplazo.ambosCasos", 10);
	}
	
	private ReglamentacionManager reglamentacionManager;

	private String sePermiteIngresar = "sePermiteIngresar_porReemplazo.soloNuevos";
	private NormativaRegistro sePermiteIngresarRegistro;
	private boolean incorporaCupos = false;

	private boolean vehiculoExistenteNoEvaluar = false;
	
	private Date vigenciaDesde;
	private Date vigenciaHasta;
	private Integer cupo;
	private List<NormativaRecordUI> recordGroup;

	private List<TipoServicio> tiposServicio;
	private TipoServicio selectedTipoServicio;
	private List<SelectionItem> regiones;
	private String selectedRegion;

	private Map<NormativaRegistro, Integer> usadosMap;
	private String aplicaAMG;
	
	public List<SelectionItem> getPropertiesSePermiteIngresar() {
		List<SelectionItem> properties = PropertiesManager.getProperties("sePermiteIngresar_porReemplazo");
		Collections.sort(properties, new Comparator<SelectionItem>() {
			@Override
			public int compare(SelectionItem o1, SelectionItem o2) {
				return sortMap.get(o1.getDescriptor()).compareTo(sortMap.get(o2.getDescriptor()));
			}
			
		});
		return properties;
	}
	
	private boolean existeVehiculoRnt(Vehiculo vehiculo) {
        CurrentSessionBean curr = (CurrentSessionBean) ElResolver.getManagedObject("currentSessionBean");
        if (curr != null)
            try {
                return curr.getVehiculoManagerRnt().getVehiculoExistente(vehiculo);
                
            } catch (GeneralDataAccessException e) {
                return false;
            }
        return false;
    }

	private boolean existeVehiculoRntOtraCategoria(Vehiculo vehiculo,TipoServicio tipoServicio) {
        CurrentSessionBean curr = (CurrentSessionBean) ElResolver.getManagedObject("currentSessionBean");
        if (curr != null)
            try {
                return curr.getVehiculoManagerRnt().getVehiculoExistenteOtraCategoria(vehiculo, tipoServicio);
                
            } catch (GeneralDataAccessException e) {
                return false;
            }
        return false;
    }
	
	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// sePermiteIngresar_porReemplazo.soloNuevos=Ingreso Directo
		// sePermiteIngresar_porReemplazo.soloReemplazo=Solo reemplazo
		// sePermiteIngresar_porReemplazo.soloReemplazoNuevoEnRegistro=Por
		// reemplazo (Nuevo en Registro)
		// sePermiteIngresar_porReemplazo.ambosCasos=Ambos casos

		//sePermiteIngresar_porReemplazo.ingresoDirectoVehiculoExistenteOtraCategoria
		
		boolean r = true;
		String m = null;

		if ((event instanceof NuevoVehiculoEvent || event instanceof TrasladoVehiculoEvent)) {
			if(soloReemplazaEnServicio(sePermiteIngresar)) {
				r = false;
				m = Resources.getString("validation.message.event.ingresoPorReemplazo.soloReemplazo");
			}
			else {
				//si permito solo ingresar solo directo nuevo en registro. no puede ser 
				if (("sePermiteIngresar_porReemplazo.soloNuevosNuevoEnRegistro".equals(sePermiteIngresar) ||
						"sePermiteIngresar_porReemplazo.ambosCasosNuevoEnRegistro".equals(sePermiteIngresar))&& 
						((event instanceof TrasladoVehiculoEvent)||(event instanceof NuevoVehiculoEvent))) {
				    ConVehiculoServicioEvent convs =(ConVehiculoServicioEvent) event;
				    if (this.existeVehiculoRnt(convs.getVehiculoServicio().getVehiculo())){//, convs.getVehiculoServicio().getServicio().getTipoServicio())) {
    					r = false;
    					m = Resources.getString("validation.message.event.ingresoPorReemplazo.soloIngresoNuevosEnRegistro");
				    }
				} else {
					if (("sePermiteIngresar_porReemplazo.soloNuevosExistenteEnRegistro".equals(sePermiteIngresar)||
							"sePermiteIngresar_porReemplazo.ambosCasosExistenteEnRegistro".equals(sePermiteIngresar)) && 
							((event instanceof TrasladoVehiculoEvent)||(event instanceof NuevoVehiculoEvent))) {
					    ConVehiculoServicioEvent convs =(ConVehiculoServicioEvent) event;
					    if (!this.existeVehiculoRnt(convs.getVehiculoServicio().getVehiculo() )){//, convs.getVehiculoServicio().getServicio().getTipoServicio())) {
					        r = false;
	                        m = Resources.getString("validation.message.event.ingresoPorReemplazo.soloIngresoExistentesEnRegistro");
	                    }
						
					} else if("sePermiteIngresar_porReemplazo.ingresoDirectoVehiculoExistenteOtraCategoria".equals(sePermiteIngresar) && ((event instanceof TrasladoVehiculoEvent)||(event instanceof NuevoVehiculoEvent))) {
					    ConVehiculoServicioEvent convs =(ConVehiculoServicioEvent) event;
					    if (!this.existeVehiculoRntOtraCategoria(convs.getVehiculoServicio().getVehiculo(), convs.getVehiculoServicio().getServicio().getTipoServicio())) {
					        r = false;
	                        m = Resources.getString("validation.message.event.ingresoPorReemplazo.ingresoDirectoVehiculoExistenteOtraCategoria");
	                    }
						
					}
				}
			}
			
//		} else if ((event instanceof ReemplazoVehiculoEvent || event instanceof ReemplazoTrasladoVehiculoEvent) && "sePermiteIngresar_porReemplazo.soloNuevos".equals(sePermiteIngresar)) {
//			r = false;
//			m = Resources.getString("validation.message.event.ingresoPorReemplazo.soloNuevos");
		} else {
			if ((event instanceof ReemplazoVehiculoEvent) || (event instanceof ReemplazoTrasladoVehiculoEvent)) {
			    ConVehiculoServicioEvent convs =(ConVehiculoServicioEvent) event;
			    VehiculoServicio vehServ = convs.getVehiculoServicio();
				if(!vehiculoExistenteNoEvaluar || !this.existeVehiculoRnt(vehServ.getVehiculo())){
					if (soloNuevosEnServicio(sePermiteIngresar)) {
						r = false;
						m = Resources.getString("validation.message.event.ingresoPorReemplazo.soloNuevos");
					}
					else {
						if (("sePermiteIngresar_porReemplazo.soloReemplazoNuevoEnRegistro".equals(sePermiteIngresar) ||
								"sePermiteIngresar_porReemplazo.ambosCasosNuevoEnRegistro".equals(sePermiteIngresar))) {
		                    if (this.existeVehiculoRnt(vehServ.getVehiculo())){//, convs.getVehiculoServicio().getServicio().getTipoServicio())) {
	    						r = false;
	    						m = Resources.getString("validation.message.event.ingresoPorReemplazo.soloReemplazoNuevoEnRegistro");
		                    }
						}
						else {
							if (("sePermiteIngresar_porReemplazo.soloReemplazoExistenteEnRegistro".equals(sePermiteIngresar)||
									"sePermiteIngresar_porReemplazo.ambosCasosExistenteEnRegistro".equals(sePermiteIngresar))) {
			                    if (!this.existeVehiculoRnt(vehServ.getVehiculo())){//, convs.getVehiculoServicio().getServicio().getTipoServicio())) {
	    							r = false;
	    							m = Resources.getString("validation.message.event.ingresoPorReemplazo.soloReemplazoExistentesEnRegistro");
			                    }
							}
						}
					}
				}
			}
		}

		try {
			if (r && "sePermiteIngresar_porReemplazo.soloNuevos".equals(sePermiteIngresar)) {// valido en caso de ingreso por cupos
				VehiculoServicio vs = null;
				if (event instanceof NuevoVehiculoEvent)
					vs = ((NuevoVehiculoEvent) event).getVehiculoServicio();
				else if (event instanceof TrasladoVehiculoEvent)
					vs = ((TrasladoVehiculoEvent) event).getVehiculoServicioNuevo();
				for (NormativaRecordUI item : recordGroup) {
					if (Long.valueOf(item.getItemsMap().get("tipo_servicio").getValue()).equals(vs.getServicio().getTipoServicio().getId())) {
						if ((!aplicaAMG.equals(MarcoGeograficoSource.AMBITO_ZONAL) && item.getItemsMap().get("region_zona").getValue().equals(vs.getServicio().getCodigoRegion()))
								|| (aplicaAMG.equals(MarcoGeograficoSource.AMBITO_ZONAL) && Long.valueOf(item.getItemsMap().get("region_zona").getValue()).equals(vs.getZonaVehiculo().getId()))) {
							Date today = new Date();
							Date desde = Constants.dateFormat.parse(item.getItemsMap().get("vigencia_desde").getValue());
							if (ValidacionHelper.esFechaMayor(desde, today)) {
								r = false;
								m = Resources.getString("validation.message.event.ingresoPorReemplazo.fueraVigencia.anteriorDesde",
										new String[] { item.getItemsMap().get("vigencia_desde").getValue() });
								return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
							}
							if (item.getItemsMap().get("vigencia_hasta").getValue() != null && !"".equals(item.getItemsMap().get("vigencia_hasta").getValue().equals(""))) {
								Date hasta = Constants.dateFormat.parse(item.getItemsMap().get("vigencia_hasta").getValue());
								if (ValidacionHelper.esFechaMayor(today, hasta)) {
									r = false;
									m = Resources.getString("validation.message.event.ingresoPorReemplazo.fueraVigencia", new String[] { item.getItemsMap().get("vigencia_desde").getValue(),
											item.getItemsMap().get("vigencia_hasta").getValue() });
									return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
								}
							}
							int cupo = Integer.valueOf(item.getItemsMap().get("valor_cupo").getValue());
							int cantidadUsada = getUsados(item);
							int modificadorServicio = vs.getServicio().getModificadorCupoVehiculos(this.getNormativa().getReglamentacion().getId(), item.getItemsMap().get("region_zona").getValue());
							if (cupo <= cantidadUsada + modificadorServicio) {
								r = false;
								m = Resources.getString("validation.message.event.ingresoPorReemplazo.superaCupo");
								return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
							}
						}
					}
				}
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	public boolean soloReemplazaEnServicio(String seleccionIngreso) {
		return "sePermiteIngresar_porReemplazo.soloReemplazo".equals(seleccionIngreso) || 
				"sePermiteIngresar_porReemplazo.soloReemplazoNuevoEnRegistro".equals(seleccionIngreso) ||
					"sePermiteIngresar_porReemplazo.soloReemplazoExistenteEnRegistro".equals(seleccionIngreso);
	}

	public boolean soloNuevosEnServicio(String seleccionIngreso) {
		return "sePermiteIngresar_porReemplazo.soloNuevos".equals(seleccionIngreso) || 
				"sePermiteIngresar_porReemplazo.soloNuevosNuevoEnRegistro".equals(seleccionIngreso) ||
				"sePermiteIngresar_porReemplazo.soloNuevosExistenteEnRegistro".equals(seleccionIngreso) ||
				"sePermiteIngresar_porReemplazo.ingresoDirectoVehiculoExistenteOtraCategoria".equals(seleccionIngreso) ;
		
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		this.reglamentacionManager = reglamentacionManager;
		aplicaAMG = normativa.getReglamentacion().getMarcoGeografico().getAplicableA();
		regiones = new ArrayList<SelectionItem>();// depende de la
													// reglamentacion
		List<Localizable> localizables = new ArrayList<Localizable>();
		if (normativa.getReglamentacion().getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL)) {
			List<Region> regionesDB = reglamentacionManager.getUbicacionGeograficaManager().getAllRegiones();
			for (Region region : regionesDB) {
				localizables.add(region);
			}
		} else {
			localizables = normativa.getReglamentacion().getMarcoGeografico().getLocalizables();
		}
		for (Localizable region : localizables) {
			regiones.add(new SelectionItem(region.getIdentifier(), region.getLabelLarge()));
		}

		tiposServicio = normativa.getReglamentacion().getTiposServicio(); // Van
																						// solo

		this.normativa = normativa;
		recordGroup = new ArrayList<NormativaRecordUI>();

		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "se_permite_ingresar");
		if (ems != null && ems.size() > 0) {
			sePermiteIngresarRegistro = ems.get(0);
			sePermiteIngresar = sePermiteIngresarRegistro.getItems().get(0).getValue();
			incorporaCupos = Boolean.valueOf(sePermiteIngresarRegistro.getItems().get(1).getValue()).booleanValue();
			if(sePermiteIngresarRegistro.getItems().size()>2){
				vehiculoExistenteNoEvaluar = Boolean.valueOf(sePermiteIngresarRegistro.getItems().get(2).getValue()).booleanValue();
			} else {
				vehiculoExistenteNoEvaluar = false;
				NormativaItem ni3 = new NormativaItem("vehiculoExistenteNoEvaluar", String.valueOf(vehiculoExistenteNoEvaluar));
				ni3.setRegistro(sePermiteIngresarRegistro);
				sePermiteIngresarRegistro.getItems().add(ni3);
			}
			
			List<NormativaRegistro> emsCupos = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "cupos_servicios");

			for (int i = 0; i < emsCupos.size(); i++) {
				NormativaRegistro normativaRegistro = emsCupos.get(i);
				NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);

				NormativaItem itemTs = recordUI.getItemsMap().get("tipo_servicio");
				if(itemTs!=null){
					itemTs.setTextualValue(getTipoServicioName(Long.valueOf(itemTs.getValue())));
				}
				NormativaItem itemR = recordUI.getItemsMap().get("region_zona");
				if(itemR!=null){
					itemR.setTextualValue(getRegionName(itemR.getValue()));
				}
				
				recordGroup.add(recordUI);
			}

		} else {
			sePermiteIngresarRegistro = new NormativaRegistro();
			sePermiteIngresarRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			sePermiteIngresarRegistro.setDescriptor("se_permite_ingresar");
			sePermiteIngresarRegistro.setItems(new ArrayList<NormativaItem>());
			NormativaItem ni1 = new NormativaItem("se_permite_ingresar", sePermiteIngresar);
			ni1.setRegistro(sePermiteIngresarRegistro);
			sePermiteIngresarRegistro.getItems().add(ni1);
			NormativaItem ni2 = new NormativaItem("incorpora_cupos", String.valueOf(incorporaCupos));
			ni2.setRegistro(sePermiteIngresarRegistro);
			sePermiteIngresarRegistro.getItems().add(ni2);
			NormativaItem ni3 = new NormativaItem("vehiculoExistenteNoEvaluar", String.valueOf(vehiculoExistenteNoEvaluar));
			ni3.setRegistro(sePermiteIngresarRegistro);
			sePermiteIngresarRegistro.getItems().add(ni3);
		}

		usadosMap = new HashMap<NormativaRegistro, Integer>();
		// for (NormativaRecordUI item : recordGroup) {
		// usadosMap.put(item.getRegistro(), getUsados(item));
		// }

		updateNormativa();

	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		sePermiteIngresarRegistro.setNormativa(normativa);
		sePermiteIngresarRegistro.getItems().get(0).setValues(Arrays.asList(new String[] { sePermiteIngresar }));
		sePermiteIngresarRegistro.getItems().get(1).setValues(Arrays.asList(new String[] { String.valueOf(incorporaCupos) }));
		sePermiteIngresarRegistro.getItems().get(2).setValues(Arrays.asList(new String[] { String.valueOf(vehiculoExistenteNoEvaluar) }));
		
		normativa.getRegistros().add(sePermiteIngresarRegistro);
		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		// if(selectedTiposVehiculo.isEmpty()){
		if (selectedTipoServicio == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposServicio") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (selectedRegion == null) {
			messageBean.addMessage(
					Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.region") }) + " / "
							+ Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.zona") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (vigenciaDesde == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaDesde") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (vigenciaDesde != null && vigenciaHasta != null && ValidacionHelper.esFechaMayor(vigenciaDesde, vigenciaHasta)) {
			messageBean.addMessage(
					Resources.getString("validation.message.orderedDates",
							new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaDesde"), Resources.getString("reglamentacion.normativa.field.vigenciaHasta") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		// if(vigenciaHasta==null){
		// messageBean.addMessage(Resources.getString("validation.message.required",new
		// String[]{Resources.getString("reglamentacion.normativa.field.vigenciaHasta")}),FacesMessage.SEVERITY_ERROR);
		// valid=false;
		// }
		if (cupo == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.cupo") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		// Valido que no se repitan las lineas
		if (valid) {
			for (NormativaRecordUI item : recordGroup) {
				if (item.getAction() != GenericModelObject.ACTION_DELETE && Long.valueOf(item.getItemsMap().get("tipo_servicio").getValue()).equals(selectedTipoServicio.getId())
						&& item.getItemsMap().get("region_zona").getValue().equals(selectedRegion)) {
					messageBean.addMessage(Resources.getString("validation.message.duplicate.rows"), FacesMessage.SEVERITY_ERROR);
					valid = false;
				}
			}
		}

		return valid;
	}

	private String getRegionName(String codigo) {
		for (SelectionItem reg : regiones) {
			if (reg.getDescriptor().equals(codigo))
				return reg.getLabel();
		}
		return null;
	}

	private String getTipoServicioName(Long id) {
		for (TipoServicio ts : tiposServicio) {
			if (ts.getId().equals(id))
				return ts.getName();
		}
		return null;
	}

	public void addItem() {
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		// tipo_servicio
		// region_zona
		// vigencia_desde
		// vigencia_hasta
		// valor_cupo

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		recordItem.put("tipo_servicio", new NormativaItem("tipo_servicio", String.valueOf(selectedTipoServicio.getId()), selectedTipoServicio.getName()));

		recordItem.put("region_zona", new NormativaItem("region_zona", selectedRegion, getRegionName(selectedRegion)));

		recordItem.put("vigencia_desde", new NormativaItem("vigencia_desde", Constants.dateFormat.format(vigenciaDesde)));

		recordItem.put("vigencia_hasta", new NormativaItem("vigencia_hasta", (vigenciaHasta != null) ? Constants.dateFormat.format(vigenciaHasta) : null));

		recordItem.put("valor_cupo", new NormativaItem("valor_cupo", String.valueOf(cupo)));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "cupos_servicios", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		// selectedTiposVehiculo=new ArrayList<TipoVehiculo>();
		selectedTipoServicio = null;
		selectedRegion = null;
		vigenciaDesde = null;
		vigenciaHasta = null;
		cupo = null;

		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;

	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		try {
			int count = 0;
			for (NormativaRecordUI rg : recordGroup) {
				if (rg.getAction() != GenericModelObject.ACTION_DELETE) {
					count++;
					// valido los elementos editados
					Date vd = Constants.dateFormat.parse(rg.getItemsMap().get("vigencia_desde").getValue());
					if (rg.getItemsMap().get("vigencia_hasta").getValue() != null) {
						Date vh = Constants.dateFormat.parse(rg.getItemsMap().get("vigencia_hasta").getValue());
						if (vd != null && vh != null && ValidacionHelper.esFechaMayor(vd, vh)) {
							messageBean.addMessage(
									Resources.getString("validation.message.orderedDates",
											new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaDesde"), Resources.getString("reglamentacion.normativa.field.vigenciaHasta") }),
									FacesMessage.SEVERITY_ERROR);
							return false;// retorno para que no me repita mas de
											// un mensaje igual
						}
					}
				}
			}
			if (normativa.getValidacion().equals("validacion.especificada") && (incorporaCupos) && (recordGroup == null || count == 0)) {
				messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return valid;
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	public String getSePermiteIngresar() {
		return sePermiteIngresar;
	}

	public void setSePermiteIngresar(String sePermiteIngresar) {
		this.sePermiteIngresar = sePermiteIngresar;
	}

	public boolean isIncorporaCupos() {
		return incorporaCupos;
	}

	public void setIncorporaCupos(boolean incorporaCupos) {
		this.incorporaCupos = incorporaCupos;
	}

	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	public TipoServicio getSelectedTipoServicio() {
		return selectedTipoServicio;
	}

	public void setSelectedTipoServicio(TipoServicio selectedTipoServicio) {
		this.selectedTipoServicio = selectedTipoServicio;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public Date getVigenciaDesde() {
		return vigenciaDesde;
	}

	public void setVigenciaDesde(Date vigenciaDesde) {
		this.vigenciaDesde = vigenciaDesde;
	}

	public Date getVigenciaHasta() {
		return vigenciaHasta;
	}

	public void setVigenciaHasta(Date vigenciaHasta) {
		this.vigenciaHasta = vigenciaHasta;
	}

	public Integer getCupo() {
		return cupo;
	}

	public void setCupo(Integer cupo) {
		this.cupo = cupo;
	}

	public List<SelectionItem> getRegiones() {
		return regiones;
	}

	public void setRegiones(List<SelectionItem> regiones) {
		this.regiones = regiones;
	}

	public String getSelectedRegion() {
		return selectedRegion;
	}

	public void setSelectedRegion(String selectedRegion) {
		this.selectedRegion = selectedRegion;
	}

	public Map<NormativaRegistro, Integer> getUsadosMap() {
		return usadosMap;
	}

	public void setUsadosMap(Map<NormativaRegistro, Integer> usadosMap) {
		this.usadosMap = usadosMap;
	}

	public Integer getUsados(NormativaRecordUI normativaRegistro) {
		Map<String, NormativaItem> map = normativaRegistro.getItemsMap();
		if (!usadosMap.containsKey(normativaRegistro.getRegistro())) {
			try {
				Integer cant = 0;
				if(map.get("tipo_servicio")!=null){
					cant = reglamentacionManager.getCantidadCupoUsado(this.getNormativa().getReglamentacion().getId(), Long.valueOf(map.get("tipo_servicio").getValue()),
						(!aplicaAMG.equals(MarcoGeograficoSource.AMBITO_ZONAL)) ? map.get("region_zona").getValue() : null,
						(aplicaAMG.equals(MarcoGeograficoSource.AMBITO_ZONAL)) ? Long.valueOf(map.get("region_zona").getValue()) : null);
				}
				usadosMap.put(normativaRegistro.getRegistro(), cant);
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (GeneralDataAccessException e) {
				e.printStackTrace();
			}
		}
		return usadosMap.get(normativaRegistro.getRegistro());
	}

	public String getAplicaAMG() {
		return aplicaAMG;
	}

	public void setAplicaAMG(String aplicaAMG) {
		this.aplicaAMG = aplicaAMG;
	}

	public void startEditItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_UPDATE);
		}
		updateNormativa();
	}

	/**
	 * @return el valor de vehiculoExistenteNoEvaluar
	 */
	public boolean isVehiculoExistenteNoEvaluar() {
		return vehiculoExistenteNoEvaluar;
	}

	/**
	 * @param setea el parametro vehiculoExistenteNoEvaluar al campo vehiculoExistenteNoEvaluar
	 */
	public void setVehiculoExistenteNoEvaluar(boolean vehiculoExistenteNoEvaluar) {
		this.vehiculoExistenteNoEvaluar = vehiculoExistenteNoEvaluar;
	}
}
