package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoConductorEvent;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Inhabilidad;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class InhabilidadesAplicadas extends GenericNormativa {

	public InhabilidadesAplicadas(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private List<Inhabilidad> inhabilidades;
	private List<Inhabilidad> selectedInhabilidades;
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		NuevoConductorEvent e = (NuevoConductorEvent) event;
		boolean r = true;
		String inhabilidadesAplicadas = "";
		if (e.getConductor().getPersona().getInhabilidades() != null) {
			for (Inhabilidad inhabilidad : e.getConductor().getPersona().getInhabilidades()) {
				if (selectedInhabilidades.contains(inhabilidad)) {
					inhabilidadesAplicadas += "&nbsp &nbsp &nbsp " + inhabilidad.getNombre() + "<br/>";
					r = false;
				}
			}
		}

		String m = null;
		if (!r) {
			m = Resources.getString("validation.message.event.inhabilidad", new String[] { " " + e.getConductor().getPersona().getRut() + " " + e.getConductor().getPersona().getNombre() + " ",
					inhabilidadesAplicadas });
		}
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		inhabilidades = reglamentacionManager.getGeneralDataManager().getAllInhabilidades();
		selectedInhabilidades = new ArrayList<Inhabilidad>();

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "inhabilidades");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			List<Long> idsClase = new ArrayList<Long>();
			for (String value : items.get("inhabilidades").getValues()) {
				idsClase.add(Long.valueOf(value));
			}
			selectedInhabilidades = reglamentacionManager.getGeneralDataManager().getInhabilidadesByIds(idsClase);

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("inhabilidades");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("inhabilidades", new ArrayList<String>()));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		List<String> idsClase = new ArrayList<String>();
		for (Inhabilidad inhab : selectedInhabilidades) {
			idsClase.add(String.valueOf(inhab.getId()));
		}
		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("inhabilidades").setValues(idsClase);

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (normativa.getValidacion().equals("validacion.especificada") && selectedInhabilidades.size() == 0) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public List<Inhabilidad> getInhabilidades() {
		return inhabilidades;
	}

	public void setInhabilidades(List<Inhabilidad> inhabilidades) {
		this.inhabilidades = inhabilidades;
	}

	public List<Inhabilidad> getSelectedInhabilidades() {
		return selectedInhabilidades;
	}

	public void setSelectedInhabilidades(List<Inhabilidad> selectedInhabilidades) {
		this.selectedInhabilidades = selectedInhabilidades;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

}
