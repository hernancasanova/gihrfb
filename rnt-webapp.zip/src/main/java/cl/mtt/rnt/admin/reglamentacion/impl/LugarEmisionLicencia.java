package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoConductorEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.ElResolver;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;

public class LugarEmisionLicencia extends GenericNormativa {

	public LugarEmisionLicencia(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String defaultAmbitoMarcoGeografico = MarcoGeograficoSource.AMBITO_REGIONAL;
	private MarcoGeografico marcoGeografico;

	private List<NormativaRecordUI> recordGroup;

	private Zona getZonaDb(Long id) {
		CurrentSessionBean curr = (CurrentSessionBean) ElResolver.getManagedObject("currentSessionBean");
		if (curr != null)
			try {
				return curr.getZonaManager().getZonaById(id);
			} catch (GeneralDataAccessException e) {
				return null;
			}
		return null;
	}

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		NuevoConductorEvent e = (NuevoConductorEvent) event;
		e.getConductor().resetComunaOtorgante();
		Comuna comunaOtorgante = e.getConductor().getComunaOtorgante();

		boolean r = false;
		for (NormativaRecordUI registros : recordGroup) {
			String aplicaA = registros.getItemsMap().get("marco_geografico_aplicable_a").getValue();
			List<NormativaItem> items = registros.getItemsMap().get("marco_geografico").getRegistro().getItems();
			for (NormativaItem item : items) {
				for (String val : item.getValues()) {
					if (aplicaA.equals(MarcoGeograficoSource.AMBITO_COMUNAL) && val.equals(e.getConductor().getCodigoComunaOtorgante()))
						r = true;
					if (aplicaA.equals(MarcoGeograficoSource.AMBITO_REGIONAL) && val.equals(comunaOtorgante.getProvincia().getRegion().getCodigo()))
						r = true;
					if (aplicaA.equals(MarcoGeograficoSource.AMBITO_ZONAL)) {
						Zona zona = getZonaDb(Long.getLong(val));
						if (zona != null) {
							for (String reg : zona.getIdRegiones()) {
								if (reg.equals(comunaOtorgante.getProvincia().getRegion().getCodigo()))
									r = true;
							}
							for (String com : zona.getIdComunas()) {
								if (com.equals(comunaOtorgante.getCodigo()))
									r = true;
							}
						}
					}
				}
			}
		}

		String m = null;
		if (!r) {
			String otorgadaEn = "";
			if (e.getConductor().getNombreComunaOtorgante() != null) {
				otorgadaEn += e.getConductor().getNombreComunaOtorgante();
			} else {
				otorgadaEn += "---";
			}
			m = Resources.getString("validation.message.event.lugarEmisionLicencias", new String[] { e.getConductor().getPersona().getRut() + " " + e.getConductor().getPersona().getNombre() + " ",
					otorgadaEn });
		}
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico);
		MarcoGeograficoSource marcoGeograficoSource = new MarcoGeograficoSource();

		NormativasDataCache cacheNorm = NormativaAccess.getInstance().getNormativasDataCache(normativa.getReglamentacion());

		marcoGeografico.setSource(cacheNorm.getMarcoGeograficoCompleto());
		marcoGeografico.setTipoZonaSelected(marcoGeografico.getSource().getTiposZona().get(0));
		this.normativa = normativa;

		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "marcos_geograficos");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);

			recordUI.getItemsMap().get("marco_geografico_aplicable_a").setTextualValue(MarcoGeograficoSource.getAmbitoName(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue()));

			String tsString = "";
			for (String key : recordUI.getItemsMap().get("marco_geografico").getValues()) {
				Localizable descripcionById = marcoGeograficoSource.getDescripcionById(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue(), key);
				if (descripcionById != null)
					tsString += descripcionById.getLabel() + ", ";
			}
			recordUI.getItemsMap().get("marco_geografico").setTextualValue(!tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString);

			recordGroup.add(recordUI);
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (!marcoGeografico.getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL) && marcoGeografico.getLocalizables().isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.marcoGeografico") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public void addItem() {
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		List<String> ts = new ArrayList<String>();
		String tsString = "";
		for (Localizable item : marcoGeografico.getLocalizables()) {
			ts.add(String.valueOf(item.getIdentifier()));
			tsString += item.getLabel() + ", ";
		}
		recordItem.put("marco_geografico", new NormativaItem("marco_geografico", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		ts = new ArrayList<String>();

		recordItem.put("marco_geografico_aplicable_a",
				new NormativaItem("marco_geografico_aplicable_a", marcoGeografico.getAplicableA(), MarcoGeograficoSource.getAmbitoName(marcoGeografico.getAplicableA())));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "marcos_geograficos", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico, marcoGeografico.getSource());

		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public MarcoGeografico getMarcoGeografico() {
		return marcoGeografico;
	}

	public void setMarcoGeografico(MarcoGeografico marcoGeografico) {
		this.marcoGeografico = marcoGeografico;
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

}
