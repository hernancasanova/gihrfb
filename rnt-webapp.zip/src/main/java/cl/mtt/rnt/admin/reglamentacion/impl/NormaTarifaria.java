package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.CambioTarifaEvent;
import cl.mtt.rnt.admin.reglamentacion.util.SelectionItem;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.Tarifa;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class NormaTarifaria extends GenericNormativa {

	public NormaTarifaria(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String registroTarifa = "registroTarifa.conRegistroTarifa";
	private String tipoTarifa = "tipoTarifa.tarifaFijaVariable";
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// ## registroTarifa
		// registroTarifa.conRegistroTarifa=Con Registro de Tarifas
		// registroTarifa.sinRegistroTarifa=Sin Registro de Tarifas
		// ## tipoTarifa
		// tipoTarifa.tarifaFijaVariable=Tarifa Fija + Tarifa Variable
		// tipoTarifa.matrizTarifaria=Matriz Tarifaria
		// tipoTarifa.indiferente=Indiferente

		CambioTarifaEvent e = (CambioTarifaEvent) event;
		if (e.getTarifa() == null) {
			e.setTarifa(new Tarifa());
			e.getTarifa().setTipoTarifa(Tarifa.TIPO_SIN_REGISTRO);
		}

		boolean r = true;
		String m = null;
		if ("registroTarifa.sinRegistroTarifa".equals(registroTarifa) && !Tarifa.TIPO_SIN_REGISTRO.equals(e.getTarifa().getTipoTarifa())) {
			r = false;
			m = Resources.getString("validation.message.event.sinRegistroTarifas");
		} else if ("registroTarifa.conRegistroTarifa".equals(registroTarifa) && Tarifa.TIPO_SIN_REGISTRO.equals(e.getTarifa().getTipoTarifa())) {
			r = false;
			m = Resources.getString("validation.message.event.conRegistroTarifas");
		} else if ("registroTarifa.conRegistroTarifa".equals(registroTarifa) && "tipoTarifa.tarifaFijaVariable".equals(tipoTarifa) && !Tarifa.TIPO_FIJA_VARIABLE.equals(e.getTarifa().getTipoTarifa())) {
			r = false;
			m = Resources.getString("validation.message.event.tarifaFijaVariable");
		} else if ("registroTarifa.conRegistroTarifa".equals(registroTarifa) && "tipoTarifa.matrizTarifaria".equals(tipoTarifa) && !Tarifa.TIPO_MATRIZ.equals(e.getTarifa().getTipoTarifa())) {
			r = false;
			m = Resources.getString("validation.message.event.matrizTarifaria");
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "norma_tarifa");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			registroTarifa = items.get("registro_tarifa").getValue();
			tipoTarifa = items.get("tipo_tarifa").getValue();

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("norma_tarifa");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("registro_tarifa", registroTarifa));
			normativaRegistro.addNormativaItem(new NormativaItem("tipo_tarifa", tipoTarifa));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		if(!Hibernate.isInitialized(normativa.getRegistros()) || normativa.getRegistros()==null){
			try{
				Hibernate.initialize(normativa.getRegistros());
				normativa.getRegistros().clear();
			}catch(HibernateException e){
				normativa.setRegistros(new ArrayList<NormativaRegistro>());	
			}
		}else{
			normativa.getRegistros().clear();
		}
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("registro_tarifa").setValues(Arrays.asList(new String[] { registroTarifa }));
		items.get("tipo_tarifa").setValues(Arrays.asList(new String[] { tipoTarifa }));

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		return valid;
	}

	public String getRegistroTarifa() {
		return registroTarifa;
	}

	public void setRegistroTarifa(String registroTarifa) {
		this.registroTarifa = registroTarifa;
	}

	public String getTipoTarifa() {
		return tipoTarifa;
	}

	public void setTipoTarifa(String tipoTarifa) {
		this.tipoTarifa = tipoTarifa;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

	public List<SelectionItem> getTipoTarifasItems() {
		List<SelectionItem> ret = new ArrayList<SelectionItem>();
		ret.add(new SelectionItem(Tarifa.TIPO_SIN_REGISTRO, Resources.getString("tarifa.field.tipoTarifa.sinTarifa")));
		if ("registroTarifa.conRegistroTarifa".equals(registroTarifa)) {
			if ("tipoTarifa.indiferente".equals(tipoTarifa) || "tipoTarifa.tarifaFijaVariable".equals(tipoTarifa))
				ret.add(new SelectionItem(Tarifa.TIPO_FIJA_VARIABLE, Resources.getString("tarifa.field.tipoTarifa.fija.variable")));
			if ("tipoTarifa.indiferente".equals(tipoTarifa) || "tipoTarifa.matrizTarifaria".equals(tipoTarifa))
				ret.add(new SelectionItem(Tarifa.TIPO_MATRIZ, Resources.getString("tarifa.field.tipoTarifa.matriz")));
		}
		return ret;
	}

	public static List<SelectionItem> getAllTipoTarifasItems() {
		List<SelectionItem> ret = new ArrayList<SelectionItem>();
		ret.add(new SelectionItem(Tarifa.TIPO_SIN_REGISTRO, Resources.getString("tarifa.field.tipoTarifa.sinTarifa")));
		ret.add(new SelectionItem(Tarifa.TIPO_FIJA_VARIABLE, Resources.getString("tarifa.field.tipoTarifa.fija.variable")));
		ret.add(new SelectionItem(Tarifa.TIPO_MATRIZ, Resources.getString("tarifa.field.tipoTarifa.matriz")));

		return ret;
	}
}
