package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.service.sgprt.VehiculoManager;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;

public class NormasTiposVehiculoPermitido extends GenericNormativa {

	public NormasTiposVehiculoPermitido(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String defaultAmbitoMarcoGeografico = MarcoGeograficoSource.AMBITO_REGIONAL;
	private MarcoGeografico marcoGeografico;
	private String sePermitenIngresar = "sePermitenIngresar.todos";
	private NormativaRegistro sePermitenIngresarRegistro;
	private List<NormativaRecordUI> recordGroup;

	private List<TipoVehiculo> tiposVehiculo;
	private List<TipoVehiculo> selectedTiposVehiculo;
	private Map<Integer, TipoVehiculo> tiposVehiculoMap;
	private ReglamentacionBean rb;

	private Map<String, Zona> zonas = new HashMap<String, Zona>();

	@Override
	public RntEventResultItem validate(GenericEvent event) {

		if ("sePermitenIngresar.todos".equals(sePermitenIngresar))
			return new RntEventResultItem(true, this, null);

		boolean r = true;
		String m = null;
		VehiculoServicio vehiculoServicio = null;
		// Mejoras 201409 Nro: 47
		if (event instanceof ConVehiculoServicioEvent) {
			vehiculoServicio = ((ConVehiculoServicioEvent) event).getVehiculoServicio();
		}
		// Mejoras 201409 Nro: 47
		Integer tipoVehiculo = vehiculoServicio.getVehiculo().getTipoVehiculo();
		Region region = vehiculoServicio.getServicio().getRegion();

		boolean nivelZonal = vehiculoServicio.getReglamentacion().getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL);
		Zona zonaVehiculo = null;
		if (nivelZonal)
			zonaVehiculo = vehiculoServicio.getZonaVehiculo();

		if (vehiculoServicio != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				List<String> tiposVehNorma = mapItem.getItemsMap().get("tipos_vehiculo").getValues();

				if (tiposVehNorma.contains(tipoVehiculo.toString())) {

					String aplicaA = mapItem.getItemsMap().get("marco_geografico_aplicable_a").getValue();

					if (MarcoGeograficoSource.AMBITO_NACIONAL.equals(aplicaA))
						return new RntEventResultItem(true, this, null);
					else {
						List<String> marcoGeog = mapItem.getItemsMap().get("marco_geografico").getValues();
						if (MarcoGeograficoSource.AMBITO_REGIONAL.equals(aplicaA)) {
							if (marcoGeog.contains(region.getCodigo()))
								return new RntEventResultItem(true, this, null);
						} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaA) && !nivelZonal) {
							for (String idZona : marcoGeog) {
								Zona zona = zonas.get(idZona);
								if (region.getCodigo().equals(zona.getIdRegion()))
									return new RntEventResultItem(true, this, null);
							}
						} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaA) && nivelZonal) {
							for (String idZona : marcoGeog) {
								Zona zona = zonas.get(idZona);
								if (zonaVehiculo.getId().equals(zona.getId()))
									return new RntEventResultItem(true, this, null);
							}
						}
					}

				}

			}
		}
		// Caso en que no está aceptado
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()), this, Resources.getString("validation.message.event.normasTiposVehiculoPermitido"));

	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico);
		MarcoGeograficoSource marcoGeograficoSource = new MarcoGeograficoSource();
		marcoGeograficoSource.updateData(reglamentacionManager.getUbicacionGeograficaManager(), reglamentacionManager.getZonaManager(), new String[] { MarcoGeograficoSource.AMBITO_NACIONAL,
				MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, normativa.getReglamentacion().getMarcoGeografico());
		marcoGeografico.setSource(marcoGeograficoSource);
		marcoGeografico.setTipoZonaSelected(marcoGeografico.getSource().getTiposZona().get(0));
		tiposVehiculoMap = new HashMap<Integer, TipoVehiculo>();
		tiposVehiculo = reglamentacionManager.getVehiculoManager().getAllTiposVehiculo();
		for (TipoVehiculo ts : tiposVehiculo) {
			tiposVehiculoMap.put(ts.getId(), ts);
		}

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "se_permiten_ingresar");
		if (ems != null && ems.size() > 0) {
			sePermitenIngresar = ems.get(0).getItems().get(0).getValue();
			sePermitenIngresarRegistro = ems.get(0);
		} else {
			sePermitenIngresarRegistro = new NormativaRegistro();
			sePermitenIngresarRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			sePermitenIngresarRegistro.setDescriptor("se_permiten_ingresar");
			
			sePermitenIngresarRegistro.setItems(new ArrayList<NormativaItem>());
			NormativaItem ni = new NormativaItem("se_permiten_ingresar", sePermitenIngresar);
			ni.setRegistro(sePermitenIngresarRegistro);
			sePermitenIngresarRegistro.getItems().add(ni);
		}
		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "vhiculos_permitidos");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);
			String tsString = "";
			for (String key : recordUI.getItemsMap().get("tipos_vehiculo").getValues()) {
				tsString += tiposVehiculoMap.get(Integer.parseInt(key)).getDescripcion() + ", ";
			}
			recordUI.getItemsMap().get("tipos_vehiculo").setTextualValue(tsString.substring(0, tsString.lastIndexOf(",")));
			recordUI.getItemsMap().get("marco_geografico_aplicable_a").setTextualValue(MarcoGeograficoSource.getAmbitoName(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue()));

			tsString = "";
			for (String key : recordUI.getItemsMap().get("marco_geografico").getValues()) {
				Localizable descripcionById = marcoGeograficoSource.getDescripcionById(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue(), key);
				if (descripcionById != null)
					tsString += descripcionById.getLabel() + ", ";
			}
			recordUI.getItemsMap().get("marco_geografico").setTextualValue(!tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString);
			recordGroup.add(recordUI);
		}
		
		updateNormativa();

		// La cache se actualiza si no esta en null, ya que se genera en prepare
//		if ((reglamentacionBean != null) && (reglamentacionBean.getNormativasCache() != null)) {
//			reglamentacionManager.getNormativasCache(this.getNormativa().getReglamentacion()).setNormaTipoVehiculos(this);
//		}
		generarMapaZonas(reglamentacionManager.getZonaManager().getAllZonas());
	}

	private void generarMapaZonas(List<Zona> listaZonas) {
		for (Zona zona : listaZonas) {
			zonas.put(String.valueOf(zona.getId()), zona);
		}
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		sePermitenIngresarRegistro.setNormativa(normativa);
		sePermitenIngresarRegistro.getItems().get(0).setValues(Arrays.asList(new String[] { sePermitenIngresar }));
		normativa.getRegistros().add(sePermitenIngresarRegistro);

		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}

	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (!marcoGeografico.getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL) && marcoGeografico.getLocalizables().isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.marcoGeografico") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (selectedTiposVehiculo.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposVehiculo") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public void addItem() {
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		List<String> ts = new ArrayList<String>();
		String tsString = "";
		for (Localizable item : marcoGeografico.getLocalizables()) {
			ts.add(String.valueOf(item.getIdentifier()));
			tsString += item.getLabel() + ", ";
		}
		recordItem.put("marco_geografico", new NormativaItem("marco_geografico", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		ts = new ArrayList<String>();
		tsString = "";
		for (TipoVehiculo item : selectedTiposVehiculo) {
			ts.add(String.valueOf(item.getId()));
			tsString += item.getDescripcion() + ", ";
		}
		recordItem.put("tipos_vehiculo", new NormativaItem("tipos_vehiculo", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		recordItem.put("marco_geografico_aplicable_a",
				new NormativaItem("marco_geografico_aplicable_a", marcoGeografico.getAplicableA(), MarcoGeograficoSource.getAmbitoName(marcoGeografico.getAplicableA())));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "vhiculos_permitidos", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		selectedTiposVehiculo = new ArrayList<TipoVehiculo>();
		marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico, marcoGeografico.getSource());
		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
			if ("sePermitenIngresar.todos".equals(sePermitenIngresar)) {
				normativa.setRegistros(new ArrayList<NormativaRegistro>());
				normativa.getRegistros().add(sePermitenIngresarRegistro);
				if (recordGroup != null) {
					for (NormativaRecordUI mapItem : recordGroup) {
						if (!mapItem.getRegistro().getDescriptor().equals("se_permiten_ingresar") && mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
							NormativaRegistro registro = mapItem.getRegistro();
							registro.setNormativa(normativa);
							registro.setDbAction(GenericModelObject.ACTION_DELETE);
							normativa.getRegistros().add(registro);
						}
					}
				}

			}
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && !"sePermitenIngresar.todos".equals(sePermitenIngresar) && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public String getSePermitenIngresar() {
		return sePermitenIngresar;
	}

	public void setSePermitenIngresar(String sePermitenIngresar) {
		this.sePermitenIngresar = sePermitenIngresar;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public List<TipoVehiculo> getTiposVehiculo() {
		return tiposVehiculo;
	}

	public void setTiposVehiculo(List<TipoVehiculo> tiposVehiculo) {
		this.tiposVehiculo = tiposVehiculo;
	}

	public List<TipoVehiculo> getSelectedTiposVehiculo() {
		return selectedTiposVehiculo;
	}

	public void setSelectedTiposVehiculo(List<TipoVehiculo> selectedTiposVehiculo) {
		this.selectedTiposVehiculo = selectedTiposVehiculo;
	}

	public MarcoGeografico getMarcoGeografico() {
		return marcoGeografico;
	}

	public void setMarcoGeografico(MarcoGeografico marcoGeografico) {
		this.marcoGeografico = marcoGeografico;
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	public MarcoGeograficoSource getMarcoGeograficoSourceCompleto(ReglamentacionManager reglamentacionManager) {

		List<MarcoGeografico> marcosGeograficosSeleccionados = new ArrayList<MarcoGeografico>();
		MarcoGeograficoSource marcoGeograficoSource = new MarcoGeograficoSource();

		try {
			if ("sePermitenIngresar.todos".equals(sePermitenIngresar)) {
				MarcoGeograficoSource source = new MarcoGeograficoSource();
				MarcoGeografico mg = reglamentacionManager.getMarcoGeograficoByIdReglamentacion(getNormativa().getReglamentacion().getId());
				source.updateData(reglamentacionManager.getUbicacionGeograficaManager(), reglamentacionManager.getZonaManager(), new String[] { MarcoGeograficoSource.AMBITO_NACIONAL,
						MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, mg);
				return source;
			}
			UbicacionGeograficaManager ubicacionGeograficaManager = reglamentacionManager.getUbicacionGeograficaManager();
			ZonaManager zonaManager = reglamentacionManager.getZonaManager();

			for (NormativaRecordUI mapItem : recordGroup) {

				String aplicaA = mapItem.getItemsMap().get("marco_geografico_aplicable_a").getValue();
				MarcoGeografico marcoGeografico = new MarcoGeografico();
				marcoGeografico.setAplicableA(aplicaA);
				List<Localizable> localizables = new ArrayList<Localizable>();
				List<String> marcoGeog = mapItem.getItemsMap().get("marco_geografico").getValues();
				if (MarcoGeograficoSource.AMBITO_REGIONAL.equals(aplicaA)) {
					// Obtengo la region y la agrego a localizables
					localizables.addAll(ubicacionGeograficaManager.getRegionesByIds(marcoGeog));
				} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaA)) {
					for (String idZona : marcoGeog) {
						localizables.add(zonaManager.getZonaById(Long.parseLong(idZona)));
					}
				}

				marcoGeografico.setLocalizables(localizables);
				marcosGeograficosSeleccionados.add(marcoGeografico);
			}

			marcoGeograficoSource.updateData(reglamentacionManager.getUbicacionGeograficaManager(), reglamentacionManager.getZonaManager(), new String[] { MarcoGeograficoSource.AMBITO_NACIONAL,
					MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, marcosGeograficosSeleccionados);
		} catch (GeneralDataAccessException e) {

		}

		return marcoGeograficoSource;
	}

	public Map<String, MarcoGeograficoSource> getMarcoGeograficoSourcePorTipoVehiculo(ReglamentacionManager reglamentacionManager) {

		Map<String, MarcoGeograficoSource> marcosGeograficoSource = new HashMap<String, MarcoGeograficoSource>();
		Map<String, List<MarcoGeografico>> mapaMarcosGeogPorVeh = new HashMap<String, List<MarcoGeografico>>();
		try {
			if ("sePermitenIngresar.todos".equals(sePermitenIngresar)) {
				MarcoGeograficoSource source = new MarcoGeograficoSource();
				MarcoGeografico mg = reglamentacionManager.getMarcoGeograficoByIdReglamentacion(getNormativa().getReglamentacion().getId());
				source.updateData(reglamentacionManager.getUbicacionGeograficaManager(), reglamentacionManager.getZonaManager(), new String[] { MarcoGeograficoSource.AMBITO_NACIONAL,
						MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, mg);
				for (TipoVehiculo tv : tiposVehiculo) {
					marcosGeograficoSource.put(String.valueOf(tv.getId()), source);
				}
				return marcosGeograficoSource;
			}

			UbicacionGeograficaManager ubicacionGeograficaManager = reglamentacionManager.getUbicacionGeograficaManager();
			ZonaManager zonaManager = reglamentacionManager.getZonaManager();

			for (NormativaRecordUI mapItem : recordGroup) {

				List<String> tiposVehNorma = mapItem.getItemsMap().get("tipos_vehiculo").getValues();

				String aplicaA = mapItem.getItemsMap().get("marco_geografico_aplicable_a").getValue();
				MarcoGeografico marcoGeografico = new MarcoGeografico();
				marcoGeografico.setAplicableA(aplicaA);
				List<Localizable> localizables = new ArrayList<Localizable>();
				List<String> marcoGeog = mapItem.getItemsMap().get("marco_geografico").getValues();
				if (MarcoGeograficoSource.AMBITO_REGIONAL.equals(aplicaA)) {
					// Obtengo la region y la agrego a localizables
					localizables.addAll(ubicacionGeograficaManager.getRegionesByIds(marcoGeog));
				} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaA)) {
					for (String idZona : marcoGeog) {
						localizables.add(zonaManager.getZonaById(Long.parseLong(idZona)));
					}
				}

				marcoGeografico.setLocalizables(localizables);

				for (String tipoVeh : tiposVehNorma) {
					List<MarcoGeografico> lista = mapaMarcosGeogPorVeh.get(tipoVeh);
					if (lista == null)
						lista = new ArrayList<MarcoGeografico>();
					lista.add(marcoGeografico);
					mapaMarcosGeogPorVeh.put(tipoVeh, lista);
				}

			}

			for (Iterator it = mapaMarcosGeogPorVeh.entrySet().iterator(); it.hasNext();) {
				Map.Entry e = (Map.Entry) it.next();
				String veh = (String) e.getKey();
				MarcoGeograficoSource source = new MarcoGeograficoSource();
				source.updateData(reglamentacionManager.getUbicacionGeograficaManager(), reglamentacionManager.getZonaManager(), new String[] { MarcoGeograficoSource.AMBITO_NACIONAL,
						MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, (List<MarcoGeografico>) e.getValue());

				marcosGeograficoSource.put(veh, source);
			}

		} catch (GeneralDataAccessException e) {
			// TODO falta setear mensaje y
		}

		return marcosGeograficoSource;
	}

	public List<TipoVehiculo> getTiposVehiculosItems(ReglamentacionManager reglamentacionManager) {
		if ("sePermitenIngresar.todos".equals(sePermitenIngresar))
			return tiposVehiculo;
		List<TipoVehiculo> vehiculos = new ArrayList<TipoVehiculo>();
		List<String> vehCargados = new ArrayList<String>();
		for (NormativaRecordUI mapItem : recordGroup) {
			List<String> tiposVehNorma = mapItem.getItemsMap().get("tipos_vehiculo").getValues();
			for (String tipoVeh : tiposVehNorma) {
				if (!vehCargados.contains(tipoVeh)) {
					try {
						vehiculos.add(reglamentacionManager.getVehiculoManager().getTipoVehiculoById(Integer.parseInt(tipoVeh)));
						vehCargados.add(tipoVeh);
					} catch (NumberFormatException e) {
						Logger.getLogger(this.getClass()).error(e.getMessage(), e);
					} catch (GeneralDataAccessException e) {
						Logger.getLogger(this.getClass()).error(e.getMessage(), e);
					}
				}
			}
		}

		return vehiculos;
	}

}
