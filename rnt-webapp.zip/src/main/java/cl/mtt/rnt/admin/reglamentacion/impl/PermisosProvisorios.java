package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.apache.commons.collections.functors.WhileClosure;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ModificarVechiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReimprimirCertificadoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.PermisoProvisorioTransient;
import cl.mtt.rnt.commons.util.Resources;

public class PermisosProvisorios extends GenericNormativa {

	public PermisosProvisorios(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private boolean permitePermisosProvisorios = false;
	private boolean conVigenciaMaxima = false;
	private Integer vigenciaMaximaValue;
	private String vigenciaMaximaUnidad = "vigenciaMaximaUnidad.dias";
	private boolean prorrogasPermitidas = false;
	private Integer prorrogasPermitidasCantidad;
	private Integer prorrogasPermitidasDias;
	private NormativaRegistro permisosProvisoriosRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {

		// Norma no validada, solo mensaje
		VehiculoServicio vs = null;
		// String m=null;
		if (event instanceof ConVehiculoServicioEvent) {
			vs = ((ConVehiculoServicioEvent) event).getVehiculoServicio();
		}
		if ((vs != null) && (vs.getTieneCertificadoProvisorio() != null) && (vs.getTieneCertificadoProvisorio().booleanValue())) {
			if (!permitePermisosProvisorios) {
				return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()), this, Resources.getString("validation.message.event.permisosProvisorios.noPermite"));
			} else {
				/**
				 * Esto se hace para que el VS tenga los datos de configuracion
				 * del permiso provisorio
				 */
				if (vs.getPermisoProvisorioTransient() == null) {
					vs.setPermisoProvisorioTransient(new PermisoProvisorioTransient());
				}
				vs.getPermisoProvisorioTransient().setConVigenciaMaxima(conVigenciaMaxima);
				vs.getPermisoProvisorioTransient().setProrrogasPermitidas(prorrogasPermitidas);
				vs.getPermisoProvisorioTransient().setProrrogasPermitidasCantidad(prorrogasPermitidasCantidad);
				vs.getPermisoProvisorioTransient().setProrrogasPermitidasDias(prorrogasPermitidasDias);
				vs.getPermisoProvisorioTransient().setVigenciaMaximaUnidad(vigenciaMaximaUnidad);
				vs.getPermisoProvisorioTransient().setVigenciaMaximaValue(vigenciaMaximaValue);

				/**
				 * Se marca para que no se permita manipular vehiculos con PP
				 * sin reglamentacion asociada
				 */
				vs.getPermisoProvisorioTransient().setReglamentado(true);

				// if(conVigenciaMaxima){
				// m=Resources.getString("validation.message.event.permisosProvisorios.siPermite");
				// m+="<br/>"+Resources.getString("validation.message.event.permisosProvisorios.conVigenciaMaxima",new
				// String[]{String.valueOf(vigenciaMaximaValue),PropertiesManager.getProperty(vigenciaMaximaUnidad)});
				// }
				// if(prorrogasPermitidas){
				// m=Resources.getString("validation.message.event.permisosProvisorios.siPermite");
				// m+="<br/>"+Resources.getString("validation.message.event.permisosProvisorios.prorrogasPermitidas",new
				// String[]{String.valueOf(prorrogasPermitidasCantidad),String.valueOf(prorrogasPermitidasDias)});
				// }
			}
		}
		return new RntEventResultItem(true, this, null);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "permisos_provisorios");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			permitePermisosProvisorios = Boolean.parseBoolean(items.get("permite_permisos_provisorios").getValue());
			conVigenciaMaxima = Boolean.parseBoolean(items.get("con_vigencia_maxima").getValue());
			vigenciaMaximaValue = (items.get("vigencia_maxima_value").getValue() != null && !"".equals(items.get("vigencia_maxima_value").getValue())) ? Integer.parseInt(items.get(
					"vigencia_maxima_value").getValue()) : null;
			vigenciaMaximaUnidad = items.get("vigencia_maxima_unidad").getValue();
			prorrogasPermitidas = Boolean.parseBoolean(items.get("prorrogas_permitidas").getValue());
			prorrogasPermitidasCantidad = (items.get("prorrogas_permitidas_cantidad").getValue() != null && !"".equals(items.get("prorrogas_permitidas_cantidad").getValue())) ? Integer.parseInt(items
					.get("prorrogas_permitidas_cantidad").getValue()) : null;
			prorrogasPermitidasDias = (items.get("prorrogas_permitidas_dias").getValue() != null && !"".equals(items.get("prorrogas_permitidas_dias").getValue())) ? Integer.parseInt(items.get(
					"prorrogas_permitidas_dias").getValue()) : null;

			permisosProvisoriosRegistro = ems.get(0);
		} else {
			permisosProvisoriosRegistro = new NormativaRegistro();
			permisosProvisoriosRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			permisosProvisoriosRegistro.setDescriptor("permisos_provisorios");
			permisosProvisoriosRegistro.setItems(new ArrayList<NormativaItem>());
			permisosProvisoriosRegistro.addNormativaItem(new NormativaItem("permite_permisos_provisorios", String.valueOf(permitePermisosProvisorios)));
			permisosProvisoriosRegistro.addNormativaItem(new NormativaItem("con_vigencia_maxima", String.valueOf(conVigenciaMaxima)));
			permisosProvisoriosRegistro.addNormativaItem(new NormativaItem("vigencia_maxima_value", String.valueOf(vigenciaMaximaValue)));
			permisosProvisoriosRegistro.addNormativaItem(new NormativaItem("vigencia_maxima_unidad", vigenciaMaximaUnidad));
			permisosProvisoriosRegistro.addNormativaItem(new NormativaItem("prorrogas_permitidas", String.valueOf(prorrogasPermitidas)));
			permisosProvisoriosRegistro.addNormativaItem(new NormativaItem("prorrogas_permitidas_cantidad", String.valueOf(prorrogasPermitidasCantidad)));
			permisosProvisoriosRegistro.addNormativaItem(new NormativaItem("prorrogas_permitidas_dias", String.valueOf(prorrogasPermitidasDias)));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		if(!Hibernate.isInitialized(normativa.getRegistros()) || normativa.getRegistros()==null){
			try{
				Hibernate.initialize(normativa.getRegistros());
				if(normativa.getRegistros()!=null){
					normativa.getRegistros().clear();
				}else{
					normativa.setRegistros(new ArrayList<NormativaRegistro>());
				}
			}catch(HibernateException e){
				normativa.setRegistros(new ArrayList<NormativaRegistro>());	
			}
		}else{
			normativa.getRegistros().clear();
		}
		permisosProvisoriosRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = permisosProvisoriosRegistro.getItemsAsMap();
		items.get("permite_permisos_provisorios").setValues(Arrays.asList(new String[] { String.valueOf(permitePermisosProvisorios) }));
		items.get("con_vigencia_maxima").setValues(Arrays.asList(new String[] { String.valueOf(conVigenciaMaxima) }));
		items.get("vigencia_maxima_value").setValues(Arrays.asList(new String[] { ((vigenciaMaximaValue != null) ? String.valueOf(vigenciaMaximaValue) : "") }));
		items.get("vigencia_maxima_unidad").setValues(Arrays.asList(new String[] { vigenciaMaximaUnidad }));
		items.get("prorrogas_permitidas").setValues(Arrays.asList(new String[] { String.valueOf(prorrogasPermitidas) }));
		items.get("prorrogas_permitidas_cantidad").setValues(Arrays.asList(new String[] { ((prorrogasPermitidasCantidad != null) ? String.valueOf(prorrogasPermitidasCantidad) : "") }));
		items.get("prorrogas_permitidas_dias").setValues(Arrays.asList(new String[] { ((prorrogasPermitidasDias != null) ? String.valueOf(prorrogasPermitidasDias) : "") }));

		normativa.getRegistros().add(permisosProvisoriosRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (permitePermisosProvisorios) {
			if (conVigenciaMaxima) {
				if (vigenciaMaximaValue == null || vigenciaMaximaValue.intValue() <= 0) {
					messageBean.addMessage(Resources.getString("validation.message.required.vigenciaMaximaValue"), FacesMessage.SEVERITY_ERROR);
					valid = false;
				}
			}
			if (prorrogasPermitidas) {
				if (prorrogasPermitidasCantidad == null || prorrogasPermitidasCantidad.intValue() <= 0 || prorrogasPermitidasDias == null || prorrogasPermitidasDias.intValue() <= 0) {
					messageBean.addMessage(Resources.getString("validation.message.required.prorrogasPermitidas"), FacesMessage.SEVERITY_ERROR);
					valid = false;
				}

			}
		}
		return valid;
	}

	public boolean isPermitePermisosProvisorios() {
		return permitePermisosProvisorios;
	}

	public void setPermitePermisosProvisorios(boolean permitePermisosProvisorios) {
		this.permitePermisosProvisorios = permitePermisosProvisorios;
	}

	public boolean isConVigenciaMaxima() {
		return conVigenciaMaxima;
	}

	public void setConVigenciaMaxima(boolean conVigenciaMaxima) {
		this.conVigenciaMaxima = conVigenciaMaxima;
	}

	public Integer getVigenciaMaximaValue() {
		return vigenciaMaximaValue;
	}

	public void setVigenciaMaximaValue(Integer vigenciaMaximaValue) {
		this.vigenciaMaximaValue = vigenciaMaximaValue;
	}

	public String getVigenciaMaximaUnidad() {
		return vigenciaMaximaUnidad;
	}

	public void setVigenciaMaximaUnidad(String vigenciaMaximaUnidad) {
		this.vigenciaMaximaUnidad = vigenciaMaximaUnidad;
	}

	public boolean isProrrogasPermitidas() {
		return prorrogasPermitidas;
	}

	public void setProrrogasPermitidas(boolean prorrogasPermitidas) {
		this.prorrogasPermitidas = prorrogasPermitidas;
	}

	public Integer getProrrogasPermitidasCantidad() {
		return prorrogasPermitidasCantidad;
	}

	public void setProrrogasPermitidasCantidad(Integer prorrogasPermitidasCantidad) {
		this.prorrogasPermitidasCantidad = prorrogasPermitidasCantidad;
	}

	public Integer getProrrogasPermitidasDias() {
		return prorrogasPermitidasDias;
	}

	public void setProrrogasPermitidasDias(Integer prorrogasPermitidasDias) {
		this.prorrogasPermitidasDias = prorrogasPermitidasDias;
	}

	public NormativaRegistro getPermisosProvisoriosRegistro() {
		return permisosProvisoriosRegistro;
	}

	public void setPermisosProvisoriosRegistro(NormativaRegistro permisosProvisoriosRegistro) {
		this.permisosProvisoriosRegistro = permisosProvisoriosRegistro;
	}

	public Date getFechaVencimiento(Date fechaInicio){
		Date now = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaInicio);
		if(getVigenciaMaximaUnidad().equalsIgnoreCase("vigenciaMaximaUnidad.dias")){
			calendar.add(Calendar.DAY_OF_YEAR, getVigenciaMaximaValue()); 	
		} else if(getVigenciaMaximaUnidad().equalsIgnoreCase("vigenciaMaximaUnidad.anios")){
			calendar.add(Calendar.YEAR, getVigenciaMaximaValue()); 	
		} else if(getVigenciaMaximaUnidad().equalsIgnoreCase("vigenciaMaximaUnidad.meses")){
			calendar.add(Calendar.MONTH, getVigenciaMaximaValue()); 	
		}
		int prorrogas = getProrrogasPermitidasCantidad();
		while(calendar.getTime().before(now) && prorrogas >0){
			calendar.add(Calendar.DAY_OF_YEAR, getProrrogasPermitidasDias());
			prorrogas--;
		}
		return calendar.getTime(); 
	}
}
