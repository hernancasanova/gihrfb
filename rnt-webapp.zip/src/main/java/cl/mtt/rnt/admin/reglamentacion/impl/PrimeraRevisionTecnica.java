package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.hibernate.Hibernate;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;

public class PrimeraRevisionTecnica extends GenericNormativa {

	public PrimeraRevisionTecnica(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String defaultAmbitoMarcoGeografico = MarcoGeograficoSource.AMBITO_REGIONAL;
	private MarcoGeografico marcoGeografico;
	private Integer antiguedadMaxima;
	private boolean restriccionAnios = false;
	private NormativaRegistro normativaRegistro;
	private List<TipoServicio> tiposServicio;
	private Map<Long, TipoServicio> allTiposServicioMap;
	private List<TipoServicio> selectedTiposServicio;

	private List<NormativaRecordUI> recordGroup;

	private Map<String, Zona> zonas = new HashMap<String, Zona>();

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// boolean r=true;
		String m = null;
		if (!restriccionAnios)
			return new RntEventResultItem(true, this, m);

		VehiculoServicio vehiculoServicio = null;
		if (event instanceof NuevoVehiculoEvent) {
			vehiculoServicio = ((NuevoVehiculoEvent) event).getVehiculoServicio();
		} else if (event instanceof ReemplazoVehiculoEvent) {
			vehiculoServicio = ((ReemplazoVehiculoEvent) event).getVehiculoServicioEntrante();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			vehiculoServicio = ((ReemplazoTrasladoVehiculoEvent) event).getVehiculoServicioEntrante();
		} else if (event instanceof TrasladoVehiculoEvent) {
			vehiculoServicio = ((TrasladoVehiculoEvent) event).getVehiculoServicioNuevo();
		}

		Integer tipoVehiculo = vehiculoServicio.getVehiculo().getTipoVehiculo();
		Region region = vehiculoServicio.getServicio().getRegion();
		if (vehiculoServicio != null) {

			for (NormativaRecordUI mapItem : recordGroup) {
				List<String> tiposServicioItem = mapItem.getItemsMap().get("tipos_servicio").getValues();

				String aplicaA = mapItem.getItemsMap().get("marco_geografico_aplicable_a").getValue();
				Integer antiguedadMax = Integer.parseInt(mapItem.getItemsMap().get("antiguedad_maxima").getValue());

				boolean nivelZonal = vehiculoServicio.getReglamentacion().getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL);
				Zona zonaVehiculo = null;
				if (nivelZonal)
					zonaVehiculo = vehiculoServicio.getZonaVehiculo();

				// boolean cumpleAntiguedad = antiguedadMax >=
				// vehiculoServicio.getVehiculo().getAntiguedad();
				if (tiposServicioItem.contains(String.valueOf(vehiculoServicio.getServicio().getTipoServicio().getId()))) {
					if (MarcoGeograficoSource.AMBITO_NACIONAL.equals(aplicaA)) {
						m = Resources.getString("validation.message.event.primeraRevisionTecnica.antiguedadMaxima", new String[] { String.valueOf(antiguedadMax) });
						return new RntEventResultItem(true, this, m);
					} else {
						List<String> marcoGeog = mapItem.getItemsMap().get("marco_geografico").getValues();
						if (MarcoGeograficoSource.AMBITO_REGIONAL.equals(aplicaA)) {
							if (marcoGeog.contains(region.getCodigo())) {
								m = Resources.getString("validation.message.event.primeraRevisionTecnica.antiguedadMaxima", new String[] { String.valueOf(antiguedadMax) });
								return new RntEventResultItem(true, this, m);
							}
						} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaA) && !nivelZonal) {
							for (String idZona : marcoGeog) {
								Zona zona = zonas.get(idZona);
								if (region.getCodigo().equals(zona.getIdRegion())) {
									m = Resources.getString("validation.message.event.primeraRevisionTecnica.antiguedadMaxima", new String[] { String.valueOf(antiguedadMax) });
									return new RntEventResultItem(true, this, m);
								}

							}
						} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaA) && nivelZonal) {
							for (String idZona : marcoGeog) {
								Zona zona = zonas.get(idZona);
								if (zonaVehiculo.getId().equals(zona.getId())) {
									m = Resources.getString("validation.message.event.primeraRevisionTecnica.antiguedadMaxima", new String[] { String.valueOf(antiguedadMax) });
									return new RntEventResultItem(true, this, m);
								}

							}
						}

					}
				}
			}
		}

		return new RntEventResultItem(true, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		allTiposServicioMap = new HashMap<Long, TipoServicio>();
		if (!Hibernate.isInitialized(normativa.getReglamentacion().getTiposServicio()))
			tiposServicio = reglamentacionManager.getTipoServicioManager().getTiposServicioByReglamentacion(normativa.getReglamentacion().getId());
		else
			tiposServicio = normativa.getReglamentacion().getTiposServicio();

		for (TipoServicio ts : tiposServicio) {
			allTiposServicioMap.put(ts.getId(), ts);
		}
		selectedTiposServicio = new ArrayList<TipoServicio>();

		marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico);

		NormativasDataCache cacheNorm = NormativaAccess.getInstance().getNormativasDataCache(normativa.getReglamentacion());

		marcoGeografico.setSource(cacheNorm.getMarcoGeograficoCompleto());
		marcoGeografico.setTipoZonaSelected(marcoGeografico.getSource().getTiposZona().get(0));

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "restriccion_anios");
		if (ems != null && ems.size() > 0) {
			restriccionAnios = Boolean.valueOf(ems.get(0).getItems().get(0).getValue());
			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("restriccion_anios");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			NormativaItem ni = new NormativaItem("restriccion_anios", String.valueOf(restriccionAnios));
			ni.setRegistro(normativaRegistro);
			normativaRegistro.getItems().add(ni);
		}

		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "marcos_geograficos");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);

			String tsString = "";
			for (String key : recordUI.getItemsMap().get("tipos_servicio").getValues()) {
				tsString += allTiposServicioMap.get(Long.parseLong(key)).getName() + ", ";
			}
			recordUI.getItemsMap().get("tipos_servicio").setTextualValue(!tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString);

			recordUI.getItemsMap().get("marco_geografico_aplicable_a").setTextualValue(MarcoGeograficoSource.getAmbitoName(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue()));

			tsString = "";
			for (String key : recordUI.getItemsMap().get("marco_geografico").getValues()) {
				Localizable descripcionById = marcoGeografico.getSource().getDescripcionById(recordUI.getItemsMap().get("marco_geografico_aplicable_a").getValue(), key);
				if (descripcionById != null)
					tsString += descripcionById.getLabel() + ", ";
			}
			recordUI.getItemsMap().get("marco_geografico").setTextualValue(!tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString);

			recordGroup.add(recordUI);
		}

		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);
		normativaRegistro.getItems().get(0).setValues(Arrays.asList(new String[] { String.valueOf(restriccionAnios) }));
		normativa.getRegistros().add(normativaRegistro);

		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (selectedTiposServicio.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposServicio") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (!marcoGeografico.getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL) && marcoGeografico.getLocalizables().isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.marcoGeografico") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (antiguedadMaxima == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.antiguedadMaxima") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public void addItem() {
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		List<String> ts = new ArrayList<String>();
		String tsString = "";
		for (TipoServicio tsa : selectedTiposServicio) {
			ts.add(String.valueOf(tsa.getId()));
			tsString += tsa.getName() + ", ";
		}
		recordItem.put("tipos_servicio", new NormativaItem("tipos_servicio", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		ts = new ArrayList<String>();
		tsString = "";
		for (Localizable item : marcoGeografico.getLocalizables()) {
			ts.add(String.valueOf(item.getIdentifier()));
			tsString += item.getLabel() + ", ";
		}
		recordItem.put("marco_geografico", new NormativaItem("marco_geografico", ts, !tsString.equals("") ? tsString.substring(0, tsString.lastIndexOf(",")) : tsString));

		ts = new ArrayList<String>();

		recordItem.put("marco_geografico_aplicable_a",
				new NormativaItem("marco_geografico_aplicable_a", marcoGeografico.getAplicableA(), MarcoGeograficoSource.getAmbitoName(marcoGeografico.getAplicableA())));
		recordItem.put("antiguedad_maxima", new NormativaItem("antiguedad_maxima", String.valueOf(antiguedadMaxima)));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "marcos_geograficos", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		antiguedadMaxima = null;
		marcoGeografico = new MarcoGeografico(defaultAmbitoMarcoGeografico, marcoGeografico.getSource());
		selectedTiposServicio = new ArrayList<TipoServicio>();

		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (normativaRegistro.getItems().get(0).getDbAction() != GenericModelObject.ACTION_SAVE) {
				normativaRegistro.setNormativa(normativa);
				normativaRegistro.setDbAction(GenericModelObject.ACTION_DELETE);
				normativa.getRegistros().add(normativaRegistro);
			}
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && (restriccionAnios) && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public Integer getAntiguedadMaxima() {
		return antiguedadMaxima;
	}

	public void setAntiguedadMaxima(Integer antiguedadMaxima) {
		this.antiguedadMaxima = antiguedadMaxima;
	}

	public boolean isRestriccionAnios() {
		return restriccionAnios;
	}

	public void setRestriccionAnios(boolean restriccionAnios) {
		this.restriccionAnios = restriccionAnios;
	}

	public MarcoGeografico getMarcoGeografico() {
		return marcoGeografico;
	}

	public void setMarcoGeografico(MarcoGeografico marcoGeografico) {
		this.marcoGeografico = marcoGeografico;
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	/**
	 * @return el valor de zonas
	 */
	public Map<String, Zona> getZonas() {
		return zonas;
	}

	/**
	 * @param setea
	 *            el parametro zonas al campo zonas
	 */
	public void setZonas(Map<String, Zona> zonas) {
		this.zonas = zonas;
	}

	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	public List<TipoServicio> getSelectedTiposServicio() {
		return selectedTiposServicio;
	}

	public void setSelectedTiposServicio(List<TipoServicio> selectedTiposServicio) {
		this.selectedTiposServicio = selectedTiposServicio;
	}

}
