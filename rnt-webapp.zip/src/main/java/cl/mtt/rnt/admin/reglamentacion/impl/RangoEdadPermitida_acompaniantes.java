package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoAuxiliarEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoConductorEvent;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.Utils;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

public class RangoEdadPermitida_acompaniantes extends GenericNormativa {

	public RangoEdadPermitida_acompaniantes(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private Integer edadMinima;
	private Integer edadMaxima;
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		NuevoAuxiliarEvent e = (NuevoAuxiliarEvent) event;

		if (e.getAuxiliar().getPersona().getFechaNacimiento() == null) {
			String m = Resources.getString("validation.message.event.rangoEdadAcompanantes.nodata", new String[] { " " + e.getAuxiliar().getPersona().getRut() + " "
					+ e.getAuxiliar().getPersona().getNombre() + " " });
			return new RntEventResultItem(true, this, m);
		}
		
		boolean r = ValidacionHelper.personaEdadEnRango(e.getAuxiliar().getPersona().getFechaNacimiento(), edadMinima, edadMaxima);
		String m = null;
		if (!r) {
			int edad = Utils.calculaEdad(e.getAuxiliar().getPersona().getFechaNacimiento());

			m = Resources.getString("validation.message.event.rangoEdadAuxiliares", new String[] { String.valueOf(edadMinima), String.valueOf(edadMaxima),
					" " + e.getAuxiliar().getPersona().getRut() + " " + e.getAuxiliar().getPersona().getNombre() + " ", String.valueOf(edad) });
		}
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "edades");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			edadMinima = (items.get("edad_minima").getValue() != null && !"".equals(items.get("edad_minima").getValue())) ? Integer.parseInt(items.get("edad_minima").getValue()) : null;
			edadMaxima = (items.get("edad_maxima").getValue() != null && !"".equals(items.get("edad_maxima").getValue())) ? Integer.parseInt(items.get("edad_maxima").getValue()) : null;

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("edades");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("edad_minima", String.valueOf(edadMinima)));
			normativaRegistro.addNormativaItem(new NormativaItem("edad_maxima", String.valueOf(edadMaxima)));
		}

		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("edad_minima").setValues(Arrays.asList(new String[] { ((edadMinima != null) ? String.valueOf(edadMinima) : "") }));
		items.get("edad_maxima").setValues(Arrays.asList(new String[] { ((edadMaxima != null) ? String.valueOf(edadMaxima) : "") }));

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		if (normativa.getValidacion().equals("validacion.especificada")) {
			MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
			if (edadMinima == null) {
				messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.edadMinima") }),
						FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
			if (edadMaxima == null) {
				messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.edadMaxima") }),
						FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
			if (edadMinima != null && edadMaxima != null && edadMinima.intValue() > edadMaxima.intValue()) {
				messageBean.addMessage(
						Resources.getString("validation.message.norma.ordered", new String[] { this.getNormativa().getLabel(), Resources.getString("reglamentacion.normativa.field.edadMinima"),
								Resources.getString("reglamentacion.normativa.field.edadMaxima") }), FacesMessage.SEVERITY_ERROR);
				valid = false;
			}

		}

		return valid;
	}

	public Integer getEdadMinima() {
		return edadMinima;
	}

	public void setEdadMinima(Integer edadMinima) {
		this.edadMinima = edadMinima;
	}

	public Integer getEdadMaxima() {
		return edadMaxima;
	}

	public void setEdadMaxima(Integer edadMaxima) {
		this.edadMaxima = edadMaxima;
	}

}
