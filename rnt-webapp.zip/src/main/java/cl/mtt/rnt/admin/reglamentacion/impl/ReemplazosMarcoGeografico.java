package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.ElResolver;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;

public class ReemplazosMarcoGeografico extends GenericNormativa {

	public ReemplazosMarcoGeografico(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String defaultAmbitoMarcoGeografico = MarcoGeograficoSource.AMBITO_REGIONAL;
	private MarcoGeografico marcoGeograficoOrigen;
	private MarcoGeografico marcoGeograficoDestino;
	private boolean ninguna = false;
	private NormativaRegistro normativaRegistro;
	private Map<String, Zona> zonas = new HashMap<String, Zona>();

	private List<NormativaRecordUI> recordGroup;

	private void updateReglamentacionMarcoGeografico(VehiculoServicio vs) {
		CurrentSessionBean curr = (CurrentSessionBean) ElResolver.getManagedObject("currentSessionBean");
		if (curr != null) {
			if (!Hibernate.isInitialized(vs.getReglamentacion())) {
				try {
					vs.setReglamentacion(curr.getReglamentacionManager().getReglamentacionByVehiculoServicio(vs.getId()));
				} catch (GeneralDataAccessException e) {
					Logger.getLogger(ReemplazosMarcoGeografico.class).error(e.getLocalizedMessage(), e);
				}
			}
		}
	}

	@Override
	public RntEventResultItem validate(GenericEvent event) {

		// TransladoVehiculoEvent e = (TransladoVehiculoEvent)event;
		// VehiculoServicio vehiculoServicioNuevo =
		// e.getVehiculoServicioNuevo();
		// VehiculoServicio vehiculoServicioAnterior =
		// e.getVehiculoServicioAnterior();
		VehiculoServicio vehiculoServicioEntrante = null;
		VehiculoServicio vehiculoServicioSaliente = null;
		if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			vehiculoServicioEntrante = e.getVehiculoServicioEntrante();
			vehiculoServicioSaliente = e.getVehiculoServicioSaliente();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			vehiculoServicioEntrante = e.getVehiculoServicioEntrante();
			vehiculoServicioSaliente = e.getVehiculoServicioSaliente();
		}

		if (ninguna && !vehiculoServicioEntrante.getServicio().getRegion().getCodigo().equals(vehiculoServicioSaliente.getServicio().getCodigoRegion())) {
			return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()), this, Resources.getString("validation.message.event.reemplazo.mismoMarcoGeografico"));
		} else if(ninguna){
			return new RntEventResultItem(true,this,null);
		} else {
			for (NormativaRecordUI recordUI : recordGroup) {
				// validar tiposregiones
				String aplicaOrigen = recordUI.getItemsMap().get("marco_geografico_origen_aplicable_a").getValue();
				List<String> localizablesOrigen = recordUI.getItemsMap().get("marco_geografico_origen").getValues();
				String aplicaDestino = recordUI.getItemsMap().get("marco_geografico_destino_aplicable_a").getValue();
				List<String> localizablesDestino = recordUI.getItemsMap().get("marco_geografico_destino").getValues();

				boolean nivelZonalNuevo = vehiculoServicioEntrante.getReglamentacion().getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL);
				// Zona zonaVehiculoNuevo=null;
				// if (nivelZonalNuevo)
				// zonaVehiculoNuevo=vehiculoServicioNuevo.getZonaVehiculo();

				updateReglamentacionMarcoGeografico(vehiculoServicioSaliente);
				if (vehiculoServicioSaliente.getReglamentacion() == null) {
					return new RntEventResultItem(true, this, Resources.getString("validation.message.event.reemplazo.marcoGeografico.noreglam.vehiant", new String[] {
							vehiculoServicioSaliente.getVehiculo().getPpu(), vehiculoServicioSaliente.getServicio().getIdentServicio().toString() }));
				}

				boolean nivelZonalAnterior = vehiculoServicioSaliente.getReglamentacion().getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL);
				// Zona zonaVehiculoAnterior=null;
				// if (nivelZonalAnterior)
				// zonaVehiculoAnterior=vehiculoServicioAnterior.getZonaVehiculo();

				List<String> regionesOrigen = new ArrayList<String>();
				List<Zona> zonasOrigen = new ArrayList<Zona>();
				if (MarcoGeograficoSource.AMBITO_REGIONAL.equals(aplicaOrigen)) {
					regionesOrigen.addAll(localizablesOrigen);
				} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaOrigen)) {
					for (String idZona : localizablesOrigen) {
						regionesOrigen.add(zonas.get(idZona).getIdRegion());
						zonasOrigen.add(zonas.get(idZona));
					}
				}
				List<String> regionesDestino = new ArrayList<String>();
				List<Zona> zonasDestino = new ArrayList<Zona>();
				if (MarcoGeograficoSource.AMBITO_REGIONAL.equals(aplicaDestino)) {
					regionesDestino.addAll(localizablesDestino);
				} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(aplicaDestino)) {
					for (String idZona : localizablesDestino) {
						regionesDestino.add(zonas.get(idZona).getIdRegion());
						zonasDestino.add(zonas.get(idZona));
					}
				}

				boolean cumpleOrigen = false;
				if (nivelZonalAnterior) {
					cumpleOrigen = zonasOrigen.contains(vehiculoServicioSaliente.getZonaVehiculo());
				} else {
					cumpleOrigen = regionesOrigen.contains(String.valueOf(vehiculoServicioSaliente.getServicio().getCodigoRegion()));
				}

				boolean cumpleDestino = false;
				if (nivelZonalNuevo) {
					cumpleDestino = zonasDestino.contains(vehiculoServicioEntrante.getZonaVehiculo());
				} else {
					cumpleDestino = regionesDestino.contains(String.valueOf(vehiculoServicioEntrante.getServicio().getRegion().getCodigo()));
				}

				if (cumpleOrigen && cumpleDestino) {
					return new RntEventResultItem(true, this, null);
				}
			}
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()), this, Resources.getString("validation.message.event.reemplazo.marcoGeografico"));
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		marcoGeograficoOrigen = new MarcoGeografico(defaultAmbitoMarcoGeografico);
		MarcoGeograficoSource marcoGeograficoSourceOrigen = new MarcoGeograficoSource();
		marcoGeograficoSourceOrigen.updateData(reglamentacionManager.getUbicacionGeograficaManager(), reglamentacionManager.getZonaManager(), new String[] { MarcoGeograficoSource.AMBITO_NACIONAL,
				MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL });

		marcoGeograficoOrigen.setSource(marcoGeograficoSourceOrigen);
		marcoGeograficoOrigen.setTipoZonaSelected(marcoGeograficoOrigen.getSource().getTiposZona().get(0));
		marcoGeograficoOrigen.getSource().setTiposZona(reglamentacionManager.getUbicacionGeograficaManager().getAllTiposZonas());
		marcoGeograficoDestino = new MarcoGeografico(defaultAmbitoMarcoGeografico);

		NormativasDataCache cacheNorm = NormativaAccess.getInstance().getNormativasDataCache(normativa.getReglamentacion());
		marcoGeograficoDestino.setSource(cacheNorm.getMarcoGeograficoCompleto());
		marcoGeograficoDestino.setTipoZonaSelected(marcoGeograficoDestino.getSource().getTiposZona().get(0));
		marcoGeograficoDestino.getSource().setTiposZona(reglamentacionManager.getUbicacionGeograficaManager().getAllTiposZonas());
		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "ninguna");
		if (ems != null && ems.size() > 0) {
			ninguna = Boolean.valueOf(ems.get(0).getItems().get(0).getValue());
			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("ninguna");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			NormativaItem ni = new NormativaItem("ninguna", String.valueOf(ninguna));
			ni.setRegistro(normativaRegistro);
			normativaRegistro.getItems().add(ni);
		}

		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "marcos_geograficos");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);

			recordUI.getItemsMap().get("marco_geografico_origen_aplicable_a")
					.setTextualValue(MarcoGeograficoSource.getAmbitoName(recordUI.getItemsMap().get("marco_geografico_origen_aplicable_a").getValue()));
			String tsString = "";
			for (String key : recordUI.getItemsMap().get("marco_geografico_origen").getValues()) {
				Localizable descripcionById=marcoGeograficoSourceOrigen.getDescripcionById(recordUI.getItemsMap().get("marco_geografico_origen_aplicable_a").getValue(), key);
				if (descripcionById != null)
					tsString += descripcionById.getLabel() + ", ";
			}
			recordUI.getItemsMap().get("marco_geografico_origen").setTextualValue(("".equals(tsString)) ? "" : tsString.substring(0, tsString.lastIndexOf(",")));

			recordUI.getItemsMap().get("marco_geografico_destino_aplicable_a")
					.setTextualValue(MarcoGeograficoSource.getAmbitoName(recordUI.getItemsMap().get("marco_geografico_destino_aplicable_a").getValue()));
			tsString = "";
			for (String key : recordUI.getItemsMap().get("marco_geografico_destino").getValues()) {
				Localizable descripcionById=marcoGeograficoDestino.getSource().getDescripcionById(recordUI.getItemsMap().get("marco_geografico_destino_aplicable_a").getValue(), key);
				if (descripcionById != null)
					tsString += descripcionById.getLabel() + ", ";
			}
			recordUI.getItemsMap().get("marco_geografico_destino").setTextualValue(("".equals(tsString)) ? "" : tsString.substring(0, tsString.lastIndexOf(",")));

			recordGroup.add(recordUI);
		}
		updateNormativa();
		generarMapaZonas(reglamentacionManager.getZonaManager().getAllZonas());

	}

	private void generarMapaZonas(List<Zona> listaZonas) {
		for (Zona zona : listaZonas) {
			zonas.put(String.valueOf(zona.getId()), zona);
		}
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);
		normativaRegistro.getItems().get(0).setValues(Arrays.asList(new String[] { String.valueOf(ninguna) }));
		normativa.getRegistros().add(normativaRegistro);

		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (!MarcoGeograficoSource.AMBITO_NACIONAL.equals(marcoGeograficoOrigen.getAplicableA()) && marcoGeograficoOrigen.getLocalizables().isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.marcoGeograficoOrigen") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (!MarcoGeograficoSource.AMBITO_NACIONAL.equals(marcoGeograficoDestino.getAplicableA()) && marcoGeograficoDestino.getLocalizables().isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.marcoGeograficoDestino") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public void addItem() {
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();

		// Carga de datos
		List<String> ts = new ArrayList<String>();
		String tsString = "";
		if (marcoGeograficoOrigen.getLocalizables().size() > 0) {
			for (Localizable item : marcoGeograficoOrigen.getLocalizables()) {
				ts.add(String.valueOf(item.getIdentifier()));
				tsString += item.getLabel() + ", ";
			}
			recordItem.put("marco_geografico_origen", new NormativaItem("marco_geografico_origen", ts, tsString.substring(0, tsString.lastIndexOf(","))));
		} else {
			recordItem.put("marco_geografico_origen", new NormativaItem("marco_geografico_origen", ts, ""));
		}
		ts = new ArrayList<String>();
		recordItem.put("marco_geografico_origen_aplicable_a",
				new NormativaItem("marco_geografico_origen_aplicable_a", marcoGeograficoOrigen.getAplicableA(), MarcoGeograficoSource.getAmbitoName(marcoGeograficoOrigen.getAplicableA())));

		ts = new ArrayList<String>();
		tsString = "";
		if (marcoGeograficoDestino.getLocalizables().size() > 0) {
			for (Localizable item : marcoGeograficoDestino.getLocalizables()) {
				ts.add(String.valueOf(item.getIdentifier()));
				tsString += item.getLabel() + ", ";
			}
			recordItem.put("marco_geografico_destino", new NormativaItem("marco_geografico_destino", ts, tsString.substring(0, tsString.lastIndexOf(","))));
		} else {
			recordItem.put("marco_geografico_destino", new NormativaItem("marco_geografico_destino", ts, ""));
		}
		ts = new ArrayList<String>();
		recordItem.put("marco_geografico_destino_aplicable_a",
				new NormativaItem("marco_geografico_destino_aplicable_a", marcoGeograficoDestino.getAplicableA(), MarcoGeograficoSource.getAmbitoName(marcoGeograficoDestino.getAplicableA())));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "marcos_geograficos", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		marcoGeograficoOrigen = new MarcoGeografico(defaultAmbitoMarcoGeografico, marcoGeograficoOrigen.getSource());
		marcoGeograficoDestino = new MarcoGeografico(defaultAmbitoMarcoGeografico, marcoGeograficoDestino.getSource());

		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
			if (ninguna) {
				normativa.setRegistros(new ArrayList<NormativaRegistro>());
				normativa.getRegistros().add(normativaRegistro);
				if (recordGroup != null) {
					for (NormativaRecordUI mapItem : recordGroup) {
						if (!mapItem.getRegistro().getDescriptor().equals("ninguna") && mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
							NormativaRegistro registro = mapItem.getRegistro();
							registro.setNormativa(normativa);
							registro.setDbAction(GenericModelObject.ACTION_DELETE);
							normativa.getRegistros().add(registro);
						}
					}
				}

			}
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	public boolean isNinguna() {
		return ninguna;
	}

	public void setNinguna(boolean ninguna) {
		this.ninguna = ninguna;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && !ninguna && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public MarcoGeografico getMarcoGeograficoOrigen() {
		return marcoGeograficoOrigen;
	}

	public void setMarcoGeograficoOrigen(MarcoGeografico marcoGeograficoOrigen) {
		this.marcoGeograficoOrigen = marcoGeograficoOrigen;
	}

	public MarcoGeografico getMarcoGeograficoDestino() {
		return marcoGeograficoDestino;
	}

	public void setMarcoGeograficoDestino(MarcoGeografico marcoGeograficoDestino) {
		this.marcoGeograficoDestino = marcoGeograficoDestino;
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

}
