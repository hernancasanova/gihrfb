package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class ReemplazosPerdidaTotal extends GenericNormativa {

	public ReemplazosPerdidaTotal(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private boolean antiguedadMaxima = false;
	private Integer antiguedadMaximaValue;
	private boolean fabricacionRespectoSaliente = false;
	private String fabricacionRespectoSalienteValue = "fabricacionRespectoSaliente.masNuevoQueSaliente";

	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		Vehiculo vEntr = null;
		Vehiculo vSal = null;
		if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			vEntr = e.getVehiculoServicioEntrante().getVehiculo();
			vSal = e.getVehiculoServicioSaliente().getVehiculo();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			vEntr = e.getVehiculoServicioEntrante().getVehiculo();
			vSal = e.getVehiculoServicioSaliente().getVehiculo();
		}

		boolean r = true;
		String m = null;

		Calendar c = new GregorianCalendar();
		
		// es una o la otra
		if (antiguedadMaxima) {
			// Vehiculo vEntr=e.getVehiculoServicioEntrante().getVehiculo();
			int ant = c.get(Calendar.YEAR) - vEntr.getAnioFabricacion();
			if (!(ant > antiguedadMaximaValue.intValue())) {// si valida antiguedad, esta listo
				return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
			}
		}
		
		if (fabricacionRespectoSaliente) {
			// fabricacionRespectoSaliente.masNuevoQueSaliente=Mas nuevo que el
			// saliente
			// fabricacionRespectoSaliente.masNuevoOIgualQueSaliente=Mas nuevo o
			// igual al saliente
			// Vehiculo vEntr=e.getVehiculoServicioEntrante().getVehiculo();
			// Vehiculo vSal=e.getVehiculoServicioSaliente().getVehiculo();
			if ("fabricacionRespectoSaliente.masNuevoQueSaliente".equals(fabricacionRespectoSalienteValue) && vSal.getAnioFabricacion().intValue() >= vEntr.getAnioFabricacion().intValue()) {
				r = false;
				m = Resources.getString("validation.message.event.antiguedadMaxima", new String[] { String.valueOf(antiguedadMaximaValue) });
				m = ((m == null) ? "" : (m + "<br/>")) + Resources.getString("validation.message.event.reemplazo.masNuevoQueSaliente");
			}
			if ("fabricacionRespectoSaliente.masNuevoOIgualQueSaliente".equals(fabricacionRespectoSalienteValue) && vSal.getAnioFabricacion().intValue() > vEntr.getAnioFabricacion().intValue()) {
				r = false;
				m = Resources.getString("validation.message.event.antiguedadMaxima", new String[] { String.valueOf(antiguedadMaximaValue) });
				m = ((m == null) ? "" : (m + "<br/>")) + Resources.getString("validation.message.event.reemplazo.masNuevoOIgualQueSaliente");
			}
		}
		
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "perdida_total");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			antiguedadMaxima = Boolean.parseBoolean(items.get("antiguedad_maxima").getValue());
			antiguedadMaximaValue = (items.get("antiguedad_maxima_value").getValue() != null && !"".equals(items.get("antiguedad_maxima_value").getValue())) ? Integer.parseInt(items.get(
					"antiguedad_maxima_value").getValue()) : null;
			fabricacionRespectoSaliente = Boolean.parseBoolean(items.get("fabricacion_respecto_saliente").getValue());
			fabricacionRespectoSalienteValue = items.get("fabricacion_respecto_saliente_value").getValue();

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("perdida_total");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("antiguedad_maxima", String.valueOf(antiguedadMaxima)));
			normativaRegistro.addNormativaItem(new NormativaItem("antiguedad_maxima_value", String.valueOf(antiguedadMaximaValue)));
			normativaRegistro.addNormativaItem(new NormativaItem("fabricacion_respecto_saliente", String.valueOf(fabricacionRespectoSaliente)));
			normativaRegistro.addNormativaItem(new NormativaItem("fabricacion_respecto_saliente_value", fabricacionRespectoSalienteValue));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("antiguedad_maxima").setValues(Arrays.asList(new String[] { String.valueOf(antiguedadMaxima) }));
		items.get("antiguedad_maxima_value").setValues(Arrays.asList(new String[] { ((antiguedadMaximaValue != null) ? String.valueOf(antiguedadMaximaValue) : "") }));
		items.get("fabricacion_respecto_saliente").setValues(Arrays.asList(new String[] { String.valueOf(fabricacionRespectoSaliente) }));
		items.get("fabricacion_respecto_saliente_value").setValues(Arrays.asList(new String[] { fabricacionRespectoSalienteValue }));

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (antiguedadMaxima) {
			if (antiguedadMaximaValue == null || antiguedadMaximaValue.intValue() <= 0) {
				messageBean.addMessage(Resources.getString("validation.message.required.antiguedadMaximaValue"), FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
		}

		return valid;
	}

	public boolean isAntiguedadMaxima() {
		return antiguedadMaxima;
	}

	public void setAntiguedadMaxima(boolean antiguedadMaxima) {
		this.antiguedadMaxima = antiguedadMaxima;
	}

	public Integer getAntiguedadMaximaValue() {
		return antiguedadMaximaValue;
	}

	public void setAntiguedadMaximaValue(Integer antiguedadMaximaValue) {
		this.antiguedadMaximaValue = antiguedadMaximaValue;
	}

	public boolean isFabricacionRespectoSaliente() {
		return fabricacionRespectoSaliente;
	}

	public void setFabricacionRespectoSaliente(boolean fabricacionRespectoSaliente) {
		this.fabricacionRespectoSaliente = fabricacionRespectoSaliente;
	}

	public String getFabricacionRespectoSalienteValue() {
		return fabricacionRespectoSalienteValue;
	}

	public void setFabricacionRespectoSalienteValue(String fabricacionRespectoSalienteValue) {
		this.fabricacionRespectoSalienteValue = fabricacionRespectoSalienteValue;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

}
