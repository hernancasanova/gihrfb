package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class ReemplazosPermisoCirculacion extends GenericNormativa {

	public ReemplazosPermisoCirculacion(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private boolean cancelarPermiso = false;
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		VehiculoServicio tsEnt = null;
		if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
		}

		boolean r = true;
		String m = null;

		if (cancelarPermiso) {
			m = Resources.getString("validation.message.event.reemplazosPermisoCirculacion");
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "restriccion_permiso");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			cancelarPermiso = Boolean.parseBoolean(items.get("cancelar_permiso").getValue());

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("restriccion_permiso");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("cancelar_permiso", String.valueOf(cancelarPermiso)));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("cancelar_permiso").setValues(Arrays.asList(new String[] { String.valueOf(cancelarPermiso) }));

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		return valid;
	}

	public boolean isCancelarPermiso() {
		return cancelarPermiso;
	}

	public void setCancelarPermiso(boolean cancelarPermiso) {
		this.cancelarPermiso = cancelarPermiso;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

}
