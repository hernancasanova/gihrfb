package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

public class ReemplazosPlazoMaximo extends GenericNormativa {

	public ReemplazosPlazoMaximo(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private Integer plazoMaximoPermitido;
	private String rigeDesde = "plazoMaximoRigeDesde.solicitudCancelacion";
	private NormativaRegistro registro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		VehiculoServicio tsEnt = null;
		VehiculoServicio tsSal = null;
		if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
			tsSal = e.getVehiculoServicioSaliente();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
			tsSal = e.getVehiculoServicioSaliente();
		}

		if (tsSal.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
			return new RntEventResultItem(true, this, null);
		}
		Date fechaPlazo = ("plazoMaximoRigeDesde.solicitudCancelacion".equals(rigeDesde)) ? tsSal.getModified() : tsSal.getFechaCambioEstado();
		Calendar c = new GregorianCalendar();
		c.setTime(tsEnt.getFechaIngreso());
		c.add(Calendar.MONTH, -plazoMaximoPermitido.intValue());

		boolean r = ValidacionHelper.esFechaMenorIgual(c.getTime(), fechaPlazo);

		String m = null;
		if (!r && "plazoMaximoRigeDesde.solicitudCancelacion".equals(rigeDesde)) {
			m = Resources.getString("validation.message.event.reemplazo.plazoMaximoPermitido.solicitud", new String[] { String.valueOf(plazoMaximoPermitido) });
		} else if (!r) {
			m = Resources.getString("validation.message.event.reemplazo.plazoMaximoPermitido.cancelacion", new String[] { String.valueOf(plazoMaximoPermitido) });
		}
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "reemplazo_plazo_maximo");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			plazoMaximoPermitido = (items.get("plazo_maximo_permitido").getValue() != null && !"".equals(items.get("plazo_maximo_permitido").getValue())) ? Integer.parseInt(items.get(
					"plazo_maximo_permitido").getValue()) : null;
			rigeDesde = items.get("rige_desde").getValue();

			registro = ems.get(0);
		} else {
			registro = new NormativaRegistro();
			registro.setDbAction(GenericModelObject.ACTION_SAVE);
			registro.setDescriptor("reemplazo_plazo_maximo");
			registro.setItems(new ArrayList<NormativaItem>());
			registro.addNormativaItem(new NormativaItem("plazo_maximo_permitido", String.valueOf(plazoMaximoPermitido)));
			registro.addNormativaItem(new NormativaItem("rige_desde", rigeDesde));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		registro.setNormativa(normativa);

		Map<String, NormativaItem> items = registro.getItemsAsMap();
		items.get("plazo_maximo_permitido").setValues(Arrays.asList(new String[] { ((plazoMaximoPermitido != null) ? String.valueOf(plazoMaximoPermitido) : "") }));
		items.get("rige_desde").setValues(Arrays.asList(new String[] { rigeDesde }));

		normativa.getRegistros().add(registro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		return valid;
	}

	public Integer getPlazoMaximoPermitido() {
		return plazoMaximoPermitido;
	}

	public void setPlazoMaximoPermitido(Integer plazoMaximoPermitido) {
		this.plazoMaximoPermitido = plazoMaximoPermitido;
	}

	public String getRigeDesde() {
		return rigeDesde;
	}

	public void setRigeDesde(String rigeDesde) {
		this.rigeDesde = rigeDesde;
	}

	public NormativaRegistro getRegistro() {
		return registro;
	}

	public void setRegistro(NormativaRegistro registro) {
		this.registro = registro;
	}

}
