package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Adquisicion;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class ReemplazosRestriccionPropietario extends GenericNormativa {

	public ReemplazosRestriccionPropietario(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private String restriccionPropietario = "restriccionPropietario.indiferente";
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		VehiculoServicio tsEnt = null;
		VehiculoServicio tsSal = null;
		if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
			tsSal = e.getVehiculoServicioSaliente();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
			tsSal = e.getVehiculoServicioSaliente();
		}

		boolean r = true;
		String m = null;

		if ("restriccionPropietario.indiferente".equals(restriccionPropietario)) {
			new RntEventResultItem(true, this, m);
		} else {
			Adquisicion adqEnt = tsEnt.getVehiculo().getAdquisicion();
			Adquisicion adqSal = tsSal.getVehiculo().getAdquisicion();

			if ("restriccionPropietario.mismoSaliente".equals(restriccionPropietario)) {
				if (!adqEnt.tieneMismosPropietarios(adqSal)) {
					r = false;
					m = Resources.getString("validation.message.event.mismoPropietario");
				}
			} else {
				if ("restriccionPropietario.diferenteSaliente".equals(restriccionPropietario)) {
					if (adqEnt.tieneMismosPropietarios(adqSal)) {
						r = false;
						m = Resources.getString("validation.message.event.diferentePropietario");
					}
				}
			}
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "restriccion_propietario");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();

			restriccionPropietario = items.get("restriccion_propietario").getValue();

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("restriccion_propietario");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("restriccion_propietario", restriccionPropietario));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("restriccion_propietario").setValues(Arrays.asList(new String[] { restriccionPropietario }));

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		return valid;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

	public String getRestriccionPropietario() {
		return restriccionPropietario;
	}

	public void setRestriccionPropietario(String restriccionPropietario) {
		this.restriccionPropietario = restriccionPropietario;
	}

}
