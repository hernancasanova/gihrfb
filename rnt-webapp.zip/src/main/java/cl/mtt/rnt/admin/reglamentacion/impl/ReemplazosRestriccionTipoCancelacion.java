package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.ReglamentacionInvalidaTipoVehiculos;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class ReemplazosRestriccionTipoCancelacion extends GenericNormativa {
	
	private List<TipoCancelacion> tiposCancelacion;
	private List<TipoCancelacion> selectedTiposCancelacion;
	private NormativaRegistro normativaRegistro;
	
	public ReemplazosRestriccionTipoCancelacion(Normativa normativa) {
		super(normativa);
	}

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		VehiculoServicio tsEnt = null;
		VehiculoServicio tsSal = null;
		if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
			tsSal = e.getVehiculoServicioSaliente();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
			tsSal = e.getVehiculoServicioSaliente();
		}

		boolean r = true;
		String m = null;
		
		if (!selectedTiposCancelacion.contains(tsSal.getTipoCancelacion())) {
			r=false;
			m = Resources.getString("validation.message.event.reemplazosRestriccionTipoCancelacion");
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException, ReglamentacionInvalidaTipoVehiculos {
		this.tiposCancelacion =reglamentacionManager.getGeneralDataManager().getAllTiposCancelacion(TipoCancelacion.APLICA_VEHICULOS, false);
		this.selectedTiposCancelacion = new ArrayList<TipoCancelacion>();
		this.normativa = normativa;
		
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "restriccion_tipo_cancelacion");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();

			List<Long> idsClase = new ArrayList<Long>();
			for (String value : items.get("tipos_cancelacion").getValues()) {
				idsClase.add(Long.valueOf(value));
			}
			for(Long id : idsClase){
				for(TipoCancelacion tc :tiposCancelacion){
					if(tc.getId().equals(id)){
						selectedTiposCancelacion.add(tc);
						break;
					}
				}
			}
			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("restriccion_tipo_cancelacion");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("tipos_cancelacion", new ArrayList<String>()));
		}
		updateNormativa();
		
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();

		List<String> idsClase = new ArrayList<String>();
		for (TipoCancelacion ts : selectedTiposCancelacion) {
			idsClase.add(String.valueOf(ts.getId()));
		}

		items.get("tipos_cancelacion").setValues(idsClase);

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	protected Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	protected boolean validateForSaving() {
		boolean valid = true;

		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (normativa.getValidacion().equals("validacion.especificada")  && selectedTiposCancelacion.size() == 0) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public List<TipoCancelacion> getTiposCancelacion() {
		return tiposCancelacion;
	}

	public void setTiposCancelacion(List<TipoCancelacion> tiposCancelacion) {
		this.tiposCancelacion = tiposCancelacion;
	}

	public List<TipoCancelacion> getSelectedTiposCancelacion() {
		return selectedTiposCancelacion;
	}

	public void setSelectedTiposCancelacion(
			List<TipoCancelacion> selectedTiposCancelacion) {
		this.selectedTiposCancelacion = selectedTiposCancelacion;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}
	
}
