package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class ReemplazosTipoServicio extends GenericNormativa {

	public ReemplazosTipoServicio(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private List<NormativaRecordUI> recordGroup;

	// private boolean mismoTipoServicio = false;
	private String tipoServicio = "remplazo_tipoServicio.ambosCasos";
	
	private NormativaRegistro normativaRegistro;
	private List<TipoServicio> tiposServicioOrigen;
	private List<TipoServicio> tiposServicioDestino;
	private Map<Long, TipoServicio> allTiposServicioMap;
	private List<TipoServicio> selectedTiposServicioOrigen;
	private List<TipoServicio> selectedTiposServicioDestino;
	
	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// remplazo_tipoServicio.mismoTipo=el mismo tipo de servicio
		// remplazo_tipoServicio.distintoTipo=tipos de servicio especificados
		// remplazo_tipoServicio.ambosCasos=cualquier tipo de servicio

		// TransladoVehiculoEvent e=(TransladoVehiculoEvent) event;
		//
		// TipoServicio tsEnt=
		// e.getVehiculoServicioNuevo().getServicio().getTipoServicio();
		// TipoServicio tsSal=
		// e.getVehiculoServicioAnterior().getServicio().getTipoServicio();
		//
		VehiculoServicio tsEnt = null;
		VehiculoServicio tsSal = null;
		if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
			tsSal = e.getVehiculoServicioSaliente();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			tsEnt = e.getVehiculoServicioEntrante();
			tsSal = e.getVehiculoServicioSaliente();
		}

		boolean r = true;
		String m = null;

		if ("remplazo_tipoServicio.mismoTipo".equals(tipoServicio) && !tsEnt.getServicio().getTipoServicio().equals(tsSal.getServicio().getTipoServicio())) {
			r = false;
			m = Resources.getString("validation.message.event.ingresoPorReemplazo.mismoTipo");
		} else if ("remplazo_tipoServicio.distintoTipo".equals(tipoServicio) ) {
			
			for (NormativaRecordUI recordUI : recordGroup) {
				// validar tipos de servicio
				if (recordUI.getItemsMap().get("tipos_servicio_origen").getValues().contains(String.valueOf(tsSal.getServicio().getTipoServicio().getId()))
						&& recordUI.getItemsMap().get("tipos_servicio_destino").getValues().contains(String.valueOf(tsEnt.getServicio().getTipoServicio().getId()))) {
					return new RntEventResultItem(true, this, null);
				}
			}
			r = false;
			m = Resources.getString("validation.message.event.ingresoPorReemplazo.distintoTipo");
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		
		allTiposServicioMap = new HashMap<Long, TipoServicio>();
		// En origen van todos,  en  destino solo los relacionados con la reglamentacion
		tiposServicioOrigen = reglamentacionManager.getTipoServicioManager().getTiposServicio(); 
		for (TipoServicio ts : tiposServicioOrigen) {
			allTiposServicioMap.put(ts.getId(), ts);
		}
		selectedTiposServicioOrigen = new ArrayList<TipoServicio>();

		tiposServicioDestino = normativa.getReglamentacion().getTiposServicio(); // En destino van solo los de la reglamentacion
		selectedTiposServicioDestino = new ArrayList<TipoServicio>();

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "restriccion_tipo_servicio");
		if (ems != null && ems.size() > 0) {
			tipoServicio = ems.get(0).getItems().get(0).getValue();
			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("restriccion_tipo_servicio");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("mismo_tipo_servicio", tipoServicio));
		}

		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "tipos_servicio");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);
			String tsString = "";
			for (String key : recordUI.getItemsMap().get("tipos_servicio_origen").getValues()) {
				tsString += allTiposServicioMap.get(Long.parseLong(key)).getName() + ", ";
			}
			recordUI.getItemsMap().get("tipos_servicio_origen").setTextualValue(tsString.substring(0, tsString.lastIndexOf(",")));

			tsString = "";
			for (String key : recordUI.getItemsMap().get("tipos_servicio_destino").getValues()) {
				tsString += allTiposServicioMap.get(Long.parseLong(key)).getName() + ", ";
			}
			recordUI.getItemsMap().get("tipos_servicio_destino").setTextualValue(tsString.substring(0, tsString.lastIndexOf(",")));

			recordGroup.add(recordUI);
		}
		
		updateNormativa();

	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (selectedTiposServicioOrigen.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposServicioOrigen") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (selectedTiposServicioDestino.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposServicioDestino") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public void addItem() {
		// List<Map<String, NormativaItem>> recordGroup =
		// recordGroups.get("tipos_servicio");
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		List<String> ts = new ArrayList<String>();
		String tsString = "";
		for (TipoServicio tsa : selectedTiposServicioOrigen) {
			ts.add(String.valueOf(tsa.getId()));
			tsString += tsa.getName() + ", ";
		}
		recordItem.put("tipos_servicio_origen", new NormativaItem("tipos_servicio_origen", ts, tsString.substring(0, tsString.lastIndexOf(","))));

		ts = new ArrayList<String>();
		tsString = "";
		for (TipoServicio tsa : selectedTiposServicioDestino) {
			ts.add(String.valueOf(tsa.getId()));
			tsString += tsa.getName() + ", ";
		}
		recordItem.put("tipos_servicio_destino", new NormativaItem("tipos_servicio_destino", ts, tsString.substring(0, tsString.lastIndexOf(","))));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "tipos_servicio", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		selectedTiposServicioOrigen = new ArrayList<TipoServicio>();
		selectedTiposServicioDestino = new ArrayList<TipoServicio>();
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("mismo_tipo_servicio").setValues(Arrays.asList(new String[] { tipoServicio }));

		normativa.getRegistros().add(normativaRegistro);

		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (normativaRegistro.getItems().get(0).getDbAction() != GenericModelObject.ACTION_SAVE) {
				normativaRegistro.setNormativa(normativa);
				normativaRegistro.setDbAction(GenericModelObject.ACTION_DELETE);
				normativa.getRegistros().add(normativaRegistro);
			}
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}


	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && "remplazo_tipoServicio.distintoTipo".equals(tipoServicio) && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}
	
	public String getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

	public List<TipoServicio> getTiposServicioOrigen() {
		return tiposServicioOrigen;
	}

	public void setTiposServicioOrigen(List<TipoServicio> tiposServicioOrigen) {
		this.tiposServicioOrigen = tiposServicioOrigen;
	}

	public List<TipoServicio> getTiposServicioDestino() {
		return tiposServicioDestino;
	}

	public void setTiposServicioDestino(List<TipoServicio> tiposServicioDestino) {
		this.tiposServicioDestino = tiposServicioDestino;
	}

	public Map<Long, TipoServicio> getAllTiposServicioMap() {
		return allTiposServicioMap;
	}

	public void setAllTiposServicioMap(Map<Long, TipoServicio> allTiposServicioMap) {
		this.allTiposServicioMap = allTiposServicioMap;
	}

	public List<TipoServicio> getSelectedTiposServicioOrigen() {
		return selectedTiposServicioOrigen;
	}

	public void setSelectedTiposServicioOrigen(
			List<TipoServicio> selectedTiposServicioOrigen) {
		this.selectedTiposServicioOrigen = selectedTiposServicioOrigen;
	}

	public List<TipoServicio> getSelectedTiposServicioDestino() {
		return selectedTiposServicioDestino;
	}

	public void setSelectedTiposServicioDestino(
			List<TipoServicio> selectedTiposServicioDestino) {
		this.selectedTiposServicioDestino = selectedTiposServicioDestino;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}


	
}
