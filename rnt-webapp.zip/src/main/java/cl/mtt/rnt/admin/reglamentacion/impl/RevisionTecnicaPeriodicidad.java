package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.NormativasDataCache;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class RevisionTecnicaPeriodicidad extends GenericNormativa {
	public RevisionTecnicaPeriodicidad(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private Integer tipoVehiculoId;
	private Integer revisionesAnuales;
	private List<TipoVehiculo> tiposVehiculo;
	private Integer antiguedadMinima;
	private Integer antiguedadMaxima;

	private List<NormativaRecordUI> recordGroup;

	@Override
	public RntEventResultItem validate(GenericEvent event) {

		// Norma no validada, solo mensaje
		Vehiculo veh = null;
		if (event instanceof NuevoVehiculoEvent) {
			NuevoVehiculoEvent e = (NuevoVehiculoEvent) event;
			veh = e.getVehiculoServicio().getVehiculo();
		} else if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			veh = e.getVehiculoServicioEntrante().getVehiculo();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			veh = e.getVehiculoServicioEntrante().getVehiculo();
		} else if (event instanceof TrasladoVehiculoEvent) {
			TrasladoVehiculoEvent e = (TrasladoVehiculoEvent) event;
			veh = e.getVehiculoServicioNuevo().getVehiculo();
		}
		String nombreTipoVehiculo = null;
		for (TipoVehiculo tipoVehiculo : tiposVehiculo) {
			if (tipoVehiculo.getId().equals(veh.getTipoVehiculo()))
				nombreTipoVehiculo = tipoVehiculo.getDescripcion();
		}

		for (NormativaRecordUI recordUI : recordGroup) {
			if (String.valueOf(veh.getTipoVehiculo()).equals(recordUI.getItemsMap().get("tipo_vehiculo").getValue())) {
				int min = Integer.parseInt(recordUI.getItemsMap().get("antiguedad_minima").getValue());
				int max = Integer.parseInt(recordUI.getItemsMap().get("antiguedad_maxima").getValue());
				if (veh.getAntiguedad() >= min && veh.getAntiguedad() <= max) {
					String m = Resources.getString("validation.message.event.revisionTecnicaPeriodicidad", new String[] { recordUI.getItemsMap().get("revisiones_anuales").getValue() });
					return new RntEventResultItem(true, this, m);
				}
			}
		}
		return new RntEventResultItem(true, this, null);

	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		NormativasDataCache cacheNorm = NormativaAccess.getInstance().getNormativasDataCache(normativa.getReglamentacion());

		if (cacheNorm.getTiposVehiculos() != null) {
			tiposVehiculo = cacheNorm.getTiposVehiculos();
		} else {
			tiposVehiculo = cacheNorm.getAllTiposVehiculos();
		}

		this.normativa = normativa;
		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "modalidades");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);
			recordUI.getItemsMap().get("tipo_vehiculo")
					.setTextualValue(reglamentacionManager.getVehiculoManager().getTipoVehiculoById(Integer.valueOf(recordUI.getItemsMap().get("tipo_vehiculo").getValue())).getDescripcion());

			recordGroup.add(recordUI);
		}
		updateNormativa();

	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (tipoVehiculoId == null) {
			messageBean
					.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tipoVehiculo") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (revisionesAnuales == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.revisionesAnuales") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (antiguedadMinima == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.antiguedadMinima") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (antiguedadMaxima == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.antiguedadMaxima") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (antiguedadMinima != null && antiguedadMaxima != null && antiguedadMaxima < antiguedadMinima) {
			messageBean.addMessage(
					Resources.getString("validation.message.ordered",
							new String[] { Resources.getString("reglamentacion.normativa.field.antiguedadMinima"), Resources.getString("reglamentacion.normativa.field.antiguedadMaxima") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public void addItem() {
		// List<Map<String, NormativaItem>> recordGroup =
		// recordGroups.get("tipos_servicio");
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		for (TipoVehiculo tipoVehiculo : tiposVehiculo) {
			if (tipoVehiculo.getId().equals(tipoVehiculoId))
				recordItem.put("tipo_vehiculo", new NormativaItem("tipo_vehiculo", String.valueOf(tipoVehiculoId), tipoVehiculo.getDescripcion()));
		}
		recordItem.put("revisiones_anuales", new NormativaItem("revisiones_anuales", String.valueOf(revisionesAnuales)));
		recordItem.put("antiguedad_minima", new NormativaItem("antiguedad_minima", String.valueOf(antiguedadMinima)));
		recordItem.put("antiguedad_maxima", new NormativaItem("antiguedad_maxima", String.valueOf(antiguedadMaxima)));
		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "modalidades", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);
		// recordGroups.put("tipos_servicio",recordGroup);

		// reseteo los datos
		revisionesAnuales = null;
		antiguedadMinima = null;
		antiguedadMaxima = null;
		tipoVehiculoId = null;
		updateNormativa();
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	public List<TipoVehiculo> getTiposVehiculo() {
		return tiposVehiculo;
	}

	public void setTiposVehiculo(List<TipoVehiculo> tiposVehiculo) {
		this.tiposVehiculo = tiposVehiculo;
	}

	public Integer getRevisionesAnuales() {
		return revisionesAnuales;
	}

	public void setRevisionesAnuales(Integer revisionesAnuales) {
		this.revisionesAnuales = revisionesAnuales;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public Integer getTipoVehiculoId() {
		return tipoVehiculoId;
	}

	public void setTipoVehiculoId(Integer tipoVehiculoId) {
		this.tipoVehiculoId = tipoVehiculoId;
	}

	public Integer getAntiguedadMinima() {
		return antiguedadMinima;
	}

	public void setAntiguedadMinima(Integer antiguedadMinima) {
		this.antiguedadMinima = antiguedadMinima;
	}

	public Integer getAntiguedadMaxima() {
		return antiguedadMaxima;
	}

	public void setAntiguedadMaxima(Integer antiguedadMaxima) {
		this.antiguedadMaxima = antiguedadMaxima;
	}

}
