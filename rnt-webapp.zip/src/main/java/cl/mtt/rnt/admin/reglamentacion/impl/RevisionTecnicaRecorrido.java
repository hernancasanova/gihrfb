package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class RevisionTecnicaRecorrido extends GenericNormativa {

	public RevisionTecnicaRecorrido(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private boolean revisionTecnica = false;
	private NormativaRegistro normativaRegistro;

	private List<TipoServicio> tiposServicio;
	private List<TipoServicio> selectedTiposServicio;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		VehiculoServicio vehiculoServicio = null;
		if (event instanceof NuevoVehiculoEvent) {
			vehiculoServicio = ((NuevoVehiculoEvent) event).getVehiculoServicio();
		} else if (event instanceof ReemplazoVehiculoEvent) {
			vehiculoServicio = ((ReemplazoVehiculoEvent) event).getVehiculoServicioEntrante();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			vehiculoServicio = ((ReemplazoTrasladoVehiculoEvent) event).getVehiculoServicioEntrante();
		} else if (event instanceof TrasladoVehiculoEvent) {
			vehiculoServicio = ((TrasladoVehiculoEvent) event).getVehiculoServicioNuevo();
		}

		boolean r = true;
		String m = null;

		if (revisionTecnica) {
			if (selectedTiposServicio.contains(vehiculoServicio.getServicio().getTipoServicio())) {
				m = Resources.getString("validation.message.event.revisionTecnica");
			}
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {

		tiposServicio = normativa.getReglamentacion().getTiposServicio(); // Van
																						// solo
																						// los
																						// de
																						// la
																						// reglamentacion
		selectedTiposServicio = new ArrayList<TipoServicio>();

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "revision_tecnica");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			revisionTecnica = Boolean.parseBoolean(items.get("revision_tecnica").getValue());

			List<Long> idsClase = new ArrayList<Long>();
			for (String value : items.get("tipos_servicio").getValues()) {
				idsClase.add(Long.valueOf(value));
			}
			selectedTiposServicio = reglamentacionManager.getTipoServicioManager().getTiposServiciosByIds(idsClase);

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("revision_tecnica");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("revision_tecnica", String.valueOf(revisionTecnica)));
			normativaRegistro.addNormativaItem(new NormativaItem("tipos_servicio", new ArrayList<String>()));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("revision_tecnica").setValues(Arrays.asList(new String[] { String.valueOf(revisionTecnica) }));

		List<String> idsClase = new ArrayList<String>();
		for (TipoServicio ts : selectedTiposServicio) {
			idsClase.add(String.valueOf(ts.getId()));
		}

		items.get("tipos_servicio").setValues(idsClase);

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;

		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (normativa.getValidacion().equals("validacion.especificada") && revisionTecnica && selectedTiposServicio.size() == 0) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public boolean isRevisionTecnica() {
		return revisionTecnica;
	}

	public void setRevisionTecnica(boolean revisionTecnica) {
		this.revisionTecnica = revisionTecnica;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	public List<TipoServicio> getSelectedTiposServicio() {
		return selectedTiposServicio;
	}

	public void setSelectedTiposServicio(List<TipoServicio> selectedTiposServicio) {
		this.selectedTiposServicio = selectedTiposServicio;
	}

}
