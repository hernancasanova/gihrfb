package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoConductorEvent;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.ClaseLicenciaConducir;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class TiposLicenciaPermitidos extends GenericNormativa {

	public TiposLicenciaPermitidos(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private List<ClaseLicenciaConducir> clasesLicenciaConducir;
	private List<ClaseLicenciaConducir> selectedClasesLicenciaConducir;
	private NormativaRegistro normativaRegistro;

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		NuevoConductorEvent e = (NuevoConductorEvent) event;

		boolean r = selectedClasesLicenciaConducir.contains(e.getConductor().getClaseLicenciaConducir());

		String m = null;
		if (!r) {
			m = Resources.getString("validation.message.event.tipoLicencia");
		}
		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		clasesLicenciaConducir = reglamentacionManager.getGeneralDataManager().getAllClasesLicenciaConducir();
		selectedClasesLicenciaConducir = new ArrayList<ClaseLicenciaConducir>();

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "licencias_permitidas");
		if (ems != null && ems.size() > 0) {
			Map<String, NormativaItem> items = ems.get(0).getItemsAsMap();
			List<Long> idsClase = new ArrayList<Long>();
			for (String value : items.get("licencias_permitidas").getValues()) {
				idsClase.add(Long.valueOf(value));
			}
			selectedClasesLicenciaConducir = reglamentacionManager.getGeneralDataManager().getClasesLicenciaConducirByIds(idsClase);

			normativaRegistro = ems.get(0);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("licencias_permitidas");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
			normativaRegistro.addNormativaItem(new NormativaItem("licencias_permitidas", new ArrayList<String>()));
		}
		updateNormativa();
	}

	@Override
	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);

		List<String> idsClase = new ArrayList<String>();
		for (ClaseLicenciaConducir lic : selectedClasesLicenciaConducir) {
			idsClase.add(String.valueOf(lic.getId()));
		}
		Map<String, NormativaItem> items = normativaRegistro.getItemsAsMap();
		items.get("licencias_permitidas").setValues(idsClase);

		normativa.getRegistros().add(normativaRegistro);
	}

	@Override
	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		}
		return normativa;
	}

	@Override
	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");

		if (normativa.getValidacion().equals("validacion.especificada") && selectedClasesLicenciaConducir.size() == 0) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public List<ClaseLicenciaConducir> getClasesLicenciaConducir() {
		return clasesLicenciaConducir;
	}

	public void setClasesLicenciaConducir(List<ClaseLicenciaConducir> clasesLicenciaConducir) {
		this.clasesLicenciaConducir = clasesLicenciaConducir;
	}

	public List<ClaseLicenciaConducir> getSelectedClasesLicenciaConducir() {
		return selectedClasesLicenciaConducir;
	}

	public void setSelectedClasesLicenciaConducir(List<ClaseLicenciaConducir> selectedClasesLicenciaConducir) {
		this.selectedClasesLicenciaConducir = selectedClasesLicenciaConducir;
	}

	public NormativaRegistro getNormativaRegistro() {
		return normativaRegistro;
	}

	public void setNormativaRegistro(NormativaRegistro normativaRegistro) {
		this.normativaRegistro = normativaRegistro;
	}

}
