package cl.mtt.rnt.admin.reglamentacion.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.CargaVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.CargaVehiculoVacioEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.ItemPeriodoNormativa;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.reglamentacion.util.PropertiesManager;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.PeriodoVigencia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.ServicioManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;
import cl.mtt.rnt.encargado.bean.CrossContextAccessBean;
import cl.mtt.rnt.encargado.dto.ServicioDTO;

public class TiposVehiculoPermitidosOtrosServicios extends GenericNormativa {

    
    public static final String KEY_NO_PERMITE_MAS_DE_UN_VIGENTE = "no_permite_mas_de_un_vigente";
    public static final String KEY_CANTIDAD_DIAS_CORRIDOS = "cantidad_dias_corridos";
    
	public TiposVehiculoPermitidosOtrosServicios(Normativa normativa) {
		super(normativa);
	}

	private List<NormativaRecordUI> recordGroup;
	
	private List<TipoServicio> allTiposServicio;
	private Map<Long, TipoServicio> allTiposServicioMap;
	private List<TipoServicio> selectedTiposServicio;
	private String tipoVigencia;
	private Date desde;
	private Date hasta;
	private Boolean mismoResponsable;
	private String nombrePeriodo;
	
	private NormativaRegistro noPermiteIngresoEnOtroServicioRegistro;
	private Boolean noPermiteIngresoEnOtroServicio = Boolean.TRUE;
	private Integer cantidadDeDiasCorridos;

	private ServicioManager getServicioManager() {
		return CrossContextAccessBean.getServicioManager();
	}

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// tipoVigencia.anual=Anual
		// tipoVigencia.rangoEspecifico=Rango Específico
	    boolean validarFechas = true;
		VehiculoServicio vs = null;
		if (event instanceof ConVehiculoServicioEvent) {
			ConVehiculoServicioEvent cve = (ConVehiculoServicioEvent) event;
			vs = cve.getVehiculoServicio();
			if ((event instanceof CargaVehiculoEvent)||(event instanceof CargaVehiculoVacioEvent)){
			    validarFechas = false;
			}
		}
		else
		if (event instanceof NuevoVehiculoEvent) {
			NuevoVehiculoEvent e = (NuevoVehiculoEvent) event;
			vs = e.getVehiculoServicio();
		} else if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			vs = e.getVehiculoServicioEntrante();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			vs = e.getVehiculoServicioEntrante();
		} 
		if (vs!=null)
			return validateByVehiculo(vs,validarFechas);
		
		return null;
	}

	private RntEventResultItem validateByVehiculo(VehiculoServicio vs,Boolean validarFechas) {
		try {
			RntEventResultItem item = validateByPeriodos(vs);
			if(!item.isResult()){
				return item;
			}
				
			boolean r = true;
			String m = null;
			ServicioDTO auxEval = null;
			List<ServicioDTO> vss = getServicioManager().getServiciosByPPU(vs.getVehiculo().getPpu());
			boolean algunVigente = false;
			for (ServicioDTO servicioDTO : vss) {
				if (servicioDTO.getEstadoVehiculo().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
				    auxEval = servicioDTO;
				    algunVigente = true;
					boolean agunPositivo = false;
					String mensaje = null;
					for (NormativaRecordUI recordUI : recordGroup) {
						String rta = analizarPeriodo(servicioDTO, recordUI, vs, validarFechas);
						if (rta ==null) {
						    agunPositivo = true;
						}
						else {
						    if (mensaje==null) {
						        mensaje = rta;
						    }
						}
						
					}
					if (!agunPositivo) {
					    r=false;
					    m = mensaje;
					} 
				}
				if (!r) {
					break;
				}

			}
			if (algunVigente) {
			    if (noPermiteIngresoEnOtroServicio) {
                    m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios", new String[] { auxEval.getDescripcion() });
                    r = false;
                }
			}
//			else {
//			    r = false ;
//                m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios6");
//			}
			return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);

		} catch (ParseException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}
	
	
	private String analizarPeriodo(ServicioDTO servicioDTO,NormativaRecordUI recordUI,VehiculoServicio vs,Boolean validarFechas) throws ParseException {
	    Date today = new Date();
	    String m = null;
	    if (recordUI.getItemsMap().get("tipos_servicio").getValues().contains(String.valueOf(servicioDTO.getIdTipoServicio()))) {
            boolean mr = Boolean.valueOf(recordUI.getItemsMap().get("mismo_responsable").getValue());
            if (!mr || (mr && servicioDTO.getIdResponsableServicio().equals(vs.getServicio().getResponsable().getId()))) {
                String tv = recordUI.getItemsMap().get("tipos_vigencia").getValue();
                if (validarFechas.booleanValue()) {
                    if ("tipoVigencia.rangoEspecifico".equals(tv)
                            && ValidacionHelper.esFechaMayorIgual(today, Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_desde").getValue()))
                            && ValidacionHelper.esFechaMenorIgual(today, Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_hasta").getValue()))) {
                        // r=true;
                    } else if ("tipoVigencia.anual".equals(tv)) {
                        Calendar desde = new GregorianCalendar();
                        desde.setTime(Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_desde").getValue()));
                        Calendar hasta = new GregorianCalendar();
                        hasta.setTime(Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_hasta").getValue()));
                        Calendar todaycal = new GregorianCalendar();
                        todaycal.setTime(vs.getFechaIngreso());
                        desde.set(Calendar.YEAR, todaycal.get(Calendar.YEAR));
                        hasta.set(Calendar.YEAR, todaycal.get(Calendar.YEAR));
                        if (hasta.before(desde)) {
                            if (hasta.before(todaycal)) {
                                hasta.set(Calendar.YEAR, todaycal.get(Calendar.YEAR)+ 1);
                            } else {
                                desde.set(Calendar.YEAR, todaycal.get(Calendar.YEAR)- 1);
                            }
                        }
                        if (ValidacionHelper.esFechaMayorIgual(vs.getFechaIngreso(), desde.getTime()) && ValidacionHelper.esFechaMenorIgual(vs.getFechaIngreso(), hasta.getTime())) {
                            //
                        } else {
                            m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios3", new String[] { servicioDTO.getDescripcion() });
       
                        }
                    } else {
                        m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios3", new String[] { servicioDTO.getDescripcion() });
                    }
                }
            } else {
                m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios2", new String[] { servicioDTO.getDescripcion() });

            }
        } else {
            m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios1", new String[] { servicioDTO.getDescripcion() });
  
        }
	    return m;
	}
	
	
	
	private int getDias(Date fInicial, Date fFinal){
        Calendar ci = Calendar.getInstance();
        ci.setTime(fInicial);

        Calendar cf = Calendar.getInstance();
        cf.setTime(fFinal);

        long ntime = cf.getTimeInMillis() - ci.getTimeInMillis();

        return (int)Math.ceil((double)ntime / 1000 / 3600 / 24);
    }
	
	private RntEventResultItem validateByPeriodos(VehiculoServicio vehiculoServicio) {
		try {
			Date today = new Date();
			if(vehiculoServicio.getPeriodosVigencia() == null){
				return new RntEventResultItem(true, this, null);
			}
			List<PeriodoVigencia> periodos = new ArrayList<PeriodoVigencia>(vehiculoServicio.getPeriodosVigencia());
			
			Integer cantDiasTotales = 0;
			for (PeriodoVigencia periodoVigencia : periodos) {
				boolean r = true;
				String m = null;
				//Voy acumulando los dias
				cantDiasTotales += getDias(periodoVigencia.getFechaDesde(),periodoVigencia.getFechaHasta());
				//verifico los limites desde-hasta
				for (NormativaRecordUI recordUI : recordGroup) {
					if (recordUI.getItemsMap().get("tipos_servicio").getValues().contains(String.valueOf(vehiculoServicio.getServicio().getTipoServicio().getId()))) {
						String nombrePer = recordUI.getItemsMap().get("nombre_periodo").getValue();
						if (nombrePer.equals(periodoVigencia.getNombrePeriodo())){
							String tv = recordUI.getItemsMap().get("tipos_vigencia").getValue();
							Calendar desde = new GregorianCalendar();
							desde.setTime(Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_desde").getValue()));
							Calendar hasta = new GregorianCalendar();
							hasta.setTime(Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_hasta").getValue()));
							if ("tipoVigencia.rangoEspecifico".equals(tv) && !ValidacionHelper.rangoFechasIncluded(periodoVigencia.getFechaDesde(), periodoVigencia.getFechaHasta(), desde.getTime(), hasta.getTime())){
								m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios4", 
										new String[] { nombrePer,Constants.dateFormat.format(periodoVigencia.getFechaDesde()),Constants.dateFormat.format(periodoVigencia.getFechaHasta()),Constants.dateFormat.format(desde.getTime()),Constants.dateFormat.format(hasta.getTime()) });
								r = false;
							} else if ("tipoVigencia.anual".equals(tv)){
								Calendar desdePer = new GregorianCalendar();
								desdePer.setTime(periodoVigencia.getFechaDesde());
								Calendar hastaPer = new GregorianCalendar();
								hastaPer.setTime(periodoVigencia.getFechaHasta());
								Calendar todaycal = new GregorianCalendar();
								todaycal.setTime(today);
								desdePer.set(Calendar.YEAR, todaycal.get(Calendar.YEAR));
								hastaPer.set(Calendar.YEAR, todaycal.get(Calendar.YEAR));
								if (hastaPer.before(desdePer)) {
									hastaPer.set(Calendar.YEAR, todaycal.get(Calendar.YEAR)+ 1);
								}
								if (hasta.before(desde)) {
									hasta.set(Calendar.YEAR, todaycal.get(Calendar.YEAR)+ 1);
								}
								if (!ValidacionHelper.rangoFechasIncluded(periodoVigencia.getFechaDesde(), periodoVigencia.getFechaHasta(), desde.getTime(), hasta.getTime())){
									m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios4", 
											new String[] { nombrePer,Constants.dayMonthFormat.format(periodoVigencia.getFechaDesde()),Constants.dayMonthFormat.format(periodoVigencia.getFechaHasta()),Constants.dayMonthFormat.format(desde.getTime()),Constants.dayMonthFormat.format(hasta.getTime()) });
									r = false;
								}
							}
						}
					}
					if(!r){
						return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
					}
				}
			}
			
			if(cantidadDeDiasCorridos!=null && cantDiasTotales > cantidadDeDiasCorridos ){
				return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) , this, 
						Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios5", new String[] {String.valueOf(cantidadDeDiasCorridos)})
					);
			}
				
			return new RntEventResultItem(true, this, null);

		} catch (ParseException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		allTiposServicioMap = new HashMap<Long, TipoServicio>();
		allTiposServicio = reglamentacionManager.getTipoServicioManager().getTiposServicio();
		for (TipoServicio ts : allTiposServicio) {
			allTiposServicioMap.put(ts.getId(), ts);
		}
		selectedTiposServicio = new ArrayList<TipoServicio>();
		this.normativa = normativa;
		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "tipos_servicio");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);
			List<String> tsStrings=new ArrayList<String>(); 
			//String tsString = "";
			if (recordUI.getItemsMap().get("tipos_servicio")!=null){
				for (String key : recordUI.getItemsMap().get("tipos_servicio").getValues()) {
					String n = allTiposServicioMap.get(Long.parseLong(key)).getName();
					tsStrings.add(n);
					//tsString += allTiposServicioMap.get(Long.parseLong(key)).getName() + ", ";
				}			
//			recordUI.getItemsMap().get("tipos_servicio").setTextualValue(tsString.substring(0, tsString.lastIndexOf(",")));
			recordUI.getItemsMap().get("tipos_servicio").setTextualValues(tsStrings);
			recordUI.getItemsMap().get("tipos_vigencia").setTextualValue(PropertiesManager.getProperty(recordUI.getItemsMap().get("tipos_vigencia").getValue()));

			if (!"tipoVigencia.rangoEspecifico".equals(recordUI.getItemsMap().get("tipos_vigencia").getValue())) {
				try {
					recordUI.getItemsMap().get("vigencia_desde")
							.setTextualValue(Constants.dayMonthFormat.format(Constants.dateFormat.parseObject(recordUI.getItemsMap().get("vigencia_desde").getValue())));
					recordUI.getItemsMap().get("vigencia_hasta")
							.setTextualValue(Constants.dayMonthFormat.format(Constants.dateFormat.parseObject(recordUI.getItemsMap().get("vigencia_hasta").getValue())));
				} catch (ParseException e) {
					
				}
			}
			}
			recordGroup.add(recordUI);
		}
		
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "no_permite_mas_de_un_vigente");
		if (ems != null && ems.size() > 0) {
			noPermiteIngresoEnOtroServicioRegistro = ems.get(0);
			noPermiteIngresoEnOtroServicio = Boolean.parseBoolean(getNormativaItemByKey(noPermiteIngresoEnOtroServicioRegistro.getItems(),KEY_NO_PERMITE_MAS_DE_UN_VIGENTE).getValue());
			if (noPermiteIngresoEnOtroServicioRegistro.getItems().size()>1){
			    String valueCantDCorr = getNormativaItemByKey(noPermiteIngresoEnOtroServicioRegistro.getItems(),KEY_CANTIDAD_DIAS_CORRIDOS).getValue();
				cantidadDeDiasCorridos = (valueCantDCorr==null || valueCantDCorr.equals("null"))?null:(Integer.parseInt(valueCantDCorr));
			}else{
				NormativaItem cdc = new NormativaItem("cantidad_dias_corridos", (String)null);
				cdc.setRegistro(noPermiteIngresoEnOtroServicioRegistro);
				noPermiteIngresoEnOtroServicioRegistro.getItems().add(cdc);
			}
		} else {
			noPermiteIngresoEnOtroServicioRegistro = new NormativaRegistro();
			noPermiteIngresoEnOtroServicioRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			noPermiteIngresoEnOtroServicioRegistro.setDescriptor("no_permite_mas_de_un_vigente");
			noPermiteIngresoEnOtroServicioRegistro.setItems(new ArrayList<NormativaItem>());
			NormativaItem ni = new NormativaItem("no_permite_mas_de_un_vigente", noPermiteIngresoEnOtroServicio.toString());
			ni.setRegistro(noPermiteIngresoEnOtroServicioRegistro);
			noPermiteIngresoEnOtroServicioRegistro.getItems().add(ni);
			NormativaItem cdc = new NormativaItem("cantidad_dias_corridos", String.valueOf(cantidadDeDiasCorridos));
			cdc.setRegistro(noPermiteIngresoEnOtroServicioRegistro);
			noPermiteIngresoEnOtroServicioRegistro.getItems().add(cdc);
		}
		tipoVigencia = "tipoVigencia.rangoEspecifico";
		nombrePeriodo=null;
		updateNormativa();
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (selectedTiposServicio.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposServicio") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (tipoVigencia == null || tipoVigencia.isEmpty()) {
			messageBean
					.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tipoVigencia") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (nombrePeriodo == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.nombrePeriodo") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (desde == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaDesde") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (hasta == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaHasta") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if ("tipoVigencia.rangoEspecifico".equals(tipoVigencia) && desde != null && hasta != null && desde.after(hasta)) {
			messageBean.addMessage(
					Resources.getString("validation.message.orderedDates",
							new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaDesde"), Resources.getString("reglamentacion.normativa.field.vigenciaHasta") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}

		return valid;
	}

	public void addItem() {
		// List<Map<String, NormativaItem>> recordGroup =
		// recordGroups.get("tipos_servicio");
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		List<String> ts = new ArrayList<String>();
		List<String> tsText = new ArrayList<String>();
		//String tsString = "";
		for (TipoServicio tsa : selectedTiposServicio) {
			ts.add(String.valueOf(tsa.getId()));
			tsText.add(tsa.getName());
			//tsString += tsa.getName() + ", ";
		}
	//	recordItem.put("tipos_servicio", new NormativaItem("tipos_servicio", ts, tsString.substring(0, tsString.lastIndexOf(","))));
		recordItem.put("tipos_servicio", new NormativaItem("tipos_servicio", ts));
		recordItem.get("tipos_servicio").setTextualValues(tsText);
		
		recordItem.put("tipos_vigencia", new NormativaItem("tipos_vigencia", tipoVigencia, PropertiesManager.getProperty(tipoVigencia)));
		if ("tipoVigencia.rangoEspecifico".equals(tipoVigencia)) {
			recordItem.put("vigencia_desde", new NormativaItem("vigencia_desde", (desde != null) ? Constants.dateFormat.format(desde) : null));
			recordItem.put("vigencia_hasta", new NormativaItem("vigencia_hasta", (hasta != null) ? Constants.dateFormat.format(hasta) : null));
		} else {
			recordItem.put("vigencia_desde", new NormativaItem("vigencia_desde", (desde != null) ? Constants.dateFormat.format(desde) : null, (desde != null) ? Constants.dayMonthFormat.format(desde)
					: null));
			recordItem.put("vigencia_hasta", new NormativaItem("vigencia_hasta", (hasta != null) ? Constants.dateFormat.format(hasta) : null, (hasta != null) ? Constants.dayMonthFormat.format(hasta)
					: null));
		}
		recordItem.put("mismo_responsable", new NormativaItem("mismo_responsable", String.valueOf(mismoResponsable)));
		recordItem.put("nombre_periodo", new NormativaItem("nombre_periodo", nombrePeriodo));
		
		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "tipos_servicio", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		selectedTiposServicio = new ArrayList<TipoServicio>();
		tipoVigencia = "tipoVigencia.rangoEspecifico";
		desde = null;
		hasta = null;
		mismoResponsable = null;
		nombrePeriodo = null;
		updateNormativa();
	}

	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		noPermiteIngresoEnOtroServicioRegistro.setNormativa(normativa);
		getNormativaItemByKey(noPermiteIngresoEnOtroServicioRegistro.getItems(), KEY_NO_PERMITE_MAS_DE_UN_VIGENTE).setValues(Arrays.asList(new String[] { noPermiteIngresoEnOtroServicio.toString() }));
		
		getNormativaItemByKey(noPermiteIngresoEnOtroServicioRegistro.getItems(), KEY_CANTIDAD_DIAS_CORRIDOS).setValues(Arrays.asList(new String[] { String.valueOf(cantidadDeDiasCorridos) }));
		
		normativa.getRegistros().add(noPermiteIngresoEnOtroServicioRegistro);
		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	public List<TipoServicio> getAllTiposServicio() {
		return allTiposServicio;
	}

	public void setAllTiposServicio(List<TipoServicio> allTiposServicio) {
		this.allTiposServicio = allTiposServicio;
	}

	public List<TipoServicio> getSelectedTiposServicio() {
		return selectedTiposServicio;
	}

	public void setSelectedTiposServicio(List<TipoServicio> selectedTiposServicio) {
		this.selectedTiposServicio = selectedTiposServicio;
	}

	public String getTipoVigencia() {
		return tipoVigencia;
	}

	public void setTipoVigencia(String tipoVigencia) {
		this.tipoVigencia = tipoVigencia;
	}

	public Date getDesde() {
		return desde;
	}

	public void setDesde(Date desde) {
		this.desde = desde;
	}

	public Date getHasta() {
		return hasta;
	}

	public void setHasta(Date hasta) {
		this.hasta = hasta;
	}

	public Boolean getMismoResponsable() {
		return mismoResponsable;
	}

	public void setMismoResponsable(Boolean mismoResponsable) {
		this.mismoResponsable = mismoResponsable;
	}

	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (!normativa.getValidacion().equals("validacion.especificada") && 
				(!this.getNormativa().getReglamentacion().getEspecificadaSobreExistente())) {
			messageBean.addMessage(Resources.getString("validation.message.debeimplementarvehiculosPermOtros"), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (!this.noPermiteIngresoEnOtroServicio.booleanValue()) {
			int count = 0;
			for (NormativaRecordUI rg : recordGroup) {
				if (rg.getAction() != GenericModelObject.ACTION_DELETE)
					count++;
			}
			if (normativa.getValidacion().equals("validacion.especificada") && (recordGroup == null || count == 0)) {
				messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
		}
		return valid;
	}

	/**
	 * @return el valor de noPermiteIngresoEnOtroServicio
	 */
	public Boolean getNoPermiteIngresoEnOtroServicio() {
		return noPermiteIngresoEnOtroServicio;
	}

	/**
	 * @param setea el parametro noPermiteIngresoEnOtroServicio al campo noPermiteIngresoEnOtroServicio
	 */
	public void setNoPermiteIngresoEnOtroServicio(Boolean noPermiteIngresoEnOtroServicio) {
		this.noPermiteIngresoEnOtroServicio = noPermiteIngresoEnOtroServicio;
	}

	public Integer getCantidadDeDiasCorridos() {
		return cantidadDeDiasCorridos;
	}

	public void setCantidadDeDiasCorridos(Integer cantidadDeDiasCorridos) {
		this.cantidadDeDiasCorridos = cantidadDeDiasCorridos;
	}

	public String getNombrePeriodo() {
		return nombrePeriodo;
	}

	public void setNombrePeriodo(String nombrePeriodo) {
		this.nombrePeriodo = nombrePeriodo;
	}

	public List<ItemPeriodoNormativa> getItemsPeriodoNormativa() {
		List<ItemPeriodoNormativa> items = new ArrayList<ItemPeriodoNormativa>();
		
		if(!noPermiteIngresoEnOtroServicio){
            for (NormativaRecordUI recordUI : recordGroup) {
                String nombre = recordUI.getItemsMap().get("nombre_periodo").getValue();
                String tipo = recordUI.getItemsMap().get("tipos_vigencia").getValue();
                ItemPeriodoNormativa itemPeriodoNormativa = new ItemPeriodoNormativa(nombre, tipo);
                if (!items.contains(itemPeriodoNormativa)) {
                    items.add(itemPeriodoNormativa);
                }
            }
        }
		return items;
	}

}
