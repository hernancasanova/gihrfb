package cl.mtt.rnt.admin.reglamentacion.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.ConVehiculoServicioEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.CargaVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.CargaVehiculoVacioEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.NuevoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.ItemPeriodoNormativa;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.reglamentacion.util.PeriodoNormativa;
import cl.mtt.rnt.admin.reglamentacion.util.PropertiesManager;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.bean.ReglamentacionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.PeriodoVigencia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.ServicioManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;
import cl.mtt.rnt.encargado.bean.CrossContextAccessBean;
import cl.mtt.rnt.encargado.dto.ServicioDTO;

public class TiposVehiculoPermitidosOtrosServicios_backup extends GenericNormativa {

    
    public static final String KEY_NO_PERMITE_MAS_DE_UN_VIGENTE = "no_permite_mas_de_un_vigente";
    public static final String KEY_CANTIDAD_DIAS_CORRIDOS = "cantidad_dias_corridos";
    
	public TiposVehiculoPermitidosOtrosServicios_backup(Normativa normativa) {
		super(normativa);
	}

	private List<NormativaRecordUI> recordGroup;
	
//	private List<TipoServicio> allTiposServicio;
	private Map<Long, TipoServicio> allTiposServicioMap;
//	private List<TipoServicio> selectedTiposServicio;
	private NormativaRecordUI itemSeleccionado;
	
	private TipoServicio tiposServicio;
	private Integer cantidadDeDiasCorridos;
	private PeriodoNormativa periodo1;
	private PeriodoNormativa periodo2;
	
	private NormativaRegistro noPermiteIngresoEnOtroServicioRegistro;
	private Boolean noPermiteIngresoEnOtroServicio = Boolean.TRUE;

	private ServicioManager getServicioManager() {
		return CrossContextAccessBean.getServicioManager();
	}

	@Override
	public RntEventResultItem validate(GenericEvent event) {
		// tipoVigencia.anual=Anual
		// tipoVigencia.rangoEspecifico=Rango Específico
	    boolean validarFechas = true;
		VehiculoServicio vs = null;
		if (event instanceof ConVehiculoServicioEvent) {
			ConVehiculoServicioEvent cve = (ConVehiculoServicioEvent) event;
			vs = cve.getVehiculoServicio();
			if ((event instanceof CargaVehiculoEvent)||(event instanceof CargaVehiculoVacioEvent)){
			    validarFechas = false;
			}
		}
		else
		if (event instanceof NuevoVehiculoEvent) {
			NuevoVehiculoEvent e = (NuevoVehiculoEvent) event;
			vs = e.getVehiculoServicio();
		} else if (event instanceof ReemplazoVehiculoEvent) {
			ReemplazoVehiculoEvent e = (ReemplazoVehiculoEvent) event;
			vs = e.getVehiculoServicioEntrante();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			vs = e.getVehiculoServicioEntrante();
		} 
		if (vs!=null)
			return validateByVehiculo(vs,validarFechas);
		
		return null;
	}

	private RntEventResultItem validateByVehiculo(VehiculoServicio vs,Boolean validarFechas) {
		try {
			boolean r = true;
			String m = null;
			Date today = new Date();
			List<ServicioDTO> vss = getServicioManager().getServiciosByPPU(vs.getVehiculo().getPpu());
			for (ServicioDTO servicioDTO : vss) {
				if (servicioDTO.getEstadoVehiculo().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
					if (noPermiteIngresoEnOtroServicio) {
						m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios", new String[] { servicioDTO.getDescripcion() });
						r = false;
					}
					for (NormativaRecordUI recordUI : recordGroup) {
						// validar tipos de servicio, ver la vigencia de acuerdo
						// al tipo de vigencia, y validar el responsable
						if (recordUI.getItemsMap().get("tipo_servicio").getValue().equals(String.valueOf(servicioDTO.getIdTipoServicio()))) {
							String m1 = null;
							boolean hab1 = Boolean.valueOf(recordUI.getItemsMap().get("habilitado1").getValue());
							if(hab1){
								m1 = validatePeriodoIndividual(vs, today, servicioDTO, recordUI,"1");
							}
							String m2 = null;
							boolean hab2 = Boolean.valueOf(recordUI.getItemsMap().get("habilitado2").getValue());
							if(hab2){
								m2 = validatePeriodoIndividual(vs, today, servicioDTO, recordUI,"2");
							}
							
							if(hab1 && hab2){//ambos periodos habilitados
								if(m1!=null && m2!=null){
									m=m1+" - "+m2;
									r=false;
								}
							}else if (hab1){//uno de los periodos habilitados
								if(m1!=null){
									m = m1;
									r = false;
								}
							}else if (hab2){//uno de los periodos habilitados
								if(m2!=null){
									m = m2;
									r = false;
								}
							}//si no hay periodos habilitados no hace nada
							
						} 
//						  else {
//							m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios1", new String[] { servicioDTO.getDescripcion() });
//							r = false;
//						}
					}
				}
				if (!r) {
					break;
				}

			}

			return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);

		} catch (ParseException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}

	/**
	 * @param vs
	 * @param m
	 * @param today
	 * @param servicioDTO
	 * @param recordUI
	 * @return
	 * @throws ParseException
	 */
	private String validatePeriodoIndividual(VehiculoServicio vs, Date today, ServicioDTO servicioDTO,
			NormativaRecordUI recordUI,String indexPeriodo) throws ParseException {
		String m=null;
		boolean mr = Boolean.valueOf(recordUI.getItemsMap().get("mismo_responsable"+indexPeriodo).getValue());
		if (!mr || (mr && servicioDTO.getIdResponsableServicio().equals(vs.getServicio().getResponsable().getId()))) {
			String tv = recordUI.getItemsMap().get("tipo_vigencia"+indexPeriodo).getValue();
			if ("tipoVigencia.rangoEspecifico".equals(tv)
					&& ValidacionHelper.esFechaMayorIgual(today, Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_desde"+indexPeriodo).getValue()))
					&& ValidacionHelper.esFechaMenorIgual(today, Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_hasta"+indexPeriodo).getValue()))) {
				// r=true;
			} else if ("tipoVigencia.anual".equals(tv)) {
				Calendar desde = new GregorianCalendar();
				desde.setTime(Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_desde"+indexPeriodo).getValue()));
				Calendar hasta = new GregorianCalendar();
				hasta.setTime(Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_hasta"+indexPeriodo).getValue()));
				Calendar todaycal = new GregorianCalendar();
				todaycal.setTime(today);
				desde.set(Calendar.YEAR, todaycal.get(Calendar.YEAR));
				hasta.set(Calendar.YEAR, todaycal.get(Calendar.YEAR));
				if (hasta.before(desde)) {
					if (hasta.before(todaycal)) {
						hasta.set(Calendar.YEAR, todaycal.get(Calendar.YEAR)+ 1);
					} else {
						desde.set(Calendar.YEAR, todaycal.get(Calendar.YEAR)- 1);
					}
				}
				if (ValidacionHelper.esFechaMayorIgual(today, desde.getTime()) && ValidacionHelper.esFechaMenorIgual(today, hasta.getTime())) {
					//
				} else {
					m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios3", new String[] { servicioDTO.getDescripcion() });
//										r = false;
				}
			} else {
				m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios3", new String[] { servicioDTO.getDescripcion() });
//									r = false;
			}
		} else {
			m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios2", new String[] { servicioDTO.getDescripcion() });
//								r = false;
		}
		return m;
	}
	
	private int getDias(Date fInicial, Date fFinal){
        Calendar ci = Calendar.getInstance();
        ci.setTime(fInicial);

        Calendar cf = Calendar.getInstance();
        cf.setTime(fFinal);

        long ntime = cf.getTimeInMillis() - ci.getTimeInMillis();

        return (int)Math.ceil((double)ntime / 1000 / 3600 / 24);
    }
	
//	private RntEventResultItem validateByPeriodos(Servicio servicio, PeriodoVigencia nuevoPeriodoVigencia) {
//		try {
//			Date today = new Date();
//			List<PeriodoVigencia> periodos = new ArrayList<PeriodoVigencia>(servicio.getPeriodosVigencia());
//			periodos.add(nuevoPeriodoVigencia);
//			
//			Integer cantDiasTotales = 0;
//			for (PeriodoVigencia periodoVigencia : periodos) {
//				boolean r = true;
//				String m = null;
//				//Voy acumulando los dias
//				cantDiasTotales += getDias(periodoVigencia.getFechaDesde(),periodoVigencia.getFechaHasta());
//				//verifico los limites desde-hasta
//				for (NormativaRecordUI recordUI : recordGroup) {
//					if (recordUI.getItemsMap().get("tipo_servicio").getValue().equals(String.valueOf(servicio.getTipoServicio().getId()))) {
//						String m1 = null;
//						boolean hab1 = Boolean.valueOf(recordUI.getItemsMap().get("habilitado1").getValue());
//						if(hab1){
//							m1 = validatePeriodoPorCambioPeriodo(today, periodoVigencia, recordUI, "1");
//						}
//						String m2 = null;
//						boolean hab2 = Boolean.valueOf(recordUI.getItemsMap().get("habilitado2").getValue());
//						if(hab2){
//							m2 = validatePeriodoPorCambioPeriodo(today, periodoVigencia, recordUI, "2");
//						}
//						
//						if(hab1 && hab2){//ambos periodos habilitados
//							if(m1!=null && m2!=null){
//								m=m1+" - "+m2;
//								r=false;
//							}
//						}else if (hab1){//uno de los periodos habilitados
//							if(m1!=null){
//								m = m1;
//								r = false;
//							}
//						}else if (hab2){//uno de los periodos habilitados
//							if(m2!=null){
//								m = m2;
//								r = false;
//							}
//						}//si no hay periodos habilitados no hace nada
//
//					}
//					if(!r){
//						return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) || r, this, m);
//					}
//				}
//			}
//			
//			if(cantidadDeDiasCorridos!=null && cantDiasTotales > cantidadDeDiasCorridos ){
//				return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()) , this, 
//						Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios5", new String[] {String.valueOf(cantidadDeDiasCorridos)})
//					);
//			}
//				
//			return new RntEventResultItem(true, this, null);
//
//		} catch (ParseException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		}
//		return null;
//	}

	/**
	 * @param today
	 * @param periodoVigencia
	 * @param m
	 * @param recordUI
	 * @return
	 * @throws ParseException
	 */
	private String validatePeriodoPorCambioPeriodo(Date today, PeriodoVigencia periodoVigencia, 
			NormativaRecordUI recordUI, String indexPeriodo) throws ParseException {
		String m=null;
		String nombrePer = recordUI.getItemsMap().get("nombre_periodo"+indexPeriodo).getValue();
		if (nombrePer.equals(periodoVigencia.getNombrePeriodo())){
			String tv = recordUI.getItemsMap().get("tipo_vigencia"+indexPeriodo).getValue();
			Calendar desde = new GregorianCalendar();
			desde.setTime(Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_desde"+indexPeriodo).getValue()));
			Calendar hasta = new GregorianCalendar();
			hasta.setTime(Constants.dateFormat.parse(recordUI.getItemsMap().get("vigencia_hasta"+indexPeriodo).getValue()));
			if ("tipoVigencia.rangoEspecifico".equals(tv) && !ValidacionHelper.rangoFechasIncluded(periodoVigencia.getFechaDesde(), periodoVigencia.getFechaHasta(), desde.getTime(), hasta.getTime())){
				m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios4", 
						new String[] { nombrePer,Constants.dateFormat.format(periodoVigencia.getFechaDesde()),Constants.dateFormat.format(periodoVigencia.getFechaHasta()),Constants.dateFormat.format(desde.getTime()),Constants.dateFormat.format(hasta.getTime()) });
//								r = false;
			} else if ("tipoVigencia.anual".equals(tv)){
				Calendar desdePer = new GregorianCalendar();
				desdePer.setTime(periodoVigencia.getFechaDesde());
				Calendar hastaPer = new GregorianCalendar();
				hastaPer.setTime(periodoVigencia.getFechaHasta());
				Calendar todaycal = new GregorianCalendar();
				todaycal.setTime(today);
				desdePer.set(Calendar.YEAR, todaycal.get(Calendar.YEAR));
				hastaPer.set(Calendar.YEAR, todaycal.get(Calendar.YEAR));
				if (hastaPer.before(desdePer)) {
					hastaPer.set(Calendar.YEAR, todaycal.get(Calendar.YEAR)+ 1);
				}
				if (hasta.before(desde)) {
					hasta.set(Calendar.YEAR, todaycal.get(Calendar.YEAR)+ 1);
				}
				if (!ValidacionHelper.rangoFechasIncluded(periodoVigencia.getFechaDesde(), periodoVigencia.getFechaHasta(), desde.getTime(), hasta.getTime())){
					m = Resources.getString("validation.message.event.tiposVehiculoPermitidosOtrosServicios4", 
							new String[] { nombrePer,Constants.dayMonthFormat.format(periodoVigencia.getFechaDesde()),Constants.dayMonthFormat.format(periodoVigencia.getFechaHasta()),Constants.dayMonthFormat.format(desde.getTime()),Constants.dayMonthFormat.format(hasta.getTime()) });
//									r = false;
				}
			}
		}
		return m;
	}

	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		allTiposServicioMap = new HashMap<Long, TipoServicio>();
		
		List<TipoServicio> allTiposServicio = normativa.getReglamentacion().getTiposServicio();//reglamentacionManager.getTipoServicioManager().getTiposServicio();
		for (TipoServicio ts : allTiposServicio) {
			allTiposServicioMap.put(ts.getId(), ts);
		}
//		selectedTiposServicio = new ArrayList<TipoServicio>();
		Map<Long, TipoServicio> tiposServicioExistentesMap=new HashMap<Long, TipoServicio>();
		
		this.normativa = normativa;
		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "periodos_tipos_servicio");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);


			TipoServicio tipoServicio = allTiposServicioMap.get(Long.parseLong(recordUI.getItemsMap().get("tipo_servicio").getValue()));
			tiposServicioExistentesMap.put(tipoServicio.getId(), tipoServicio);
			String tsString = tipoServicio.getName();
			
			recordUI.getItemsMap().get("tipo_servicio").setTextualValue(tsString);
			recordUI.getItemsMap().get("tipo_vigencia1").setTextualValue(PropertiesManager.getProperty(recordUI.getItemsMap().get("tipo_vigencia1").getValue()));

			if (!"tipoVigencia.rangoEspecifico".equals(recordUI.getItemsMap().get("tipo_vigencia1").getValue())) {
				try {
					recordUI.getItemsMap().get("vigencia_desde1")
							.setTextualValue(Constants.dayMonthFormat.format(Constants.dateFormat.parseObject(recordUI.getItemsMap().get("vigencia_desde1").getValue())));
					recordUI.getItemsMap().get("vigencia_hasta1")
							.setTextualValue(Constants.dayMonthFormat.format(Constants.dateFormat.parseObject(recordUI.getItemsMap().get("vigencia_hasta1").getValue())));
				} catch (ParseException e) {
					
				}
			}
			
			recordUI.getItemsMap().get("tipo_vigencia2").setTextualValue(PropertiesManager.getProperty(recordUI.getItemsMap().get("tipo_vigencia2").getValue()));

			if (!"tipoVigencia.rangoEspecifico".equals(recordUI.getItemsMap().get("tipo_vigencia2").getValue())) {
				try {
					recordUI.getItemsMap().get("vigencia_desde2")
							.setTextualValue(Constants.dayMonthFormat.format(Constants.dateFormat.parseObject(recordUI.getItemsMap().get("vigencia_desde2").getValue())));
					recordUI.getItemsMap().get("vigencia_hasta2")
							.setTextualValue(Constants.dayMonthFormat.format(Constants.dateFormat.parseObject(recordUI.getItemsMap().get("vigencia_hasta2").getValue())));
				} catch (ParseException e) {
					
				}
			}
			
			recordGroup.add(recordUI);
		}
		
		for (TipoServicio ts : allTiposServicio) {
			if(!tiposServicioExistentesMap.containsKey(ts.getId())){
				Map<String, NormativaItem> itemsMap= new HashMap<String, NormativaItem>();
				NormativaItem value = new NormativaItem("tipo_servicio",String.valueOf(ts.getId()));
				value.setTextualValue(ts.getName());
				itemsMap.put("tipo_servicio", value);
				NormativaRecordUI rg = new NormativaRecordUI(itemsMap, "tipo_servicio", normativa);
				rg.setAction(GenericModelObject.ACTION_SAVE);
				recordGroup.add(rg);
			}
		}

		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "no_permite_mas_de_un_vigente");
		if (ems != null && ems.size() > 0) {
			noPermiteIngresoEnOtroServicioRegistro = ems.get(0);
			noPermiteIngresoEnOtroServicio = Boolean.parseBoolean(getNormativaItemByKey(noPermiteIngresoEnOtroServicioRegistro.getItems(),KEY_NO_PERMITE_MAS_DE_UN_VIGENTE).getValue());
//			if (noPermiteIngresoEnOtroServicioRegistro.getItems().size()>1){
//			    String valueCantDCorr = getNormativaItemByKey(noPermiteIngresoEnOtroServicioRegistro.getItems(),KEY_CANTIDAD_DIAS_CORRIDOS).getValue();
//				cantidadDeDiasCorridos = (valueCantDCorr==null || valueCantDCorr.equals("null"))?null:(Integer.parseInt(valueCantDCorr));
//			}else{
//				NormativaItem cdc = new NormativaItem("cantidad_dias_corridos", (String)null);
//				cdc.setRegistro(noPermiteIngresoEnOtroServicioRegistro);
//				noPermiteIngresoEnOtroServicioRegistro.getItems().add(cdc);
//			}
		} else {
			noPermiteIngresoEnOtroServicioRegistro = new NormativaRegistro();
			noPermiteIngresoEnOtroServicioRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			noPermiteIngresoEnOtroServicioRegistro.setDescriptor("no_permite_mas_de_un_vigente");
			noPermiteIngresoEnOtroServicioRegistro.setItems(new ArrayList<NormativaItem>());
			NormativaItem ni = new NormativaItem("no_permite_mas_de_un_vigente", noPermiteIngresoEnOtroServicio.toString());
			ni.setRegistro(noPermiteIngresoEnOtroServicioRegistro);
			noPermiteIngresoEnOtroServicioRegistro.getItems().add(ni);
//			NormativaItem cdc = new NormativaItem("cantidad_dias_corridos", String.valueOf(cantidadDeDiasCorridos));
//			cdc.setRegistro(noPermiteIngresoEnOtroServicioRegistro);
//			noPermiteIngresoEnOtroServicioRegistro.getItems().add(cdc);
		}
//		tipoVigencia = "tipoVigencia.rangoEspecifico";
//		nombrePeriodo=null;
		updateNormativa();
	}

	private boolean validatePeriodo(PeriodoNormativa periodo) {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if(!periodo.getHabilitado()){
			return true;
		}
		if (periodo.getTipoVigencia() == null || periodo.getTipoVigencia().isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tipoVigencia") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (periodo.getNombrePeriodo() == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.nombrePeriodo") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (periodo.getDesde() == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaDesde") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (periodo.getHasta() == null) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaHasta") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if ("tipoVigencia.rangoEspecifico".equals(periodo.getTipoVigencia()) && periodo.getDesde() != null && periodo.getHasta() != null && periodo.getDesde().after(periodo.getHasta())) {
			messageBean.addMessage(
					Resources.getString("validation.message.orderedDates",
							new String[] { Resources.getString("reglamentacion.normativa.field.vigenciaDesde"), Resources.getString("reglamentacion.normativa.field.vigenciaHasta") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
//		if (selectedTiposServicio.isEmpty()) {
//			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tiposServicio") }),
//					FacesMessage.SEVERITY_ERROR);
//			valid = false;
//		}
		
		valid = validatePeriodo(periodo1) && validatePeriodo(periodo2);
		
		if (cantidadDeDiasCorridos == null) {
			messageBean
					.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.tipoVigencia") }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}else if(valid){
			int total = cantidadDeDiasCorridos;
			if(periodo1.getHabilitado()){
				total -= periodo1.getCantidadDias();
			}
			if(periodo2.getHabilitado()){
				total -= periodo2.getCantidadDias();
			}
			if(total <0){
				messageBean.addMessage(Resources.getString("validation.message.normativa.cantidadDias.corridos"), FacesMessage.SEVERITY_ERROR);
				valid = false;	
			}
		}
	

		return valid;
	}

	public void prepareEditItem(NormativaRecordUI recordUI){
		this.itemSeleccionado = recordUI;
		String tiposServicioId = this.itemSeleccionado.getItemsMap().get("tipo_servicio").getValue();
		tiposServicio = allTiposServicioMap.get(Long.parseLong(tiposServicioId));
		if(this.itemSeleccionado.getItemsMap().get("cantidad_dias_corridos")!=null){
			cantidadDeDiasCorridos = Integer.parseInt(this.itemSeleccionado.getItemsMap().get("cantidad_dias_corridos").getValue());
		}
		
		periodo1=new PeriodoNormativa();
		try {
			periodo1.setHabilitado(Boolean.valueOf(this.itemSeleccionado.getItemsMap().get("habilitado1").getValue()));
			periodo1.setDesde(Constants.dateFormat.parse(this.itemSeleccionado.getItemsMap().get("vigencia_desde1").getValue()));
			periodo1.setHasta(Constants.dateFormat.parse(this.itemSeleccionado.getItemsMap().get("vigencia_hasta1").getValue()));
			periodo1.setMismoResponsable(Boolean.valueOf(this.itemSeleccionado.getItemsMap().get("mismo_responsable1").getValue()));
			periodo1.setNombrePeriodo(this.itemSeleccionado.getItemsMap().get("nombre_periodo1").getValue());
			periodo1.setTipoVigencia(recordUI.getItemsMap().get("tipo_vigencia1").getValue());
		} catch (ParseException e) {
		} catch (Exception e) {
		}
		
		periodo2=new PeriodoNormativa();
		try{
			periodo2.setHabilitado(Boolean.valueOf(this.itemSeleccionado.getItemsMap().get("habilitado2").getValue()));
			periodo2.setDesde(Constants.dateFormat.parse(this.itemSeleccionado.getItemsMap().get("vigencia_desde2").getValue()));
			periodo2.setHasta(Constants.dateFormat.parse(this.itemSeleccionado.getItemsMap().get("vigencia_hasta2").getValue()));
			periodo2.setMismoResponsable(Boolean.valueOf(this.itemSeleccionado.getItemsMap().get("mismo_responsable2").getValue()));
			periodo2.setNombrePeriodo(this.itemSeleccionado.getItemsMap().get("nombre_periodo2").getValue());
			periodo2.setTipoVigencia(this.itemSeleccionado.getItemsMap().get("tipo_vigencia2").getValue());
		} catch (ParseException e) {
		} catch (Exception e) {
		}
	
		
	}
	
	public void modifyItem() {
		if (!validateAddItem()) {
			return;
		}

		// Carga de datos
		
	//	recordItem.put("tipos_servicio", new NormativaItem("tipos_servicio", ts, tsString.substring(0, tsString.lastIndexOf(","))));
		this.itemSeleccionado.getItemsMap().put("cantidad_dias_corridos",new NormativaItem("cantidad_dias_corridos",String.valueOf(cantidadDeDiasCorridos)));
		
		cargarDatosPeriodo(periodo1,"1");
		cargarDatosPeriodo(periodo2,"2");
		
		
		// fin carga de datos
		if(this.itemSeleccionado.getAction() != GenericModelObject.ACTION_SAVE){
			this.itemSeleccionado.setAction(GenericModelObject.ACTION_UPDATE);
		}
		
		// reseteo los datos
		tiposServicio = null;
		periodo1 = new PeriodoNormativa();
		periodo2 = new PeriodoNormativa();
		cantidadDeDiasCorridos = null;

		updateNormativa();
	}

	public void cancelModifyItem(){
		this.itemSeleccionado = null;
		tiposServicio = null;
		periodo1 = new PeriodoNormativa();
		periodo2 = new PeriodoNormativa();
		cantidadDeDiasCorridos = null;
	}
	
	/**
	 * 
	 */
	private void cargarDatosPeriodo(PeriodoNormativa periodo,String index) {
		this.itemSeleccionado.getItemsMap().put("habilitado"+index,new NormativaItem("habilitado"+index,String.valueOf(periodo.getHabilitado())));
		if(periodo.getHabilitado()){
			this.itemSeleccionado.getItemsMap().put("tipo_vigencia"+index,new NormativaItem("tipo_vigencia"+index,periodo.getTipoVigencia(), PropertiesManager.getProperty(periodo.getTipoVigencia())));
			if ("tipoVigencia.rangoEspecifico".equals(periodo.getTipoVigencia())) {
				this.itemSeleccionado.getItemsMap().put("vigencia_desde"+index, new NormativaItem("vigencia_desde"+index, (periodo.getDesde() != null) ? Constants.dateFormat.format(periodo.getDesde()) : null));
				this.itemSeleccionado.getItemsMap().put("vigencia_hasta"+index, new NormativaItem("vigencia_hasta"+index, (periodo.getHasta() != null) ? Constants.dateFormat.format(periodo.getHasta()) : null));
			} else {
				this.itemSeleccionado.getItemsMap().put("vigencia_desde"+index, new NormativaItem("vigencia_desde"+index, (periodo.getDesde() != null) ? Constants.dateFormat.format(periodo.getDesde()) : null, (periodo.getDesde() != null) ? Constants.dayMonthFormat.format(periodo.getDesde())
						: null));
				this.itemSeleccionado.getItemsMap().put("vigencia_hasta"+index, new NormativaItem("vigencia_hasta"+index, (periodo.getHasta() != null) ? Constants.dateFormat.format(periodo.getHasta()) : null, (periodo.getHasta() != null) ? Constants.dayMonthFormat.format(periodo.getHasta())
						: null));
			}
			this.itemSeleccionado.getItemsMap().put("mismo_responsable"+index, new NormativaItem("mismo_responsable"+index, String.valueOf(periodo.getMismoResponsable())));
			this.itemSeleccionado.getItemsMap().put("nombre_periodo"+index, new NormativaItem("nombre_periodo"+index, periodo.getNombrePeriodo()));
			this.itemSeleccionado.getItemsMap().put("numero_dias"+index, new NormativaItem("numero_dias"+index, String.valueOf(periodo.getCantidadDias())));
		}
	}

	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		noPermiteIngresoEnOtroServicioRegistro.setNormativa(normativa);
		getNormativaItemByKey(noPermiteIngresoEnOtroServicioRegistro.getItems(), KEY_NO_PERMITE_MAS_DE_UN_VIGENTE).setValues(Arrays.asList(new String[] { noPermiteIngresoEnOtroServicio.toString() }));
		
//		getNormativaItemByKey(noPermiteIngresoEnOtroServicioRegistro.getItems(), KEY_CANTIDAD_DIAS_CORRIDOS).setValues(Arrays.asList(new String[] { String.valueOf(cantidadDeDiasCorridos) }));
		
		normativa.getRegistros().add(noPermiteIngresoEnOtroServicioRegistro);
		if (recordGroup != null) {
			for (NormativaRecordUI mapItem : recordGroup) {
				NormativaRegistro registro = mapItem.getRegistro();
				registro.setNormativa(normativa);
				normativa.getRegistros().add(registro);
			}
		}
	}

//	public void removeItem(Integer index) {
//		NormativaRecordUI elem = recordGroup.get(index);
//		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
//			elem.setAction(GenericModelObject.ACTION_DELETE);
//		} else {
//			recordGroup.remove(index.intValue());
//		}
//		updateNormativa();
//	}
//
//	public void undoRemoveItem(Integer index) {
//		NormativaRecordUI elem = recordGroup.get(index);
//		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
//			elem.setAction(GenericModelObject.ACTION_NOACTION);
//		}
//		updateNormativa();
//	}

	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}

	

	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (!normativa.getValidacion().equals("validacion.especificada") && 
				(!this.getNormativa().getReglamentacion().getEspecificadaSobreExistente())) {
			messageBean.addMessage(Resources.getString("validation.message.debeimplementarvehiculosPermOtros"), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (!this.noPermiteIngresoEnOtroServicio.booleanValue()) {
			int count = 0;
			for (NormativaRecordUI rg : recordGroup) {
				if (rg.getAction() != GenericModelObject.ACTION_DELETE)
					count++;
			}
			if (normativa.getValidacion().equals("validacion.especificada") && (recordGroup == null || count == 0)) {
				messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
				valid = false;
			}
		}
		return valid;
	}

	/**
	 * @return el valor de noPermiteIngresoEnOtroServicio
	 */
	public Boolean getNoPermiteIngresoEnOtroServicio() {
		return noPermiteIngresoEnOtroServicio;
	}

	/**
	 * @param setea el parametro noPermiteIngresoEnOtroServicio al campo noPermiteIngresoEnOtroServicio
	 */
	public void setNoPermiteIngresoEnOtroServicio(Boolean noPermiteIngresoEnOtroServicio) {
		this.noPermiteIngresoEnOtroServicio = noPermiteIngresoEnOtroServicio;
	}

	public Integer getCantidadDeDiasCorridos() {
		return cantidadDeDiasCorridos;
	}

	public void setCantidadDeDiasCorridos(Integer cantidadDeDiasCorridos) {
		this.cantidadDeDiasCorridos = cantidadDeDiasCorridos;
	}

	

	public List<ItemPeriodoNormativa> getItemsPeriodoNormativa() {
		if(!noPermiteIngresoEnOtroServicio){
			for (NormativaRecordUI recordUI : recordGroup) {
//				if (recordUI.getItemsMap().get("tipo_servicio").getValue().equals(String.valueOf(tipoServicio.getId()))) {
//					List<ItemPeriodoNormativa> items = new ArrayList<ItemPeriodoNormativa>();
//
//					String nombre1 = recordUI.getItemsMap().get("nombre_periodo1").getValue();
//					String tipo1 = recordUI.getItemsMap().get("tipo_vigencia1").getValue();
//					items.add(new ItemPeriodoNormativa(nombre1, tipo1));
//					
//					String nombre2 = recordUI.getItemsMap().get("nombre_periodo2").getValue();
//					String tipo2 = recordUI.getItemsMap().get("tipo_vigencia2").getValue();
//					items.add(new ItemPeriodoNormativa(nombre2, tipo2));
//					
//					return items;
//				}
			}
		}
		
		return new ArrayList<ItemPeriodoNormativa>();
	}

	/**
	 * @return el valor de tiposServicio
	 */
	public TipoServicio getTiposServicio() {
		return tiposServicio;
	}

	/**
	 * @param setea el parametro tiposServicio al campo tiposServicio
	 */
	public void setTiposServicio(TipoServicio tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	/**
	 * @return el valor de periodo1
	 */
	public PeriodoNormativa getPeriodo1() {
		return periodo1;
	}

	/**
	 * @param setea el parametro periodo1 al campo periodo1
	 */
	public void setPeriodo1(PeriodoNormativa periodo1) {
		this.periodo1 = periodo1;
	}

	/**
	 * @return el valor de periodo2
	 */
	public PeriodoNormativa getPeriodo2() {
		return periodo2;
	}

	/**
	 * @param setea el parametro periodo2 al campo periodo2
	 */
	public void setPeriodo2(PeriodoNormativa periodo2) {
		this.periodo2 = periodo2;
	}

}
