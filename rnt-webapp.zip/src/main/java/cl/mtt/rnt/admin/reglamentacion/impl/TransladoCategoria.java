package cl.mtt.rnt.admin.reglamentacion.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.application.FacesMessage;

import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.NormativaConGlosa;
import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReemplazoTrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.SeleccionMotivoCancelacionEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.TrasladoVehiculoEvent;
import cl.mtt.rnt.admin.reglamentacion.util.NormativaRecordUI;
import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.bean.MessageBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.Resources;

public class TransladoCategoria extends NormativaConGlosa {

	public TransladoCategoria(Normativa normativa) {
		super(normativa);
		// TODO Auto-generated constructor stub
	}

	private List<NormativaRecordUI> recordGroup;

	private List<CategoriaTransporteSeleccionble> categoriasOrigen;
	private List<CategoriaTransporteSeleccionble> categoriasDestino;
	private Map<String, CategoriaTransporteSeleccionble> allCategoriasMap;
	private List<CategoriaTransporteSeleccionble> selectedCategoriasOrigen;
	private List<CategoriaTransporteSeleccionble> selectedCategoriasDestino;

//	private List<Modalidad> modalidadOrigen;
//	private List<Modalidad> modalidadDestino;
//	private Map<Long, Modalidad> allModalidadMap;
//	private List<Modalidad> selectedModalidadOrigen;
//	private List<Modalidad> selectedModalidadDestino;
	private NormativaRegistro normativaRegistro;
	
	private CurrentSessionBean currentSessionBean;  
	
	@Override
	public RntEventResultItem validate(GenericEvent event) {

		if (event instanceof SeleccionMotivoCancelacionEvent){
			return validateSeleccionMotivoCancelacion(event);
		}


		// TransladoVehiculoEvent e = (TransladoVehiculoEvent)event;
		// VehiculoServicio vehiculoServicioNuevo =
		// e.getVehiculoServicioNuevo();
		// VehiculoServicio vehiculoServicioAnterior =
		// e.getVehiculoServicioAnterior();
		VehiculoServicio vehiculoServicioNuevo = null;
		VehiculoServicio vehiculoServicioAnterior = null;
		if (event instanceof TrasladoVehiculoEvent) {
			TrasladoVehiculoEvent e = (TrasladoVehiculoEvent) event;
			vehiculoServicioNuevo = e.getVehiculoServicioNuevo();
			vehiculoServicioAnterior = e.getVehiculoServicioAnterior();
		} else if (event instanceof ReemplazoTrasladoVehiculoEvent) {
			ReemplazoTrasladoVehiculoEvent e = (ReemplazoTrasladoVehiculoEvent) event;
			vehiculoServicioNuevo = e.getVehiculoServicioEntrante();
			vehiculoServicioAnterior = e.getVehiculoServicioAnterior();
		}

		if (ninguna && !vehiculoServicioNuevo.getServicio().getTipoServicio().getNombreCategoriaSeleccionableId().equals(vehiculoServicioAnterior.getServicio().getTipoServicio().getNombreCategoriaSeleccionableId())) {
			if(isPlazoMeses()){
			    Date fechaLimite = getFechaLimiteInicio();
			    Date fechaVehiculo = getFechaVehiculo(vehiculoServicioNuevo);
			    
			    if(fechaVehiculo != null && fechaVehiculo.before(fechaLimite)){
					return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()), this, Resources.getString("validation.message.event.translado.categoria"));	
				}
			    
				return new RntEventResultItem(true, this, null);
			} else  {
				return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()), this, Resources.getString("validation.message.event.translado.categoria"));	
			}
		} else {
			if (ninguna && vehiculoServicioNuevo.getServicio().getTipoServicio().getNombreCategoriaSeleccionableId().equals(vehiculoServicioAnterior.getServicio().getTipoServicio().getNombreCategoriaSeleccionableId())) {
				return new RntEventResultItem(true, this, null);
			} else {
				for (NormativaRecordUI recordUI : recordGroup) {
					// validar modalidades
					if (recordUI.getItemsMap().get("categorias_origen").getValues().contains(String.valueOf(vehiculoServicioAnterior.getServicio().getTipoServicio().getNombreCategoriaSeleccionableId()))
							&& recordUI.getItemsMap().get("categorias_destino").getValues().contains(String.valueOf(vehiculoServicioNuevo.getServicio().getTipoServicio().getNombreCategoriaSeleccionableId()))) {
						return new RntEventResultItem(true, this, null);
					}
				}
			}
		}

		return new RntEventResultItem("tipoNorma.advertencia".equals(getNormativa().getTipoNormativa()), this, Resources.getString("validation.message.event.translado.categoria"));
	}


	
	private CurrentSessionBean getCurrentSessionBean(){
		if(currentSessionBean==null){
			currentSessionBean  = (CurrentSessionBean) ELFacesResolver.getManagedObject("currentSessionBean");
		}
		return currentSessionBean;
	}
	
	@Override
	protected void populatePrivate(ReglamentacionManager reglamentacionManager, Normativa normativa) throws GeneralDataAccessException {
		allCategoriasMap = new HashMap<String, CategoriaTransporteSeleccionble>();
		categoriasOrigen = getCurrentSessionBean().getCategoriasSeleccionables(); 
		
		for (CategoriaTransporteSeleccionble cat : categoriasOrigen) {
			allCategoriasMap.put(cat.getNombreId(), cat);
		}
		selectedCategoriasOrigen = new ArrayList<CategoriaTransporteSeleccionble>();

		categoriasDestino = new ArrayList<CategoriaTransporteSeleccionble>();// En destino van solo los
														// de la reglamentacion
		Set<String> categoriasMap = new HashSet<String>();
		for (TipoServicio ts : normativa.getReglamentacion().getTiposServicio()) {
			if (!categoriasMap.contains(ts.getNombreCategoriaSeleccionableId())) {
				categoriasDestino.add(ts.getNewCategoriaSeleccionable());
				categoriasMap.add(ts.getNombreCategoriaSeleccionableId());
			}
		}
		selectedCategoriasDestino = new ArrayList<CategoriaTransporteSeleccionble>();

		this.normativa = normativa;
		List<NormativaRegistro> ems = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "ninguna");
		if (ems != null && ems.size() > 0) {
			normativaRegistro = ems.get(0);
			Map<String, NormativaItem> itemsAsMap = normativaRegistro.getItemsAsMap();
			ninguna = Boolean.valueOf(itemsAsMap.get("ninguna").getValue());
			addGlosaPopulateValues(normativaRegistro,itemsAsMap);
			normativaRegistro.setDbAction(GenericModelObject.ACTION_UPDATE);
		} else {
			normativaRegistro = new NormativaRegistro();
			normativaRegistro.setDbAction(GenericModelObject.ACTION_SAVE);
			normativaRegistro.setDescriptor("ninguna");
			normativaRegistro.setItems(new ArrayList<NormativaItem>());
//			NormativaItem ni = new NormativaItem("ninguna", String.valueOf(ninguna));
//			ni.setRegistro(normativaRegistro);
//			normativaRegistro.getItems().add(ni);
			addNewNormativaItem(normativaRegistro,"ninguna", String.valueOf(ninguna));
			
			addGlosaNewValues(normativaRegistro);
		}

		recordGroup = new ArrayList<NormativaRecordUI>();
		List<NormativaRegistro> registros = reglamentacionManager.getNormativaRegistrosByNormativaAndDescriptor(normativa.getId(), "modalidad");
		for (NormativaRegistro normativaRegistro : registros) {
			NormativaRecordUI recordUI = new NormativaRecordUI(normativaRegistro);
			String tsString = "";
			for (String key : recordUI.getItemsMap().get("categorias_origen").getValues()) {
				if(allCategoriasMap.get(key)!=null){
					tsString += allCategoriasMap.get(key).getNombre() + ", ";
				}
			}
			recordUI.getItemsMap().get("categorias_origen").setTextualValue(tsString.substring(0, tsString.lastIndexOf(",")));

			tsString = "";
			for (String key : recordUI.getItemsMap().get("categorias_destino").getValues()) {
				if(allCategoriasMap.containsKey(key)){
					tsString += allCategoriasMap.get(key).getNombre() + ", ";
				}
			}
			recordUI.getItemsMap().get("categorias_destino").setTextualValue(tsString.substring(0, tsString.lastIndexOf(",")));

			recordGroup.add(recordUI);
		}
		updateNormativa();
	}

	private boolean validateAddItem() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		if (selectedCategoriasOrigen.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.categoriasOrigen") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		if (selectedCategoriasDestino.isEmpty()) {
			messageBean.addMessage(Resources.getString("validation.message.required", new String[] { Resources.getString("reglamentacion.normativa.field.categoriasDestino") }),
					FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		
		valid = valid && validateGlosas(ninguna,messageBean);

		return valid;
	}

	public void addItem() {
		// List<Map<String, NormativaItem>> recordGroup =
		// recordGroups.get("modalidad");
		if (!validateAddItem()) {
			return;
		}
		if (recordGroup == null)
			recordGroup = new ArrayList<NormativaRecordUI>();

		Map<String, NormativaItem> recordItem = new HashMap<String, NormativaItem>();
		// Carga de datos
		List<String> ts = new ArrayList<String>();
		String tsString = "";
		for (CategoriaTransporteSeleccionble tsa : selectedCategoriasOrigen) {
			ts.add(tsa.getNombreId());
			tsString += tsa.getNombre() + ", ";
		}
		recordItem.put("categorias_origen", new NormativaItem("categorias_origen", ts, tsString.substring(0, tsString.lastIndexOf(","))));

		ts = new ArrayList<String>();
		tsString = "";
		for (CategoriaTransporteSeleccionble tsa : selectedCategoriasDestino) {
			ts.add(tsa.getNombreId());
			tsString += tsa.getNombre() + ", ";
		}
		recordItem.put("categorias_destino", new NormativaItem("categorias_destino", ts, tsString.substring(0, tsString.lastIndexOf(","))));

		// fin carga de datos
		NormativaRecordUI rg = new NormativaRecordUI(recordItem, "modalidad", normativa);
		rg.setAction(GenericModelObject.ACTION_SAVE);
		recordGroup.add(rg);

		// reseteo los datos
		selectedCategoriasOrigen = new ArrayList<CategoriaTransporteSeleccionble>();
		selectedCategoriasDestino = new ArrayList<CategoriaTransporteSeleccionble>();
		updateNormativa();
	}

	protected void updateNormativa() {
		normativa.setRegistros(new ArrayList<NormativaRegistro>());
		normativaRegistro.setNormativa(normativa);
		normativaRegistro.getItemsAsMap().get("ninguna").setValues(Arrays.asList(new String[] { String.valueOf(ninguna) }));
		updateNormativaGlosas(normativaRegistro);

		normativa.getRegistros().add(normativaRegistro);

		if (!ninguna) {
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					NormativaRegistro registro = mapItem.getRegistro();
					registro.setNormativa(normativa);
					normativa.getRegistros().add(registro);
				}
			}
		} else {
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
	}

	public void removeItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() != GenericModelObject.ACTION_SAVE) {
			elem.setAction(GenericModelObject.ACTION_DELETE);
		} else {
			recordGroup.remove(index.intValue());
		}
		updateNormativa();
	}

	public void undoRemoveItem(Integer index) {
		NormativaRecordUI elem = recordGroup.get(index);
		if (elem.getAction() == GenericModelObject.ACTION_DELETE) {
			elem.setAction(GenericModelObject.ACTION_NOACTION);
		}
		updateNormativa();
	}

	public Normativa getNormativaForSaving() {
		if (normativa.getValidacion().equals("validacion.especificada")) {
			updateNormativa();
		} else {
			normativa.setRegistros(new ArrayList<NormativaRegistro>());
			if (recordGroup != null) {
				for (NormativaRecordUI mapItem : recordGroup) {
					if (mapItem.getAction() != GenericModelObject.ACTION_SAVE) {
						NormativaRegistro registro = mapItem.getRegistro();
						registro.setNormativa(normativa);
						registro.setDbAction(GenericModelObject.ACTION_DELETE);
						normativa.getRegistros().add(registro);
					}
				}
			}
		}
		return normativa;
	}

	public List<NormativaRecordUI> getRecordGroup() {
		return recordGroup;
	}

	public void setRecordGroup(List<NormativaRecordUI> recordGroup) {
		this.recordGroup = recordGroup;
	}


	/**
	 * @return el valor de categoriasOrigen
	 */
	public List<CategoriaTransporteSeleccionble> getCategoriasOrigen() {
		return categoriasOrigen;
	}

	/**
	 * @param setea el parametro categoriasOrigen al campo categoriasOrigen
	 */
	public void setCategoriasOrigen(List<CategoriaTransporteSeleccionble> categoriasOrigen) {
		this.categoriasOrigen = categoriasOrigen;
	}

	/**
	 * @return el valor de categoriasDestino
	 */
	public List<CategoriaTransporteSeleccionble> getCategoriasDestino() {
		return categoriasDestino;
	}

	/**
	 * @param setea el parametro categoriasDestino al campo categoriasDestino
	 */
	public void setCategoriasDestino(List<CategoriaTransporteSeleccionble> categoriasDestino) {
		this.categoriasDestino = categoriasDestino;
	}

	/**
	 * @return el valor de selectedCategoriasOrigen
	 */
	public List<CategoriaTransporteSeleccionble> getSelectedCategoriasOrigen() {
		return selectedCategoriasOrigen;
	}

	/**
	 * @param setea el parametro selectedCategoriasOrigen al campo selectedCategoriasOrigen
	 */
	public void setSelectedCategoriasOrigen(List<CategoriaTransporteSeleccionble> selectedCategoriasOrigen) {
		this.selectedCategoriasOrigen = selectedCategoriasOrigen;
	}

	/**
	 * @return el valor de selectedCategoriasDestino
	 */
	public List<CategoriaTransporteSeleccionble> getSelectedCategoriasDestino() {
		return selectedCategoriasDestino;
	}

	/**
	 * @param setea el parametro selectedCategoriasDestino al campo selectedCategoriasDestino
	 */
	public void setSelectedCategoriasDestino(List<CategoriaTransporteSeleccionble> selectedCategoriasDestino) {
		this.selectedCategoriasDestino = selectedCategoriasDestino;
	}


	public boolean validateForSaving() {
		boolean valid = true;
		MessageBean messageBean = (MessageBean) ELFacesResolver.getManagedObject("messageBean");
		int count = 0;
		for (NormativaRecordUI rg : recordGroup) {
			if (rg.getAction() != GenericModelObject.ACTION_DELETE)
				count++;
		}
		if (normativa.getValidacion().equals("validacion.especificada") && !ninguna && (recordGroup == null || count == 0)) {
			messageBean.addMessage(Resources.getString("validation.message.itemsrequired", new String[] { normativa.getLabel() }), FacesMessage.SEVERITY_ERROR);
			valid = false;
		}
		return valid;
	}

}
