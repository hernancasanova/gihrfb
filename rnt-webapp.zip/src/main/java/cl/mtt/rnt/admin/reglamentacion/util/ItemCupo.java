package cl.mtt.rnt.admin.reglamentacion.util;

import java.util.Date;

public class ItemCupo {

	private Long idReglamentacion;
	private String nombreReglamentacion;
	private Date vigenciaDesde;
	private Date vigenciaHasta;
	private Long idTipoServicio;
	private String nombreTipoServicio;
	private String codigoRegion;
	private String nombreRegionZona;
	private Long idZona;
	private Integer valorCupo;
	private Integer cantidadUsada;
	private Integer diferencia;

	public Long getIdReglamentacion() {
		return idReglamentacion;
	}

	public void setIdReglamentacion(Long idReglamentacion) {
		this.idReglamentacion = idReglamentacion;
	}

	public String getNombreReglamentacion() {
		return nombreReglamentacion;
	}

	public void setNombreReglamentacion(String nombreReglamentacion) {
		this.nombreReglamentacion = nombreReglamentacion;
	}

	public Date getVigenciaDesde() {
		return vigenciaDesde;
	}

	public void setVigenciaDesde(Date vigenciaDesde) {
		this.vigenciaDesde = vigenciaDesde;
	}

	public Date getVigenciaHasta() {
		return vigenciaHasta;
	}

	public void setVigenciaHasta(Date vigenciaHasta) {
		this.vigenciaHasta = vigenciaHasta;
	}

	public Long getIdTipoServicio() {
		return idTipoServicio;
	}

	public void setIdTipoServicio(Long idTipoServicio) {
		this.idTipoServicio = idTipoServicio;
	}

	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	public Long getIdZona() {
		return idZona;
	}

	public void setIdZona(Long idZona) {
		this.idZona = idZona;
	}

	public Integer getValorCupo() {
		return valorCupo;
	}

	public void setValorCupo(Integer valorCupo) {
		this.valorCupo = valorCupo;
	}

	public Integer getCantidadUsada() {
		return cantidadUsada;
	}

	public void setCantidadUsada(Integer cantidadUsada) {
		this.cantidadUsada = cantidadUsada;
	}

	public Integer getDiferencia() {
		return diferencia;
	}

	public void setDiferencia(Integer diferencia) {
		this.diferencia = diferencia;
	}

	public String getNombreTipoServicio() {
		return nombreTipoServicio;
	}

	public void setNombreTipoServicio(String nombreTipoServicio) {
		this.nombreTipoServicio = nombreTipoServicio;
	}

	public String getNombreRegionZona() {
		return nombreRegionZona;
	}

	public void setNombreRegionZona(String nombreRegionZona) {
		this.nombreRegionZona = nombreRegionZona;
	}

}
