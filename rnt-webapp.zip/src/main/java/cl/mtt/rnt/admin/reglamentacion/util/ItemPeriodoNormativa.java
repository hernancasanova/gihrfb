package cl.mtt.rnt.admin.reglamentacion.util;

public class ItemPeriodoNormativa {

	private String nombrePeriodo;
	private String tipoVigencia;
	
	public ItemPeriodoNormativa(){
		super();
	}
	
	public ItemPeriodoNormativa(String nombrePeriodo, String tipoVigencia) {
		super();
		this.nombrePeriodo = nombrePeriodo;
		this.tipoVigencia = tipoVigencia;
	}

	public String getNombrePeriodo() {
		return nombrePeriodo;
	}

	public void setNombrePeriodo(String nombrePeriodo) {
		this.nombrePeriodo = nombrePeriodo;
	}

	public String getTipoVigencia() {
		return tipoVigencia;
	}

	public void setTipoVigencia(String tipoVigencia) {
		this.tipoVigencia = tipoVigencia;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombrePeriodo == null) ? 0 : nombrePeriodo.hashCode());
		result = prime * result + ((tipoVigencia == null) ? 0 : tipoVigencia.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemPeriodoNormativa other = (ItemPeriodoNormativa) obj;
		if (nombrePeriodo == null) {
			if (other.nombrePeriodo != null)
				return false;
		} else if (!nombrePeriodo.equals(other.nombrePeriodo))
			return false;
		if (tipoVigencia == null) {
			if (other.tipoVigencia != null)
				return false;
		} else if (!tipoVigencia.equals(other.tipoVigencia))
			return false;
		return true;
	}
	
	
	
}
