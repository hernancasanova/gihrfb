package cl.mtt.rnt.admin.reglamentacion.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;

public class NormativaRecordUI {

	private NormativaRegistro registro;
	private Map<String, NormativaItem> itemsMap;

	public NormativaRecordUI(NormativaRegistro registro) {
		super();
		this.registro = registro;
		this.itemsMap = new HashMap<String, NormativaItem>();
		for (NormativaItem item : registro.getItems()) {
			this.itemsMap.put(item.getKey(), item);
		}
	}

	public NormativaRecordUI(Map<String, NormativaItem> itemsMap, String descriptor, Normativa normativa) {
		super();
		this.itemsMap = itemsMap;
		this.registro = new NormativaRegistro();
		this.registro.setDescriptor(descriptor);
		this.registro.setItems(new ArrayList<NormativaItem>(itemsMap.values()));
		this.registro.setNormativa(normativa);
		List<NormativaItem> items = new ArrayList<NormativaItem>(itemsMap.values());
		for (NormativaItem normativaItem : items) {
			normativaItem.setRegistro(registro);
		}
	}

	public NormativaRegistro getRegistro() {
		return registro;
	}

	public void setRegistro(NormativaRegistro registro) {
		this.registro = registro;
	}

	public Map<String, NormativaItem> getItemsMap() {
		return itemsMap;
	}

	public void setItemsMap(Map<String, NormativaItem> itemsMap) {
		this.itemsMap = itemsMap;
		List<NormativaItem> items = new ArrayList<NormativaItem>(itemsMap.values());
		for (NormativaItem normativaItem : items) {
			normativaItem.setRegistro(registro);
		}
	}

	public int getAction() {
		return registro.getDbAction();
	}

	public void setAction(int action) {
		registro.setDbAction(action);
	}

}
