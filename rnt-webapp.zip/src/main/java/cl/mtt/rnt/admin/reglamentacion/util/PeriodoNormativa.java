package cl.mtt.rnt.admin.reglamentacion.util;

import java.util.Date;

public class PeriodoNormativa {
	
	private final long MILLSECS_PER_DAY = 24 * 60 * 60 * 1000; 
	
	private Boolean habilitado;
	private String tipoVigencia;
	private Date desde;
	private Date hasta;
	private Boolean mismoResponsable;
	private String nombrePeriodo;
	
	/**
	 * @return el valor de tipoVigencia
	 */
	public String getTipoVigencia() {
		return tipoVigencia;
	}
	/**
	 * @param setea el parametro tipoVigencia al campo tipoVigencia
	 */
	public void setTipoVigencia(String tipoVigencia) {
		this.tipoVigencia = tipoVigencia;
	}
	/**
	 * @return el valor de desde
	 */
	public Date getDesde() {
		return desde;
	}
	/**
	 * @param setea el parametro desde al campo desde
	 */
	public void setDesde(Date desde) {
		this.desde = desde;
	}
	/**
	 * @return el valor de hasta
	 */
	public Date getHasta() {
		return hasta;
	}
	/**
	 * @param setea el parametro hasta al campo hasta
	 */
	public void setHasta(Date hasta) {
		this.hasta = hasta;
	}
	/**
	 * @return el valor de mismoResponsable
	 */
	public Boolean getMismoResponsable() {
		return mismoResponsable;
	}
	/**
	 * @param setea el parametro mismoResponsable al campo mismoResponsable
	 */
	public void setMismoResponsable(Boolean mismoResponsable) {
		this.mismoResponsable = mismoResponsable;
	}
	/**
	 * @return el valor de nombrePeriodo
	 */
	public String getNombrePeriodo() {
		return nombrePeriodo;
	}
	/**
	 * @param setea el parametro nombrePeriodo al campo nombrePeriodo
	 */
	public void setNombrePeriodo(String nombrePeriodo) {
		this.nombrePeriodo = nombrePeriodo;
	}
	/**
	 * @return el valor de habilitado
	 */
	public Boolean getHabilitado() {
		return habilitado;
	}
	/**
	 * @param setea el parametro habilitado al campo habilitado
	 */
	public void setHabilitado(Boolean habilitado) {
		this.habilitado = habilitado;
	}
	public int getCantidadDias() {
		if(!"tipoVigencia.rangoEspecifico".equals(tipoVigencia) && desde.after(hasta)){
			Long diff = ( hasta.getTime() + MILLSECS_PER_DAY * 365 - desde.getTime() )/MILLSECS_PER_DAY;
			return diff.intValue();
		}
		Long diff = ( hasta.getTime() - desde.getTime() )/MILLSECS_PER_DAY; 
		return diff.intValue();
	}

	
}
