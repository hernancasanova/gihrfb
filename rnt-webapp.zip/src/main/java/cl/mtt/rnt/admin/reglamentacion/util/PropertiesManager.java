package cl.mtt.rnt.admin.reglamentacion.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.model.comparator.ReglamentacionSelectComparator;

public class PropertiesManager {

	private static Properties properties;

	private static void loadProperties() {
		properties = new Properties();
		try {
			properties.load(PropertiesManager.class.getResourceAsStream("/reglamentacion.properties"));
		} catch (IOException e) {
			Logger.getLogger(PropertiesManager.class).error(e.getLocalizedMessage(), e);
		}
	}

	public static final String getProperty(String key) {
		if (properties == null)
			loadProperties();
		return properties.getProperty(key);
	}

	public static final List<SelectionItem> getProperties(String keyGroup) {
		if (properties == null)
			loadProperties();
		List<SelectionItem> ret = new ArrayList<SelectionItem>();
		Set<Object> keys = properties.keySet();
		for (Object object : keys) {
			String key = (String) object;
			if (key.startsWith(keyGroup + ".")) {
				ret.add(new SelectionItem(key, properties.getProperty(key)));
			}
		}
		Collections.sort(ret,new ReglamentacionSelectComparator());
		return ret;
	}

}