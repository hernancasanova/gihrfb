package cl.mtt.rnt.admin.reglamentacion.util;

public class SelectionItem {

	private String descriptor;
	private String label;
	private boolean checked;

	public SelectionItem() {
		super();
	}

	public SelectionItem(String descriptor, String label) {
		super();
		this.descriptor = descriptor;
		this.label = label;
	}
	
	public SelectionItem(String descriptor,String label, boolean checked){
		super();
		this.descriptor = descriptor;
		this.label = label;
		this.checked = checked;
	}

	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((descriptor == null) ? 0 : descriptor.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SelectionItem other = (SelectionItem) obj;
		if (descriptor == null) {
			if (other.descriptor != null)
				return false;
		} else if (!descriptor.equals(other.descriptor))
			return false;
		return true;
	}

}
