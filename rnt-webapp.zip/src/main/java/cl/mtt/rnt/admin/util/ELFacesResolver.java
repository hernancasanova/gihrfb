package cl.mtt.rnt.admin.util;

import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.util.ElResolver;

public class ELFacesResolver {

	public static Object getManagedObject(String name) {
		try {
			FacesContext context = FacesContext.getCurrentInstance();
			if ((context != null) && (context.getApplication() != null) && context.getExternalContext().getSession(true)!=null) {
				return context.getApplication().evaluateExpressionGet(context, "#{" + name + "}", Object.class);
			} else {
				return null;
			}
		} catch (Exception e) {
			Logger.getLogger(ElResolver.class).error(e.getMessage(), e);
			return null;
		}
	}

}
