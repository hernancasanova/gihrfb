package cl.mtt.rnt.admin.util;

/**
 * 
 * @author Mariano Camarzana - BISion
 * 
 */
public class RedirectConstants {

	public static final String SEL_TABLA_TO_MANT_DICCIONARIO = "mantenedor_diccionario";
	public static final String SEL_TABLA_TO_MANT_TIPODOC = "mantenedor_tipodoc";
	public static final String SEL_TABLA_TO_MANT_TIPOCERTPLANT = "mantenedor_tipoCertPlant";
	public static final String SEL_TABLA_TO_MANT_TIPOTRANSPORTE = "mantenedor_tipoTransporte";
	public static final String SEL_TABLA_TO_MANT_MEDIOTRANSPORTE = "mantenedor_medioTransporte";
	public static final String SEL_TABLA_TO_MANT_MODALIDADTRANSPORTE = "mantenedor_modalidadTransporte";
	public static final String SEL_TABLA_TO_MANT_CATEGORIATRANSPORTE = "mantenedor_categoriaTransporte";
	public static final String SEL_TABLA_TO_MANT_TIPOSERVICIOAREA = "mantenedor_tipoServicioArea";
	public static final String SEL_TABLA_TO_MANT_TERMINAL = "mantenedor_terminal";
	public static final String SEL_TABLA_TO_MANT_ZONA = "mantenedor_zona";
	public static final String SEL_TABLA_TO_MANT_CUPOS = "mantenedor_cupos";
	// Mejoras 201409 Nro: 70
	public static final String SEL_TABLA_TO_MANT_PPU_ANULADA = "mantenedor_ppu_anuladas";
	// Mejoras 201409 Nro: 70
	
	public static final String SEL_TABLA_TO_MANT_DOCUMENTACION = "mantenedor_documentacion";
	
	public static final String SEL_TABLA_TO_MANT_TIPOVEHICULOSERVICIO = "mantenedor_tipoVehiculoServicio";
	public static final String NO_REDIRECT = "";
	public static final String TO_ADMIN_USER_LIST = "admin_user_list";
	public static final String USERLIST_TO_NEW_USER = "admin_user_new";
	public static final String USERLIST_TO_EDIT_USER = "admin_user_edit";
	public static final String TO_ADMIN_USER_LIST_NO_REDIRECT = "admin_user_list_no_redirect";

}
