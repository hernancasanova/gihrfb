package cl.mtt.rnt.commons.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;
import org.richfaces.event.FileUploadEvent;
import org.richfaces.model.UploadedFile;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.InvalidUploadAlfrescoException;
import cl.mtt.rnt.commons.model.core.DocumentoBiblioteca;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.TipoDocumento;
import cl.mtt.rnt.commons.model.view.TipoDocumentoSeleccionable;
import cl.mtt.rnt.commons.service.BibliotecaDigitalManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.ElResolver;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.ws.bibliotecadigital.auth.AuthenticationFault_Exception;
import cl.mtt.rnt.commons.ws.bibliotecadigital.content.GetDocumentObjectResponse;

@ManagedBean
@ViewScoped
public class BibliotecaDigitalBean {

	@ManagedProperty(value = "#{reglamentacionManager}")
	private ReglamentacionManager reglamentacionManager;

	@ManagedProperty(value = "#{bibliotecaDigitalManager}")
	private BibliotecaDigitalManager bibliotecaDigitalManager;

	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	
	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;

	
	private BibliotecaDigitalCriteria criteria = new BibliotecaDigitalCriteria();

	private List<TipoDocumento> tiposDocumento;
	private List<GetDocumentObjectResponse> documentos;
	
	private DocumentoBiblioteca documento;
	
	private String modo = "busqueda";//agregar
	
	private String listenerBeanName;
	private String listenerParam;	
	private String errorCarga;
	private Map<Long,TipoDocumentoSeleccionable> tiposDocumentoSeleccionables;
	
	
	public void setReglamentacionManager(ReglamentacionManager reglamentacionManager) {
		this.reglamentacionManager = reglamentacionManager;
	}

	
	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}


	public String getCodigoRegionCriterio() {
		if(currentSessionBean.getCurrentModule().equals(1)){
			criteria.setCodigoRegionCriterio(currentSessionBean.getUser().getContext().getRegionSeleccionada().getCodigo());
		}
		return criteria.getCodigoRegionCriterio();
	}


	public void setCodigoRegionCriterio(String codigoRegionCriterio) {
		if(currentSessionBean.getCurrentModule().equals(1)){
			criteria.setCodigoRegionCriterio(currentSessionBean.getUser().getContext().getRegionSeleccionada().getCodigo());
		}
		this.criteria.setCodigoRegionCriterio(codigoRegionCriterio);
	}


	public String getNumeroDocumentoCriterio() {
		return criteria.getNumeroDocumentoCriterio();
	}


	public void setNumeroDocumentoCriterio(String numeroDocumentoCriterio) {
		this.criteria.setNumeroDocumentoCriterio(numeroDocumentoCriterio);
	}


	public TipoDocumento getTipoDocumentoCriterio() {
		return criteria.getTipoDocumentoCriterio();
	}


	public void setTipoDocumentoCriterio(TipoDocumento tipoDocumentoCriterio) {
		this.criteria.setTipoDocumentoCriterio(tipoDocumentoCriterio);
	}


	public String getMateriaCriterio() {
		return criteria.getMateriaCriterio();
	}


	public void setMateriaCriterio(String materiaCriterio) {
		this.criteria.setMateriaCriterio(materiaCriterio);
	}


	public Integer getAnioCriterio() {
		return criteria.getAnioCriterio();
	}


	public void setAnioCriterio(Integer anioCriterio) {
		this.criteria.setAnioCriterio(anioCriterio);
	}


	public Date getFechaDesdeCriterio() {
		return criteria.getFechaDesdeCriterio();
	}


	public void setFechaDesdeCriterio(Date fechaDesdeCriterio) {
		this.criteria.setFechaDesdeCriterio(fechaDesdeCriterio);
	}


	public Date getFechaHastaCriterio() {
		return criteria.getFechaHastaCriterio();
	}


	public void setFechaHastaCriterio(Date fechaHastaCriterio) {
		this.criteria.setFechaHastaCriterio(fechaHastaCriterio);
	}

	
	public List<TipoDocumento> getTiposDocumento() {
		if (tiposDocumento == null) {
			try {
				tiposDocumento=new ArrayList<TipoDocumento>();
				tiposDocumentoSeleccionables=new HashMap<Long, TipoDocumentoSeleccionable>();
				
				List<TipoDocumentoSeleccionable> tiposDocumentoSel = reglamentacionManager.getTiposDocumento();
				for (TipoDocumentoSeleccionable td: tiposDocumentoSel) {
					tiposDocumento.add(td.getTipoDocumento());
					tiposDocumentoSeleccionables.put(td.getTipoDocumento().getId(), td);
				}
				
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}catch (Exception e) {
				Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			}
		}
		return tiposDocumento;
	}

	public void setTiposDocumento(List<TipoDocumento> tiposDocumento) {
		this.tiposDocumento = tiposDocumento;
	}


	private void cleanCriterio(){
		criteria.setCodigoRegionCriterio(null);
		if(currentSessionBean.getCurrentModule().equals(1)){
			criteria.setCodigoRegionCriterio(currentSessionBean.getUser().getContext().getRegionSeleccionada().getCodigo());
		}
		criteria.setNumeroDocumentoCriterio(null);
		criteria.setTipoDocumentoCriterio(null);
		criteria.setMateriaCriterio(null);
		
		Calendar c = new GregorianCalendar();
		criteria.setAnioCriterio(c.get(Calendar.YEAR));
		
		criteria.setFechaDesdeCriterio(null);
		criteria.setFechaHastaCriterio(null);
	}
	
	public void prepareBusqueda(){
		cleanCriterio();
		documentos = new ArrayList<GetDocumentObjectResponse>();
		modo = "busqueda";
	}
	
	public void prepareAgregar(){
		documento = new DocumentoBiblioteca();
		if(currentSessionBean.getCurrentModule().equals(1)){
			documento.setCodigoRegion(currentSessionBean.getUser().getContext().getRegionSeleccionada().getCodigo());
		}
		clearListener();
		this.errorCarga = null;
		modo = "agregar";
	}
	
	public void cancelarAgregar(){
		modo = "busqueda";
		clearListener();
		this.errorCarga = null;
	}
	
	public void limpiarFiltro(){
		cleanCriterio();
		documentos = new ArrayList<GetDocumentObjectResponse>();
        modo = "busqueda";
	}

	public void searchDocumentos(){
		try{
			if(criteria.getFechaDesdeCriterio()!=null && criteria.getFechaHastaCriterio()!=null && criteria.getFechaDesdeCriterio().after(criteria.getFechaHastaCriterio())){
				messageBean.addMessage(Resources.getString("exception.filtro.fechaDesdeHastaIncorrecta"), FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().validationFailed();
				return;
			}
			documentos = bibliotecaDigitalManager.findDocumentos(criteria,currentSessionBean.getUser());
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (AuthenticationFault_Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("exception.authenticationFault"), FacesMessage.SEVERITY_ERROR);
		} catch (DatatypeConfigurationException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (InvalidUploadAlfrescoException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}


	public List<GetDocumentObjectResponse> getDocumentos() {
		return documentos;
	}

	public void setDocumentos(List<GetDocumentObjectResponse> documentos) {
		this.documentos = documentos;
	}
		
	
	public DocumentoBiblioteca getDocumento() {
		return documento;
	}


	public void setDocumento(DocumentoBiblioteca documento) {
		this.documento = documento;
	}


	public void setBibliotecaDigitalManager(BibliotecaDigitalManager bibliotecaDigitalManager) {
		this.bibliotecaDigitalManager = bibliotecaDigitalManager;
	}

	/**
	 * Debemos tomar el archivo y dejarlo en el bean!!
	 * @param event
	 * @throws Exception
	 */
	public void uploadListener(FileUploadEvent event) throws Exception {
	   this.currentSessionBean.setUploadedFile(event.getUploadedFile());
	}
	 
	public void clearListener(){
	   this.currentSessionBean.setUploadedFile(null);
	}
	
	
	/***
	 * sleeccionar documento
	 */
	public void selecccionarDocumento(GetDocumentObjectResponse outobject) {
	    
	    try {
    	    
    	    
    	    DocumentoBiblioteca documentoLocal = null;
    	    if (this.criteria !=null) {
    	        if (this.criteria.getCodigoRegionCriterio()!=null) {
    	            documentoLocal = bibliotecaDigitalManager.getDocumentoLocal(outobject.getDocumentTitle(),this.criteria.getCodigoRegionCriterio() , outobject.getDocumentMatter());
    	        }
    	        else {
    	            documentoLocal = bibliotecaDigitalManager.getDocumentoLocal(outobject.getDocumentTitle(),"00" , outobject.getDocumentMatter());
    	        }
            }
    	    else {
    	        documentoLocal = bibliotecaDigitalManager.getDocumentoLocal(outobject.getDocumentTitle(),"00" , outobject.getDocumentMatter());
    	    }
    	    
    	    if (documentoLocal == null) {
    	        documentoLocal = new DocumentoBiblioteca();
    	        
    	        if ((this.criteria !=null)&&(this.criteria.getCodigoRegionCriterio()!=null)) {
    	            documentoLocal.setCodigoRegion(criteria.getCodigoRegionCriterio());
    	        } 
    	        else {
    	            documentoLocal.setCodigoRegion("00");
    	        }
    	        documentoLocal.setNumero(outobject.getFolio());
    	        documentoLocal.setDbAction(GenericModelObject.ACTION_SAVE);
    	        documentoLocal.setFecha(new SimpleDateFormat("yyyy-MM-dd").parse(outobject.getDocumentDate()));
    	        documentoLocal.setLinkDocumento(outobject.getLinkDownlaod());
    	        documentoLocal.setMateria(outobject.getDocumentMatter());
    	        documentoLocal.setNombre(outobject.getDocumentTitle());
    	        for (TipoDocumento td :getTiposDocumento()) {
    	            if (td.getNombre().equalsIgnoreCase(outobject.getDocumentType())) {
    	                documentoLocal.setTipoDocumento(td);
    	            }
    	        }
    	        bibliotecaDigitalManager.registrarDocumentoExistente(documentoLocal);
    	    }
    	    else {
    	        documentoLocal.setDbAction(GenericModelObject.ACTION_NOACTION);
    	    }
    	    
    	    
    	    evalDocumentListener(documentoLocal);
	    } catch (GeneralDataAccessException e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
            messageBean.addMessage(Resources.getString("bibliotecaDocumento.error.save"), FacesMessage.SEVERITY_ERROR);
            FacesContext.getCurrentInstance().validationFailed();
        } catch (Exception e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
            messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
            FacesContext.getCurrentInstance().validationFailed();
        }
	}
	
	/**
	 * Guardamops el archivo completamente
	 */
	public void saveDocumento(){
	    this.errorCarga = null;
		try {
			if (currentSessionBean.getUploadedFile() == null) {
				messageBean.addMessage(Resources.getString("bibliotecaDocumento.message.required"),
						FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().validationFailed();
				return;
			}
			bibliotecaDigitalManager.saveDocumento(documento, currentSessionBean.getUploadedFile(),currentSessionBean.getUser());
			
			evalDocumentListener(documento);
			
			modo = "busqueda";
		} catch (InvalidUploadAlfrescoException ae) {
		    this.errorCarga = Resources.getString("bibliotecaDocumento.error.msg") + " " + ae.getDescription();
			FacesContext.getCurrentInstance().validationFailed();
		} catch (AuthenticationFault_Exception ae) {
		    this.errorCarga = Resources.getString("bibliotecaDocumento.error.auth");
			Logger.getLogger(this.getClass()).error(ae.getMessage(), ae);
			FacesContext.getCurrentInstance().validationFailed();
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.errorCarga = Resources.getString("bibliotecaDocumento.error.save");
			FacesContext.getCurrentInstance().validationFailed();
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			this.errorCarga =  Resources.getString("error.generico");
			FacesContext.getCurrentInstance().validationFailed();
		}
	}


	/**
	 * 
	 */
	private void evalDocumentListener(DocumentoBiblioteca doc) {
		DocumentableBean docBean = (DocumentableBean)ElResolver.getManagedObject(listenerBeanName);
		docBean.addBibliotecaDigitalDocument(doc, listenerParam);
	}


	public UploadedFile getFile() {
		return currentSessionBean.getUploadedFile();
	}


	public void setFile(UploadedFile file) {
		this.currentSessionBean.setUploadedFile(file);
	}


	public String getModo() {
		return modo;
	}


	public void setModo(String modo) {
		this.modo = modo;
	}


	/**
	 * @param setea el parametro currentSessionBean al campo currentSessionBean
	 */
	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}


	/**
	 * @return el valor de listenerBeanName
	 */
	public String getListenerBeanName() {
		return listenerBeanName;
	}


	/**
	 * @param setea el parametro listenerBeanName al campo listenerBeanName
	 */
	public void setListenerBeanName(String listenerBeanName) {
		this.listenerBeanName = listenerBeanName;
	}


	/**
	 * @return el valor de listenerParam
	 */
	public String getListenerParam() {
		return listenerParam;
	}


	/**
	 * @param setea el parametro listenerParam al campo listenerParam
	 */
	public void setListenerParam(String listenerParam) {
		this.listenerParam = listenerParam;
	}


    /**
     * @return el valor de errorCarga
     */
    public String getErrorCarga() {
        return errorCarga;
    }


    /**
     * @param setea el parametro errorCarga al campo errorCarga
     */
    public void setErrorCarga(String errorCarga) {
        this.errorCarga = errorCarga;
    }

    
	/**
	 * @return el valor de materiasSeleccionables
	 */
	public List<String> getMateriasSeleccionables(Long tipoDocId) {
		if(tipoDocId!=null && tiposDocumentoSeleccionables.get(tipoDocId)!=null){
			return tiposDocumentoSeleccionables.get(tipoDocId).getMaterias();
		}
		return null;
	}

	public boolean materiasRequeridas(Long tipoDocId){
		if(tipoDocId!=null && tiposDocumentoSeleccionables.get(tipoDocId)!=null){
			return tiposDocumentoSeleccionables.get(tipoDocId).isMateriaObligatoria();
		}
		return false;
		
	}

	
	public boolean materiasHabilitadas(Long tipoDocId){
		if(tipoDocId!=null && tiposDocumentoSeleccionables.get(tipoDocId)!=null){
			return tiposDocumentoSeleccionables.get(tipoDocId).isMateriaHabilitada();
		}
		return false;
		
	}

	
	
	
	
}
