package cl.mtt.rnt.commons.bean;

import java.util.Date;

import cl.mtt.rnt.commons.model.core.TipoDocumento;

public class BibliotecaDigitalCriteria {
	private String codigoRegionCriterio;
	private String numeroDocumentoCriterio;
	private TipoDocumento tipoDocumentoCriterio;
	private String materiaCriterio;
	private Integer anioCriterio;
	private Date fechaDesdeCriterio;
	private Date fechaHastaCriterio;
	private String nombreDocumento;

	public BibliotecaDigitalCriteria() {
	}

	public String getCodigoRegionCriterio() {
		return codigoRegionCriterio;
	}

	public void setCodigoRegionCriterio(String codigoRegionCriterio) {
		this.codigoRegionCriterio = codigoRegionCriterio;
	}

	public String getNumeroDocumentoCriterio() {
		return numeroDocumentoCriterio;
	}

	public void setNumeroDocumentoCriterio(String numeroDocumentoCriterio) {
		this.numeroDocumentoCriterio = numeroDocumentoCriterio;
	}

	public TipoDocumento getTipoDocumentoCriterio() {
		return tipoDocumentoCriterio;
	}

	public void setTipoDocumentoCriterio(TipoDocumento tipoDocumentoCriterio) {
		this.tipoDocumentoCriterio = tipoDocumentoCriterio;
	}

	public String getMateriaCriterio() {
		return materiaCriterio;
	}

	public void setMateriaCriterio(String materiaCriterio) {
		this.materiaCriterio = materiaCriterio;
	}

	public Integer getAnioCriterio() {
		return anioCriterio;
	}

	public void setAnioCriterio(Integer anioCriterio) {
		this.anioCriterio = anioCriterio;
	}

	public Date getFechaDesdeCriterio() {
		return fechaDesdeCriterio;
	}

	public void setFechaDesdeCriterio(Date fechaDesdeCriterio) {
		this.fechaDesdeCriterio = fechaDesdeCriterio;
	}

	public Date getFechaHastaCriterio() {
		return fechaHastaCriterio;
	}

	public void setFechaHastaCriterio(Date fechaHastaCriterio) {
		this.fechaHastaCriterio = fechaHastaCriterio;
	}

    /**
     * @return el valor de nombreDocumento
     */
    public String getNombreDocumento() {
        return nombreDocumento;
    }

    /**
     * @param setea el parametro nombreDocumento al campo nombreDocumento
     */
    public void setNombreDocumento(String nombreDocumento) {
        this.nombreDocumento = nombreDocumento;
    }
}