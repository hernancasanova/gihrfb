package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Estado;
import cl.mtt.rnt.commons.service.AtributoManager;
import cl.mtt.rnt.commons.service.BibliotecaDigitalManager;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.PersonaManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.ServicioManager;
import cl.mtt.rnt.commons.service.TipoCertificadoManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Constants;

@ManagedBean(eager=true)
@ApplicationScoped
public class ConstantsBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2517935669938144599L;
	private List<Estado> estados;

	@ManagedProperty(value = "#{reglamentacionManager}")
	private ReglamentacionManager reglamentacionManager;

	@ManagedProperty(value = "#{zonaManager}")
    private ZonaManager zonaManager;
	
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
    private UbicacionGeograficaManager ubicacionGeograficaManager;
	
	
	@ManagedProperty(value = "#{tipoServicioManager}")
    private TipoServicioManager tipoServicioManager;
	
	@ManagedProperty(value = "#{atributoManager}")
    private AtributoManager atributoManager;
	
	@ManagedProperty(value = "#{generalDataManager}")
    private GeneralDataManager generalDataManager;

	@ManagedProperty(value = "#{tipoCertificadoManager}")
	TipoCertificadoManager tipoCertificadoManager;
	
	@ManagedProperty(value = "#{bibliotecaDigitalManager}")
	BibliotecaDigitalManager bibliotecaDigitalManager;
	
	@ManagedProperty(value = "#{servicioManager}")
    ServicioManager servicioManager;
	
	@ManagedProperty(value = "#{personaManager}")
	PersonaManager personaManager;
	/**
	 * @param setea el parametro reglamentacionManager al campo reglamentacionManager
	 */
	public void setReglamentacionManager(ReglamentacionManager reglamentacionManager) {
		this.reglamentacionManager = reglamentacionManager;
	}

	public String getDateFormatPattern() {
		return Constants.DATE_FORMAT_PATTERN;
	}

	public String getTimeFormatPattern() {
		return Constants.TIME_FORMAT_PATTERN;
	}

	public String getDateTimeFormatPattern() {
		return Constants.DATETIME_FORMAT_PATTERN;
	}

	public String getDayMonthFormatPattern() {
		return Constants.DAY_MONTH_FORMAT_PATTERN;
	}

	@PostConstruct
	public void init(){
	    try {
	        servicioManager.getAllMotivosModificacionServicio(); //carga los motivos
	        personaManager.getAllCategoriasPersonaJuridica();//carga categorias
	        generalDataManager.fillCache();
	    }
	    catch (GeneralDataAccessException e) {
	        Logger.getLogger(ConstantsBean.class).error(e.getLocalizedMessage(), e);
	    } 
	    ubicacionGeograficaManager.fillCache();
	    zonaManager.fillCache();
	    tipoServicioManager.fillCache();
	    reglamentacionManager.fillCache();
        NormativaAccess.build(reglamentacionManager);
	    generalDataManager.fillCache();
		atributoManager.fillCache();
		tipoCertificadoManager.fillCache();
		bibliotecaDigitalManager.fillCache();
	}
	
	/**
	 * @return the timeZone
	 */
	public TimeZone getTimeZone() {
		return TimeZone.getDefault();
	}

	public List<Estado> getEstadosActInact() {
		if (estados == null) {
			estados = new ArrayList<Estado>();
			estados.add(new Estado(Boolean.TRUE, Constants.ESTADO_ACTIVO));
			estados.add(new Estado(Boolean.FALSE, Constants.ESTADO_INACTIVO));
		}
		return estados;
	}
	
	public String getUbicacionParadero(){
		return Constants.TIPO_UBICACION_DENTRO_DE_PARADERO;
	}
	public String getUbicacionTerminal(){
		return Constants.TIPO_UBICACION_DENTRO_DE_TERMINAL;
	}
	public String getUbicacionDireccion(){
		return Constants.TIPO_UBICACION_DIRECCION;
	}
	public String getUbicacionWeb(){
		return Constants.TIPO_UBICACION_SOLO_WEB;
	}

    /**
     * @param setea el parametro zonaManager al campo zonaManager
     */
    public void setZonaManager(ZonaManager zonaManager) {
        this.zonaManager = zonaManager;
    }

    /**
     * @param setea el parametro ubicacionGeograficaManager al campo ubicacionGeograficaManager
     */
    public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
        this.ubicacionGeograficaManager = ubicacionGeograficaManager;
    }

    /**
     * @param setea el parametro tipoServicioManager al campo tipoServicioManager
     */
    public void setTipoServicioManager(TipoServicioManager tipoServicioManager) {
        this.tipoServicioManager = tipoServicioManager;
    }

    /**
     * @param setea el parametro atributoManager al campo atributoManager
     */
    public void setAtributoManager(AtributoManager atributoManager) {
        this.atributoManager = atributoManager;
    }

    /**
     * @param setea el parametro generalDataManager al campo generalDataManager
     */
    public void setGeneralDataManager(GeneralDataManager generalDataManager) {
        this.generalDataManager = generalDataManager;
    }

    /**
     * @param setea el parametro tipoCertificadoManager al campo tipoCertificadoManager
     */
    public void setTipoCertificadoManager(TipoCertificadoManager tipoCertificadoManager) {
        this.tipoCertificadoManager = tipoCertificadoManager;
    }

    /**
     * @param setea el parametro bibliotecaDigitalManager al campo bibliotecaDigitalManager
     */
    public void setBibliotecaDigitalManager(BibliotecaDigitalManager bibliotecaDigitalManager) {
        this.bibliotecaDigitalManager = bibliotecaDigitalManager;
    }

    /**
     * @param setea el parametro servicioManager al campo servicioManager
     */
    public void setServicioManager(ServicioManager servicioManager) {
        this.servicioManager = servicioManager;
    }

    /**
     * @param setea el parametro personaManager al campo personaManager
     */
    public void setPersonaManager(PersonaManager personaManager) {
        this.personaManager = personaManager;
    }
	
	
}
