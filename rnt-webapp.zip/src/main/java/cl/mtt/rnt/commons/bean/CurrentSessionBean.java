package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import org.apache.log4j.Logger;
import org.richfaces.model.UploadedFile;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.UnaccesibleRedirectionException;
import cl.mtt.rnt.commons.model.comparator.CategoriaTransporteSeleccionbleComparator;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.model.view.UserWrapper;
import cl.mtt.rnt.commons.service.CategoriaTransporteManager;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.CollectionSorter;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.encargado.dto.ServicioDTO;

@ManagedBean
@SessionScoped
public class CurrentSessionBean implements Serializable {
	private static final long serialVersionUID = 2894268886171854372L;

	@ManagedProperty(value = "#{categoriaTransporteManager}")
	private CategoriaTransporteManager categoriaTransporteManager;

	@ManagedProperty(value = "#{generalDataManager}")
	private GeneralDataManager generalDataManager;

	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@ManagedProperty(value = "#{reglamentacionManager}")
	private ReglamentacionManager reglamentacionManager;

	@ManagedProperty(value = "#{zonaManager}")
	private ZonaManager zonaManager;

	@ManagedProperty(value = "#{vehiculoManagerRnt}")
    private VehiculoManagerRnt vehiculoManagerRnt;
	
	@ManagedProperty(value = "#{tipoServicioManager}")
	TipoServicioManager tipoServicioManager;

	private User user;
	private String userName;
	private String userFullName;
	private CategoriaTransporteSeleccionble categoriaSeleccionada;
	private List<CategoriaTransporteSeleccionble> categoriasSeleccionables;

	private HashMap<String, Integer> tablaPaginacion;

	private HashMap<String, CollectionSorter> sorters = new HashMap<String, CollectionSorter>();
	
	private UploadedFile uploadedFile;
        //Mejoras TEL 201907 Nro: 6
        private boolean telHabilitarUsuarioTramiteSel;

   //	private Map<Reglamentacion,NormativasCache> normativasCache=new HashMap<Reglamentacion, NormativasCache>();
	/**
	 * @return el valor de zonaManager
	 */
	public ZonaManager getZonaManager() {
		return zonaManager;
	}

	/**
	 * @param setea
	 *            el parametro zonaManager al campo zonaManager
	 */
	public void setZonaManager(ZonaManager zonaManager) {
		this.zonaManager = zonaManager;
	}

	public CategoriaTransporteSeleccionble getCategoriaSeleccionada() {
		return categoriaSeleccionada;
	}

	public void setCategoriaSeleccionada(CategoriaTransporteSeleccionble cat) {
		this.categoriaSeleccionada = cat;
		if (cat != null) {
			if (user instanceof UserWrapper)
				this.setUser(new UserWrapper(((UserWrapper) user).getUser(), cat));
			else
				this.setUser(new UserWrapper(user, cat));
		}
	}

	private Integer currentModule;

	private Map<String, List<TipoCancelacion>> allTiposCancelacion;

	public Integer getCurrentModule() {
		return currentModule;
	}

	public void setCurrentModule(Integer currentModule) {
		this.currentModule = currentModule;
	}

	public String getModulePath() {
		return Constants.urls.get((currentModule == null) ? Constants.MODULE_COMMON : currentModule);
	}

	public Date getCurrentDate() {
		return Calendar.getInstance().getTime();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getModuleVersion() {
		return Resources.getString("module.version");
	}

	public String getModuleName() {
		return Resources.getString("module.name");
	}

	/**
	 * @return el valor de user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user
	 *            setea el valor de user
	 */
	public void setUser(User user) {
		this.user = user;
	}

	public HashMap<String, Integer> getTablaPaginacion() {
		if (tablaPaginacion == null) {
			tablaPaginacion = new HashMap<String, Integer>();
			tablaPaginacion.put(Constants.TABLA_LISTADO_TIPO_SERVICIO, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_TIPO_TRANSPORTE, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_MEDIO_TRANSPORTE, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_CATEGORIA_TRANSPORTE, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_MODALIDAD, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_TIPO_SERVICIO_AREA, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_TERMINALES, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_REGLAMENTACION, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_ZONAS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_TIPO_CERTIFICADO, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_TIPO_VEHICULO_SERVICIO, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_BLOQUES_PREDETERMINADOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_VEHICULOS_SERVICIO, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_CERTIFICADOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_PROPIETARIOS_SERVICIO, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_RECORRIDOS_SERVICIO, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_CUPOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_CALLES, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_USUARIOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_CERTIFICADOS_INSCVEHICULO, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_CERTIFICADOS_RECORRIDOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_OFICINAS_VENTA_PASAJE, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_GRUPOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_AUTORIZACION, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_NOTIFICACION, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_CANCELACION_VEHICULOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_GREMIOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_TIPO_CERTIFICADO_CERTIFICADOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_VEHICULOS_ANULADOS, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_DOCUMENTACION, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			tablaPaginacion.put(Constants.TABLA_LISTADO_TRAMITE, Constants.CANTIDAD_FILAS_POR_DEFECTO);
			
			
			

		}
		return tablaPaginacion;
	}

	public void setTablaPaginacion(HashMap<String, Integer> tablaPaginacion) {
		this.tablaPaginacion = tablaPaginacion;
	}

	public boolean tieneVariasCat() {
		if (this.getUser().getContext().getCategorias() != null)
			try {
				UserWrapper user = (UserWrapper) this.getUser();
				return user.getUser().getContext().getCategorias().size() > 1;
			} catch (Exception e) {
				return this.getUser().getContext().getCategorias().size() > 1;
			}

		return false;
	}

	/**
	 * @return el valor de categoriasSeleccionables
	 * @throws GeneralDataAccessException
	 */
	public List<CategoriaTransporteSeleccionble> getCategoriasSeleccionables() throws GeneralDataAccessException {
		if (categoriasSeleccionables == null) {
			registerCategoriasSeleccionablesPorTipoServicio(this.getUser());
		}
		return categoriasSeleccionables;
	}

	/**
	 * @param setea
	 *            el parametro categoriaTransporteManager al campo
	 *            categoriaTransporteManager
	 */
	public void setCategoriaTransporteManager(CategoriaTransporteManager categoriaTransporteManager) {
		this.categoriaTransporteManager = categoriaTransporteManager;
	}

	public TipoCancelacion getTipoCancelacion(Long id, String alcance) {
		try {
			if (allTiposCancelacion == null)
				allTiposCancelacion = new HashMap<String, List<TipoCancelacion>>();
			if (!allTiposCancelacion.containsKey(alcance))
				allTiposCancelacion.put(alcance, generalDataManager.getAllTiposCancelacion(alcance,true));
			List<TipoCancelacion> canc = allTiposCancelacion.get(alcance);
			for (TipoCancelacion tipoCancelacion : canc) {
				if (tipoCancelacion.getId().equals(id)) {
					return tipoCancelacion;
				}
			}
			return null;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @return el valor de generalDataManager
	 */
	public GeneralDataManager getGeneralDataManager() {
		return generalDataManager;
	}

	/**
	 * @param setea
	 *            el parametro generalDataManager al campo generalDataManager
	 */
	public void setGeneralDataManager(GeneralDataManager generalDataManager) {
		this.generalDataManager = generalDataManager;
	}

	public List<Region> getAllRegiones() {
		try {
			return ubicacionGeograficaManager.getAllRegiones();
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			return new ArrayList<Region>();
		}
	}

	/**
	 * @return el valor de ubicacionGeograficaManager
	 */
	public UbicacionGeograficaManager getUbicacionGeograficaManager() {
		return ubicacionGeograficaManager;
	}

	/**
	 * @param setea
	 *            el parametro ubicacionGeograficaManager al campo
	 *            ubicacionGeograficaManager
	 */
	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public List<CategoriaTransporteSeleccionble> registerCategoriasSeleccionablesPorTipoServicio(User usuarioBase) throws GeneralDataAccessException {
		List<TipoServicio> tiposServicioByUsuario = this.tipoServicioManager.getAllTiposServicioByUsuario(usuarioBase);
		categoriasSeleccionables = new ArrayList<CategoriaTransporteSeleccionble>();
		for (TipoServicio tipoServicio : tiposServicioByUsuario) {
			CategoriaTransporteSeleccionble cts = new CategoriaTransporteSeleccionble();
			cts.setCategoria(tipoServicio.getCategoriaTransporte());
			cts.setMedio(tipoServicio.getMedioTransporte());
			cts.setTipoTransporte(tipoServicio.getTipoTransporte());
			if (!categoriasSeleccionables.contains(cts))
				categoriasSeleccionables.add(cts);
		}
		Collections.sort(categoriasSeleccionables, new CategoriaTransporteSeleccionbleComparator());
		return categoriasSeleccionables;

	}

	public List<CategoriaTransporteSeleccionble> registerAllCategorias() throws GeneralDataAccessException {
		List<CategoriaTransporte> categoriasAll = this.categoriaTransporteManager.getAllCategoriasTrasporte();
		categoriasSeleccionables = new ArrayList<CategoriaTransporteSeleccionble>();
		for (CategoriaTransporte categ : categoriasAll) {
			CategoriaTransporteSeleccionble cts = new CategoriaTransporteSeleccionble();
			cts.setCategoria(categ);
			cts.setMedio(new MedioTransporte());
			cts.getMedio().setId(0l);
			cts.setTipoTransporte(new TipoTransporte());
			cts.getTipoTransporte().setId(0l);
			if (!categoriasSeleccionables.contains(cts))
				categoriasSeleccionables.add(cts);
		}
		return categoriasSeleccionables;
	}

	/**
	 * @return el valor de tipoServicioManager
	 */
	public TipoServicioManager getTipoServicioManager() {
		return tipoServicioManager;
	}

	/**
	 * @param setea
	 *            el parametro tipoServicioManager al campo tipoServicioManager
	 */
	public void setTipoServicioManager(TipoServicioManager tipoServicioManager) {
		this.tipoServicioManager = tipoServicioManager;
	}

	/**
	 * @return el valor de reglamentacionManager
	 */
	public ReglamentacionManager getReglamentacionManager() {
		return reglamentacionManager;
	}

	/**
	 * @param setea
	 *            el parametro reglamentacionManager al campo
	 *            reglamentacionManager
	 */
	public void setReglamentacionManager(ReglamentacionManager reglamentacionManager) {
		this.reglamentacionManager = reglamentacionManager;
	}

	public boolean isRedireccionVista(ServicioDTO servicio) throws UnaccesibleRedirectionException, GeneralDataAccessException {
		if (getUser().getContext().getRoles().contains("ROLE_USER_ENCARGADO")) {

			boolean esEncargadoEnvistaRegion = true;
			boolean esEncargadoEnvistaCat = true;

			List<Region> regdisponible = (getUser().getContext().getRegionesDisponibles());
			for (Region region : regdisponible) {
				if (region.getCodigo().equals(servicio.getCodigoRegion()))
					esEncargadoEnvistaRegion = false;
			}

			TipoServicio ts = tipoServicioManager.getTipoServicioById(servicio.getIdTipoServicio());

			User usuarioSinWrapp = ((UserWrapper) getUser()).getUser();

			if (((usuarioSinWrapp.getContext().getCategorias().contains(ts.getCategoriaTransporte()))
					&& (usuarioSinWrapp.getContext().getMediosTransporte().contains(ts.getMedioTransporte())) 
					&& (usuarioSinWrapp.getContext().getTiposTransporte().contains(ts.getTipoTransporte())))   ) {
				esEncargadoEnvistaCat = false;
			}

			return esEncargadoEnvistaRegion || esEncargadoEnvistaCat;
		} else if (getUser().getContext().getRoles().contains("ROLE_USER_CONSULTOR")) {

			this.getUser().getContext().setRegionSeleccionada(ubicacionGeograficaManager.getRegionById(servicio.getCodigoRegion()));
			// this.getUser().getContext()//.set.setCategorias(servicio.getTipoServicio().getCategoriaTransporte());
			return true;
		} else
			throw new UnaccesibleRedirectionException("No tiene rol Asociado");
	}

	public boolean isRedireccionVista(Servicio servicio) throws UnaccesibleRedirectionException, GeneralDataAccessException {
		if (getUser().getContext().getRoles().contains("ROLE_USER_ENCARGADO")) {
			List<Region> regdisponible = (getUser().getContext().getRegionesDisponibles());
			
			if(servicio.getRevisionNumber()!=null){
				return true;
			}
			User usuarioSinWrapp = ((UserWrapper) getUser()).getUser();

			for (Region region : regdisponible) {
				if (region.getCodigo().equals(servicio.getCodigoRegion())){
					if (((usuarioSinWrapp.getContext().getCategorias().contains(servicio.getTipoServicio().getCategoriaTransporte()))
						&& (usuarioSinWrapp.getContext().getMediosTransporte().contains(servicio.getTipoServicio().getMedioTransporte())) 
						&& (usuarioSinWrapp.getContext().getTiposTransporte().contains(servicio.getTipoServicio().getTipoTransporte())))   ) {
						return false;
					}
					return true;
				}
			}
			return true;
		} else if (getUser().getContext().getRoles().contains("ROLE_USER_CONSULTOR")) {
			this.getUser().getContext().setRegionSeleccionada(ubicacionGeograficaManager.getRegionById(servicio.getCodigoRegion()));
			// this.getUser().getContext()//.set.setCategorias(servicio.getTipoServicio().getCategoriaTransporte());
			return true;
		} else
			throw new UnaccesibleRedirectionException("No tiene rol Asociado");
	}

	/**
	 * Ordena una lista a partir del campo field *
	 * 
	 * @param idList
	 *            es usado para almacenar el ordenador para la lista
	 * @param list
	 * @param field
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void sortCollection(String idList, List list, String field) {
		CollectionSorter collectionSorter = sorters.get(idList);
		if (collectionSorter == null) {
			collectionSorter = new CollectionSorter();
			sorters.put(idList, collectionSorter);
		}
		collectionSorter.sortByField(list, field); 

	}

	/**
	 * @return el valor de uploadedFile
	 */
	public UploadedFile getUploadedFile() {
		return uploadedFile;
	}

	/**
	 * @param setea el parametro uploadedFile al campo uploadedFile
	 */
	public void setUploadedFile(UploadedFile uploadedFile) {
		this.uploadedFile = uploadedFile;
	}


    /**
     * @return el valor de vehiculoManagerRnt
     */
    public VehiculoManagerRnt getVehiculoManagerRnt() {
        return vehiculoManagerRnt;
    }

    /**
     * @param setea el parametro vehiculoManagerRnt al campo vehiculoManagerRnt
     */
    public void setVehiculoManagerRnt(VehiculoManagerRnt vehiculoManagerRnt) {
        this.vehiculoManagerRnt = vehiculoManagerRnt;
    }
    //Mejoras TEL 201907 Nro: 6
     public boolean getTelHabilitarUsuarioTramiteSel() {
        return telHabilitarUsuarioTramiteSel;
    }

    public void setTelHabilitarUsuarioTramiteSel(boolean telHabilitarUsuarioTramiteSel) {
        this.telHabilitarUsuarioTramiteSel = telHabilitarUsuarioTramiteSel;
    }
    
	/**
	 * @return el valor de normativasCache
	 */
//	public NormativasCache getNormativasCache(Reglamentacion reglamentacion) {
//		return normativasCache.get(reglamentacion);
//	}

	/**
	 * @param setea el parametro normativasCache al campo normativasCache
	 */
//	public void setNormativasCache(Reglamentacion reglamentacion,NormativasCache normativasCache) {
//		this.normativasCache.put(reglamentacion, normativasCache);
//	}
	
//	public void initNormativasCahce(Reglamentacion reglamentacion,ReglamentacionBean reglamentacionBean) throws GeneralDataAccessException, JAXBException, EventEvalException {
//		 NormativasCache nc = new NormativasCache(reglamentacionBean);
//		MarcoGeograficoSource source = new MarcoGeograficoSource();
//		if (!Hibernate.isInitialized(reglamentacion.getMarcoGeografico())){
//			reglamentacion.setMarcoGeografico(reglamentacionManager.getMarcoGeograficoByIdReglamentacion(reglamentacion.getId()));
//		}
//		reglamentacion.getMarcoGeografico().setSource(source);
//		nc.setMarcoGeograficoCompleto(source);
////		EventManager em = new EventManager(reglamentacion, this.getReglamentacionManager(), tipoServicioManager);
//		setNormativasCache(reglamentacion,nc);
//		nc.setNormaTipoVehiculos((NormasTiposVehiculoPermitido) NormativaAccess.getInstance().getNormativaAplicada(reglamentacion, Normativa.descriptorTiposVehiculosPermitidos));
//	}
	
}
