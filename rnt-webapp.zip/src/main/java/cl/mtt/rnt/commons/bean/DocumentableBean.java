package cl.mtt.rnt.commons.bean;

import cl.mtt.rnt.commons.model.core.DocumentoBiblioteca;

public interface DocumentableBean {

	public void addBibliotecaDigitalDocument(DocumentoBiblioteca documento, String param);
	
	public void removeBibliotecaDigitalDocument(DocumentoBiblioteca documento, String param);

}
