package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.userrol.UserContext;
import cl.mtt.rnt.commons.service.CategoriaTransporteManager;
import cl.mtt.rnt.commons.service.MedioTransporteManager;
import cl.mtt.rnt.commons.service.TipoTransporteManager;
import cl.mtt.rnt.commons.service.UsuarioManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.ws.WSConsultBy;
import cl.mtt.rnt.commons.ws.util.RNTAuthenticationToken;
import cl.mtt.rnt.encargado.bean.CrossContextAccessBean;

@ManagedBean
@ViewScoped
public class LoginBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3177719768149445486L;
	
	@ManagedProperty(value = "#{crossContextAccessBean}")
	private CrossContextAccessBean crossContextAccessBean;

	private SecurityManager securityManager = CrossContextAccessBean.getSecurityManager();

	private String userName;
	private String password;

	private AuthenticationManager authenticationManager;
	
	private UbicacionGeograficaManager ubicacionGeograficaManager;
	
	
	@ManagedProperty(value = "#{tipoTransporteManager}")
	private TipoTransporteManager tipoTransporteManager;
	@ManagedProperty(value = "#{medioTransporteManager}")
	private MedioTransporteManager medioTransporteManager;
	@ManagedProperty(value = "#{categoriaTransporteManager}")
	private CategoriaTransporteManager categoriaTransporteManager;
	
	private UsuarioManager usuarioManager;
	
	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	
	@PostConstruct
	public void init() {
		authenticationManager = CrossContextAccessBean.getAuthenticationManager();
		ubicacionGeograficaManager =  CrossContextAccessBean.getUbicacionGeograficaManager();
		usuarioManager = CrossContextAccessBean.getUbicacionUsuarioManager();
	}

	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public SecurityManager getSecurityManager() {
		return securityManager;
	}

	public void setSecurityManager(SecurityManager securityManager) {
		this.securityManager = securityManager;
	}

	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public String login() {
		User user = new User();
		try {
			Authentication request = new UsernamePasswordAuthenticationToken(getUserName(), getPassword());
			Authentication result = authenticationManager.authenticate(request);
			SecurityContextHolder.getContext().setAuthentication(result);
			boolean autenticadoPorWS = result instanceof RNTAuthenticationToken;
				
			user.setNombreUsuario(userName);
			user.setPassword(password);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			Iterator<?> it = auth.getAuthorities().iterator();
			user.setContext(new UserContext());
			user.getContext().setRoles(new ArrayList<String>());
			user.getContext().setRegiones(new ArrayList<Region>());
			user.getContext().setRegionesDisponibles(new ArrayList<Region>());
			Map<String,Region> allRegionesMap = ubicacionGeograficaManager.getAllRegionesAsMap();
			boolean primero = true;
			
			if(autenticadoPorWS){
				user.getContext().setTiposTransporte(new ArrayList<TipoTransporte>());
				user.getContext().setMediosTransporte(new ArrayList<MedioTransporte>());
				user.getContext().setCategorias(new ArrayList<CategoriaTransporte>());
				user.setAplicaNacion(((RNTAuthenticationToken)result).getAplicaNacionBoolean());
				while (it.hasNext()) {
					SimpleGrantedAuthority au = (SimpleGrantedAuthority) it.next();
					String role = au.getAuthority();
					user.getContext().getRoles().add(role);
				}
				for (String idRegion : ((RNTAuthenticationToken)result).getRegiones()) {
					Region region = allRegionesMap.get(((idRegion.length()==1)?"0":"")+idRegion);
					if (region!= null) {
					    if (primero) {
	                        user.getContext().setRegionSeleccionada(region);
	                        primero = false;
	                    }
					    user.getContext().getRegionesDisponibles().add(region);
					}
				}
				for (String codTipoTrans : ((RNTAuthenticationToken)result).getTiposTransporte()) {
					TipoTransporte o = tipoTransporteManager.getTipoTranporteByDescriptor(codTipoTrans);
					if(o!=null){
						user.getContext().getTiposTransporte().add(o);
					}
				}
				for (String codmedioTrans : ((RNTAuthenticationToken)result).getMediosTransporte()) {
					MedioTransporte o = medioTransporteManager.getMedioTransporteByDescriptor(codmedioTrans);
					if(o!=null){
						user.getContext().getMediosTransporte().add(o);
					}
				}
				for (String codCateg : ((RNTAuthenticationToken)result).getCategoriasTransporte()) {
					CategoriaTransporte o = categoriaTransporteManager.getCategoriaTransporteByDescriptor(codCateg);
					if(o!=null){
						user.getContext().getCategorias().add(o);
					}
				}
			}else{
				while (it.hasNext()) {
					SimpleGrantedAuthority au = (SimpleGrantedAuthority) it.next();
					String role = au.getAuthority();
					if (role.startsWith(Constants.PREFIJO_ROL_REGION)) {
						String idRegion = role.replace(Constants.PREFIJO_ROL_REGION, "").trim();
						idRegion = ((idRegion.length()==1)?"0":"")+idRegion;
						Region region = allRegionesMap.get(idRegion);
						if (primero) {
							user.getContext().setRegionSeleccionada(region);
							primero = false;
						}
						user.getContext().getRegionesDisponibles().add(region);
					} else {
						user.getContext().getRoles().add(role);
					}
				}
			}
			
			User usuarioBase = null;
			String systemState = ((ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext()).getInitParameter("rnt.system.state");
			if ((systemState != null) && (systemState.equals("SETUP"))) {
				usuarioBase = user;
				if (user.getContext().getRoles().contains(Constants.ROLE_USER_ADMINISTRADOR)) {

					user.getContext().getRoles().clear();
					user.getContext().getRoles().add(Constants.ROLE_USER_ADMINISTRADOR);
					usuarioBase = user;
					currentSessionBean.setUserName(usuarioBase.getNombreUsuario());
					currentSessionBean.setUserFullName(usuarioBase.getNombreUsuario());
					currentSessionBean.setUser(usuarioBase);
					currentSessionBean.registerAllCategorias();

				} else {
					messageBean.addMessage(Resources.getString("login.message.error.setupmode"), FacesMessage.SEVERITY_ERROR);
					FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
					return "login_fail";
				}
			} else {
				usuarioBase = usuarioManager.getUsuarioByName(userName);
				if(usuarioBase!=null && !usuarioBase.getEstado().booleanValue()){
					messageBean.addMessage(Resources.getString("login.message.error"), FacesMessage.SEVERITY_ERROR);
					return "login_fail";
				}
				if (usuarioBase == null) {
					usuarioBase = user;
					usuarioBase.setFechaEstado(new Timestamp(new Date().getTime()));
					usuarioBase.setEstado(true); 
					usuarioBase.setNombreCompleto(userName);
					usuarioBase.setPassword("");
					usuarioManager.saveUsuario(usuarioBase);
				}
				usuarioBase.setPassword(user.getPassword());
				usuarioBase.setFechaUltimoLogin(new Timestamp(new Date().getTime()));
				usuarioBase.getContext().setRoles(user.getContext().getRoles());
				usuarioBase.getContext().setRegiones(user.getContext().getRegiones());
				usuarioBase.getContext().setRegionesDisponibles(user.getContext().getRegionesDisponibles());
				usuarioBase.getContext().setRegionSeleccionada(user.getContext().getRegionSeleccionada());
				if(autenticadoPorWS){
					usuarioBase.getContext().setTiposTransporte(user.getContext().getTiposTransporte());
					usuarioBase.getContext().setMediosTransporte(user.getContext().getMediosTransporte());
					usuarioBase.getContext().setCategorias(user.getContext().getCategorias());
					usuarioBase.setAplicaNacion(user.getAplicaNacion());
				}
				usuarioManager.updateUsuario(usuarioBase);
				currentSessionBean.setUserName(usuarioBase.getNombreUsuario());
				currentSessionBean.setUserFullName(usuarioBase.getNombreCompleto());
				currentSessionBean.setUser(usuarioBase);
			}

			if (WSConsultBy.getConsultDummies() == null) {
				String dummyFiles = ((ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext()).getInitParameter("rnt.ws.dummy.files");
				if ((dummyFiles != null) && (dummyFiles.equalsIgnoreCase("true"))) {
					WSConsultBy.setConsultDummies(Boolean.TRUE);
				} else {
					WSConsultBy.setConsultDummies(Boolean.FALSE);
				}
			}

			// **************************************

			// CertificadoSeccion sec=new CertificadoSeccion();
			// sec.setNombre("usuario");
			// sec.setCampos(new ArrayList<CertificadoCampo>());
			// sec.getCampos().add(new
			// CertificadoCampo("nombre","nombreUsuario"));
			// sec.getCampos().add(new CertificadoCampo("rut","rut"));
			// sec.setSecciones(new ArrayList<CertificadoSeccion>());
			//
			// CertificadoSeccion cat=new CertificadoSeccion();
			// cat.setNombre("categoria");
			// cat.setProperty("context.categorias");
			// cat.setMultiple(true);
			// cat.setCampos(new ArrayList<CertificadoCampo>());
			// cat.getCampos().add(new CertificadoCampo("nombre","nombre"));
			// cat.getCampos().add(new CertificadoCampo("desc","descriptor"));
			//
			// sec.getSecciones().add(cat);
			//
			// CertificadoXMLUtil cu=new CertificadoXMLUtil();
			// // Object test=cu.getProperty(usuarioBase,
			// "context.categorias.nombre");
			// String test=cu.getCertificadoXMLasString(sec, usuarioBase);

			// test=cu.getCertificadoXSDasString(sec);
	

			// **************************************

			if (usuarioBase.getContext().getRoles().contains(Constants.ROLE_USER_ENCARGADO)) {
				currentSessionBean.registerCategoriasSeleccionablesPorTipoServicio(usuarioBase);
				if (currentSessionBean.getCategoriasSeleccionables().size() > 0) {
					if (currentSessionBean.getCategoriasSeleccionables().size() > 1) {
						currentSessionBean.setCurrentModule(Constants.MODULE_ENCARGADO);
						return "login_success_varias_cat";
					}
					currentSessionBean.setCategoriaSeleccionada(currentSessionBean.getCategoriasSeleccionables().get(0));
					currentSessionBean.setCurrentModule(Constants.MODULE_ENCARGADO);
					return "login_success";
				} else {
					messageBean.addMessage(Resources.getString("login.sincategorias.error"), FacesMessage.SEVERITY_ERROR);
					FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
					return "login_fail";
				}

			} else if (usuarioBase.getContext().getRoles().contains(Constants.ROLE_USER_CONSULTOR)) {
				// Se deja separado el rol de consultor por si se realiza luego
				// la redireccion a paginas
				// distintas que las del consultor
				currentSessionBean.registerCategoriasSeleccionablesPorTipoServicio(usuarioBase);
				if (currentSessionBean.getCategoriasSeleccionables().size() > 0) {
					if (currentSessionBean.getCategoriasSeleccionables().size() > 1) {
						currentSessionBean.setCurrentModule(Constants.MODULE_ENCARGADO);
						return "login_success_varias_cat";
					}
					currentSessionBean.setCategoriaSeleccionada(currentSessionBean.getCategoriasSeleccionables().get(0));
					currentSessionBean.setCurrentModule(Constants.MODULE_ENCARGADO);
					return "login_success";
				} else {
					messageBean.addMessage(Resources.getString("login.sincategorias.error"), FacesMessage.SEVERITY_ERROR);
					FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
					return "login_fail";
				}
			} else if (usuarioBase.getContext().getRoles().contains(Constants.ROLE_USER_ADMINISTRADOR)) {
				currentSessionBean.setCurrentModule(Constants.MODULE_ADMIN);
				return "login_admin";
			} else {
				messageBean.addMessage(Resources.getString("login.message.error"), FacesMessage.SEVERITY_ERROR);
				FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
				return "login_fail";
			}

		} catch (AuthenticationException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("login.message.error"), FacesMessage.SEVERITY_ERROR);
			return "login_fail";
		} catch (Exception ex) {
			Logger.getLogger(this.getClass()).error(ex.getMessage(), ex);
			messageBean.addMessage(Resources.getString("login.message.error"), FacesMessage.SEVERITY_ERROR);
			return "login_fail";
		}

	}

	public String logout() {
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		return "logout_success";
	}

	public String getCurrentUserName() {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		return ((User) authentication.getPrincipal()).getNombreUsuario();
	}

	public String changeToAdmin() {
		this.currentSessionBean.setCurrentModule(Constants.MODULE_ADMIN);
		return "modulo_administrativo";
	}

	public String gotoSelectCategoria() {
		currentSessionBean.setCategoriaSeleccionada(null);
                //Mejoras TEL 201907 Nro: 2 
                currentSessionBean.setTelHabilitarUsuarioTramiteSel(false);
		return "seleccion_categoria";
	}

	public String changeToEncargado() {
		this.currentSessionBean.setCurrentModule(Constants.MODULE_ENCARGADO);
		// si tiene varias catergorias
		try {
			if (currentSessionBean.getCategoriaSeleccionada() == null && currentSessionBean.getCategoriasSeleccionables().size() > 1)
				return "seleccion_categoria";
			else if (currentSessionBean.getCategoriasSeleccionables().size() == 1) {
				currentSessionBean.setCategoriaSeleccionada(currentSessionBean.getCategoriasSeleccionables().get(0));
			}
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("login.message.error"), FacesMessage.SEVERITY_ERROR);
		}
		return "modulo_encargado";
	}

	/**
	 * @param setea
	 *            el parametro usuarioManager al campo usuarioManager
	 */
	public void setUsuarioManager(UsuarioManager usuarioManager) {
		this.usuarioManager = usuarioManager;
	}

	/**
	 * @param setea
	 *            el parametro ubicacionGeograficaManager al campo
	 *            ubicacionGeograficaManager
	 */
	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public String cambioRegion(Region region) {
		this.currentSessionBean.getUser().getContext().setRegionSeleccionada(region);
                //Mejoras TEL 201907 Nro: 4s
                if (this.currentSessionBean.getTelHabilitarUsuarioTramiteSel()) { return "success_tel_cambioRegion";} else { return "success_cambioRegion";}
	}

	/**
	 * @param setea el parametro crossContextAccessBean al campo crossContextAccessBean
	 */
	public void setCrossContextAccessBean(
			CrossContextAccessBean crossContextAccessBean) {
		this.crossContextAccessBean = crossContextAccessBean;
	}



	public void setTipoTransporteManager(TipoTransporteManager tipoTransporteManager) {
		this.tipoTransporteManager = tipoTransporteManager;
	}



	public void setMedioTransporteManager(
			MedioTransporteManager medioTransporteManager) {
		this.medioTransporteManager = medioTransporteManager;
	}



	public void setCategoriaTransporteManager(
			CategoriaTransporteManager categoriaTransporteManager) {
		this.categoriaTransporteManager = categoriaTransporteManager;
	}
	
	
}