package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.RntEventResultItem;
import cl.mtt.rnt.commons.service.batch.CertificadosControlledGenerator;

@ManagedBean
@SessionScoped
public class MessageBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5578026745670065487L;

	public MessageBean() {
		super();
		this.eventResultItems = null;
	}

	private static final String MESSAGE_ID = "MESSAGE_ID";

	private String message = null;
	private Integer severity = 0;
	private List<RntEventResultItem> eventResultItems;
	private List<RntEventResultItem> lastEventResultItems;

	public String getMessage() {
		// if (message == null){
		message = "";
		severity = 0;
		Iterator<FacesMessage> messages = FacesContext.getCurrentInstance().getMessages(MESSAGE_ID);
		while (messages.hasNext()) {
			FacesMessage facMessage = (FacesMessage) messages.next();
			message += facMessage.getDetail();
			if (facMessage.getSeverity().getOrdinal() > severity)
				severity = facMessage.getSeverity().getOrdinal();
			facMessage.rendered();
			if (messages.hasNext()) {
				message += "<br/>";
			}
		}
		// clearMessages();
		// }
		// 0 - INFO 0
		// 1 - WARN 1
		// 2 - ERROR 2
		// 3 - FATAL 3
		return message;
	}

	/**
	 * Elimina los mensajes de FacesContext
	 * 
	 * @author Federico Dukatz
	 */
	// protected void clearMessages() {
	// Iterator<FacesMessage> iter =
	// FacesContext.getCurrentInstance().getMessages(MESSAGE_ID);
	// while (iter.hasNext()) {
	// FacesMessage el = iter.next();
	// iter.remove();
	// }
	// }

	public boolean getShowMessage() {
		return !"".equals(getMessage());
	}

	public void addMessage(String message, Severity severity) {
		try{
			FacesContext.getCurrentInstance().addMessage(MESSAGE_ID, new FacesMessage(severity, message, message));
			if (severity.getOrdinal() > this.severity)
				this.severity = severity.getOrdinal();
		}catch(Exception e){
            Logger.getLogger(this.getClass()).error(message, e);
		}
	}

	public Integer getSeverity() {
		if (!FacesContext.getCurrentInstance().getMessages(MESSAGE_ID).hasNext())
			severity = 0;
		return severity;
	}

	public Integer getSeverity_INFO() {
		return 0;
	}

	public Integer getSeverity_WARN() {
		return 1;
	}

	public Integer getSeverity_ERROR() {
		return 2;
	}

	public Integer getSeverity_FATAL() {
		return 3;
	}

	public boolean isHasReglamentacionMessages() {
		return ((eventResultItems != null) && (eventResultItems.size() > 0));
	}

	public List<RntEventResultItem> getRntEventResultItems() {
		lastEventResultItems = eventResultItems;
		eventResultItems = null;
		return lastEventResultItems;
	}

	public void setRntEventResultItems(List<RntEventResultItem> eventResultItems) {
		this.eventResultItems = eventResultItems;
	}

	public boolean getPermiteExceptuar(){
		boolean ret = true;
		boolean sonTodasAdvertencias = true;
		for (RntEventResultItem rntEventResultItem : lastEventResultItems) {
			ret = ret && ((rntEventResultItem.isResult()) || (!rntEventResultItem.isResult() && rntEventResultItem.getNorma().getNormativa().getPermiteAutorizacion()));
			sonTodasAdvertencias = sonTodasAdvertencias && rntEventResultItem.isResult(); 
		}
		if(sonTodasAdvertencias){
			return false;
		}
		return ret;
	}

	public List<RntEventResultItem> getLastEventResultItems() {
		return lastEventResultItems;
	}

	public void setLastEventResultItems(
			List<RntEventResultItem> lastEventResultItems) {
		this.lastEventResultItems = lastEventResultItems;
	}
	
	
}

