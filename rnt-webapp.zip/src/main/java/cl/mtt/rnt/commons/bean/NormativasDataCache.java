package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cl.mtt.rnt.admin.reglamentacion.impl.NormasTiposVehiculoPermitido;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.ReglamentacionInvalidaTipoVehiculos;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.sgprt.VehiculoManager;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;

public class NormativasDataCache implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5021431944383861180L;

//	NormasTiposVehiculoPermitido normaTipoVehiculos;
	List<TipoVehiculo> tiposVehiculos;
	Map<String, MarcoGeograficoSource> marcoGeograficoSourcePorTipoVehiculo;
	MarcoGeograficoSource marcoGeograficoCompleto;
	private List<TipoVehiculo> allTiposVehiculo;

	public NormativasDataCache() {
	}

	/**
	 * @param setea
	 *            el parametro normaTipoVehiculos al campo normaTipoVehiculos
	 */
	public void setNormaTipoVehiculosData(NormasTiposVehiculoPermitido normaTipoVehiculos,ReglamentacionManager reglamentacionManager) {
		if (normaTipoVehiculos != null) {
			this.tiposVehiculos = normaTipoVehiculos.getTiposVehiculosItems(reglamentacionManager);
			this.marcoGeograficoCompleto = normaTipoVehiculos.getMarcoGeograficoSourceCompleto(reglamentacionManager);
			this.marcoGeograficoSourcePorTipoVehiculo = normaTipoVehiculos.getMarcoGeograficoSourcePorTipoVehiculo(reglamentacionManager);
		}
	}

	/**
	 * @return el valor de tiposVehiculos
	 */
	public List<TipoVehiculo> getTiposVehiculos() {
//		if (this.tiposVehiculos == null) {
//			this.tiposVehiculos = this.normaTipoVehiculos.getTiposVehiculosItems(rb);
//		}
		return tiposVehiculos;
	}

	/**
	 * @param setea
	 *            el parametro tiposVehiculos al campo tiposVehiculos
	 */
	public void setTiposVehiculos(List<TipoVehiculo> tiposVehiculos) {
		this.tiposVehiculos = tiposVehiculos;
	}

	/**
	 * @return el valor de marcoGeograficoSourcePorTipoVehiculo
	 * @throws ReglamentacionInvalidaTipoVehiculos
	 */
	public Map<String, MarcoGeograficoSource> getMarcoGeograficoSourcePorTipoVehiculo() throws ReglamentacionInvalidaTipoVehiculos {

//		if (this.normaTipoVehiculos == null) {
//			throw new ReglamentacionInvalidaTipoVehiculos();
//		}
//
//		if (marcoGeograficoSourcePorTipoVehiculo == null) {
//			this.marcoGeograficoSourcePorTipoVehiculo = this.normaTipoVehiculos.getMarcoGeograficoSourcePorTipoVehiculo(rb);
//		}
		return marcoGeograficoSourcePorTipoVehiculo;
	}

	/**
	 * @param setea
	 *            el parametro marcoGeograficoSourcePorTipoVehiculo al campo
	 *            marcoGeograficoSourcePorTipoVehiculo
	 */
	public void setMarcoGeograficoSourcePorTipoVehiculo(Map<String, MarcoGeograficoSource> marcoGeograficoSourcePorTipoVehiculo) {
		this.marcoGeograficoSourcePorTipoVehiculo = marcoGeograficoSourcePorTipoVehiculo;
	}

	/**
	 * @return el valor de marcoGeograficoCompleto
	 */
	public MarcoGeograficoSource getMarcoGeograficoCompleto() {
//		if (this.marcoGeograficoCompleto == null) {
//			this.marcoGeograficoCompleto = this.normaTipoVehiculos.getMarcoGeograficoSourceCompleto(rb);
//		}
		return marcoGeograficoCompleto;
	}

	/**
	 * @param setea
	 *            el parametro marcoGeograficoCompleto al campo
	 *            marcoGeograficoCompleto
	 */
	public void setMarcoGeograficoCompleto(MarcoGeograficoSource marcoGeograficoCompleto) {
		this.marcoGeograficoCompleto = marcoGeograficoCompleto;
	}

	public List<TipoVehiculo> getAllTiposVehiculos() throws GeneralDataAccessException {
//		if (this.allTiposVehiculo == null) {
//			allTiposVehiculo = rb.getVehiculoManager().getAllTiposVehiculo();
//		}
		return allTiposVehiculo;
	}

}
