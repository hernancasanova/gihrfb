package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.DataModel;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;

import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;
import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.util.PropertiesManager;
import cl.mtt.rnt.admin.reglamentacion.util.SelectionItem;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo.SubGrupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo.SubGrupo.Norma;
import cl.mtt.rnt.commons.exception.CriteriaDefinitionException;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.ReglamentacionInvalidaTipoVehiculos;
import cl.mtt.rnt.commons.export.reglaasociacion.AsociacionesReglamentacionReportBuilder;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.DocumentoBiblioteca;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.GlosaReglamentacion;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.Modalidad;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoReglamentacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoServicioArea;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.core.TipoZona;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.ServicioReglamentadosVO;
import cl.mtt.rnt.commons.model.view.VehiculoReglamentadosVO;
import cl.mtt.rnt.commons.service.AutorizacionManager;
import cl.mtt.rnt.commons.service.CategoriaTransporteManager;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.GrupoManager;
import cl.mtt.rnt.commons.service.MedioTransporteManager;
import cl.mtt.rnt.commons.service.ModalidadManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.TipoServicioAreaManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.service.TipoTransporteManager;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.service.sgprt.VehiculoManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Duration;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.gui.PagedListDataModel;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

@ManagedBean
@ViewScoped
public class ReglamentacionBean implements DocumentableBean,Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4957350970403869734L;

	@ManagedProperty(value = "#{generalDataManager}")
	private GeneralDataManager generalDataManager;

	@ManagedProperty(value = "#{tipoServicioAreaManager}")
	private TipoServicioAreaManager tipoServicioAreaManager;

	@ManagedProperty(value = "#{tipoServicioManager}")
	private TipoServicioManager tipoServicioManager;

	@ManagedProperty(value = "#{reglamentacionManager}")
	private ReglamentacionManager reglamentacionManager;

	@ManagedProperty(value = "#{vehiculoManager}")
	private VehiculoManager vehiculoManager;

	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;

	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;

	@ManagedProperty(value = "#{tipoTransporteManager}")
	private TipoTransporteManager tipoTransporteManager;
	@ManagedProperty(value = "#{categoriaTransporteManager}")
	private CategoriaTransporteManager categoriaTransporteManager;
	@ManagedProperty(value = "#{medioTransporteManager}")
	private MedioTransporteManager medioTransporteManager;

	@ManagedProperty(value = "#{modalidadManager}")
	private ModalidadManager modalidadManager;

	@ManagedProperty(value = "#{zonaManager}")
	private ZonaManager zonaManager;
	
	@ManagedProperty(value = "#{grupoManager}")
	private  GrupoManager grupoManager;
	
	@ManagedProperty(value = "#{autorizacionManager}")
	private AutorizacionManager autorizacionManager;
	
	
	private List<TipoTransporte> tiposTransporte;
	private List<MedioTransporte> mediosTransporte;
	private List<CategoriaTransporte> categoriasTransporte;
	private List<TipoServicioArea> tiposServicioArea;
	private List<Modalidad> modalidades;

	private Map<String, GenericNormativa> normativas;
	// private Map<String,Boolean> gruposLoaded;
	private ReglamentacionXML reglamentacion;
	private Reglamentacion reglamentacionDB;

	// private UIDataTable reglamentacionesTable; // para hacer el binding con
	// la página
	private PagedListDataModel pagedListDataModel;
	private int currentPage = 1;
	private int totalListSize;
	// Variables para el ordenamiento
	private String sortingField;
	private Boolean sortingAsc;
	private Map<String,Boolean> sorters;

	private List<TipoReglamentacion> tiposReglamentacion;
	private Long idTipoReglamentacion;
//	private List<TipoDocumento> tiposDocumento;
//	private Long idTipoDocumento;
	private List<TipoServicio> tiposServicio;

	private List<Reglamentacion> reglamentaciones;
	private Long idReglamentacionDeQueDepende;
	private Map<String, Object> filters = new HashMap<String, Object>();
	private List<Map<String, Object>> optionalsFilters = new ArrayList<Map<String, Object>>();

	private MarcoGeograficoSource marcoGeograficoFilterSource;
	private List<Reglamentacion> reglamentacionesHistorial;
	private List<Reglamentacion> reglamentacionesPadre;

	private List<TipoServicio> tiposServicioSeleccionados;

	private boolean permiteModificarMarcoGeografico = true;
	private boolean permiteModificarTipoServicio = true;
	
	private List<cl.mtt.rnt.commons.model.core.autorizacion.Grupo> grupos;
	
	private String idRegionFiltro;
	private String aplicaAFiltro;
	private String idZonaFiltro; 
	private TipoZona tipoZonaFilter;

	private Long idReglamentacion;
	
//	private NormativasCache normativasCache;
//	private Map<Long,List<String>> materiasSeleccionables;

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);

	}
		
	
	public List<cl.mtt.rnt.commons.model.core.autorizacion.Grupo> getGrupos() {
		if(grupos == null)
			grupos = new ArrayList<cl.mtt.rnt.commons.model.core.autorizacion.Grupo>();
		return grupos;
	}

	public GrupoManager getGrupoManager() {
		return grupoManager;
	}

	public void setGrupoManager(GrupoManager grupoManager) {
		this.grupoManager = grupoManager;
	}

	public void setGrupos(List<cl.mtt.rnt.commons.model.core.autorizacion.Grupo> grupos) {
		this.grupos = grupos;
	}
	
	public AutorizacionManager getAutorizacionManager() {
		return autorizacionManager;
	}

	public void setAutorizacionManager(AutorizacionManager autorizacionManager) {
		this.autorizacionManager = autorizacionManager;
	}
	
	
	public GeneralDataManager getGeneralDataManager() {
		return generalDataManager;
	}

	public void setGeneralDataManager(GeneralDataManager generalDataManager) {
		this.generalDataManager = generalDataManager;
	}

	public ZonaManager getZonaManager() {
		return zonaManager;
	}

	public void setZonaManager(ZonaManager zonaManager) {
		this.zonaManager = zonaManager;
	}

	/**
	 * @return el valor de idRegionFiltro
	 */
	public String getIdRegionFiltro() {
		return idRegionFiltro;
	}

	/**
	 * @param setea
	 *            el parametro idRegionFiltro al campo idRegionFiltro
	 */
	public void setIdRegionFiltro(String idRegionFiltro) {
		this.idRegionFiltro = idRegionFiltro;
	}
	
	public String getAplicaAFiltro() {
		return aplicaAFiltro;
	}

	public void setAplicaAFiltro(String aplicaAFiltro) {
		this.aplicaAFiltro = aplicaAFiltro;
	}

	public String getIdZonaFiltro() {
		return idZonaFiltro;
	}

	public void setIdZonaFiltro(String idZonaFiltro) {
		this.idZonaFiltro = idZonaFiltro;
	}

	
	public TipoZona getTipoZonaFilter() {
		return tipoZonaFilter;
	}

	public void setTipoZonaFilter(TipoZona tipoZonaFilter) {
		this.tipoZonaFilter = tipoZonaFilter;
	}
		
	/**
	 * @return el valor de optionalsFilters
	 */
	public List<Map<String, Object>> getOptionalsFilters() {
		return optionalsFilters;
	}


	/**
	 * @param setea
	 *            el parametro optionalsFilters al campo optionalsFilters
	 */
	public void setOptionalsFilters(List<Map<String, Object>> optionalsFilters) {
		this.optionalsFilters = optionalsFilters;
	}

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public String prepararListarReglamentaciones() {
		// this.sessionCacheManager.clearSession();
		try {
			estimarTablaInicial();
			tiposTransporte = tipoTransporteManager.getAllTiposTransporte();
			mediosTransporte = medioTransporteManager.getAllMediosTrasporte();
			categoriasTransporte = categoriaTransporteManager.getAllCategoriasTrasporte();
			tiposServicioArea = tipoServicioAreaManager.getAllTipoServicioArea();
			modalidades = modalidadManager.getAllModalidades();
			// //reglamentacionesTable=null;
			pagedListDataModel = null;
			marcoGeograficoFilterSource = new MarcoGeograficoSource();
			marcoGeograficoFilterSource.updateData(ubicacionGeograficaManager, zonaManager, new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL,
					MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser());

			//por defecto solo muestra las activas
			filters.put("estado","estadoReglamentacion.activa");
			
			sessionCacheManager.saveState(this);
			return "success_prepararListarReglamentaciones";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararListarReglamentaciones";
	}

	public String prepararNuevaReglamentacion() {

		try {
			tiposServicio = tipoServicioManager.getAllTiposServicioByUsuario(currentSessionBean.getUser());
			reglamentacionDB = new Reglamentacion();
			// reglamentacionManager.initializeNormativas(reglamentacionDB);
			// //Realizar cuando se guarda
			reglamentacionDB.setMarcoGeografico(new MarcoGeografico(MarcoGeograficoSource.AMBITO_REGIONAL));
			MarcoGeograficoSource source = new MarcoGeograficoSource();
			source.updateData(ubicacionGeograficaManager, zonaManager,
					new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser());
			reglamentacionDB.getMarcoGeografico().setSource(source);
			reglamentacionDB.getMarcoGeografico().setTipoZonaSelected(reglamentacionDB.getMarcoGeografico().getSource().getTiposZona().get(0));
			// reglamentacionesTable=null;
			pagedListDataModel = null;
			reglamentacionesPadre = reglamentacionManager.getActiveReglamentaciones();
			idReglamentacionDeQueDepende = null;
			reglamentacionDB.setSeleccionableServicio(Boolean.TRUE);
			reglamentacionDB.setSeleccionableVehiculo(Boolean.TRUE);
			sessionCacheManager.saveState(this);
			return "success_prepararNuevaReglamentacion";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		// reglamentacionesTable=null;
		pagedListDataModel = null;
		sessionCacheManager.saveState(this);
		return "error_prepararNuevaReglamentacion";
	}

	public String prepararModificarReglamentacion(Reglamentacion reg) {
		try {
			this.setReglamentacionDB(reglamentacionManager.getReglamentacionByIdForEditing(reg.getId()));
			reg = this.getReglamentacionDB();
			if(reg.getGlosaVehiculo()==null){
				reg.setGlosaVehiculo(new GlosaReglamentacion());
			}
			if(reg.getGlosaCertificado()==null){
				reg.setGlosaCertificado(new GlosaReglamentacion());
			}

			//this.setIdTipoDocumento(reg.getTipoDocumento().getId());
			this.setIdReglamentacionDeQueDepende((reg.getReglamentacionDeQueDepende() == null) ? null : reg.getReglamentacionDeQueDepende().getId());

			permiteModificarMarcoGeografico = true;
			permiteModificarTipoServicio = true;
//			List<Normativa> norms = reglamentacionManager.getNormativasByReglamentacion(reglamentacionDB);
			for (Normativa normativa : reglamentacionDB.getNormativas()) {
				if ("validacion.especificada".equals(normativa.getValidacion())) {
					if (normativa.isRequiereMarcoGeografico())
						permiteModificarMarcoGeografico = false;
					if (normativa.isRequiereTipoServicio())
						permiteModificarTipoServicio = false;
				}
			}

			if (!validateMarcosGeograficosUsuario(reg)) {
				this.sessionCacheManager.saveState(this);
				return "error_prepararModificarReglamentacion";
			}

			reg.getMarcoGeografico().setSource(new MarcoGeograficoSource());
			if (permiteModificarMarcoGeografico) {
				// si una zona está usada no se podrá quitar de la
				// reglamentación
				List<Localizable> localizablesBloqueadas = new ArrayList<Localizable>();
				if (reg.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL)) {
					List<Zona> zonas = reg.getMarcoGeografico().getZonas();
					for (Zona zona : zonas) {
						int uses = reglamentacionManager.getCantZonasUsadas(reg.getId(), zona.getId());
						if (uses > 0) {
							localizablesBloqueadas.add(zona);
						}
					}
				} else if (reg.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_REGIONAL)) {
					List<Region> regs = reg.getMarcoGeografico().getRegiones();
					for (Region region : regs) {
						int uses = reglamentacionManager.getCantRegionesUsadas(reg.getId(), region.getCodigo());
						if (uses > 0) {
							localizablesBloqueadas.add(region);
						}
					}
				}
				if (localizablesBloqueadas.size() == 0)
					reg.getMarcoGeografico()
							.getSource()
							.updateData(ubicacionGeograficaManager, zonaManager,
									new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser());
				else {
					reg.getMarcoGeografico()
							.getSource()
							.updateDataExcludingLocalizables(ubicacionGeograficaManager, zonaManager,
									new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser(),
									reg.getMarcoGeografico().getAplicableA(), localizablesBloqueadas);
					reg.getMarcoGeografico().lockLocalizables(localizablesBloqueadas);
					permiteModificarMarcoGeografico = false;
				}
			} else {// no permite modificar marco geografica
				reg.getMarcoGeografico()
						.getSource()
						.updateDataExcludingExisting(ubicacionGeograficaManager, zonaManager,
								new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL, MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser(),
								reg.getMarcoGeografico());
				reg.getMarcoGeografico().lockLocalizables();
			}
			tiposServicio = tipoServicioManager.getAllTiposServicioByUsuario(currentSessionBean.getUser());
			if (permiteModificarTipoServicio) {
				tiposServicioSeleccionados = reg.getTiposServicio();
			} else {
				tiposServicioSeleccionados = new ArrayList<TipoServicio>();
				tiposServicio.removeAll(reg.getTiposServicio());
			}
			reg.setMotivoCambio(null);
			reglamentacionesHistorial = reglamentacionManager.getHistoralReglamentaciones(reg);
			// reglamentacionesTable=null;
			reglamentacionesPadre = reglamentacionManager.getPosiblesReglamentacionesPadre(reglamentacionDB,reglamentacionDB.getTiposServicio());
			Collections.sort(reglamentacionesPadre);
			
			pagedListDataModel = null;
			this.sessionCacheManager.saveState(this);

			return "success_prepararModificarReglamentacion";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarReglamentacion";
	}

	public void updateReglamentacionesPadre(){
		try {
			if(reglamentacionDB.getId()!=null){
				List<TipoServicio> ts=new ArrayList<TipoServicio>(tiposServicioSeleccionados);
				if (!permiteModificarTipoServicio){
					ts.addAll(reglamentacionDB.getTiposServicio());
				}
				reglamentacionesPadre = reglamentacionManager.getPosiblesReglamentacionesPadre(reglamentacionDB,ts);
			}else{
				reglamentacionesPadre = reglamentacionManager.getPosiblesReglamentacionesPadre(reglamentacionDB,reglamentacionDB.getTiposServicio());
			}
			Collections.sort(reglamentacionesPadre);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	/**
	 * Revisa que el usuario tenga permisos para trabajar en los marcos
	 * seleccionados de la reglamentacion Agregar mensajes al message bean
	 * Retorna true si tiene permisos
	 * 
	 * @param reg
	 */
	private boolean validateMarcosGeograficosUsuario(Reglamentacion reg) {
		User user = currentSessionBean.getUser();
		if (reg.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL)) {
			if ((user.getAplicaNacion() == null) || (!user.getAplicaNacion().booleanValue())) {
				messageBean.addMessage(Resources.getString("error.nacional.nopermitido"), FacesMessage.SEVERITY_ERROR);
				return false;
			}
		} else {
			if (reg.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_REGIONAL)) {
				List<Region> regiones = reg.getMarcoGeografico().getRegiones();
				for (Region region : regiones) {
					if (!user.getContext().getRegionesDisponibles().contains(region)) {
						messageBean.addMessage(Resources.getString("error.regiones.nopermitidas"), FacesMessage.SEVERITY_ERROR);
						return false;
					}
				}
			} else {
				if (reg.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL)) {
					List<Zona> zonas = reg.getMarcoGeografico().getZonas();
					for (Zona zona : zonas) {
						if (!user.getContext().getRegionesDisponibles().contains(zona.getRegionResponsable())) {
							messageBean.addMessage(Resources.getString("error.zonas.nopermitidas"), FacesMessage.SEVERITY_ERROR);
							return false;
						}
					}
				}
			}
		}
		return true;
	}

	public String prepararVerReglamentacion(Reglamentacion reg) {
		try {
			tiposServicio = tipoServicioManager.getAllTiposServicioByUsuario(currentSessionBean.getUser());
			this.setReglamentacionDB(reg);
		//	this.setIdTipoDocumento(reg.getTipoDocumento().getId());
			this.setIdReglamentacionDeQueDepende((reg.getReglamentacionDeQueDepende() == null) ? null : reg.getReglamentacionDeQueDepende().getId());
			reg.getMarcoGeografico().setSource(new MarcoGeograficoSource());
			marcoGeograficoFilterSource.updateData(ubicacionGeograficaManager, zonaManager, new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL,
					MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser());
			reglamentacionesHistorial = reglamentacionManager.getHistoralReglamentaciones(reg);
			// reglamentacionesTable=null;
			pagedListDataModel = null;
			this.sessionCacheManager.saveState(this);
			return "success_prepararVerReglamentacion";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararVerReglamentacion";
	}



	public String prepararVerNormativas(Reglamentacion reg) {
		if (!validateMarcosGeograficosUsuario(reg)) {
			this.sessionCacheManager.saveState(this);
			return "error_prepararVerNormativas";
		}
		try {
			JAXBContext context = JAXBContext.newInstance(ReglamentacionXML.class);
			reglamentacion = (ReglamentacionXML) context.createUnmarshaller().unmarshal(ReglamentacionXML.class.getResourceAsStream("/normativas.xml"));

			normativas = new HashMap<String, GenericNormativa>();
			// gruposLoaded=new HashMap<String, Boolean>();
			tiposServicio = tipoServicioManager.getAllTiposServicioByUsuario(currentSessionBean.getUser());

			reglamentacionDB = reglamentacionManager.getReglamentacionByIdForEditing(reg.getId());
//			 List<Normativa>
//			 ns=reglamentacionManager.getNormativasByReglamentacion(reglamentacionDB);
//			 if(ns.size()==0)
//			 reglamentacionManager.initializeNormativas(reglamentacionDB);
//			reglamentacionDB.setNormativasInicializadas(false);
			reglamentacionManager.initializeNormativas(reglamentacionDB);

			if (reglamentacionDB.getMarcoGeografico() == null) {
				reglamentacionDB.setMarcoGeografico(new MarcoGeografico(MarcoGeograficoSource.AMBITO_REGIONAL));
			}
			
//			currentSessionBean.setNormativasCache(reglamentacionDB, new NormativasCache(this));

//			this.normativasCache = new NormativasCache(this);
			MarcoGeograficoSource source = new MarcoGeograficoSource();
			
			Date durationDate = new Date();
			marcoGeograficoFilterSource.updateData(ubicacionGeograficaManager, zonaManager, new String[] { MarcoGeograficoSource.AMBITO_NACIONAL, MarcoGeograficoSource.AMBITO_REGIONAL,
					MarcoGeograficoSource.AMBITO_ZONAL }, currentSessionBean.getUser());
			Logger.getLogger(this.getClass()).error(new Duration(durationDate,new Date()).getDuracionText("marcoGeograficoFilterSource.updateData"));
			reglamentacionDB.getMarcoGeografico().setSource(source);
			
			durationDate = new Date();
//			currentSessionBean.getNormativasCache(reglamentacionDB).setMarcoGeograficoCompleto(source);
			Logger.getLogger(this.getClass()).error(new Duration(durationDate,new Date()).getDuracionText("getNormativasCache(reglamentacionDB).setMarcoGeograficoCompleto(source)"));
            
//			this.normativasCache.setMarcoGeograficoCompleto(source);

			try {
			    durationDate = new Date();
				updateNormas();
				Logger.getLogger(this.getClass()).error(new Duration(durationDate,new Date()).getDuracionText("updateNormas()"));
				
			} catch (ReglamentacionInvalidaTipoVehiculos e) {
				boolean esnuevaNormativa = esNuevaNormativa();
				if (!esnuevaNormativa) {
					messageBean.addMessage(e.getMessage(), FacesMessage.SEVERITY_WARN);
				}
			}
			
//			try {
//			    durationDate = new Date();
//				EventManager em = new EventManager(this.getReglamentacionDB(), this.getReglamentacionManager(), tipoServicioManager);
//				Logger.getLogger(this.getClass()).error(new Duration(durationDate,new Date()).getDuracionText("updateNormas()"));
                
//				currentSessionBean.getNormativasCache(reglamentacionDB).setNormaTipoVehiculos(;
				
//				normativasCache.setNormaTipoVehiculos((NormasTiposVehiculoPermitido) em.getNormativaAplicada(this.getReglamentacionDB(), Normativa.descriptorTiposVehiculosPermitidos));
//				if (currentSessionBean.getNormativasCache(reglamentacionDB).getNormaTipoVehiculos() == null) {
//					boolean esnuevaNormativa = esNuevaNormativa();
//					if (!esnuevaNormativa) {
//						messageBean.addMessage(Resources.getString("reglamentacion.error.tipovehiculo.noreglamenta"), FacesMessage.SEVERITY_WARN);
//					}
//				}
//			} catch (JAXBException e) {
//				Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
//			} catch (EventEvalException e) {
//				Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
//			}

			this.sessionCacheManager.saveState(this);
			this.getGruposAutorizacion();
			return "success_prepararVerNormativas";
		} catch (JAXBException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		this.sessionCacheManager.saveState(this);
		return "error_prepararVerNormativas";
	}

	/**
	 * @return
	 */
	private boolean esNuevaNormativa() {
		boolean esnuevaNormativa = true;

		if (normativas != null) {
			for (Entry<String, GenericNormativa> entry : normativas.entrySet()) {
				GenericNormativa norm = entry.getValue();
				if (norm.getNormativa().getId() != null) {
					esnuevaNormativa = false;
				}
			}
		}
		return esnuevaNormativa;
	}

	private void estimarTablaInicial() {
		try {
			updateFiltros();
			int totalListSize = new Long(reglamentacionManager.getReglamentacionesCount(filters, optionalsFilters)).intValue();
			setTotalListSize(totalListSize);

		} catch (GeneralDataAccessException e) {
			pagedListDataModel = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModel = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public String guardarNuevaReglamentacion() {
		try {
			if (reglamentacionDB.getVigenciaHasta() == null || ValidacionHelper.esFechaMayor(reglamentacionDB.getVigenciaHasta(), reglamentacionDB.getVigenciaDesde())) {
				reglamentacionDB.setTipoReglamentacion(reglamentacionManager.getTipoReglamentacionById(idTipoReglamentacion));
				//reglamentacionDB.setTipoDocumento(reglamentacionManager.getTipoDocumentoById(idTipoDocumento));
				if (idReglamentacionDeQueDepende != null)
					reglamentacionDB.setReglamentacionDeQueDepende(reglamentacionManager.getReglamentacionById(idReglamentacionDeQueDepende));

				
				//validar configuracion
				if (!validarConfiguracion(reglamentacionDB)) {
					this.reglamentacionDB.getMarcoGeografico().setId(null);
					pagedListDataModel = null;
					sessionCacheManager.saveState(this);
					return "error_guardarNuevaReglamentacion";
				}
				
				reglamentacionManager.saveReglamentacion(reglamentacionDB);
				
				loadDataModel();
				sessionCacheManager.saveState(this);
				return "success_guardarNuevaReglamentacion";
			} else {
				messageBean.addMessage(Resources.getString("reglamentacion.message.fechaVigenciaDesdeInvalida"), FacesMessage.SEVERITY_ERROR);
				return null;
			}
		} catch (GeneralDataAccessException e) {
			this.reglamentacionDB.getMarcoGeografico().setId(null);
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);

		}

		pagedListDataModel = null;
		sessionCacheManager.saveState(this);
		return "error_guardarNuevaReglamentacion";
	}

	private boolean validarConfiguracion(Reglamentacion reg) {
		if (reg.getAplicaVehiculos().equals(Reglamentacion.APLICACION_TODOS_VEHICULOS)) {
			if (reg.getSeleccionableVehiculo()==null || !reg.getSeleccionableVehiculo()) {
				messageBean.addMessage(Resources.getString("reglamentacion.message.configinv.noselvehiculos"), FacesMessage.SEVERITY_ERROR);
				return false;
			}
		}
		return true;
	}

	public String revertirReglamentacion() {
		try {
			Reglamentacion r = reglamentacionManager.getReglamentacionById(reglamentacionDB.getId());
			prepararModificarReglamentacion(r);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_revertirReglamentacion";
		}
		return "success_revertirReglamentacion";
	}

	public String editarReglamentacion() {
		try {
			if (reglamentacionDB.getVigenciaHasta() == null || ValidacionHelper.esFechaMayor(reglamentacionDB.getVigenciaHasta(), reglamentacionDB.getVigenciaDesde())) {
			//	reglamentacionDB.setTipoDocumento(reglamentacionManager.getTipoDocumentoById(idTipoDocumento));
				if (idReglamentacionDeQueDepende != null)
					reglamentacionDB.setReglamentacionDeQueDepende(reglamentacionManager.getReglamentacionById(idReglamentacionDeQueDepende));
				

				//validar configuracion
				if (!validarConfiguracion(reglamentacionDB)) {
					pagedListDataModel = null;
					sessionCacheManager.saveState(this);
					return "error_guardarNuevaReglamentacion";
				}

				reglamentacionDB.getMarcoGeografico().unlockLocalizables();
				if (permiteModificarTipoServicio)
					reglamentacionDB.setTiposServicio(tiposServicioSeleccionados);
				else
					reglamentacionDB.getTiposServicio().addAll(tiposServicioSeleccionados);
				reglamentacionManager.updateReglamentacion(reglamentacionDB);

				// reglamentacionesTable=null;
				pagedListDataModel = null;
				sessionCacheManager.saveState(this);

				return "success_editarReglamentacion";
			} else {
				messageBean.addMessage(Resources.getString("reglamentacion.message.fechaVigenciaDesdeInvalida"), FacesMessage.SEVERITY_ERROR);
				return null;
			}
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);

		}

		pagedListDataModel = null;
		sessionCacheManager.saveState(this);
		return "error_editarReglamentacion";
	}

	public void revertirNormas(String normativaDescriptor) {
		try {
			for (Grupo grupo : reglamentacion.getGrupo()) {
				for (SubGrupo subGrupo : grupo.getSubGrupo()) {
					for (Norma norma : subGrupo.getNorma()) {
						if (norma.getDescriptor().equals(normativaDescriptor)) {
//							Normativa n = reglamentacionManager.getNormativaByReglamentacionAndDescriptor(reglamentacionDB.getId(), norma.getDescriptor());
							// n.setRequiereMarcoGeografico((norma.getRequiereMarcoGeografico()==null)?false:norma.getRequiereMarcoGeografico());
							// n.setRequiereTipoServicio((norma.getRequiereTipoServicio()==null)?false:norma.getRequiereTipoServicio());
							GenericNormativa normativa = NormativaAccess.getInstance().getNormativa(reglamentacionDB, norma.getDescriptor()) ;
//						try {
//							normativa.populate(this, n);
//						} catch (ReglamentacionInvalidaTipoVehiculos e) {
//							messageBean.addMessage(e.getMessage(), FacesMessage.SEVERITY_ERROR);
//						}

							normativas.put(norma.getDescriptor(), normativa);
							return;
						}
					}
				}
			}
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (InstantiationException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (IllegalAccessException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (ClassNotFoundException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (IllegalArgumentException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (SecurityException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (InvocationTargetException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (NoSuchMethodException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
	}

	public void populateNormativa(String descriptor) {
		try {
			// descriptor=descriptor.substring(String.valueOf(reglamentacionDB.getId()).length()*2+2);
			GenericNormativa normativa = normativas.get(descriptor);
			try {
				normativa.populateIfNotLoaded(reglamentacionManager, NormativaAccess.getInstance().getNormativa(reglamentacionDB, descriptor).getNormativa());
				if(normativa.getNormativa().getAutorizacion() == null)
					normativa.getNormativa().setAutorizacion(this.autorizacionManager.getAutorizacionByNormativa(normativa.getNormativa().getId()));
				normativa.initializeAutorizacion();
			} catch (ReglamentacionInvalidaTipoVehiculos e) {
				messageBean.addMessage(e.getMessage(), FacesMessage.SEVERITY_ERROR);
			}

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public void updateNormas() throws ReglamentacionInvalidaTipoVehiculos {
	    Date durationDate = new Date();
		try {
//		    List<Normativa> normativasByReglamentacion = reglamentacionManager.getNormativasByReglamentacion(reglamentacionDB);
		    HashMap<String, Normativa> normativasHash = new HashMap<String, Normativa>();
		    for (Normativa normativa : reglamentacionDB.getNormativas()) {
		        normativa.setReglamentacion(reglamentacionDB);
		        normativasHash.put(normativa.getDescriptor(), normativa);
            }
			for (Grupo grupo : reglamentacion.getGrupo()) {
				for (SubGrupo subGrupo : grupo.getSubGrupo()) {
					for (Norma norma : subGrupo.getNorma()) {
						Normativa n = normativasHash.get(norma.getDescriptor());
						if(n==null){
							n=new Normativa();
						}
						GenericNormativa normativa = (GenericNormativa) Class.forName(norma.getImplementacion().getClassName()).getConstructor(Normativa.class).newInstance(n);
						normativa.setPermiteAutorizacionXML(norma.getPermiteExcepcion());
						normativas.put(norma.getDescriptor(), normativa);
					}
				}
			}
			Logger.getLogger(this.getClass()).error(new Duration(durationDate,new Date()).getDuracionText("NORMAS CARGADAS AL XML"));
            
		} catch (InstantiationException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (IllegalAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (ClassNotFoundException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//		} catch (GeneralDataAccessException e) {
//			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (IllegalArgumentException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (SecurityException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (InvocationTargetException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (NoSuchMethodException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		// Hago el populate de la primera, ya que la necesitamos
		try {
		    durationDate = new Date();
		    
			GenericNormativa normativa = normativas.get(Normativa.descriptorTiposVehiculosPermitidos);
			if (!normativa.isLoaded()) {
			    normativa.populateIfNotLoaded(reglamentacionManager, normativa.getNormativa());
//				GenericNormativa normativaAplicada = NormativaAccess.getInstance().getNormativaAplicada(this.getReglamentacionDB(), Normativa.descriptorTiposVehiculosPermitidos);
//			    if (normativaAplicada!=null) {
//			        normativas.put(Normativa.descriptorTiposVehiculosPermitidos, normativaAplicada);
//			    }
//			    else {
//			        throw new ReglamentacionInvalidaTipoVehiculos();
//			    }
			}
			Logger.getLogger(this.getClass()).error(new Duration(durationDate,new Date()).getDuracionText("POPULA descriptorTiposVehiculosPermitidos"));
			durationDate = new Date();
			normativa = normativas.get(Normativa.descriptorVehiculosPrestandoOtrosServicios);
			if (!normativa.isLoaded()) {
			    normativa.populateIfNotLoaded(reglamentacionManager, normativa.getNormativa());

//			    GenericNormativa normativaAplicada = NormativaAccess.getInstance().getNormativaAplicada(this.getReglamentacionDB(), Normativa.descriptorVehiculosPrestandoOtrosServicios);
//                normativas.put(Normativa.descriptorVehiculosPrestandoOtrosServicios, normativaAplicada);
				
			}
			Logger.getLogger(this.getClass()).error(new Duration(durationDate,new Date()).getDuracionText("POPULA descriptorVehiculosPrestandoOtrosServicios"));
		} 
//        catch (EventEvalException e) {
//            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//        }
        catch (GeneralDataAccessException e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
        }

	}

	public MarcoGeograficoSource getMarcoGeograficoFilterSource() {
		return marcoGeograficoFilterSource;
	}

	public void setMarcoGeograficoFilterSource(MarcoGeograficoSource marcoGeograficoFilterSource) {
		this.marcoGeograficoFilterSource = marcoGeograficoFilterSource;
	}

	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public TipoServicioManager getTipoServicioManager() {
		return tipoServicioManager;
	}

	public void setTipoServicioManager(TipoServicioManager tipoServicioManager) {
		this.tipoServicioManager = tipoServicioManager;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public TipoServicioAreaManager getTipoServicioAreaManager() {
		return tipoServicioAreaManager;
	}

	public void setTipoServicioAreaManager(TipoServicioAreaManager tipoServicioAreaManager) {
		this.tipoServicioAreaManager = tipoServicioAreaManager;
	}

	public ReglamentacionXML getReglamentacion() {
		return reglamentacion;
	}

	public void setReglamentacion(ReglamentacionXML reglamentacion) {
		this.reglamentacion = reglamentacion;
	}

	public Map<String, GenericNormativa> getNormativas() {
		return normativas;
	}

	public void setNormativas(Map<String, GenericNormativa> normativas) {
		this.normativas = normativas;
	}

	public List<SelectionItem> properties(String keyGroup) {
		return PropertiesManager.getProperties(keyGroup);
	}

	public String property(String key) {
		return PropertiesManager.getProperty(key);
	}

	public ReglamentacionManager getReglamentacionManager() {
		return reglamentacionManager;
	}

	public void setReglamentacionManager(ReglamentacionManager reglamentacionManager) {
		this.reglamentacionManager = reglamentacionManager;
	}

	public void firstSaveChanges() {
		saveChangesAll(false);
	}
	
	
	public void saveChanges() {
		saveChangesAll(true);
	}

	public String saveChangesAndReturn() {
		saveChangesAll(true);
		return prepararListarReglamentaciones();
	}
	
	/**
	 * Si valido todo es true, valida todas las normas cargadas, sino solo valida Tipos de vehiculos permitidos (obligatoria)
	 * @param validoTodo
	 */
	public void saveChangesAll(boolean validoTodo) {
		try {
			// primero hago las validaciones
			boolean valid = true;
			List<GenericNormativa> norms = new ArrayList<GenericNormativa>();
			for (GenericNormativa gn : normativas.values()) {
			    if (gn!=null){
			        norms.add(gn);
			    }
			}
			if (validoTodo) {
				for (GenericNormativa normativaXML : norms) {
					valid = valid && normativaXML.validateDataForSaving();
				}
			}
			else {
				for (GenericNormativa normativaXML : norms) {
					if (normativaXML.getNormativa().getDescriptor().equals(Normativa.descriptorTiposVehiculosPermitidos)) {
						valid = valid && normativaXML.validateDataForSaving();
					}
				}
			}
			if (!valid) {
				// return "validation_error_saveChanges";
				return;
			}
			List<Normativa> normsDB = new ArrayList<Normativa>();
			
			for (GenericNormativa normativaXML : norms) {
				if (normativaXML.isLoaded()){
					Normativa n = normativaXML.getNormativaDataForSaving();
					if(n.getPermiteAutorizacion()){
						if(n.getAutorizacion().getId() == null){
							n.getAutorizacion().setDbAction(GenericModelObject.ACTION_SAVE);
						}
						else{
							n.getAutorizacion().setDbAction(GenericModelObject.ACTION_UPDATE);
						}
						
					}
					normsDB.add(n);
				}
			}
			for (Normativa normativa : normsDB) {
			    if (reglamentacionDB.getNormativas().indexOf(normativa)>0) {
			        reglamentacionDB.getNormativas().set(reglamentacionDB.getNormativas().indexOf(normativa) , normativa);
			    }
			}
			reglamentacionManager.updateNormativas(reglamentacionDB,normsDB);	
			
			boolean esvalidatipovehiculo = true;
			try {
				this.updateNormas();
			} catch (ReglamentacionInvalidaTipoVehiculos e) {
				esvalidatipovehiculo = false;
			}
			// cargar las normativas que estaban abiertas antes
			for (Normativa normativa : normsDB) {
				populateNormativa(normativa.getDescriptor());
			}
			populateNormativa(Normativa.descriptorTiposVehiculosPermitidos);
			
			NormativaAccess.getInstance().updateCacheDataReglamentacion(reglamentacionDB);
			if (esvalidatipovehiculo)
				messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
			else
				messageBean.addMessage(Resources.getString("reglamentacion.warnsave.tipovehiculo.noreglamenta"), FacesMessage.SEVERITY_WARN);
			// return "success_saveChanges";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		// return "error_saveChanges";
	}
	
	// Mejoras 201409 Nro: 75
	@SuppressWarnings("unused")
    private void completarCreationModified (GenericModelObject data, boolean creation){
		java.util.Date utilDate = new java.util.Date();
		long lnMilisegundos = utilDate.getTime();
		if(creation){
			data.setCreation(new Timestamp(lnMilisegundos));
			data.setModified(new Timestamp(lnMilisegundos));
			data.setUserCreation(this.getCurrentSessionBean().getUser());
			data.setUserModified(this.getCurrentSessionBean().getUser());
		}
		else{
			data.setModified(new Timestamp(lnMilisegundos));
			data.setUserModified(this.getCurrentSessionBean().getUser());
		}
	}
	// Mejoras 201409 Nro: 75
	
	public VehiculoManager getVehiculoManager() {
		return vehiculoManager;
	}

	public void setVehiculoManager(VehiculoManager vehiculoManager) {
		this.vehiculoManager = vehiculoManager;
	}

	public Reglamentacion getReglamentacionDB() {
		return reglamentacionDB;
	}

	public void setReglamentacionDB(Reglamentacion reglamentacionDB) {
		this.reglamentacionDB = reglamentacionDB;
	}

	public UbicacionGeograficaManager getUbicacionGeograficaManager() {
		return ubicacionGeograficaManager;
	}

	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	private void updateFiltros() {

		if (filters.get("tipoReglamentacion.id") == null)
			filters.remove("tipoReglamentacion.id");
		else if (filters.get("tipoReglamentacion.id") instanceof String)
			filters.put("tipoReglamentacion.id", Long.parseLong((String) filters.get("tipoReglamentacion.id")));

		if (filters.get("tiposServicio.tipoTransporte.id") == null)
			filters.remove("tiposServicio.tipoTransporte.id");
		else if (filters.get("tiposServicio.tipoTransporte.id") instanceof String)
			filters.put("tiposServicio.tipoTransporte.id", Long.parseLong((String) filters.get("tiposServicio.tipoTransporte.id")));

		if (filters.get("tiposServicio.categoriaTransporte.id") == null)
			filters.remove("tiposServicio.categoriaTransporte.id");
		else if (filters.get("tiposServicio.categoriaTransporte.id") instanceof String)
			filters.put("tiposServicio.categoriaTransporte.id", Long.parseLong((String) filters.get("tiposServicio.categoriaTransporte.id")));

		if (filters.get("tiposServicio.medioTransporte.id") == null)
			filters.remove("tiposServicio.medioTransporte.id");
		else if (filters.get("tiposServicio.medioTransporte.id") instanceof String)
			filters.put("tiposServicio.medioTransporte.id", Long.parseLong((String) filters.get("tiposServicio.medioTransporte.id")));

		if (filters.get("tiposServicio.tipoServicioArea.id") == null)
			filters.remove("tiposServicio.tipoServicioArea.id");
		else if (filters.get("tiposServicio.tipoServicioArea.id") instanceof String)
			filters.put("tiposServicio.tipoServicioArea.id", Long.parseLong((String) filters.get("tiposServicio.tipoServicioArea.id")));

		if (filters.get("tiposServicio.modalidad.id") == null)
			filters.remove("tiposServicio.modalidad.id");
		else if (filters.get("tiposServicio.modalidad.id") instanceof String)
			filters.put("tiposServicio.modalidad.id", Long.parseLong((String) filters.get("tiposServicio.modalidad.id")));

		// Mejoras 201409 Nro: 2
		filters.remove("marcoGeografico.aplicableA");
		filters.remove("marcoGeografico.marcosGeograficoslocalizables.idLocalizable");
		if (this.aplicaAFiltro != null) {
			if (this.aplicaAFiltro.equals(MarcoGeograficoSource.AMBITO_NACIONAL)){
				filters.put("marcoGeografico.aplicableA", MarcoGeograficoSource.AMBITO_NACIONAL);
			} else if(this.aplicaAFiltro.equals(MarcoGeograficoSource.AMBITO_REGIONAL)){
				filters.put("marcoGeografico.aplicableA", MarcoGeograficoSource.AMBITO_REGIONAL);
				if (this.idRegionFiltro != null) {
					filters.put("marcoGeografico.marcosGeograficoslocalizables.idLocalizable", this.idRegionFiltro);
				}
			} else if(this.aplicaAFiltro.equals(MarcoGeograficoSource.AMBITO_ZONAL)){
				filters.put("marcoGeografico.aplicableA", MarcoGeograficoSource.AMBITO_ZONAL);
				if (this.idZonaFiltro != null) {
					filters.put("marcoGeografico.marcosGeograficoslocalizables.idLocalizable", this.idZonaFiltro);
				}else{
					List<Zona> zonas = marcoGeograficoFilterSource.getZonasFiltradasPorRegion(idRegionFiltro, tipoZonaFilter);
					List<String> ids = new ArrayList<String>(zonas.size());
					for (Zona z : zonas) {
						ids.add(z.getIdentifier());
					}
					filters.put("marcoGeografico.marcosGeograficoslocalizables.idLocalizable", ids);
				}
			}	
		}
		// Mejoras 201409 Nro: 2

		if (filters.get("estado") == null)
			filters.remove("estado");

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void loadDataModel() {
		try {
			updateFiltros();
			int totalListSize = new Long(reglamentacionManager.getReglamentacionesCount(filters, optionalsFilters)).intValue();
			setTotalListSize(totalListSize);
			int rows = Integer.valueOf(currentSessionBean.getTablaPaginacion().get(Constants.TABLA_LISTADO_REGLAMENTACION));
			int first = (this.getCurrentPage() - 1) * rows;// this.getReglamentacionesTable().getRows();

			// Si sucede esto es que hay menos elementos que páginas
			if ((first / rows) > (Math.ceil(totalListSize / rows))) {
				first = 0;
				setCurrentPage(1);
			}

			// this.getReglamentacionesTable().setFirst(0);
			List<String> order = new ArrayList<String>();
			if (this.getSortingField() != null && !this.getSortingField().equals("")) {
				order.add(this.getSortingField() + ((this.getSortingAsc()) ? "" : " desc"));
			}
			order.add("modified desc");

			List<Reglamentacion> items = reglamentacionManager.getReglamentacionesPage(first, rows, filters, order, this.optionalsFilters);

			pagedListDataModel = new PagedListDataModel(new ArrayList(items), totalListSize, rows);

			// sessionCacheManager.saveState(this);

		} catch (CriteriaDefinitionException e) {
			setTotalListSize(0);
			pagedListDataModel = new PagedListDataModel(new ArrayList(), 0, 0);
		} catch (GeneralDataAccessException e) {
			pagedListDataModel = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModel = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}

	public void actualizarFilas() {
		this.loadDataModel();
	}
	
	public void sortCollection(String currentFieldOrder) {
		if(sorters == null){
			sorters = new HashMap<String, Boolean>();
		}
		Boolean lastOrderIsAsc = sorters.get(currentFieldOrder);
		if(lastOrderIsAsc == null || !lastOrderIsAsc.booleanValue()){
			lastOrderIsAsc = true;
		}else{
			lastOrderIsAsc = false;
		}
		sorters.put(currentFieldOrder, lastOrderIsAsc);
		this.sortingField = currentFieldOrder;
		this.sortingAsc = lastOrderIsAsc;
		this.loadDataModel();		
	}

	@SuppressWarnings("rawtypes")
	public DataModel getReglamentacionesPagedDataModel() {
		if (pagedListDataModel == null)
			this.loadDataModel();
		return this.pagedListDataModel;

	}

	// public UIDataTable getReglamentacionesTable() {
	// return reglamentacionesTable;
	// }
	//
	// public void setReglamentacionesTable(UIDataTable reglamentacionesTable) {
	// this.reglamentacionesTable = reglamentacionesTable;
	// }

	public int getTotalListSize() {
		return totalListSize;
	}

	public void setTotalListSize(int totalListSize) {
		this.totalListSize = totalListSize;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		if (this.currentPage != currentPage) {
			this.currentPage = currentPage;
			this.loadDataModel();
		}

	}

	public String getSortingField() {
		return sortingField;
	}

	public void setSortingField(String sortingField) {
		this.sortingField = sortingField;
	}

	public Boolean getSortingAsc() {
		return sortingAsc;
	}

	public void setSortingAsc(Boolean sortingAsc) {
		this.sortingAsc = sortingAsc;
	}

	public List<TipoReglamentacion> getTiposReglamentacion() {
		if (tiposReglamentacion == null) {
			try {
				tiposReglamentacion = reglamentacionManager.getTiposReglamentacion();
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
		return tiposReglamentacion;
	}

	public void setTiposReglamentacion(List<TipoReglamentacion> tiposReglamentacion) {
		this.tiposReglamentacion = tiposReglamentacion;
	}

	public Long getIdTipoReglamentacion() {
		return idTipoReglamentacion;
	}

	public void setIdTipoReglamentacion(Long idTipoReglamentacion) {
		this.idTipoReglamentacion = idTipoReglamentacion;
	}

	
//	public List<TipoDocumento> getTiposDocumento() {
//		if (tiposDocumento == null) {
//			try {
//				tiposDocumento=new ArrayList<TipoDocumento>();
//				materiasSeleccionables=new HashMap<Long, List<String>>();
//				
//				List<TipoDocumentoSeleccionable> tiposDocumentoSel = reglamentacionManager.getTiposDocumento();
//				for (TipoDocumentoSeleccionable td: tiposDocumentoSel) {
//					tiposDocumento.add(td.getTipoDocumento());
//					materiasSeleccionables.put(td.getTipoDocumento().getId(), td.getMaterias());
//				}
//				
//			} catch (GeneralDataAccessException e) {
//				Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
//				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
//			}
//		}
//		return tiposDocumento;
//	}
	
	/**
	 * @return el valor de materiasSeleccionables
	 */
//	public List<String> getMateriasSeleccionables() {
//		if(idTipoDocumento!=null){
//			return materiasSeleccionables.get(idTipoDocumento);
//		}
//		return null;
//	}


//	public void setTiposDocumento(List<TipoDocumento> tiposDocumento) {
//		this.tiposDocumento = tiposDocumento;
//	}

//	public Long getIdTipoDocumento() {
//		return idTipoDocumento;
//	}
//
//	public void setIdTipoDocumento(Long idTipoDocumento) {
//		this.idTipoDocumento = idTipoDocumento;
//	}

	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	public void filterDataTable() {
		this.loadDataModel();
	}

	public List<Reglamentacion> getReglamentaciones() {
		// if(reglamentaciones==null){
		// try {
		// reglamentaciones=reglamentacionManager.getReglamentaciones();
		// } catch (GeneralDataAccessException e) {
		// Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
		// messageBean.addMessage(Resources.getString("error.generico"),
		// FacesMessage.SEVERITY_ERROR);
		// }
		// }
		return reglamentaciones;
	}

	public void setReglamentaciones(List<Reglamentacion> reglamentaciones) {
		this.reglamentaciones = reglamentaciones;
	}

	public Long getIdReglamentacionDeQueDepende() {
		return idReglamentacionDeQueDepende;
	}

	public void setIdReglamentacionDeQueDepende(Long idReglamentacionDeQueDepende) {
		this.idReglamentacionDeQueDepende = idReglamentacionDeQueDepende;
	}

	public Map<String, Object> getFilters() {
		return filters;
	}

	public void setFilters(Map<String, Object> filters) {
		this.filters = filters;
	}

	public List<TipoTransporte> getTiposTransporte() {
		return tiposTransporte;
	}

	public List<MedioTransporte> getMediosTransporte() {
		return mediosTransporte;
	}

	public List<CategoriaTransporte> getCategoriasTransporte() {
		return categoriasTransporte;
	}

	public List<TipoServicioArea> getTiposServicioArea() {
		return tiposServicioArea;
	}

	public List<Modalidad> getModalidades() {
		return modalidades;
	}

	public TipoTransporteManager getTipoTransporteManager() {
		return tipoTransporteManager;
	}

	public void setTipoTransporteManager(TipoTransporteManager tipoTransporteManager) {
		this.tipoTransporteManager = tipoTransporteManager;
	}

	public CategoriaTransporteManager getCategoriaTransporteManager() {
		return categoriaTransporteManager;
	}

	public void setCategoriaTransporteManager(CategoriaTransporteManager categoriaTransporteManager) {
		this.categoriaTransporteManager = categoriaTransporteManager;
	}

	public MedioTransporteManager getMedioTransporteManager() {
		return medioTransporteManager;
	}

	public void setMedioTransporteManager(MedioTransporteManager medioTransporteManager) {
		this.medioTransporteManager = medioTransporteManager;
	}

	public ModalidadManager getModalidadManager() {
		return modalidadManager;
	}

	public void setModalidadManager(ModalidadManager modalidadManager) {
		this.modalidadManager = modalidadManager;
	}

	public void setTiposTransporte(List<TipoTransporte> tiposTransporte) {
		this.tiposTransporte = tiposTransporte;
	}

	public void setMediosTransporte(List<MedioTransporte> mediosTransporte) {
		this.mediosTransporte = mediosTransporte;
	}

	public void setCategoriasTransporte(List<CategoriaTransporte> categoriasTransporte) {
		this.categoriasTransporte = categoriasTransporte;
	}

	public void setTiposServicioArea(List<TipoServicioArea> tiposServicioArea) {
		this.tiposServicioArea = tiposServicioArea;
	}

	public void setModalidades(List<Modalidad> modalidades) {
		this.modalidades = modalidades;
	}

	public List<Reglamentacion> getReglamentacionesHistorial() {
		return reglamentacionesHistorial;
	}

	public void setReglamentacionesHistorial(List<Reglamentacion> reglamentacionesHistorial) {
		this.reglamentacionesHistorial = reglamentacionesHistorial;
	}

	public List<Reglamentacion> getReglamentacionesPadre() {
		return reglamentacionesPadre;
	}

	public void setReglamentacionesPadre(List<Reglamentacion> reglamentacionesPadre) {
		this.reglamentacionesPadre = reglamentacionesPadre;
	}

	public boolean isPermiteModificarMarcoGeografico() {
		return permiteModificarMarcoGeografico;
	}

	public void setPermiteModificarMarcoGeografico(boolean permiteModificarMarcoGeografico) {
		this.permiteModificarMarcoGeografico = permiteModificarMarcoGeografico;
	}

	public boolean isPermiteModificarTipoServicio() {
		return permiteModificarTipoServicio;
	}

	public void setPermiteModificarTipoServicio(boolean permiteModificarTipoServicio) {
		this.permiteModificarTipoServicio = permiteModificarTipoServicio;
	}

	public List<TipoServicio> getTiposServicioSeleccionados() {
		return tiposServicioSeleccionados;
	}

	public void setTiposServicioSeleccionados(List<TipoServicio> tiposServicioSeleccionados) {
		this.tiposServicioSeleccionados = tiposServicioSeleccionados;
	}

	public boolean isShowNormativasAll() {
		return true;// NormativaAccess.getInstance().getNormativasDataCache(reglamentacionDB).getNormaTipoVehiculos() != null;
	}

	public boolean getShowNormativasAll() {
		return true;//isShowNormativasAll();
	}

	/**
	 * @return el valor de normativasCache
	 */
//	public NormativasCache getNormativasCache(Reglamentacion reglamentacion) {
//		NormativasCache nc = currentSessionBean.getNormativasCache(reglamentacion);
//
//		if (nc == null)
//			try {
//				currentSessionBean.initNormativasCahce(reglamentacion,this);
//			} catch (GeneralDataAccessException e) {
//				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//			} catch (JAXBException e) {
//				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//			} catch (EventEvalException e) {
//				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//			}
//		return currentSessionBean.getNormativasCache(reglamentacion);
//	}

//	public NormativasCache getNormativasCache() {
//		return currentSessionBean.getNormativasCache(reglamentacionDB);
//	}


	/**
	 * @param setea
	 *            el parametro normativasCache al campo normativasCache
	 */
//	public void setNormativasCache(NormativasCache normativasCache) {
//		currentSessionBean.setNormativasCache(reglamentacionDB,normativasCache);
//	}

	public void limpiarFiltro() {
		this.filters = new HashMap<String, Object>();
		this.idRegionFiltro = null;
		// Mejoras 201409 Nro: 2
		this.aplicaAFiltro = null;
		this.idZonaFiltro = null;
		// Mejoras 201409 Nro: 2
		this.filterDataTable();
	}

	public void dependenciaCheckChanged(AjaxBehaviorEvent abe) {
		if ((this.getReglamentacionDB().getEspecificadaSobreExistente() == null) || (!this.getReglamentacionDB().getEspecificadaSobreExistente())) {
			this.getReglamentacionDB().setEspecificadaSobreExistente(null);
		}

	}
	// Mejoras 201409 Nro: 3
	
	
	
	public void eliminarReglamentacion(){
		try {
			Reglamentacion reg = reglamentacionManager.getReglamentacionById(idReglamentacion);
			if (!validateMarcosGeograficosUsuario(reg)) {
				return;
			}
			int count=reglamentacionManager.getCantidadUsesOfReglamentacion(idReglamentacion);
			if (count>0){
				messageBean.addMessage(Resources.getString("reglamentacion.message.delete.noSePuede"), FacesMessage.SEVERITY_WARN);
				return;
			}
			reglamentacionManager.removeReglamentacion(idReglamentacion);
			loadDataModel();
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public Long getIdReglamentacion() {
		return idReglamentacion;
	}

	public void setIdReglamentacion(Long idReglamentacion) {
		this.idReglamentacion = idReglamentacion;
	}
	
	// Mejoras 201409 Nro: 3
	
	
	// Mejoras 201409 Nro: 75
	private void getGruposAutorizacion(){
		try{
				List<Region> regiones = new ArrayList<Region>();
				Region todaLasRegiones = new Region();
				todaLasRegiones.setCodigo("00");
				this.getGrupos().clear();
				List<Long> tipoTransporte = new ArrayList<Long>();
				List<Long> medioTransporte = new ArrayList<Long>();
				List<Long> categoriaTransporte = new ArrayList<Long>();
				if(reglamentacionDB.getTiposServicio() != null ){
					for(TipoServicio ts :reglamentacionDB.getTiposServicio()){
						if(!tipoTransporte.contains(ts.getTipoTransporte().getId()))
							tipoTransporte.add(ts.getTipoTransporte().getId());
						if(!medioTransporte.contains(ts.getMedioTransporte().getId()))
							medioTransporte.add(ts.getMedioTransporte().getId());
						if(!categoriaTransporte.contains(ts.getCategoriaTransporte().getId()))
							categoriaTransporte.add(ts.getCategoriaTransporte().getId());
					}
				}
				if(reglamentacionDB.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL)){
					regiones = new ArrayList<Region>();
					Region aplicaNacion = new Region();
					aplicaNacion.setCodigo("");
					regiones.add(aplicaNacion);		
					this.grupos = grupoManager.getGruposByRegionesAndCategorias(regiones,tipoTransporte,medioTransporte,categoriaTransporte);
					//Grupos de todas las regiones tambien ingresan en grupos
					regiones.clear();
					regiones.add(todaLasRegiones);
	                List<cl.mtt.rnt.commons.model.core.autorizacion.Grupo> grupoTodasRegiones = grupoManager.getGruposByRegionesAndCategorias(regiones,tipoTransporte,medioTransporte,categoriaTransporte);
	                for (cl.mtt.rnt.commons.model.core.autorizacion.Grupo gr :grupoTodasRegiones) {
	                    if (!this.grupos.contains(gr)) {
	                        this.grupos.add(gr);
	                    }
	                }
	                //todos los individuales de regiones
	                regiones.clear();
	                regiones = ubicacionGeograficaManager.getAllRegiones();
	                grupoTodasRegiones = grupoManager.getGruposByRegionesAndCategorias(regiones,tipoTransporte,medioTransporte,categoriaTransporte);
                    for (cl.mtt.rnt.commons.model.core.autorizacion.Grupo gr :grupoTodasRegiones) {
                        if (!this.grupos.contains(gr)) {
                            this.grupos.add(gr);
                        }
                    }
				}
				else if (reglamentacionDB.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_REGIONAL)){
					regiones = this.reglamentacionDB.getMarcoGeografico().getRegiones();
					regiones.add(todaLasRegiones);
					this.grupos = grupoManager.getGruposByRegionesAndCategorias(regiones,tipoTransporte,medioTransporte,categoriaTransporte);
				}
				else if (reglamentacionDB.getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL)){
					List<Zona> zonas = this.reglamentacionDB.getMarcoGeografico().getZonas();
					if(zonas != null && !zonas.isEmpty()){
						regiones = new ArrayList<Region>();
						for(Zona z : zonas){
							regiones.add(z.getRegionResponsable());
						}
						regiones.add(todaLasRegiones);
						this.grupos = grupoManager.getGruposByRegionesAndCategorias(regiones,tipoTransporte,medioTransporte,categoriaTransporte);
					}
					
				}
		} catch (GeneralDataAccessException gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception gde) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(gde));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		
	}
	// Mejoras 201409 Nro: 75
	
	
	public void generarReporteAsociaciones(Reglamentacion reglamentacion) {
	    FacesContext context = FacesContext.getCurrentInstance();
        HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
        response.setContentType("application/xls");
        response.setHeader("Content-Disposition", "attachment;filename=\"asociaciones_" + reglamentacion.getNombre() + 
                    ".xls"+ "\"");
        ServletOutputStream outputStream = null;
	    try {
	        if (reglamentacion.getIdReglamentacionSuperior()!=null) {
                reglamentacion.setReglamentacionDeQueDepende(reglamentacionManager.getReglamentacionById(reglamentacion.getIdReglamentacionSuperior()));
            }
	    	if(!Hibernate.isInitialized(reglamentacion.getReglamentacionesSubordinadas())){
	    		reglamentacion.setReglamentacionesSubordinadas(reglamentacionManager.getReglamentacionesSubordinadas(reglamentacion.getId()));
	    	}
	    	if(!Hibernate.isInitialized(reglamentacion.getTiposServicio())){
	    		reglamentacion.setTiposServicio(tipoServicioManager.getTiposServicioByReglamentacion(reglamentacion.getId()));
	    	}
	    	
	        outputStream = response.getOutputStream();
            HashMap<String, Object> parametros = new HashMap<String, Object>();
            List<ServicioReglamentadosVO> servicios =  reglamentacionManager.getServiciosAsociados(reglamentacion);
            parametros.put(AsociacionesReglamentacionReportBuilder.PARAM_SERVICIOS_ASOCIADOS, servicios);
            List<VehiculoReglamentadosVO> vehiculos = reglamentacionManager.getVehiculosAsociados(reglamentacion);
            parametros.put(AsociacionesReglamentacionReportBuilder.PARAM_VEHICULOS_ASOCIADOS, vehiculos);
            
            parametros.put(AsociacionesReglamentacionReportBuilder.PARAM_REGLAMENTACION, reglamentacion);
            
            AsociacionesReglamentacionReportBuilder.generateReport(parametros,outputStream);
            outputStream.flush();
            outputStream.close();
            context.responseComplete();
            
            
	    }
	    catch (Exception e) {
	        Logger.getLogger(ReglamentacionBean.class).error(e.getLocalizedMessage(), e);
	        try {
	            outputStream.flush();
	            outputStream.close();
	        }
	        catch (Exception ex) {
	            Logger.getLogger(ReglamentacionBean.class).error(ex.getLocalizedMessage(), ex);
	        }
            context.responseComplete();
	    }
	    
	    sessionCacheManager.saveState(this);
	    
	}
	
	public void addBibliotecaDigitalDocument(DocumentoBiblioteca documento, String param){
		reglamentacionDB.setDocumentoBiblioteca(documento);
		
	}

	@Override
	public void removeBibliotecaDigitalDocument(DocumentoBiblioteca documento, String param) {
		reglamentacionDB.setDocumentoBiblioteca(null);
	}

	public void addItemVehiculo(){
		if(reglamentacionDB.getGlosaVehiculo().getNuevoItem()!=null && !reglamentacionDB.getGlosaVehiculo().getNuevoItem().isEmpty() && !"".equals(reglamentacionDB.getGlosaVehiculo().getNuevoItem())){
			reglamentacionDB.getGlosaVehiculo().addItem(reglamentacionDB.getGlosaVehiculo().getNuevoItem());
			reglamentacionDB.getGlosaVehiculo().setNuevoItem(null);
		}
	}
	
	public void addItemCertificado(){
		if(reglamentacionDB.getGlosaCertificado().getNuevoItem()!=null && !reglamentacionDB.getGlosaCertificado().getNuevoItem().isEmpty() && !"".equals(reglamentacionDB.getGlosaCertificado().getNuevoItem())){
			reglamentacionDB.getGlosaCertificado().addItem(reglamentacionDB.getGlosaCertificado().getNuevoItem());
			reglamentacionDB.getGlosaCertificado().setNuevoItem(null);
		}
	}	
}
