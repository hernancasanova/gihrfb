package cl.mtt.rnt.commons.bean;

import java.io.Serializable;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class SeleccionCategoriaBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2727825768584534246L;
	private CategoriaTransporte categoriaNueva;

	public CategoriaTransporte getCategoriaNueva() {
		return categoriaNueva;
	}

	public String prepareSeleccionCategoria() {
		currentSessionBean.setCurrentModule(Constants.MODULE_COMMON);
		return Constants.REDIRECT_ALL_TO_SELECCION_CATEGORIA;
	}

	public void setCategoriaNueva(CategoriaTransporte categoriaNueva) {
		this.categoriaNueva = categoriaNueva;
	}

	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;

	public String seleccionarCategoria(CategoriaTransporteSeleccionble cat) {

		this.categoriaNueva = cat.getCategoria();
		if (this.categoriaNueva == null) {
			messageBean.addMessage(Resources.getString("seleccion.categoria.error"), FacesMessage.SEVERITY_ERROR);
			currentSessionBean.setCurrentModule(Constants.MODULE_ADMIN);
			return Constants.NO_REDIRECT;
		}

		currentSessionBean.setCategoriaSeleccionada(cat);

		return Constants.REDIRECT_SEL_CAT_TO_MAIN_PAGE;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

}