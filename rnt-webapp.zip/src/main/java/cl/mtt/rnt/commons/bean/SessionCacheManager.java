/**
 * 
 */
package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * @author federico
 * 
 */
@Service("sessionCacheManager")
@Lazy(value = true)
public class SessionCacheManager implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2341135508862114242L;

	private HttpSession getCurrentSession() {
		return (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
	}

	// public void addSearchList(List list){
	// getCurrentSession().setAttribute("searchList", list);
	// }
	//
	// public List getSearchList(){
	// return (List) getCurrentSession().getAttribute("searchList");
	// }
	//
	// public void addWorkingObject(Object object){
	// getCurrentSession().setAttribute("workingObject", object);
	// }
	//
	// public Object getWorkingObject(){
	// return getCurrentSession().getAttribute("workingObject");
	// }

	private Object loadData(Object source, Object target) throws Exception {

		Method[] gettersAndSetters = source.getClass().getMethods();

		for (int i = 0; i < gettersAndSetters.length; i++) {
			String methodName = gettersAndSetters[i].getName();
			try {
				if (methodName.startsWith("get")) {
					target.getClass().getMethod(methodName.replaceFirst("get", "set"), gettersAndSetters[i].getReturnType()).invoke(target, gettersAndSetters[i].invoke(source, null));
				} else if (methodName.startsWith("is")) {
					target.getClass().getMethod(methodName.replaceFirst("is", "set"), gettersAndSetters[i].getReturnType()).invoke(target, gettersAndSetters[i].invoke(source, null));
				}

			} catch (NoSuchMethodException e) {
				// TODO: handle exception
			} catch (IllegalArgumentException e) {
				// TODO: handle exception
			}

		}

		return null;
	}

	private Map<String, Boolean> getSessionMap() {
		Map<String, Boolean> map = (Map<String, Boolean>) getCurrentSession().getAttribute("CurrentSessionAttributesMap");
		if (map == null) {
			map = new HashMap<String, Boolean>();
			getCurrentSession().setAttribute("CurrentSessionAttributesMap", map);
		}
		return map;
	}

	private void saveState(String beanName, Object object) {
		getCurrentSession().setAttribute(beanName, object);
		// Agrego el bean al mapa de session
		getSessionMap().put(beanName, true);

	}

	public void saveState(Object object) {
		if(object!=null)
			saveState(object.getClass().getSimpleName(), object);
	}

	public boolean restoreState(Object currentBean) {
		return restoreState(currentBean.getClass().getSimpleName(), currentBean);
	}

	private boolean restoreState(String beanName, Object currentBean) {
		Object bean = getCurrentSession().getAttribute(beanName);
		getCurrentSession().removeAttribute(beanName);

		if (bean != null && bean.getClass().getName().equals(currentBean.getClass().getName())) {
			try {
				loadData(bean, currentBean);
			} catch (Exception e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			}
			return true;
		}
		return false;
	}

	public void clearSession() {
		Map<String, Boolean> map = getSessionMap();
		Set<String> keys = map.keySet();
		Iterator<String> it = keys.iterator();
		while (it.hasNext()) {
			String e = it.next();
			getCurrentSession().removeAttribute(e);
			it.remove();
		}
		getCurrentSession().setAttribute("CurrentSessionAttributesMap", new HashMap<String, Boolean>());
	}
}
