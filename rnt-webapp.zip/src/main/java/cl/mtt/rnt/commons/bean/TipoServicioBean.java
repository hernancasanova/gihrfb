package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.richfaces.event.DataScrollEvent;

import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.Atributo;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.FuenteDato;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.GlosaAuxiliar;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.Modalidad;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoServicioArea;
import cl.mtt.rnt.commons.model.core.TipoServicioAtributo;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.core.TipoVehiculoServicio;
import cl.mtt.rnt.commons.service.AtributoManager;
import cl.mtt.rnt.commons.service.CategoriaTransporteManager;
import cl.mtt.rnt.commons.service.FuenteDatoManager;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.MedioTransporteManager;
import cl.mtt.rnt.commons.service.ModalidadManager;
import cl.mtt.rnt.commons.service.TipoServicioAreaManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.service.TipoTransporteManager;
import cl.mtt.rnt.commons.service.TipoVehiculoServicioManager;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.gui.PagedListDataModel;

@ManagedBean
@ViewScoped
public class TipoServicioBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -985016481033167659L;

	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{tipoTransporteManager}")
	private TipoTransporteManager tipoTransporteManager;
	@ManagedProperty(value = "#{categoriaTransporteManager}")
	private CategoriaTransporteManager categoriaTransporteManager;
	@ManagedProperty(value = "#{medioTransporteManager}")
	private MedioTransporteManager medioTransporteManager;
	@ManagedProperty(value = "#{tipoServicioAreaManager}")
	private TipoServicioAreaManager tipoServicioAreaManager;
	@ManagedProperty(value = "#{modalidadManager}")
	private ModalidadManager modalidadManager;
	@ManagedProperty(value = "#{tipoServicioManager}")
	private TipoServicioManager tipoServicioManager;
	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;
	@ManagedProperty(value = "#{currentSessionBean}")
	private CurrentSessionBean currentSessionBean;
	@ManagedProperty(value = "#{atributoManager}")
	private AtributoManager atributoManager;
	@ManagedProperty(value = "#{fuenteDatoManager}")
	private FuenteDatoManager fuenteDatoManager;
	@ManagedProperty(value = "#{tipoVehiculoServicioManager}")
	private TipoVehiculoServicioManager tipoVehiculoServicioManager;
	@ManagedProperty(value = "#{generalDataManager}")
	private GeneralDataManager generalDataManager;

	private Long idtipoTransporteFiltro;
	private Long idMedioFiltro;
	private Long idCategoriaFiltro;
	private Long idTipoServicioAreaFiltro;
	private Long idModalidadFiltro;
	private Long idTipoVehiculoServicioFiltro;

	private Long idtipoTransporteSeleccionado;
	private Long idMedioSeleccionado;
	private Long idCategoriaSeleccionada;
	private Long idTipoServicioAreaSeleccionado;
	private Long idModalidadSeleccionada;
	private Long idTipoServicio;
	private Long idTipoVehiculoSeleccionado;
	private Long idGlosaAuxiliarSeleccionado;

	private List<TipoTransporte> tiposTransporte;
	private List<MedioTransporte> mediosTransporte;
	private List<CategoriaTransporte> categoriasTransporte;
	private List<TipoServicioArea> tiposServicioArea;
	private List<Modalidad> modalidades;
	private List<TipoVehiculoServicio> tiposVehiculosServicio;
	private List<TipoCancelacion> tiposCancelacion;
	private List<TipoCancelacion> tiposCancelacionSeleccionadas;

	private PagedListDataModel pagedListDataModelTiposServicios;
	private int currentPage = 1;
	private int totalListSize;
	// Variables para el ordenamiento
	private String sortingField;
	private Boolean sortingAsc;
	private HashMap<String,Boolean> sorters;

	private TipoServicio tipoServicio = new TipoServicio();
	private TipoTransporte tipoTransporte = new TipoTransporte();
	private MedioTransporte medioTransporte = new MedioTransporte();
	private CategoriaTransporte categoriaTransporte = new CategoriaTransporte();
	private TipoServicioArea tipoServicioArea = new TipoServicioArea();
	private Modalidad modalidad = new Modalidad();
	private TipoVehiculoServicio tipoVehiculoServicio = new TipoVehiculoServicio();

	private String nuevoElemento;

	private List<Atributo> atributosVehiculo;
	private List<Atributo> atributosServicio;

	private List<FuenteDato> fuenteDatos;
	private Atributo atributo = new Atributo();
	private FuenteDato fuenteDato = new FuenteDato();
	private FuenteDato fuenteDatoAdd = new FuenteDato();
	private Long idFuenteDato;

	private List<GlosaAuxiliar> glosasAuxiliar;

	private String conductorANivel;
	private String auxiliarANivel;
	private List<SelectItem> conductorNiveles;
	private List<SelectItem> auxiliarNiveles;
	private String pasajeroANivel;
	private List<SelectItem> pasajeroNiveles;

	private static final String NIVEL_SERVICIO = "Servicio";
	private static final String NIVEL_VEHICULO = "Vehículo";
	private static final String NIVEL_AMBOS = "Ambos";

	// private List<Atributo> atributosVehiculosSeleccionadas;
	// private List<Atributo> atributosServiciosSeleccionadas;

	@PostConstruct
	public void init() {
		sessionCacheManager.restoreState(this);
	}

	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public CurrentSessionBean getCurrentSessionBean() {
		return currentSessionBean;
	}

	public void setCurrentSessionBean(CurrentSessionBean currentSessionBean) {
		this.currentSessionBean = currentSessionBean;
	}

	public Long getIdtipoTransporteFiltro() {
		return idtipoTransporteFiltro;
	}

	public void setIdtipoTransporteFiltro(Long idtipoTransporteFiltro) {
		this.idtipoTransporteFiltro = idtipoTransporteFiltro;
	}

	public Long getIdMedioFiltro() {
		return idMedioFiltro;
	}

	public void setIdMedioFiltro(Long idMedioFiltro) {
		this.idMedioFiltro = idMedioFiltro;
	}

	public Long getIdCategoriaFiltro() {
		return idCategoriaFiltro;
	}

	public void setIdCategoriaFiltro(Long idCategoriaFiltro) {
		this.idCategoriaFiltro = idCategoriaFiltro;
	}

	public Long getIdTipoServicioAreaFiltro() {
		return idTipoServicioAreaFiltro;
	}

	public void setIdTipoServicioAreaFiltro(Long idTipoServicioAreaFiltro) {
		this.idTipoServicioAreaFiltro = idTipoServicioAreaFiltro;
	}

	public Long getIdModalidadFiltro() {
		return idModalidadFiltro;
	}

	public void setIdModalidadFiltro(Long idModalidadFiltro) {
		this.idModalidadFiltro = idModalidadFiltro;
	}

	// Getters and Setters
	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		if (this.currentPage != currentPage) {
			this.currentPage = currentPage;
			sortingFieldsClean();
			this.cargarDataModelTipoServicios();
		}
	}

	public void setPageData(ActionEvent e) {
		this.setCurrentPage(((DataScrollEvent) e).getPage());
	}

	public PagedListDataModel getPagedListDataModelTiposServicios() {
		if (pagedListDataModelTiposServicios == null) {
			sortingFieldsClean();
			this.cargarDataModelTipoServicios();
		}
		return pagedListDataModelTiposServicios;
	}

	public void setPagedListDataModelTiposServicios(PagedListDataModel pagedListDataModelTiposServicios) {
		this.pagedListDataModelTiposServicios = pagedListDataModelTiposServicios;
	}

	public int getTotalListSize() {
		return totalListSize;
	}

	public void setTotalListSize(int totalListSize) {
		this.totalListSize = totalListSize;
	}

	public String getSortingField() {
		return sortingField;
	}

	public void setSortingField(String sortingField) {
		this.sortingField = sortingField;
	}

	public Boolean getSortingAsc() {
		return sortingAsc;
	}

	public void setSortingAsc(Boolean sortingAsc) {
		this.sortingAsc = sortingAsc;
	}

	public Long getIdtipoTransporteSeleccionado() {
		return idtipoTransporteSeleccionado;
	}

	public void setIdtipoTransporteSeleccionado(Long idtipoTransporteSeleccionado) {
		this.idtipoTransporteSeleccionado = idtipoTransporteSeleccionado;
	}

	public Long getIdMedioSeleccionado() {
		return idMedioSeleccionado;
	}

	public void setIdMedioSeleccionado(Long idMedioSeleccionado) {
		this.idMedioSeleccionado = idMedioSeleccionado;
	}

	public Long getIdCategoriaSeleccionada() {
		return idCategoriaSeleccionada;
	}

	public void setIdCategoriaSeleccionada(Long idCategoriaSeleccionada) {
		this.idCategoriaSeleccionada = idCategoriaSeleccionada;
	}

	public Long getIdTipoServicioAreaSeleccionado() {
		return idTipoServicioAreaSeleccionado;
	}

	public void setIdTipoServicioAreaSeleccionado(Long idTipoServicioAreaSeleccionado) {
		this.idTipoServicioAreaSeleccionado = idTipoServicioAreaSeleccionado;
	}

	public Long getIdModalidadSeleccionada() {
		return idModalidadSeleccionada;
	}

	public void setIdModalidadSeleccionada(Long idModalidadSeleccionada) {
		this.idModalidadSeleccionada = idModalidadSeleccionada;
	}

	public Long getIdTipoServicio() {
		return idTipoServicio;
	}

	public void setIdTipoServicio(Long idTipoServicio) {
		this.idTipoServicio = idTipoServicio;
	}

	public List<TipoTransporte> getTiposTransporte() {
		return tiposTransporte;
	}

	public void setTiposTransporte(List<TipoTransporte> tiposTransporte) {
		this.tiposTransporte = tiposTransporte;
	}

	public List<MedioTransporte> getMediosTransporte() {
		return mediosTransporte;
	}

	public void setMediosTransporte(List<MedioTransporte> mediosTransporte) {
		this.mediosTransporte = mediosTransporte;
	}

	public List<CategoriaTransporte> getCategoriasTransporte() {
		return categoriasTransporte;
	}

	public void setCategoriasTransporte(List<CategoriaTransporte> categoriasTransporte) {
		this.categoriasTransporte = categoriasTransporte;
	}

	public List<TipoServicioArea> getTiposServicioArea() {
		return tiposServicioArea;
	}

	public void setTiposServicioArea(List<TipoServicioArea> tiposServicioArea) {
		this.tiposServicioArea = tiposServicioArea;
	}

	public List<Modalidad> getModalidades() {
		return modalidades;
	}

	public void setModalidades(List<Modalidad> modalidades) {
		this.modalidades = modalidades;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	// Métodos privados

	public TipoTransporteManager getTipoTransporteManager() {
		return tipoTransporteManager;
	}

	public void setTipoTransporteManager(TipoTransporteManager tipoTransporteManager) {
		this.tipoTransporteManager = tipoTransporteManager;
	}

	public CategoriaTransporteManager getCategoriaTransporteManager() {
		return categoriaTransporteManager;
	}

	public void setCategoriaTransporteManager(CategoriaTransporteManager categoriaTransporteManager) {
		this.categoriaTransporteManager = categoriaTransporteManager;
	}

	public MedioTransporteManager getMedioTransporteManager() {
		return medioTransporteManager;
	}

	public void setMedioTransporteManager(MedioTransporteManager medioTransporteManager) {
		this.medioTransporteManager = medioTransporteManager;
	}

	public TipoServicioAreaManager getTipoServicioAreaManager() {
		return tipoServicioAreaManager;
	}

	public void setTipoServicioAreaManager(TipoServicioAreaManager tipoServicioAreaManager) {
		this.tipoServicioAreaManager = tipoServicioAreaManager;
	}

	public ModalidadManager getModalidadManager() {
		return modalidadManager;
	}

	public void setModalidadManager(ModalidadManager modalidadManager) {
		this.modalidadManager = modalidadManager;
	}

	public TipoServicioManager getTipoServicioManager() {
		return tipoServicioManager;
	}

	public void setTipoServicioManager(TipoServicioManager tipoServicioManager) {
		this.tipoServicioManager = tipoServicioManager;
	}

	public TipoServicio getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(TipoServicio tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	public TipoTransporte getTipoTransporte() {
		return tipoTransporte;
	}

	public void setTipoTransporte(TipoTransporte tipoTransporte) {
		this.tipoTransporte = tipoTransporte;
	}

	public MedioTransporte getMedioTransporte() {
		return medioTransporte;
	}

	public void setMedioTransporte(MedioTransporte medioTransporte) {
		this.medioTransporte = medioTransporte;
	}

	public CategoriaTransporte getCategoriaTransporte() {
		return categoriaTransporte;
	}

	public void setCategoriaTransporte(CategoriaTransporte categoriaTransporte) {
		this.categoriaTransporte = categoriaTransporte;
	}

	public TipoServicioArea getTipoServicioArea() {
		return tipoServicioArea;
	}

	public void setTipoServicioArea(TipoServicioArea tipoServicioArea) {
		this.tipoServicioArea = tipoServicioArea;
	}

	public Modalidad getModalidad() {
		return modalidad;
	}

	public void setModalidad(Modalidad modalidad) {
		this.modalidad = modalidad;
	}

	/**
	 * @return el valor de atributosVehiculo
	 */
	public List<Atributo> getAtributosVehiculo() {
		return atributosVehiculo;
	}

	/**
	 * @param setea
	 *            el parametro atributosVehiculo al campo atributosVehiculo
	 */
	public void setAtributosVehiculo(List<Atributo> atributosVehiculo) {
		this.atributosVehiculo = atributosVehiculo;
	}

	/**
	 * @return el valor de atributosServicio
	 */
	public List<Atributo> getAtributosServicio() {
		return atributosServicio;
	}

	/**
	 * @param setea
	 *            el parametro atributosServicio al campo atributosServicio
	 */
	public void setAtributosServicio(List<Atributo> atributosServicio) {
		this.atributosServicio = atributosServicio;
	}

	/**
	 * @return el valor de atributosVehiculosSeleccionadas
	 */
	// public List<Atributo> getAtributosVehiculosSeleccionadas() {
	// return atributosVehiculosSeleccionadas;
	// }
	//
	// /**
	// * @param setea el parametro atributosVehiculosSeleccionadas al campo
	// atributosVehiculosSeleccionadas
	// */
	// public void setAtributosVehiculosSeleccionadas(
	// List<Atributo> atributosVehiculosSeleccionadas) {
	// this.atributosVehiculosSeleccionadas = atributosVehiculosSeleccionadas;
	// }
	//
	// /**
	// * @return el valor de atributosServiciosSeleccionadas
	// */
	// public List<Atributo> getAtributosServiciosSeleccionadas() {
	// return atributosServiciosSeleccionadas;
	// }
	//
	// /**
	// * @param setea el parametro atributosServiciosSeleccionadas al campo
	// atributosServiciosSeleccionadas
	// */
	// public void setAtributosServiciosSeleccionadas(
	// List<Atributo> atributosServiciosSeleccionadas) {
	// this.atributosServiciosSeleccionadas = atributosServiciosSeleccionadas;
	// }

	/**
	 * @return el valor de atributoManager
	 */
	public AtributoManager getAtributoManager() {
		return atributoManager;
	}

	/**
	 * @param setea
	 *            el parametro atributoManager al campo atributoManager
	 */
	public void setAtributoManager(AtributoManager atributoManager) {
		this.atributoManager = atributoManager;
	}

	/**
	 * @return el valor de fuenteDatos
	 */
	public List<FuenteDato> getFuenteDatos() {
		return fuenteDatos;
	}

	/**
	 * @param setea
	 *            el parametro fuenteDatos al campo fuenteDatos
	 */
	public void setFuenteDatos(List<FuenteDato> fuenteDatos) {
		this.fuenteDatos = fuenteDatos;
	}

	/**
	 * @return el valor de atributo
	 */
	public Atributo getAtributo() {
		return atributo;
	}

	/**
	 * @param setea
	 *            el parametro atributo al campo atributo
	 */
	public void setAtributo(Atributo atributo) {
		this.atributo = atributo;
	}

	/**
	 * @return el valor de fuenteDato
	 */
	public FuenteDato getFuenteDato() {
		return fuenteDato;
	}

	/**
	 * @param setea
	 *            el parametro fuenteDato al campo fuenteDato
	 */
	public void setFuenteDato(FuenteDato fuenteDato) {
		this.fuenteDato = fuenteDato;
	}

	/**
	 * @return el valor de idFuenteDato
	 */
	public Long getIdFuenteDato() {
		return idFuenteDato;
	}

	/**
	 * @param setea
	 *            el parametro idFuenteDato al campo idFuenteDato
	 */
	public void setIdFuenteDato(Long idFuenteDato) {
		this.idFuenteDato = idFuenteDato;
	}

	/**
	 * @return el valor de fuenteDatoManager
	 */
	public FuenteDatoManager getFuenteDatoManager() {
		return fuenteDatoManager;
	}

	/**
	 * @param setea
	 *            el parametro fuenteDatoManager al campo fuenteDatoManager
	 */
	public void setFuenteDatoManager(FuenteDatoManager fuenteDatoManager) {
		this.fuenteDatoManager = fuenteDatoManager;
	}

	/**
	 * @return el valor de idTipoVehiculoSeleccionado
	 */
	public Long getIdTipoVehiculoSeleccionado() {
		return idTipoVehiculoSeleccionado;
	}

	/**
	 * @param setea
	 *            el parametro idTipoVehiculoSeleccionado al campo
	 *            idTipoVehiculoSeleccionado
	 */
	public void setIdTipoVehiculoSeleccionado(Long idTipoVehiculoSeleccionado) {
		this.idTipoVehiculoSeleccionado = idTipoVehiculoSeleccionado;
	}

	/**
	 * @return el valor de tiposVehiculosServicio
	 */
	public List<TipoVehiculoServicio> getTiposVehiculosServicio() {
		return tiposVehiculosServicio;
	}

	/**
	 * @param setea
	 *            el parametro tiposVehiculosServicio al campo
	 *            tiposVehiculosServicio
	 */
	public void setTiposVehiculosServicio(List<TipoVehiculoServicio> tiposVehiculosServicio) {
		this.tiposVehiculosServicio = tiposVehiculosServicio;
	}

	/**
	 * @return el valor de tipoVehiculoServicioManager
	 */
	public TipoVehiculoServicioManager getTipoVehiculoServicioManager() {
		return tipoVehiculoServicioManager;
	}

	/**
	 * @param setea
	 *            el parametro tipoVehiculoServicioManager al campo
	 *            tipoVehiculoServicioManager
	 */
	public void setTipoVehiculoServicioManager(TipoVehiculoServicioManager tipoVehiculoServicioManager) {
		this.tipoVehiculoServicioManager = tipoVehiculoServicioManager;
	}

	/**
	 * @return el valor de tipoVehiculoServicio
	 */
	public TipoVehiculoServicio getTipoVehiculoServicio() {
		return tipoVehiculoServicio;
	}

	/**
	 * @param setea
	 *            el parametro tipoVehiculoServicio al campo
	 *            tipoVehiculoServicio
	 */
	public void setTipoVehiculoServicio(TipoVehiculoServicio tipoVehiculoServicio) {
		this.tipoVehiculoServicio = tipoVehiculoServicio;
	}

	/**
	 * @return el valor de idTipoVehiculoServicioFiltro
	 */
	public Long getIdTipoVehiculoServicioFiltro() {
		return idTipoVehiculoServicioFiltro;
	}
	
	

	/**
	 * @param setea
	 *            el parametro idTipoVehiculoServicioFiltro al campo
	 *            idTipoVehiculoServicioFiltro
	 */
	public void setIdTipoVehiculoServicioFiltro(Long idTipoVehiculoServicioFiltro) {
		this.idTipoVehiculoServicioFiltro = idTipoVehiculoServicioFiltro;
	}
	

	/**
	 * @return el valor de pasajeroANivel
	 */
	public String getPasajeroANivel() {
		return pasajeroANivel;
	}

	/**
	 * @param setea el parametro pasajeroANivel al campo pasajeroANivel
	 */
	public void setPasajeroANivel(String pasajeroANivel) {
		this.pasajeroANivel = pasajeroANivel;
	}

	/**
	 * @return el valor de pasajeroNiveles
	 */
	public List<SelectItem> getPasajeroNiveles() {
		return pasajeroNiveles;
	}

	/**
	 * @param setea el parametro pasajeroNiveles al campo pasajeroNiveles
	 */
	public void setPasajeroNiveles(List<SelectItem> pasajeroNiveles) {
		this.pasajeroNiveles = pasajeroNiveles;
	}

	public String prepararListarTiposServicios() {

		try {
			estimarTablaInicial();
			pagedListDataModelTiposServicios = null;
			tiposTransporte = tipoTransporteManager.getAllTiposTransporte();
			mediosTransporte = medioTransporteManager.getAllMediosTrasporte();
			categoriasTransporte = categoriaTransporteManager.getAllCategoriasTrasporte();
			tiposServicioArea = tipoServicioAreaManager.getAllTipoServicioArea();
			modalidades = modalidadManager.getAllModalidades();
			tiposVehiculosServicio = tipoVehiculoServicioManager.getAllTiposVehiculoServicio();
			sorters = new HashMap<String, Boolean>();
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		sessionCacheManager.saveState(this);
		return "success_prepararListarTiposServicios";
	}

	private HashMap<String, Object> getFiltrosTipoServicio() {
		HashMap<String, Object> filters = new HashMap<String, Object>();

		// Filtro Tipo Transporte
		if (this.idtipoTransporteFiltro != null && this.idtipoTransporteFiltro != 0) {
			filters.put("tipoTransporte.id", idtipoTransporteFiltro);
		}
		// Filtro Categoría Transporte
		if (this.idCategoriaFiltro != null && this.idCategoriaFiltro != 0) {
			filters.put("categoriaTransporte.id", idCategoriaFiltro);
		}
		// Filtro Medio Transporte
		if (this.idMedioFiltro != null && this.idMedioFiltro != 0) {
			filters.put("medioTransporte.id", idMedioFiltro);
		}
		// Filtro Tipo Servicio Área
		if (this.idTipoServicioAreaFiltro != null && this.idTipoServicioAreaFiltro != 0) {
			filters.put("tipoServicioArea.id", idTipoServicioAreaFiltro);
		}
		// Filtro TipoVehiculo Servicio
		if (this.idTipoVehiculoServicioFiltro != null && this.idTipoVehiculoServicioFiltro != 0) {
			filters.put("tipoVehiculoServicio.id", idTipoVehiculoServicioFiltro);
		}

		// Filtro Categoría Transporte
		if (this.idModalidadFiltro != null && this.idModalidadFiltro != 0) {
			filters.put("modalidad.id", idModalidadFiltro);
		}
		return filters;
	}

	private void estimarTablaInicial() {
		try {
			HashMap<String, Object> filters = getFiltrosTipoServicio();
			int totalListSize = new Long(tipoServicioManager.getTiposServicioCount(filters)).intValue();
			setTotalListSize(totalListSize);

		} catch (GeneralDataAccessException e) {
			pagedListDataModelTiposServicios = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModelTiposServicios = null;
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	private void cargarDataModelTipoServicios() {
		try {
			HashMap<String, Object> filters = getFiltrosTipoServicio();

			int totalListSize = new Long(tipoServicioManager.getTiposServicioCount(filters)).intValue();

			setTotalListSize(totalListSize);

			int rows;
			Object r = currentSessionBean.getTablaPaginacion().get(Constants.TABLA_LISTADO_TIPO_SERVICIO);

			if (r instanceof BigDecimal)
				rows = ((BigDecimal) r).intValue();
			else
				rows = Integer.valueOf(currentSessionBean.getTablaPaginacion().get(Constants.TABLA_LISTADO_TIPO_SERVICIO));

			int first = (this.getCurrentPage() - 1) * rows;

			// Si sucede esto es que hay menos elementos que páginas
			if ((first / rows) > (Math.ceil(totalListSize / rows))) {
				first = 0;
				setCurrentPage(1);
			}

			List<String> order = new ArrayList<String>();
			if (this.getSortingField() != null && !this.getSortingField().equals("")) {
				order.add(this.getSortingField() + ((this.getSortingAsc()) ? "" : " desc"));
			}

			List<TipoServicio> tiposServicio = tipoServicioManager.getTiposServicioPage(first, rows, filters, order);

			pagedListDataModelTiposServicios = new PagedListDataModel(new ArrayList(tiposServicio), totalListSize, rows);

		} catch (GeneralDataAccessException e) {
			pagedListDataModelTiposServicios = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (Exception e) {
			pagedListDataModelTiposServicios = null;
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}

	}

	public String getNuevoElemento() {
		return nuevoElemento;
	}

	public void setNuevoElemento(String nuevoElemento) {
		this.nuevoElemento = nuevoElemento;
	}

	public void filtrarTiposServicio() {
		sortingFieldsClean();
		this.cargarDataModelTipoServicios();
	}

	/**
	 * Limpia los campos de ordenamiento
	 */
	private void sortingFieldsClean() {
		this.sorters = new HashMap<String, Boolean>();
		this.sortingAsc = true;
		this.sortingField = new String();
	}

	public String prepararGuardarTipoServicio() {
		pagedListDataModelTiposServicios = null;
		tipoServicio = new TipoServicio();
		idtipoTransporteSeleccionado = null;
		idCategoriaSeleccionada = null;
		idMedioSeleccionado = null;
		idTipoServicioAreaSeleccionado = null;
		idModalidadSeleccionada = null;
		idTipoVehiculoSeleccionado = null;
		idGlosaAuxiliarSeleccionado = null;
		this.tiposCancelacionSeleccionadas = new ArrayList<TipoCancelacion>();
		// atributosVehiculosSeleccionadas = new ArrayList<Atributo>();
		// atributosServiciosSeleccionadas = new ArrayList<Atributo>();
		try {
			tiposTransporte = tipoTransporteManager.getAllTiposTransporte();
			mediosTransporte = medioTransporteManager.getAllMediosTrasporte();
			categoriasTransporte = categoriaTransporteManager.getAllCategoriasTrasporte();
			tiposServicioArea = tipoServicioAreaManager.getAllTipoServicioArea();
			modalidades = modalidadManager.getAllModalidades();
			tiposVehiculosServicio = tipoVehiculoServicioManager.getAllTiposVehiculoServicio();
			glosasAuxiliar = generalDataManager.getAllGlosasAuxiliar();
			tiposCancelacion = generalDataManager.getAllTiposCancelacion();

			this.atributosVehiculo = atributoManager.getAllAtributosByAplicaA(Atributo.APLICA_A_VEHICULO);
			this.atributosServicio = atributoManager.getAllAtributosByAplicaA(Atributo.APLICA_A_SERVICIO);

			this.conductorANivel = NIVEL_SERVICIO;
			this.auxiliarANivel = NIVEL_SERVICIO;
			this.pasajeroANivel = NIVEL_SERVICIO;
			this.cargarNivelesConductor();
			this.cargarNivelesAuxiliares();
			this.cargarNivelesPasajeros();

			sessionCacheManager.saveState(this);
			return "success_prepararGuardarTipoServicio";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararGuardarTipoServicio";
	}

	private void cargarNivelesConductor() {
		conductorNiveles = new ArrayList<SelectItem>();
		conductorNiveles.add(new SelectItem(NIVEL_SERVICIO, NIVEL_SERVICIO));
		conductorNiveles.add(new SelectItem(NIVEL_VEHICULO, NIVEL_VEHICULO));
		conductorNiveles.add(new SelectItem(NIVEL_AMBOS, NIVEL_AMBOS));
	}

	private void cargarNivelesAuxiliares() {
		auxiliarNiveles = new ArrayList<SelectItem>();
		SelectItem item = new SelectItem(NIVEL_SERVICIO, NIVEL_SERVICIO);
		auxiliarNiveles.add(item);
		SelectItem item1 = new SelectItem(NIVEL_VEHICULO, NIVEL_VEHICULO);
		auxiliarNiveles.add(item1);
	}
	
	private void cargarNivelesPasajeros() {
		pasajeroNiveles = new ArrayList<SelectItem>();
		SelectItem item = new SelectItem(NIVEL_SERVICIO, NIVEL_SERVICIO);
		pasajeroNiveles.add(item);
		SelectItem item1 = new SelectItem(NIVEL_VEHICULO, NIVEL_VEHICULO);
		pasajeroNiveles.add(item1);
	}

	public String guardarTipoServicio() {
		try {
			if (tipoServicio.getGlosaAlVehiculo() || tipoServicio.getGlosaPorServicio() || tipoServicio.getGlosaEnCertificado()) {
				if (tipoServicio.getGlosa() == null || (tipoServicio.getGlosa() != null && tipoServicio.getGlosa().isEmpty())) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarGlosa"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_guardar";
				}
			}

			if (tipoServicio.getHabilitarConductor()) {
				if (this.conductorANivel == null) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarNivelConductor"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_guardar";
				}
			}

			if (tipoServicio.getHabilitarAuxiliar()) {
				if (idGlosaAuxiliarSeleccionado == null) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarGlosaAuxiliar"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_guardar";
				}
				if (this.auxiliarANivel == null) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarNivelAuxiliar"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_guardar";
				}
			}
			
			if (tipoServicio.getHabilitarPasajero()) {
				if (this.pasajeroANivel == null) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarNivelPasajero"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_guardar";
				}
			}

			tipoServicio.setTipoTransporte(tipoTransporteManager.getTipoTransporteById(idtipoTransporteSeleccionado));
			tipoServicio.setCategoriaTransporte(categoriaTransporteManager.getCategoriaTransporteById(idCategoriaSeleccionada));
			tipoServicio.setMedioTransporte(medioTransporteManager.getMedioTransporteById(idMedioSeleccionado));
			tipoServicio.setTipoServicioArea(tipoServicioAreaManager.getTipoServicioAreaById(idTipoServicioAreaSeleccionado));
			tipoServicio.setModalidad(modalidadManager.getModalidadById(idModalidadSeleccionada));
			tipoServicio.setTipoVehiculoServicio(tipoVehiculoServicioManager.getTipoVehiculoServicioById(idTipoVehiculoSeleccionado));
			if (idGlosaAuxiliarSeleccionado != null)
				tipoServicio.setGlosaAuxiliar(generalDataManager.getGlosaAuxiliarById(idGlosaAuxiliarSeleccionado));
			List<TipoServicioAtributo> tipoServicioAtributos = new ArrayList<TipoServicioAtributo>();
			// Atributos aplicados a un vehículo
			for (Atributo atributo : this.atributosVehiculo) {
				if (atributo.isSeleccionado()) {
					TipoServicioAtributo tsa = new TipoServicioAtributo();
					tsa.setAtributo(atributo);
					tsa.setObligatorio(atributo.isObligatorio());
					tsa.setTipoServicio(tipoServicio);
					tipoServicioAtributos.add(tsa);
				}
			}
			// Atributos aplicados a un servicio
			for (Atributo atributo : this.atributosServicio) {
				if (atributo.isSeleccionado()) {
					TipoServicioAtributo tsa = new TipoServicioAtributo();
					tsa.setAtributo(atributo);
					tsa.setObligatorio(atributo.isObligatorio());
					tsa.setTipoServicio(tipoServicio);
					tipoServicioAtributos.add(tsa);
				}
			}

			tipoServicio.setTipoServicioAtributos(tipoServicioAtributos);

			tipoServicio.setConductoresPorServicio(this.conductorANivel.equals(NIVEL_SERVICIO));
			tipoServicio.setConductoresPorAmbos(this.conductorANivel.equals(NIVEL_AMBOS));
			tipoServicio.setAuxiliaresPorServicio(this.auxiliarANivel.equals(NIVEL_SERVICIO));
			tipoServicio.setPasajerosPorServicio(this.pasajeroANivel.equals(NIVEL_SERVICIO));
			
			tipoServicio.setTiposCancelacion(tiposCancelacionSeleccionadas);

			tipoServicioManager.saveTipoServicio(tipoServicio);

			pagedListDataModelTiposServicios = null;
			sessionCacheManager.saveState(this);

		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("tipoServicio.error.existeTipoServicio"), FacesMessage.SEVERITY_ERROR);
			pagedListDataModelTiposServicios = null;
			sessionCacheManager.saveState(this);
			return "error_TipoServicioExistente_guardar";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			pagedListDataModelTiposServicios = null;
			sessionCacheManager.saveState(this);
			return "error_TipoServicio_guardar";
		}

		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_guardarTipoServicio";
	}

	public void guardarTipoTransporte() {
		try {
			tipoTransporte.setNombre(this.getNuevoElemento());
			tipoTransporteManager.saveTipoTransporte(tipoTransporte);
			tiposTransporte = this.tipoTransporteManager.getAllTiposTransporte();
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("tipoTransporte.error.existeTipoTransporte"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public void guardarCategoriaTransporte() {
		try {
			categoriaTransporteManager.saveCategoriaTransporte(categoriaTransporte);
			categoriasTransporte = this.categoriaTransporteManager.getAllCategoriasTrasporte();
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("categoriaTransporte.error.existeCategoriaTransporte"), FacesMessage.SEVERITY_ERROR);
		}

	}

	public void guardarMedioTransporte() {
		try {
			medioTransporte.setNombre(this.getNuevoElemento());
			medioTransporteManager.saveMedioTransporte(medioTransporte);
			mediosTransporte = this.medioTransporteManager.getAllMediosTrasporte();
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("medioTransporte.error.existeMedioTransporte"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public void guardarModalidad() {
		try {
			modalidad.setNombre(this.getNuevoElemento());
			modalidadManager.saveModalidad(modalidad);
			modalidades = this.modalidadManager.getAllModalidades();
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("modalidad.error.existeModalidad"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public void guardarTipoServicioArea() {
		try {
			tipoServicioArea.setNombre(this.getNuevoElemento());
			tipoServicioAreaManager.saveTipoServicioArea(tipoServicioArea);
			tiposServicioArea = this.tipoServicioAreaManager.getAllTipoServicioArea();
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("tipoServicioArea.error.existeTipoServicioArea"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public void guardarTipoVehiculoServicio() {
		try {
			tipoVehiculoServicio.setNombre(this.getNuevoElemento());
			tipoVehiculoServicioManager.saveTipoVehiculoServicio(tipoVehiculoServicio);
			tiposVehiculosServicio = this.tipoVehiculoServicioManager.getAllTiposVehiculoServicio();
			messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("tipoVehiculoServicio.error.existeTipoVehiculoServicio"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public String prepararModificarTipoServicio(TipoServicio tipoServicio) {
		try {
			this.setTipoServicio(tipoServicio);
			pagedListDataModelTiposServicios = null;
			idGlosaAuxiliarSeleccionado = tipoServicio.getGlosaAuxiliar() != null ? tipoServicio.getGlosaAuxiliar().getId() : null;
			this.atributosVehiculo = atributoManager.getAllAtributosByAplicaA(Atributo.APLICA_A_VEHICULO);
			this.atributosServicio = atributoManager.getAllAtributosByAplicaA(Atributo.APLICA_A_SERVICIO);
			this.glosasAuxiliar = generalDataManager.getAllGlosasAuxiliar();
			this.conductorANivel = null;
			this.auxiliarANivel = null;
			this.tiposCancelacionSeleccionadas = tipoServicio.getTiposCancelacion();
			this.tiposCancelacion = generalDataManager.getAllTiposCancelacion();

			// Este dato es obligatorio ahora, pero para los datos que ya estan
			// guardados en la base con valores nulos hacemos el control
			if (tipoServicio.getConductoresPorAmbos() != null && tipoServicio.getConductoresPorAmbos().booleanValue()){
				this.conductorANivel = NIVEL_AMBOS;
			}else if (tipoServicio.getConductoresPorServicio() != null){
				this.conductorANivel = tipoServicio.getConductoresPorServicio() ? NIVEL_SERVICIO : NIVEL_VEHICULO;
			}else {
				this.conductorANivel = NIVEL_SERVICIO;
			}
			
			if (tipoServicio.getAuxiliaresPorServicio() != null)
				this.auxiliarANivel = tipoServicio.getAuxiliaresPorServicio() ? NIVEL_SERVICIO : NIVEL_VEHICULO;
			else
				this.auxiliarANivel = NIVEL_SERVICIO;
			
			if(tipoServicio.getPasajerosPorServicio() != null)
				this.pasajeroANivel = tipoServicio.getPasajerosPorServicio() ? NIVEL_SERVICIO : NIVEL_VEHICULO;
			else
				this.pasajeroANivel = NIVEL_SERVICIO;

			this.cargarNivelesConductor();
			this.cargarNivelesAuxiliares();
			this.cargarNivelesPasajeros();

			// List<Atributo> atributosVehiculosSeleccionadas =
			// atributoManager.getAtributosByTipoServicioAplicaA(tipoServicio.getId(),
			// Atributo.APLICA_A_VEHICULO);
			// List<Atributo> atributosServiciosSeleccionadas =
			// atributoManager.getAtributosByTipoServicioAplicaA(tipoServicio.getId(),
			// Atributo.APLICA_A_SERVICIO);

			for (Atributo atributo : atributosVehiculo) {
				TipoServicioAtributo tsa = tipoServicioManager.getTipoServicioAtributo(atributo.getId(), tipoServicio.getId());
				if (tsa != null) {
					atributo.setSeleccionado(true);
					atributo.setObligatorio(tsa.getObligatorio().booleanValue());
					// Mejoras 201409 Nro: 28
					atributo.setPrincipal(tsa.getPrincipal().booleanValue());
					// Mejoras 201409 Nro: 28
				}else{
					atributo.setSeleccionado(false);
				}

			}

			for (Atributo atributo : atributosServicio) {
				TipoServicioAtributo tsa = tipoServicioManager.getTipoServicioAtributo(atributo.getId(), tipoServicio.getId());
				if (tsa != null) {
					atributo.setSeleccionado(true);
					atributo.setObligatorio(tsa.getObligatorio().booleanValue());
					// Mejoras 201409 Nro: 28
					atributo.setPrincipal(tsa.getPrincipal().booleanValue());
					// Mejoras 201409 Nro: 28
				}

			}

			this.sessionCacheManager.saveState(this);
			return "success_prepararModificarTipoServicio";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
		return "error_prepararModificarTipoServicio";
	}

	public String modificarTipoServicio() {
		try {
			// List<Atributo> atributos = new
			// ArrayList<Atributo>(atributosVehiculosSeleccionadas);
			// atributos.addAll(atributosServiciosSeleccionadas);
			// tipoServicio.setAtributos(atributos);

			if (tipoServicio.getGlosaAlVehiculo() || tipoServicio.getGlosaPorServicio() || tipoServicio.getGlosaEnCertificado()) {
				if (tipoServicio.getGlosa() == null || (tipoServicio.getGlosa() != null && tipoServicio.getGlosa().isEmpty())) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarGlosa"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_modificar";
				}
			}

			if (tipoServicio.getHabilitarConductor()) {
				if (this.conductorANivel == null) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarNivelConductor"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_modificar";
				}
			}

			if (tipoServicio.getHabilitarAuxiliar()) {
				if (idGlosaAuxiliarSeleccionado == null) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarGlosaAuxiliar"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_modificar";
				}
				if (this.auxiliarANivel == null) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarNivelAuxiliar"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_modificar";
				}
			}
			
			if (tipoServicio.getHabilitarPasajero()) {
				if (this.pasajeroANivel == null) {
					messageBean.addMessage(Resources.getString("tipoServicio.error.cargarNivelPasajero"), FacesMessage.SEVERITY_ERROR);
					pagedListDataModelTiposServicios = null;
					sessionCacheManager.saveState(this);
					return "error_TipoServicio_guardar";
				}
			}

			List<TipoServicioAtributo> tipoServicioAtributos = new ArrayList<TipoServicioAtributo>();
			// Atributos aplicados a un vehículo
			for (Atributo atributo : this.atributosVehiculo) {
				TipoServicioAtributo tsa = tipoServicioManager.getTipoServicioAtributo(atributo.getId(), tipoServicio.getId());
				if (atributo.isSeleccionado()) {
					if (tsa != null) {
						tsa.setDbAction(GenericModelObject.ACTION_UPDATE);
						tsa.setObligatorio(atributo.isObligatorio());
						// Mejoras 201409 Nro: 28
						tsa.setPrincipal(atributo.isPrincipal());
						// Mejoras 201409 Nro: 28
					} else {
						tsa = new TipoServicioAtributo();
						tsa.setAtributo(atributo);
						tsa.setObligatorio(atributo.isObligatorio());
						// Mejoras 201409 Nro: 28
						tsa.setPrincipal(atributo.isPrincipal());
						// Mejoras 201409 Nro: 28
						tsa.setTipoServicio(tipoServicio);
						tsa.setDbAction(GenericModelObject.ACTION_SAVE);
					}
				} else {
					if (tsa != null)
						tsa.setDbAction(GenericModelObject.ACTION_DELETE);
				}
				tipoServicioAtributos.add(tsa);
			}
			// Atributos aplicados a un servicio
			for (Atributo atributo : this.atributosServicio) {
				TipoServicioAtributo tsa = tipoServicioManager.getTipoServicioAtributo(atributo.getId(), tipoServicio.getId());
				if (atributo.isSeleccionado()) {
					if (tsa != null) {
						tsa.setDbAction(GenericModelObject.ACTION_UPDATE);
						tsa.setObligatorio(atributo.isObligatorio());
						// Mejoras 201409 Nro: 28
						tsa.setPrincipal(atributo.isPrincipal());
						// Mejoras 201409 Nro: 28
					} else {
						tsa = new TipoServicioAtributo();
						tsa.setAtributo(atributo);
						tsa.setObligatorio(atributo.isObligatorio());
						// Mejoras 201409 Nro: 28
						tsa.setPrincipal(atributo.isPrincipal());
						// Mejoras 201409 Nro: 28
						tsa.setTipoServicio(tipoServicio);
						tsa.setDbAction(GenericModelObject.ACTION_SAVE);
					}
				} else {
					if (tsa != null)
						tsa.setDbAction(GenericModelObject.ACTION_DELETE);
				}
				tipoServicioAtributos.add(tsa);
			}

			tipoServicio.setTipoServicioAtributos(tipoServicioAtributos);
			if (idGlosaAuxiliarSeleccionado != null)
				tipoServicio.setGlosaAuxiliar(generalDataManager.getGlosaAuxiliarById(idGlosaAuxiliarSeleccionado));

			tipoServicio.setConductoresPorServicio(this.conductorANivel.equals(NIVEL_SERVICIO));
			tipoServicio.setConductoresPorAmbos(this.conductorANivel.equals(NIVEL_AMBOS));
			tipoServicio.setAuxiliaresPorServicio(this.auxiliarANivel.equals(NIVEL_SERVICIO));
			tipoServicio.setPasajerosPorServicio(this.pasajeroANivel.equals(NIVEL_SERVICIO));
			tipoServicio.setTiposCancelacion(tiposCancelacionSeleccionadas);

			tipoServicioManager.updateTipoServicio(tipoServicio);
			pagedListDataModelTiposServicios = null;
			this.sessionCacheManager.saveState(this);

		} catch (DuplicatedIdException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("tipoServicio.error.existeTipoServicio"), FacesMessage.SEVERITY_ERROR);
			pagedListDataModelTiposServicios = null;
			this.sessionCacheManager.saveState(this);
			return "error_TipoServicioExistente_modificar";
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			pagedListDataModelTiposServicios = null;
			this.sessionCacheManager.saveState(this);
			return "error_TipoServicio_modificar";
		}
		messageBean.addMessage(Resources.getString("messages.success"), FacesMessage.SEVERITY_INFO);
		return "success_modificarTipoServicio";
	}

	public String eliminarTipoServicio() {
		try {
			TipoServicio tipoServicio = this.getTipoServicioManager().getTipoServicioById(this.getIdTipoServicio());
			this.tipoServicioManager.removeTipoServicio(tipoServicio);

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			pagedListDataModelTiposServicios = null;
			sessionCacheManager.saveState(this);
			return "error_TipoServicio_eliminar";
		} catch (RemoveNotAllowedException e) {
			Logger.getLogger(this.getClass()).error(StackTraceUtil.getStackTraceString(e));
			messageBean.addMessage(Resources.getString("tipoServicio.error.eliminarTipoServicio"), FacesMessage.SEVERITY_ERROR);
			pagedListDataModelTiposServicios = null;
			sessionCacheManager.saveState(this);
			return "error_TipoServicio_eliminarNoPermitido";
		}
		pagedListDataModelTiposServicios = null;
		sessionCacheManager.saveState(this);

		messageBean.addMessage(Resources.getString("tipoServicio.messages.eliminarTipoServicio"), FacesMessage.SEVERITY_INFO);
		return "success_eliminarTipoServicio";
	}

	public void actualizarFilas() {
		this.filtrarTiposServicio();
	}

	public String revertirModificarTipoServicio() {
		pagedListDataModelTiposServicios = null;
		try {
			this.setTipoServicio(this.getTipoServicioManager().getTipoServicioById(this.getTipoServicio().getId()));
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			return "error_revertirModificarTipoServicio";
		}
		this.sessionCacheManager.saveState(this);
		return "success_revertirModificarTipoServicio";

	}

	public void prepararAgregarFuentesDatos(Atributo atributo) {
		this.setAtributo(atributo);
		this.fuenteDatoAdd = new FuenteDato();
		this.sessionCacheManager.saveState(this);
	}

	public void agregarFuenteDatoAtributo() {
		FuenteDato fd = new FuenteDato();
		fd.setAtributo(atributo);
		fd.setDbAction(GenericModelObject.ACTION_SAVE);
		fd.setValor(fuenteDatoAdd.getValor());
		// fuenteDatoAdd.setAtributo(atributo);
		// fuenteDatoAdd.setDbAction(GenericModelObject.ACTION_SAVE);
		// this.getAtributo().getFuenteDeDatos().add(this.fuenteDatoAdd);
		this.getAtributo().getFuenteDeDatos().add(fd);
	}

	public void eliminarFuenteDato(FuenteDato fuenteDato) {
		if (fuenteDato.getDbAction() != GenericModelObject.ACTION_SAVE) {
			fuenteDato.setDbAction(GenericModelObject.ACTION_DELETE);
		} else {
			atributo.getFuenteDeDatos().remove(fuenteDato);
		}

	}

	public void prepararModificarFuentesDatos(FuenteDato fuenteDato) {
		this.fuenteDato = fuenteDato;
	}

	public void modificarFuenteDato() {
		// if (this.fuenteDato.getDbAction()!= GenericModelObject.ACTION_SAVE)
		if (this.fuenteDato.getId() != null) {
			this.fuenteDato.setDbAction(GenericModelObject.ACTION_UPDATE);
			for (FuenteDato fd : atributo.getFuenteDeDatos()) {
				if (fd.getId().equals(fuenteDato.getId())) {
					fd.setValor(fuenteDato.getValor());
				}
			}
		}

	}

	public void actualizarFuenteDatos() {
		try {
			this.getFuenteDatoManager().preHandle(atributo.getFuenteDeDatos());
			this.getFuenteDatoManager().postHandle(atributo.getFuenteDeDatos());

		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}
	
	
	public void sortCollection(String currentFieldOrder) {
		if(sorters == null){
			sorters = new HashMap<String, Boolean>();
		}
		Boolean lastOrderIsAsc = sorters.get(currentFieldOrder);
		if(lastOrderIsAsc == null || !lastOrderIsAsc.booleanValue()){
			lastOrderIsAsc = true;
		}else{
			lastOrderIsAsc = false;
		}
		sorters.put(currentFieldOrder, lastOrderIsAsc);
		this.sortingField = currentFieldOrder;
		this.sortingAsc = lastOrderIsAsc;
		this.cargarDataModelTipoServicios();		
	}

	/**
	 * @return el valor de fuenteDatoAdd
	 */
	public FuenteDato getFuenteDatoAdd() {
		return fuenteDatoAdd;
	}

	/**
	 * @param setea
	 *            el parametro fuenteDatoAdd al campo fuenteDatoAdd
	 */
	public void setFuenteDatoAdd(FuenteDato fuenteDatoAdd) {
		this.fuenteDatoAdd = fuenteDatoAdd;
	}

	/**
	 * @return el valor de glosasAuxiliar
	 */
	public List<GlosaAuxiliar> getGlosasAuxiliar() {
		return glosasAuxiliar;
	}

	/**
	 * @param setea
	 *            el parametro glosasAuxiliar al campo glosasAuxiliar
	 */
	public void setGlosasAuxiliar(List<GlosaAuxiliar> glosasAuxiliar) {
		this.glosasAuxiliar = glosasAuxiliar;
	}

	/**
	 * @return el valor de generalDataManager
	 */
	public GeneralDataManager getGeneralDataManager() {
		return generalDataManager;
	}

	/**
	 * @param setea
	 *            el parametro generalDataManager al campo generalDataManager
	 */
	public void setGeneralDataManager(GeneralDataManager generalDataManager) {
		this.generalDataManager = generalDataManager;
	}

	/**
	 * @return el valor de idGlosaAuxiliarSeleccionado
	 */
	public Long getIdGlosaAuxiliarSeleccionado() {
		return idGlosaAuxiliarSeleccionado;
	}

	/**
	 * @param setea
	 *            el parametro idGlosaAuxiliarSeleccionado al campo
	 *            idGlosaAuxiliarSeleccionado
	 */
	public void setIdGlosaAuxiliarSeleccionado(Long idGlosaAuxiliarSeleccionado) {
		this.idGlosaAuxiliarSeleccionado = idGlosaAuxiliarSeleccionado;
	}

	/**
	 * @return el valor de conductorANivel
	 */
	public String getConductorANivel() {
		return conductorANivel;
	}

	/**
	 * @param setea
	 *            el parametro conductorANivel al campo conductorANivel
	 */
	public void setConductorANivel(String conductorANivel) {
		this.conductorANivel = conductorANivel;
	}

	/**
	 * @return el valor de auxiliarANivel
	 */
	public String getAuxiliarANivel() {
		return auxiliarANivel;
	}

	/**
	 * @param setea
	 *            el parametro auxiliarANivel al campo auxiliarANivel
	 */
	public void setAuxiliarANivel(String auxiliarANivel) {
		this.auxiliarANivel = auxiliarANivel;
	}

	/**
	 * @return el valor de conductorNiveles
	 */
	public List<SelectItem> getConductorNiveles() {
		return conductorNiveles;
	}

	/**
	 * @param setea
	 *            el parametro conductorNiveles al campo conductorNiveles
	 */
	public void setConductorNiveles(List<SelectItem> conductorNiveles) {
		this.conductorNiveles = conductorNiveles;
	}

	/**
	 * @return el valor de auxiliarNiveles
	 */
	public List<SelectItem> getAuxiliarNiveles() {
		return auxiliarNiveles;
	}

	/**
	 * @param setea
	 *            el parametro auxiliarNiveles al campo auxiliarNiveles
	 */
	public void setAuxiliarNiveles(List<SelectItem> auxiliarNiveles) {
		this.auxiliarNiveles = auxiliarNiveles;
	}

	public void limpiarFiltro() {
		this.idtipoTransporteFiltro = null;
		this.idCategoriaFiltro = null;
		this.idMedioFiltro = null;
		this.idTipoServicioAreaFiltro = null;
		this.idTipoVehiculoServicioFiltro = null;
		this.idModalidadFiltro = null;

		this.filtrarTiposServicio();
	}

	public List<TipoCancelacion> getTiposCancelacion() {
		return tiposCancelacion;
	}

	public void setTiposCancelacion(List<TipoCancelacion> tiposCancelacion) {
		this.tiposCancelacion = tiposCancelacion;
	}

	public List<TipoCancelacion> getTiposCancelacionSeleccionadas() {
		return tiposCancelacionSeleccionadas;
	}

	public void setTiposCancelacionSeleccionadas(List<TipoCancelacion> tiposCancelacionSeleccionadas) {
		this.tiposCancelacionSeleccionadas = tiposCancelacionSeleccionadas;
	}

}
