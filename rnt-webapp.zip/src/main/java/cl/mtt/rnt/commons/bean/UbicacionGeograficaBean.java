package cl.mtt.rnt.commons.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.recorrido.DatoDiccionario;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Provincia;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;

@ManagedBean
@ViewScoped
public class UbicacionGeograficaBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6751859456363449847L;
	@ManagedProperty(value = "#{messageBean}")
	private MessageBean messageBean;
	@ManagedProperty(value = "#{ubicacionGeograficaManager}")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@ManagedProperty(value = "#{sessionCacheManager}")
	private SessionCacheManager sessionCacheManager;

	@ManagedProperty(value = "#{generalDataManager}")
	private GeneralDataManager generalDataManager;
	
	private String idRegionSeleccionada;
	private String idProvinciaSeleccionada;
	private List<Region> regiones;
	private Map<String,Region> regionesMap;
	private List<Provincia> provincias;
	private List<Comuna> comunas;
	private List<DatoDiccionario> calles;
 
	
	@PostConstruct
	public void init() {
		try {
			sessionCacheManager.restoreState(this);
			if ((this.regiones == null) || (this.regiones.isEmpty())) {
				this.regiones = ubicacionGeograficaManager.getAllRegiones();
			}
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public void setGeneralDataManager(GeneralDataManager generalDataManager) {
		this.generalDataManager = generalDataManager;
	}

	public MessageBean getMessageBean() {
		return messageBean;
	}

	public void setMessageBean(MessageBean messageBean) {
		this.messageBean = messageBean;
	}

	public UbicacionGeograficaManager getUbicacionGeograficaManager() {
		return ubicacionGeograficaManager;
	}

	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public String getIdRegionSeleccionada() {
		return idRegionSeleccionada;
	}

	public void setIdRegionSeleccionada(String idRegionSeleccionada) {
		this.idRegionSeleccionada = idRegionSeleccionada;
	}

	public String getIdProvinciaSeleccionada() {
		return idProvinciaSeleccionada;
	}

	public void setIdProvinciaSeleccionada(String idProvinciaSeleccionada) {
		this.idProvinciaSeleccionada = idProvinciaSeleccionada;
	}

	public List<Region> getRegiones() {
		return regiones;
	}

	public void setRegiones(List<Region> regiones) {
		this.regiones = regiones;
	}

	public List<Provincia> getProvincias() {
		return provincias;
	}

	public void setProvincias(List<Provincia> provincias) {
		this.provincias = provincias;
	}

	public List<Comuna> getComunas() {
		return comunas;
	}

	public void setComunas(List<Comuna> comunas) {
		this.comunas = comunas;
	}

	public void actualizarProvincias(AjaxBehaviorEvent event) {
		if (this.idRegionSeleccionada != null) {
			try {
				this.provincias = ubicacionGeograficaManager.getAllProvinciasByIdRegion(idRegionSeleccionada);
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		} else {
			this.idProvinciaSeleccionada = null;
		}
	}

	public void actualizarComunas(AjaxBehaviorEvent event) {
		if (this.idProvinciaSeleccionada != null) {
			try {
				this.comunas = ubicacionGeograficaManager.getAllComunasByIdProvincia(idProvinciaSeleccionada);
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
	}

	public void actualizarComunasFromRegion(AjaxBehaviorEvent event) {
		if (this.idRegionSeleccionada != null) {
			try {
				this.comunas = ubicacionGeograficaManager.getAllComunasByIdRegion(idRegionSeleccionada);
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
	}

	/**
	 * @return el valor de sessionCacheManager
	 */
	public SessionCacheManager getSessionCacheManager() {
		return sessionCacheManager;
	}

	/**
	 * @param setea
	 *            el parametro sessionCacheManager al campo sessionCacheManager
	 */
	public void setSessionCacheManager(SessionCacheManager sessionCacheManager) {
		this.sessionCacheManager = sessionCacheManager;
	}

	public List<Comuna> getComunasPorRegion(Region reg) {
		if (this.idRegionSeleccionada != null) {
			try {
				return ubicacionGeograficaManager.getAllComunasByIdRegion(idRegionSeleccionada);
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
		return new ArrayList<Comuna>();
	}

	public List<Comuna> getComunasByRegion(Region reg) {
		if (reg != null) {
			try {
				return ubicacionGeograficaManager.getAllComunasByIdRegion(reg.getCodigo());
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				messageBean.addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
		return new ArrayList<Comuna>();
	}

	public void updateCalles(String codigoComuna) {
		try {
			calles = generalDataManager.findDatosDiccionarioByComuna(codigoComuna);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
		}
	}

	public List<String> autocompleteCalle(Object object) {
		String calleName = (object == null) ? "" : (String) object;
		List<String> returnList = new ArrayList<String>();
		if (calles != null) {
			for (int i = 0; i < calles.size(); i++) {
				if (calles.get(i).getCalle1().indexOf(calleName) != -1)
					returnList.add(calles.get(i).getCalle1());
			}
		}

		return returnList;
	}

	public List<DatoDiccionario> getCalles() {
		return calles;
	}

	public void setCalles(List<DatoDiccionario> calles) {
		this.calles = calles;
	}

	public Map<String, Region> getRegionesMap() {
		if(regionesMap==null){
			try {
				regionesMap=ubicacionGeograficaManager.getAllRegionesAsMap();
			} catch (GeneralDataAccessException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
				getMessageBean().addMessage(Resources.getString("error.generico"), FacesMessage.SEVERITY_ERROR);
			}
		}
		return regionesMap;
	}

	public void setRegionesMap(Map<String, Region> regionesMap) {
		this.regionesMap = regionesMap;
	}

	
}
