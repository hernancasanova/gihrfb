package cl.mtt.rnt.commons.certificado;

import java.text.SimpleDateFormat;
import java.util.Map;

import cl.mtt.rnt.commons.model.core.TipoCertificado;

public interface XsdCertificadoBuilder {

	public static final SimpleDateFormat formatoFechaCert = new SimpleDateFormat("dd/MM/yyyy");

	public String createXmlInstance(TipoCertificado tipoCertificado, Object certifxml, Map<String, Object> asociados) throws Exception;

}