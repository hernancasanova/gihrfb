package cl.mtt.rnt.commons.certificado.auturbtaxbas;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Map;

import javax.xml.bind.JAXBContext;

import cl.mtt.rnt.commons.certificado.XsdCertificadoBuilder;
import cl.mtt.rnt.commons.certificado.auturbtaxbas.Certificado.Contenido;
import cl.mtt.rnt.commons.certificado.auturbtaxbas.Certificado.Contenido.Conductores;
import cl.mtt.rnt.commons.certificado.auturbtaxbas.Certificado.Contenido.Servicio;
import cl.mtt.rnt.commons.certificado.auturbtaxbas.Certificado.Contenido.Servicio.Responsable;
import cl.mtt.rnt.commons.certificado.auturbtaxbas.Certificado.Contenido.Vehiculo;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;

public class XsdCertificadoBuilderImpl implements XsdCertificadoBuilder {

	@Override
	public String createXmlInstance(TipoCertificado tipoCertificado, Object certifxml, Map<String, Object> asociados) throws Exception {
		Certificado certObject = (Certificado) certifxml;
		VehiculoServicio vs = (VehiculoServicio) asociados.get(TipoCertificado.OBJETO_VEHICULO);

		Contenido contenido = new Certificado.Contenido();
		contenido.setTitulo("CERTIFICADO DE TAXIS UBANO BASICOS");
		if (vs.getTieneCertificadoProvisorio()) {
			contenido.setProvisorio("Certificado Provisorio");
		} else {
			contenido.setProvisorio("");
		}
		if (vs.getServicio().getTipoServicio().getGlosaEnCertificado().booleanValue()) {
			contenido.setGlosa(vs.getServicio().getTipoServicio().getGlosa());
		} else {
			contenido.setGlosa("");
		}

		// SERVICIO
		Servicio servicio = new Servicio();
		servicio.setFechaInicio(formatoFechaCert.format(vs.getServicio().getVigenciaDesde()));
		if (vs.getServicio().getVigenciaHasta() != null)
			servicio.setFechaVencimiento(formatoFechaCert.format(vs.getServicio().getVigenciaHasta()));
		else
			servicio.setFechaVencimiento("---");
		servicio.setFolio(vs.getServicio().getIdentServicio().toString());
		servicio.setRegion("" + vs.getServicio().getRegion().getCodigo() + " - " + vs.getServicio().getRegion().getNombre());

		// RESPONSABLE
		Responsable resp = new Responsable();
		resp.setNombre(vs.getServicio().getResponsable().getPersona().getNombre());
		resp.setRut(vs.getServicio().getResponsable().getPersona().getRut());
		servicio.setResponsable(resp);

		// TIPO_SERVICIO
		servicio.setTipoServicioModalidad(vs.getServicio().getTipoServicio().getTipoServicioArea().getNombre() + " " + vs.getServicio().getTipoServicio().getModalidad().getNombre());

		contenido.setServicio(servicio);

		if (vs.getConductoresVehiculo() != null) {
			Conductores conds = new Conductores();
			conds.conductor = new ArrayList<Certificado.Contenido.Conductores.Conductor>();
			for (ConductorVehiculo cv : vs.getConductoresVehiculo()) {
				Certificado.Contenido.Conductores.Conductor cc = new Certificado.Contenido.Conductores.Conductor();
				cc.setNombre(cv.getConductorServicio().getConductor().getPersona().getNombre());
				cc.setRut(cv.getConductorServicio().getConductor().getPersona().getRut());
				conds.conductor.add(cc);
			}
			contenido.setConductores(conds);
		} else {
			Conductores conds = new Conductores();
			conds.conductor = new ArrayList<Certificado.Contenido.Conductores.Conductor>();
			Certificado.Contenido.Conductores.Conductor cc = new Certificado.Contenido.Conductores.Conductor();
			cc.setRut("");
			cc.setNombre("");
			conds.conductor.add(cc);
			contenido.setConductores(conds);
		}

		contenido.setVehiculo(new Vehiculo());
		contenido.getVehiculo().setPlacaPatente(vs.getVehiculo().getPpu());
		// contenido.getVehiculo().setTipoVehiculo(vs.getVehiculo().getTipoServicio().getName());
		contenido.getVehiculo().setTipoVehiculo(vs.getVehiculo().getNombreTipoVehiculo());

		certObject.setContenido(contenido);

		// Te dice si es de vehiculo con recorrido o sin recorrido
		// si imprime solo calles, calles y paraderos o solo paraderos
		if (vs.getServicio().getTipoContrato() != null)
			vs.getServicio().getTipoContrato().getTipoCertificacion();

		// Sacamos el XML
		JAXBContext jaxbContext = JAXBContext.newInstance(Certificado.class);
		StringWriter stringWriter = new StringWriter();
		jaxbContext.createMarshaller().marshal(certObject, stringWriter);
		String theXML = stringWriter.toString();
		return theXML;
	}

}
