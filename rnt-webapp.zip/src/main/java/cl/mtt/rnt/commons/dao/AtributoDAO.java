package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Atributo;
import cl.mtt.rnt.commons.model.core.Servicio;

public interface AtributoDAO extends GenericDAO<Atributo> {

	public List<Atributo> getAtributosByTipoServicioAplicaA(Long idTipoServicio, String aplicaA) throws GeneralDataAccessException;

	public List<Atributo> getAtributosSinIntanciaByAplicaA(Servicio servicio, String aplicaA) throws GeneralDataAccessException;
	
	public String getValueAtributoInstancia(Long idServico, String descriptor, String aplicaA)throws GeneralDataAccessException;

    public List<Atributo> getAtributosByAplica(String aplicaA) throws GeneralDataAccessException;;
}
