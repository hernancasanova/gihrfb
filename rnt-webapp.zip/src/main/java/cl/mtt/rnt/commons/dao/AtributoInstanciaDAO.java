package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.encargado.dto.AtributoServicioLogDTO;

public interface AtributoInstanciaDAO extends GenericDAO<AtributoInstancia> {

	/**
	 * 
	 * @param servicio
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<AtributoInstancia> getAtributosInstanciaServicio(Servicio servicio) throws GeneralDataAccessException;

	/**
	 * 
	 * @param v
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<AtributoInstancia> getAtributosInstanciaVehiculo(Vehiculo v) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<AtributoServicioLogDTO> getAtributosLogInstanciaServicio(Long id) throws GeneralDataAccessException;

	/**
	 * 
	 * @param servicio
	 * @param valor
	 */
	public void updateLineaVsAud(Servicio servicio, String valor) throws GeneralDataAccessException;

	/**
	 * 
	 * @param id
	 * @param descriptor
	 * @param aplicaAServicio
	 * @return
	 */
	public String getValorAtributoInstanciaByIdServicioAndDescriptor(Long id,String descriptor, String aplicaAServicio) throws GeneralDataAccessException;
}
