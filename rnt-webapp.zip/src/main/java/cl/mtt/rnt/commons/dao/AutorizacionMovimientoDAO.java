package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;

public interface AutorizacionMovimientoDAO extends GenericDAO<AutorizacionMovimiento> {
	
    /**
     * 
     * @param user
     * @param first
     * @param rows
     * @param orderFields
     * @return
     * @throws GeneralDataAccessException
     */
	public List<AutorizacionMovimiento> getAutorizacionesMovimientoPag(User user ,int first, int rows, List<String> orderFields) throws GeneralDataAccessException;

	/**
	 * 
	 * @param user
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public long getAutorizacionesMovimientoCount(User user) throws GeneralDataAccessException;

	/**
	 * 
	 * @param servicio
	 * @return
	 */
    public List<Grupo> getGrupoAutorizantesRevertir(Servicio servicio) throws GeneralDataAccessException;

    
    /**
     * 
     * @param criterias
     * @return
     */
    public List<Grupo> getGruposByCriteria(List<Region> regiones,List<Long> tipoTransporte, List<Long> medioTransporte,List<Long> categoriaTransporte) throws GeneralDataAccessException;
    
    
}
