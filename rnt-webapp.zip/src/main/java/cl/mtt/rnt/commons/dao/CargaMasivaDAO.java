package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.CargaMasiva;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoCargaMasiva;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;

public interface CargaMasivaDAO extends GenericDAO<CargaMasiva> {
	
	public List<CargaMasiva> getCargasMasivas(User user, CategoriaTransporteSeleccionble categoria, Region region) throws GeneralDataAccessException;

	public List<TipoCargaMasiva> getTiposCargaMasiva() throws GeneralDataAccessException;
	
	public int updateFechasVigencia(Servicio servicio) throws GeneralDataAccessException;
}
