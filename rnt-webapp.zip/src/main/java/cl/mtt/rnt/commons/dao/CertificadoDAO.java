package cl.mtt.rnt.commons.dao;

import java.util.List;
import java.util.Map;

import cl.mtt.rnt.commons.exception.CertificadoMigradoException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.util.filter.CertificadoFilter;

public interface CertificadoDAO extends GenericDAO<Certificado> {

	public List<Certificado> getCertificadosByFilter(CertificadoFilter filtro, CategoriaTransporte ct, User user,List<Long> ids) throws GeneralDataAccessException;

	public List<Certificado> getCertificadosByFilter(CertificadoFilter filtro) throws GeneralDataAccessException;

	public List<Long> getIdsCertificadosByFilter(CertificadoFilter filtro, CategoriaTransporte ct, User user) throws GeneralDataAccessException;
	
	public Certificado getCurrentCertificado(Long vsId) throws GeneralDataAccessException, CertificadoMigradoException;

	public Certificado getCurrentCertificado(Long vsId, Long recoId) throws GeneralDataAccessException, CertificadoMigradoException;

	public List<Certificado> getCurrentCertificados(Long servicioId) throws GeneralDataAccessException, CertificadoMigradoException;
	public List<Certificado> getCurrentsCertificadosByVS(Long vsId) throws GeneralDataAccessException;

	public List<Certificado> getCertificadosByServicio(Long id, String objetoVehiculo, int first, int rows, CertificadoFilter filter, List<String> orderFields,List<Long> idsVS) throws GeneralDataAccessException;

	public long getCertificadosByServicioCount(Long id, String objetoVehiculo,CertificadoFilter filter,List<Long> idsVS) throws GeneralDataAccessException;
	
	public TipoCertificado getTipoCertificadoByReglamentacioTipoServicio(String movimiento, String objeto,Long idReglamentacion, Long idTipoServicio) throws GeneralDataAccessException;

	public TipoCertificado getTipoCertificadoTipoServicioDefault(String movimiento, String nombreObjeto, Long idTipoServicio)throws GeneralDataAccessException;

	public Long getCountCertificadosByTipoCertificadoAndEstado(String estadoFirma, boolean soloVigentes,Long idTipoCertificado)throws GeneralDataAccessException;

	public Long getCountCertificadosByServicioAndEstado(String estadoFirma, Long idServicio)throws GeneralDataAccessException;

	public List<Long> getReglamentacionesEnTiposCertificado() throws GeneralDataAccessException;

	public List<Long> getTiposDeServicioAllReglamentacionesEnTiposCertificado() throws GeneralDataAccessException;

	public Certificado getCountCertificadosByVehiculoAndEstado(String estadoSinFirmar, Long idVehiculo) throws GeneralDataAccessException;


}
