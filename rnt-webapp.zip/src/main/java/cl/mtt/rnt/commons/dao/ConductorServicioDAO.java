package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.ConductorServicio;

public interface ConductorServicioDAO extends GenericDAO<ConductorServicio> {
	
	public void deleteConductorServicioRechazada(ConductorServicio cs) throws GeneralDataAccessException;

}
