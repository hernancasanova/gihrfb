package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;

public interface ConductorVehiculoDAO extends GenericDAO<ConductorVehiculo> {
	
	public void deleteConductorVehiculoRechazada(ConductorVehiculo cv) throws GeneralDataAccessException;

}
