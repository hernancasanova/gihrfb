package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Contacto;
import cl.mtt.rnt.commons.model.core.Servicio;

public interface ContactoDAO extends GenericDAO<Contacto> {

    /**
     * 
     * @param contacto
     * @return
     * @throws GeneralDataAccessException
     */
	public int getCountServicesByContacto(Contacto contacto) throws GeneralDataAccessException;

	/**
	 * 
	 * @param contacto
	 * @return
	 * @throws GeneralDataAccessException 
	 */
    public List<Servicio> getServiciosDelContacto(Contacto contacto) throws GeneralDataAccessException;
}
