package cl.mtt.rnt.commons.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Order;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.util.filter.DataTableFilter;

/**
 * 
 * @author Federico Dukatz
 * 
 * @param <T>
 */
public interface GenericDAO<T> {

	public static final String CRITERION_PREFIX_LIKE = "LIKE";
	public static final String CRITERION_PREFIX_ILIKE = "ILIKE";
	public static final String CRITERION_PREFIX_NOT_EQUALS = "NOT_EQUALS";
	public static final String CRITERION_PREFIX_EQUALS = "EQUALS";
	public static final String CRITERION_PREFIX_EQUALS_IGNORE_CASE = "EQUALS_IGNORE_CASE";
	public static final String CRITERION_PREFIX_LESS_THAN = "LESS_THAN";
	public static final String CRITERION_PREFIX_GREATER_THAN = "GREATER_THAN";
	public static final String CRITERION_PREFIX_LESS_EQUALS_THAN = "LESS_EQUALS_THAN";
	public static final String CRITERION_PREFIX_GREATER_EQUALS_THAN = "GREATER_EQUALS_THAN";

	public void save(T newInstance) throws GeneralDataAccessException;

	public void update(T persistenceInstance) throws GeneralDataAccessException;

	public void remove(T persistenceInstance) throws GeneralDataAccessException, IntegrityViolationException;

	public List<T> getAll() throws GeneralDataAccessException;

	/**
	 * Obtiene un objeto desde la Base de Datos dada su clave primaria
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public T getByPrimaryKey(Object id) throws GeneralDataAccessException;

	/**
	 * Salva o actualiza un conjunto de objetos en la Base de Datos de acuerdo a
	 * la existencia de cada uno
	 * 
	 * @param objects
	 * @throws GeneralDataAccessException
	 */
	public void saveOrUpdateAll(List<T> objects) throws GeneralDataAccessException;

	public void proceedAccordingDBAction(List<T> objects) throws GeneralDataAccessException, IntegrityViolationException;

	public void removeAll(List<T> objects) throws GeneralDataAccessException;

	public List<T> findBySimpleCriteria(Map<String, Object> res) throws GeneralDataAccessException;

	public List<T> findBySimpleCriteriaOrders(Map<String, Object> res, List<Order> ordenamientos) throws GeneralDataAccessException;

	public List<T> findBySimpleCriteria(Map<String, Object> res, List<String> sortingColumns) throws GeneralDataAccessException;

	public List<T> findBySimpleOptionalCriteria(Map<String, Object> obligatoryCriteria, List<Map<String, Object>> optionalCriteria) throws GeneralDataAccessException;

	public List<T> findBySimpleOptionalCriteria(Map<String, Object> obligatoryCriteria, List<Map<String, Object>> optionalCriteria,List<String> sortingList) throws GeneralDataAccessException;
	
	public List<T> getPagedData(int start, int page) throws GeneralDataAccessException;

	public List<T> getPagedData(List<String> sortingColumns, int start, int page) throws GeneralDataAccessException;

	public List<T> getPagedData(Map<String, Object> simpleCriteria, int start, int page) throws GeneralDataAccessException;

	public List<T> getPagedData(Map<String, Object> simpleCriteria, List<String> sortingColumns, int start, int page) throws GeneralDataAccessException;

	/**
	 * Devuelve una página de las filas de la tabla de acuerdo a un filtro de
	 * tipo DataTableFilter, dados un inicio y una cantidad de filas, ordenados
	 * de acuerdo a un criterio
	 * 
	 * @author Federico Dukatz
	 * @param filter
	 *            filtros para la búsqueda de los datos
	 * @param sortingColumns
	 *            columnas por la cual se va a ordenar
	 * @param start
	 *            valor de inicio de la página
	 * @param page
	 *            cantidad de filas en la página
	 * @return lista de filas de la tabla
	 * @throws GeneralDataAccessException
	 *             Lanzada si hay un problema en la base de datos
	 */
	public List<T> getPagedData(DataTableFilter filter, List<String> sortingColumns, int start, int page) throws GeneralDataAccessException;

	public int getDataCount() throws GeneralDataAccessException;

	public int getDataCount(Map<String, Object> simpleCriteria) throws GeneralDataAccessException;

	/**
	 * Devuelve la cantidad de filas de la tabla de acuerdo a un filtro de tipo
	 * DataTableFilter
	 * 
	 * @author Federico Dukatz
	 * @param filter
	 *            filtros para los datos
	 * @return cantidad de datos filtrados
	 * @throws GeneralDataAccessException
	 *             Lanzada si hay un problema en la base de datos
	 */
	public long getDataCount(DataTableFilter filter) throws GeneralDataAccessException;

	public List<T> findBySimpleHQL(Map<String, Object> res) throws GeneralDataAccessException;

	public List<T> findBySimpleHQL(Map<String, Object> res, List<String> sortingColumns, boolean desc) throws GeneralDataAccessException;

	public List<T> findBySimpleHQL(Map<String, Object> res, List<String> sortingColumns, Map<String, Object> likeFields, boolean desc) throws GeneralDataAccessException;

	/**
	 * Incluye una lista de DAOOperation por la cual se puede consultar por cada
	 * campo con un operador diferente.
	 * 
	 * @param list
	 * @return
	 * @throws GeneralDataAccessException
	 * @author Leonardo Pavone
	 */
	public List<T> findBySimpleHQL(List<OperationDAO> list) throws GeneralDataAccessException;

	/**
	 * Incluye una lista de criterios opcionales
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 * @author Leonardo Pavone
	 */
	public List<T> findByHQLwithOptionalCriteria(Map<String, Object> obligatoryCriteria, List<Map<String, Object>> optionalCriteria) throws GeneralDataAccessException;

	public List<T> findByHQLwithOptionalCriteria(Map<String, Object> obligatoryCriteria, List<Map<String, Object>> optionalCriteria, List<String> sortingColumns, boolean desc)
			throws GeneralDataAccessException;

	public void clearCache() throws GeneralDataAccessException;

	/**
	 * Retorna el valor mas grande de una columna determinada. La columna puede
	 * tener valores numericos, strings, dates, etc. Por eso se retorna un
	 * object, el cual luego deberia castearse al tipo de dato necesario.
	 * 
	 * @author Leonardo Pavone
	 * @param columnName
	 * @return max value
	 * @throws GeneralDataAccessException
	 *             Si el nombre de la columna es incorrecto
	 */
	public Object getMaxValueByColumn(String columnName) throws GeneralDataAccessException;

	/**
	 * Retorna el valor mas grande de una columna determinada dadas las
	 * condiciones pasadas en la lista. La columna puede tener valores
	 * numericos, strings, dates, etc. Por eso se retorna un object, el cual
	 * luego deberia castearse al tipo de dato necesario.
	 * 
	 * @author Leonardo Pavone
	 * @param columnName
	 *            columna de la que se extrae el mayor valor
	 * @param list
	 *            Condiciones para filtrar las filas de la tabla
	 * @return max value
	 * @throws GeneralDataAccessException
	 *             Si el nombre de la columna es incorrecto
	 */
	public Object getMaxValueByColumnWithConditions(String columnName, List<OperationDAO> list) throws GeneralDataAccessException;

	/**
	 * Retorna el valor mas pequeño de una columna determinada. La columna puede
	 * tener valores numericos, strings, dates, etc. Por eso se retorna un
	 * object, el cual luego deberia castearse al tipo de dato necesario.
	 * 
	 * @author Leonardo Pavone
	 * @param columnName
	 * @return min value
	 * @throws GeneralDataAccessException
	 *             Si el nombre de la columna es incorrecto
	 */
	public Object getMinValueByColumn(String columnName) throws GeneralDataAccessException;

	/**
	 * Retorna el valor mas pequeño de una columna determinada dadas las
	 * condiciones pasadas en la lista. La columna puede tener valores
	 * numericos, strings, dates, etc. Por eso se retorna un object, el cual
	 * luego deberia castearse al tipo de dato necesario.
	 * 
	 * @author Leonardo Pavone
	 * @param columnName
	 *            columna de la que se extrae el menor valor
	 * @param list
	 *            Condiciones para filtrar las filas de la tabla
	 * @return min value
	 * @throws GeneralDataAccessException
	 *             Si el nombre de la columna es incorrecto
	 */
	public Object getMinValueByColumnWithConditions(String columnName, List<OperationDAO> list) throws GeneralDataAccessException;

	/**
	 * Incluye una lista de DAOOperation por la cual se puede consultar por cada
	 * campo con un operador diferente, una lista de columnas por las cuales se
	 * desea ordenar y un boolean que indica si se ordena descendentemente o no.
	 * 
	 * @param list
	 * @param list
	 * @param sortingColumns
	 * @param desc
	 * @return
	 * @throws GeneralDataAccessException
	 * @author Marina Chobadindegui
	 */
	public List<T> findBySimpleHQL(List<OperationDAO> list, List<String> sortingColumns, boolean desc) throws GeneralDataAccessException;

	public List<T> getRevisions(T instance);

	public List<Long> getIdsPagedData(Map<String, Object> simpleCriteria, List<Map<String, Object>> optionalsCriteria) throws GeneralDataAccessException;

	public int getDataCount(Map<String, Object> simpleCriteria, List<Map<String, Object>> optionalsCriteria) throws GeneralDataAccessException;

	public List<T> getPagedData(Map<String, Object> simpleCriteria, List<Map<String, Object>> optionalsCriteria, List<String> sortingColumns, int start, int page) throws GeneralDataAccessException;

	@Deprecated
	public List<T> findByWithOperatorCriteria(HashMap<String, WithOperatorCriteria> criteria) throws GeneralDataAccessException;
	@Deprecated
	public List<T> findByWithOperatorCriteria(HashMap<String, WithOperatorCriteria> criteria, List<String> ordenamientos) throws GeneralDataAccessException;
	@Deprecated
	public class WithOperatorCriteria {
		public static final String OPERATOR_EQUAL = "eq";
		public static final String OPERATOR_NOT_EQUAL = "ne";

		String operator;
		Object value;

		/**
		 * @return el valor de operator
		 */
		public String getOperator() {
			return operator;
		}

		/**
		 * @param setea
		 *            el parametro operator al campo operator
		 */
		public void setOperator(String operator) {
			this.operator = operator;
		}

		/**
		 * @return el valor de value
		 */
		public Object getValue() {
			return value;
		}

		/**
		 * @param setea
		 *            el parametro value al campo value
		 */
		public void setValue(Object value) {
			this.value = value;
		}

	}



}
