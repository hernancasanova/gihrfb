package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.ItemMatrizTarifaria;

public interface ItemMatrizTarifariaDAO extends GenericDAO<ItemMatrizTarifaria> {


	public void removeItemMatrizTarifaria(ItemMatrizTarifaria itemMT) throws GeneralDataAccessException;

	public void updateItemMatrizTarifaria(ItemMatrizTarifaria itemMT) throws GeneralDataAccessException;

}
