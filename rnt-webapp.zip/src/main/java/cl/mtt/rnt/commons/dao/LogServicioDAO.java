package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.LogServicio;

/**
 * 
 * @author Federico Dukatz
 * 
 * @param 
 */
public interface LogServicioDAO {

	public void save(LogServicio newInstance) throws GeneralDataAccessException;

	public List<LogServicio> getLog(Long idServicio, Long rev) throws GeneralDataAccessException;

}
