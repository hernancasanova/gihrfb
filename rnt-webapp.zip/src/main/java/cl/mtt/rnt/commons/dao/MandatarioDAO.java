package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Mandatario;

public interface MandatarioDAO extends GenericDAO<Mandatario> {

	public int getCountServicesByMandatario(Mandatario mandatario) throws GeneralDataAccessException;
}
