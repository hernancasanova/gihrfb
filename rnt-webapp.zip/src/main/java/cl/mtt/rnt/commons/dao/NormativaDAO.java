package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Normativa;

public interface NormativaDAO extends GenericDAO<Normativa> {

    /**
     * Obtiene la Normativa junto con la autorizacion
     * 
     * @param idReglamentacion
     * @return
     * @throws GeneralDataAccessException
     */
    public List<Normativa> getReglamentacionesByReglamentacion(Long idReglamentacion) throws GeneralDataAccessException;
    
    
    public void deleteNormativaItemDataWhenIsNull (Long normativaItemId ) throws GeneralDataAccessException;
	

}
