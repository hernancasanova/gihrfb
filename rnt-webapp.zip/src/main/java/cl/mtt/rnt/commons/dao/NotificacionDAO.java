package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.autorizacion.Notificacion;
import cl.mtt.rnt.commons.model.userrol.User;

public interface NotificacionDAO extends GenericDAO<Notificacion> {
	
	public List<Notificacion> getNotificacionesPag(User user, Integer tipo, int first, int rows, List<String> orderFields) throws GeneralDataAccessException;
	
	public long getNotifiacionesCount(User user, boolean solonuevas, Integer tipo) throws GeneralDataAccessException;
}
