package cl.mtt.rnt.commons.dao;

public class OperationDAO {

	public static final String OPERATION_EQUALS = "=";
	public static final String OPERATION_NOT_EQUALS = "<>";
	public static final String OPERATION_LESS_THAN = "<";
	public static final String OPERATION_GREATER_THAN = ">";
	public static final String OPERATION_LESS_OR_EQUALS = "<=";
	public static final String OPERATION_GREATER_OR_EQUALS = ">=";
	public static final String OPERATION_IS_NOT_NULL = "IS NOT NULL";
	public static final String OPERATION_IS_NULL = "IS NULL";
	public static final String OPERATION_IN = "IN";
	public static final String OPERATION_NOT_IN = "NOT IN";

	private String field;
	private String operator;
	private Object value;

	/**
	 * Constructor a utilizar cuando la restriccion tiene 3 operadores. Ej:
	 * field=value
	 * 
	 * @param field
	 *            campo a chequear
	 * @param operator
	 *            operador
	 * @param value
	 *            valor
	 */
	public OperationDAO(String field, String operator, Object value) {
		super();
		this.field = field;
		this.operator = operator;
		this.value = value;
	}

	/**
	 * Constructor a utilizar cuando la restriccion tiene 2 operadores. Ej:
	 * field is null
	 * 
	 * @param field
	 *            campo a chequear
	 * @param operator
	 *            operador
	 */
	public OperationDAO(String field, String operator) {
		super();
		this.field = field;
		this.operator = operator;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

}
