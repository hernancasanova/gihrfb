package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Paradero;

public interface ParaderoDAO extends GenericDAO<Paradero> {

	public Long getIdParadero(String tipoParadero, String nombreParadero,String domicilioParadero,String numero, String comunaParadero) throws GeneralDataAccessException;

}
