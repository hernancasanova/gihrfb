package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.model.core.PeriodoVigencia;

public interface PeriodoVigenciaDAO extends GenericDAO<PeriodoVigencia> {

}
