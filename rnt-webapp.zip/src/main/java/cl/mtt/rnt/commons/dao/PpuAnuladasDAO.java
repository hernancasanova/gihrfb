package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.VehiculoServicioRemplazadoException;
import cl.mtt.rnt.commons.model.core.PpuAnulada;

public interface PpuAnuladasDAO  extends GenericDAO<PpuAnulada>{
	
	public void AnularPPU(PpuAnulada ppuanulada, Long idVehiculo, Long idVehiculoServicio) throws GeneralDataAccessException, VehiculoServicioRemplazadoException;

}
