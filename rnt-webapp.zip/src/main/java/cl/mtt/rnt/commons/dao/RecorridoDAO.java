package cl.mtt.rnt.commons.dao;

import java.util.LinkedList;
import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.encargado.dto.RecorridoDTO;

public interface RecorridoDAO extends GenericDAO<Recorrido> {

	public LinkedList<RecorridoDTO> getRecorridosSkeleton(Servicio servicio, String currentOrder) throws GeneralDataAccessException;

	public void loadRecorridosPaginados(Servicio servicio, int pagina, Integer cantidadRegistros, String orderBy) throws GeneralDataAccessException;

	public Long getIdRecorridoByServicioYNombre(Long idServicio,String nombreRecorrido) throws GeneralDataAccessException;

	public void updateRecorridoEstadoFirma(Recorrido recorrido) throws GeneralDataAccessException;

    public Recorrido getRecorridoById(Long id)  throws GeneralDataAccessException;

    public List<Recorrido> getRecorridosHqlByServicio(Long id) throws GeneralDataAccessException;

}
