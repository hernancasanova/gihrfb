package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.admin.reglamentacion.util.ItemCupo;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.view.ServicioReglamentadosVO;
import cl.mtt.rnt.commons.model.view.VehiculoReglamentadosVO;

public interface ReglamentacionDAO extends GenericDAO<Reglamentacion> {

    /**
     * 
     * @param idReglamentacion
     * @param idZona
     * @return
     * @throws GeneralDataAccessException
     */
	public Integer getCantidadZonasUsadas(Long idReglamentacion, Long idZona) throws GeneralDataAccessException;

	/**
	 * 
	 * @param idReglamentacion
	 * @param idRegion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Integer getCantidadRegionesUsadas(Long idReglamentacion, String idRegion) throws GeneralDataAccessException;


// Mejoras 201409 Nro: 3
	/**
	 * 
	 * @param idReglamentacion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public int getCantidadReglamentacionesUsadas(Long idReglamentacion) throws GeneralDataAccessException;
// Mejoras 201409 Nro: 3
	
	/**
	 * 
	 * @param idReglamentacion
	 * @param idTipoServicio
	 * @param codigoRegion
	 * @param idZona
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<ItemCupo> getItemsCupo(Long idReglamentacion, Long idTipoServicio, String codigoRegion, Long idZona) throws GeneralDataAccessException;

	/**
	 * 
	 * @param idReglamentacion
	 * @param idTipoServicio
	 * @param codigoRegion
	 * @param idZona
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Integer getCantUsadosCupo(Long idReglamentacion, Long idTipoServicio, String codigoRegion, Long idZona) throws GeneralDataAccessException;

	/**
	 * 
	 * @param tipoServicio
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Long> getReglamentacionesVehiculoIds(TipoServicio tipoServicio) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param idReglamentacion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Long> getReglamentacionesSubordinadasIds(Long idReglamentacion) throws GeneralDataAccessException;

	/**
	 * 
	 * @param reg
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<ServicioReglamentadosVO> getServiciosAsociados(Reglamentacion reg) throws GeneralDataAccessException;

	/**
	 * 
	 * @param reg
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<VehiculoReglamentadosVO> getVehiculosAsociados(Reglamentacion reg) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param idTipoServicio
	 * @param codigoRegion
	 * @param aplicaNacion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Long> getReglamentacionesIdsSeleccionables(Long idTipoServicio, String codigoRegion, boolean aplicaNacion) throws GeneralDataAccessException;
}
