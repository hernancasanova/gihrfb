package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.RepresentanteLegal;

public interface RepresentanteLegalDAO extends GenericDAO<RepresentanteLegal> {

	public int getCountServicesByRepresentante(RepresentanteLegal representante) throws GeneralDataAccessException;
}
