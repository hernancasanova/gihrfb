package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.Persona;
import cl.mtt.rnt.commons.model.core.Propietario;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.AtributoCargaMasivaDTO;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.ServicioCargaMasivaDTO;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.TarifaFVCargaMasivaDTO;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.VehiculoServicioCargaMasivaDTO;
import cl.mtt.rnt.encargado.dto.PropietarioDTO;
import cl.mtt.rnt.encargado.dto.ServicioDTO;
import cl.mtt.rnt.encargado.dto.ServicioHistoricoDTO;
import cl.mtt.rnt.encargado.dto.ServicioLogDTO;

public interface ServicioDAO extends GenericDAO<Servicio> {

	/**
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<ServicioDTO> getServiciosResponsable(Long id) throws GeneralDataAccessException;

	public List<ServicioDTO> getServiciosByRutCategoria(Persona persona, List<TipoServicio> tiposServicio, User user) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Long getNewIdentificadorServicio() throws GeneralDataAccessException;

	// public List<ServicioDTO> getServiciosContacto(Long contactoID) throws
	// GeneralDataAccessException;

	public List<ServicioDTO> getServiciosRepresentante(Long representanteID) throws GeneralDataAccessException;

	public List<Propietario> getPropietariosVehiculosByServicio(Servicio servicio) throws GeneralDataAccessException;

//	public List<ServicioDTO> getServiciosByPPUCategoria(String ppu, CategoriaTransporte categoria,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user, boolean vigente) throws GeneralDataAccessException;
	public List<ServicioDTO> getServiciosByPPUSinCategoria(String ppu, boolean vigente) throws GeneralDataAccessException;

	public List<ServicioDTO> getServiciosByPPUCategoria(String ppu) throws GeneralDataAccessException;

	public Boolean getZonaUsada(Zona zona) throws GeneralDataAccessException;

	public List<String> getRutsSinDV() throws GeneralDataAccessException;

	public void updateRutPersona(String rut, String newRut) throws GeneralDataAccessException;

	public List<PropietarioDTO> getPropietariosVehiculosByServicioDTO(Servicio servicio) throws GeneralDataAccessException;
	
	// Mejoras 201409 Nro: 43
	public List<PropietarioDTO>getPropietariosVehiculosVigentesByServicioDTO(Servicio servicio) throws GeneralDataAccessException;
	// Mejoras 201409 Nro: 43
	

	public boolean getConductorTieneCancelacionByCategoria(String rut, TipoServicio tipoServicio) throws GeneralDataAccessException;

	public List<ServicioHistoricoDTO> getServicioHistoricoByServicio(Long id) throws GeneralDataAccessException;
		
	public ServicioCargaMasivaDTO getServicioCargaMasivaDTO(Long identificador, CategoriaTransporte categoriaTransporte,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException;

	public VehiculoServicioCargaMasivaDTO getVehiculoServicioCargaMasivaDTO(Long identificador, String ppu, CategoriaTransporte categoriaTransporte,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException;

	public AtributoCargaMasivaDTO getAtributoServicioCargaMasivaDTO(Long id,String atributo,CategoriaTransporte categoria,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException;

	public AtributoCargaMasivaDTO getAtributoVehiculoCargaMasivaDTO(String ppu, String atributo) throws GeneralDataAccessException;

	public TarifaFVCargaMasivaDTO getTarifaFVCargaMasivaDTO(Long identificador, CategoriaTransporte categoriaTransporte,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException;
	
	public Servicio getServicioHistoricoByRevision(Long id ,Long rev) throws GeneralDataAccessException;

	public Long getLastRevisionNumber(Servicio servicio) throws GeneralDataAccessException;
	
	public ServicioLogDTO getServicioLog(Long id) throws GeneralDataAccessException;

	/**
	 * 
	 * @param identificador Identificador de Servicio Campo
	 * @param categoriaTransporte
	 * @param regionSeleccionada
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public Servicio getServicioInicializado(Long identificador, CategoriaTransporteSeleccionble categoriaTransporte, String regionSeleccionada) throws GeneralDataAccessException;

    /**
     * Con el identificador de Servicio en tabla
     * @param id
     * @return
     * @throws GeneralDataAccessException
     */
    public Servicio getServicioInicializado(Long id) throws GeneralDataAccessException;;
		
	public boolean isTieneCertificadosFaltantes(Long idServicio) throws GeneralDataAccessException;

}
