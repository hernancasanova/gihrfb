package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Sector;
import cl.mtt.rnt.commons.model.core.Tarifa;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.ItemMatrizTarifariaDTO;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.TramoTarifarioCargaMasivaDTO;

public interface TarifaDAO extends GenericDAO<Tarifa> {

	public void removeItemTramoTarifarioWithoutSectorTramoTarifario(Long idTarifa) throws GeneralDataAccessException;

	public void removeDataFromTramoTarifario(Long idTramoTarifario) throws GeneralDataAccessException;

	public void cleanSectorTramoTarifario(Sector sector) throws GeneralDataAccessException;

	public List<TramoTarifarioCargaMasivaDTO> getTramoTarifarioByServicioYNombre(Long idServicio, String nombreTramo) throws GeneralDataAccessException;

	public TramoTarifarioCargaMasivaDTO getTramoTarifarioByRecorridoYNombre(Long idRecorrido, String tramoTarifario) throws GeneralDataAccessException;

	public ItemMatrizTarifariaDTO getItemMatrizTarifaria(Long idTramo,String tramoInicial, String tramoFinal) throws GeneralDataAccessException;
}
