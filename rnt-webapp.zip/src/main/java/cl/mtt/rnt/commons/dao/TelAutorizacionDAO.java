/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.TelAutorizacion;


/**
 *
 * @author jhenriquez
 */
public interface TelAutorizacionDAO extends GenericDAO<TelAutorizacion> {
    public int getCountResponsablesByAutorizacion(TelAutorizacion telAutorizacion) throws GeneralDataAccessException;
}
