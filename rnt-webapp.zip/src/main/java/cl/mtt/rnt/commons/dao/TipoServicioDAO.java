package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Modalidad;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoServicioArea;
import cl.mtt.rnt.commons.model.core.TipoVehiculoServicio;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;

/**
 * 
 * @author jeyler
 *
 */
public interface TipoServicioDAO extends GenericDAO<TipoServicio> {

	/**
	 * Retorna los tipos de servicio disponibles, que no estan asociados a un tipo de certidficado con regla sin reglamentecion
	 * por clase.
	 * @param idClaseTipoCertificado
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Long> getTiposServiciosSinTipoCertificado(Long idClaseTipoCertificado) throws GeneralDataAccessException;

	/**
	 * Retorna los tipos de servicio que no estan asociados a la reglamentacion indicada en algun tipo por clase.
	 * @param idClaseTipoCertificado
	 * @param idReglamentacion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Long> getTiposServiciosDisponiblesCertificadoReglamentacion(Long idClaseTipoCertificado, Long idReglamentacion) throws GeneralDataAccessException;

	/**
	 * 
	 * @param categoria
	 * @return
	 */
    public List<TipoServicioArea> getTiposServicioArea(CategoriaTransporteSeleccionble categoria) throws GeneralDataAccessException;

    /**
     * 
     * @param categoria
     * @return
     * @throws GeneralDataAccessException
     */
    public List<TipoVehiculoServicio> getTiposVehiculoServicio(CategoriaTransporteSeleccionble categoria) throws GeneralDataAccessException;

    
    /**
     * 
     * @param categoria
     * @return
     * @throws GeneralDataAccessException
     */
    public List<Modalidad> getModalidades(CategoriaTransporteSeleccionble categoria) throws GeneralDataAccessException;

    /**
     * 
     * @return
     * @throws GeneralDataAccessException
     */
    public List<TipoServicio> getAllTiposServicio() throws GeneralDataAccessException;

}
