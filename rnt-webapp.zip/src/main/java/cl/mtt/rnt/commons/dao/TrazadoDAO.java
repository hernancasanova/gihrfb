package cl.mtt.rnt.commons.dao;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.recorrido.Trazado;

public interface TrazadoDAO extends GenericDAO<Trazado> {

	public Long getIdTrazadoByRecorridoYNombre(Long idRecorrido,String nombreTrazado) throws GeneralDataAccessException;

}
