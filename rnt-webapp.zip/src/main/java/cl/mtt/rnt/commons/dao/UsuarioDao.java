package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.userrol.UserContext;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;

public interface UsuarioDao extends GenericDAO<User> {
	
	public List<User> getUsuariosByCategoriaTransporte(CategoriaTransporteSeleccionble cts) throws GeneralDataAccessException;
	public List<User> getUsuariosAplicaNacionyCategoriaTransporte(boolean aplicaNacion, CategoriaTransporteSeleccionble cts) throws GeneralDataAccessException;
	public List<User> getUsuariosByRegionyCategoriaTransporte(String codRegion, CategoriaTransporteSeleccionble cts) throws GeneralDataAccessException;

	public void updateUserContextRegiones(UserContext userContext, List<Region> regiones) throws GeneralDataAccessException;

}
