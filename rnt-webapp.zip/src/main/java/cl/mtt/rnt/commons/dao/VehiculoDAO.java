package cl.mtt.rnt.commons.dao;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoRegistroCivil;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.encargado.dto.VehiculoServicioDTO;

public interface VehiculoDAO extends GenericDAO<Vehiculo> {

	public Integer getCantidadPendientesMigracion() throws GeneralDataAccessException;

	public List<String> getNextMigraPPU(Integer cantidadEjecutar) throws GeneralDataAccessException;

	public User getUsuarioMigracion() throws GeneralDataAccessException;

	public List<String> getNextMigraPPUEspecifica(String ppu) throws GeneralDataAccessException;

	public List<String> getNextMigraPPUServ(String identServ) throws GeneralDataAccessException;

	public Integer getCantCertificadosAnteriores(Long idVehiculoServicio, Date fechaUltimoCert) throws GeneralDataAccessException;

	public Date getFechaInicioUltimaVigencia(Long idVehiculoServicio) throws GeneralDataAccessException;

	public void loadVehiculosPaginados(Servicio servicio, int pagina, Integer cantidadRegistros, String orderBy) throws GeneralDataAccessException;

	public void loadVehiculosPaginados(List<VehiculoServicioDTO> vehiculosFiltrados, int pagina, int cantPorPagina, String order) throws GeneralDataAccessException;

	// Mejoras 201409 Nro: 69
	public void getNotInVehiculosPaginados(List<VehiculoServicio> vehiculosFiltrados, Long IdServicio) throws GeneralDataAccessException;
	// Mejoras 201409 Nro: 69
	public Integer getCantidadVehiulosServicio(Servicio servicio) throws GeneralDataAccessException;

	public boolean getTieneCancelacionByCategoria(Vehiculo vehiculo, TipoServicio tipoServicio) throws GeneralDataAccessException;

	public List<VehiculoServicio> getVehiculosServicioByReglamentacion(Long idReglamentacion) throws GeneralDataAccessException;

	public LinkedList<VehiculoServicioDTO> getVehiculosSkeleton(Servicio servicio, String currentOrder) throws GeneralDataAccessException;

	/**
	 * 
	 * @param ids
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public List<VehiculoServicio> loadVehiculosIndexados(List<Long> ids)  throws GeneralDataAccessException;

    /**
     * 
     * @param ppuIngresado
     * @return
     */
    public VehiculoRegistroCivil getVehiculoRegistroCivil(String ppuIngresado) throws GeneralDataAccessException;

    /**
     * 
     * @param vehiculo
     * @param tipoServicio
     * @return
     */
    public boolean getVehiculoExistenteCategoria(Vehiculo vehiculo, TipoServicio tipoServicio);

    /**
     * 
     * @param idVehiculo
     * @return
     * @throws GeneralDataAccessException
     */
    public List<VehiculoServicio> getUltimoVehiculoServicioByVehiculo(Long idVehiculo) throws GeneralDataAccessException;

    /**
     * 
     * @param vehiculo
     * @return
     */
    public boolean getVehiculoExistente(Vehiculo vehiculo);
    
    /**
     * 
     * @param vehiculo
     * @param tipoServicio 
     * @return
     */
    public boolean getVehiculoExistenteOtraCategoria(Vehiculo vehiculo, TipoServicio tipoServicio);

}
