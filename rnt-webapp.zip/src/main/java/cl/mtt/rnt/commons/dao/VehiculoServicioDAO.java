package cl.mtt.rnt.commons.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.view.IDRevision;
import cl.mtt.rnt.encargado.bean.controller.util.VehiculoReemplazable;
import cl.mtt.rnt.encargado.dto.VehiculoServicioHistoricoDTO;

public interface VehiculoServicioDAO extends GenericDAO<VehiculoServicio> {

	/**
	 * 
	 * @param vehiculoServicio
	 * @throws GeneralDataAccessException
	 */
	public void updateVehiculoServicioEstadoFirma(VehiculoServicio vehiculoServicio) throws GeneralDataAccessException;

	/**
	 * 
	 * @param ppu
	 * @param idTipoTransporte
	 * @param idMedioTransporte
	 * @param idCategoriaTransporte
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Long getVehiculoServicioIdTraslado(String ppu, Long idTipoTransporte, Long idMedioTransporte, Long idCategoriaTransporte) throws GeneralDataAccessException;
	
	public Integer getEstadoVehiculo(Long idVehiculoServicio) throws GeneralDataAccessException;
	
	
	// Mejoras 201409 Nro: 70
	public List<VehiculoServicioHistoricoDTO> getVehiculoServicioHistoricoById(Long id) throws GeneralDataAccessException;
	
	public VehiculoServicio getVehiculoServicioHistoricoByRevision(Long id, Long rev) throws GeneralDataAccessException;
	
	public void deleteVehiculoServicioAud (Long IdvehiculoServicio, Long rev) throws GeneralDataAccessException;
	
	
	/**
	 * Elimina las referencias de reeemplaza en los vehiculo servicio del vehiculo
	 * @param idVs
	 * @throws GeneralDataAccessException
	 */
	public void isRemplazaAllVs(Long idVs)  throws GeneralDataAccessException;
	
	/**
	 * Elimina referencias de reemplaza en el vehiculo Servicio
	 * @param idVs
	 * @throws GeneralDataAccessException
	 */
	public void isRemplaza(Long idVs)  throws GeneralDataAccessException;

	/**
	 * 
	 * @param idVs
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public boolean isRemplazado(Long idVs)  throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param idVs
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public boolean isRemplazadoAllVs(Long idVs)  throws GeneralDataAccessException;
	
	public void setRemplaza(VehiculoServicio vs)  throws GeneralDataAccessException;
	// Mejoras 201409 Nro: 70
	
	
	public void deleteVehiculoServicioRechazada(VehiculoServicio vs)throws GeneralDataAccessException; 
		
	public List<VehiculoReemplazable> getVehiculosReemplazables(Long idServicio,String codigoRegion,Long idVehiculoServicioOrigen) throws GeneralDataAccessException;

	public List<VehiculoReemplazable> getVehiculosReemplazablesByIdent(Long identServicio,String codigoRegion, String ppuReemplazada) throws GeneralDataAccessException;
	
	public List<VehiculoServicio> getHistorialVehiculo(Long idVehiculo)throws GeneralDataAccessException;

	/**
	 * 
	 * @param idVs
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public IDRevision getIdReemplazaAud(Long idVs) throws GeneralDataAccessException;
    
    /**
     * 
     * @param idVs
     * @return
     * @throws GeneralDataAccessException
     */
    public IDRevision getIdReemplazadoAud(Long idVs) throws GeneralDataAccessException;

    /**
     * 
     * @param idVs
     * @param rev
     * @return
     * @throws GeneralDataAccessException
     */
    public VehiculoServicio getVehiculoServicioVersionado(Long idVs,Long rev) throws GeneralDataAccessException;

    /**
     * 
     * @param id
     * @return
     */
    public VehiculoServicio getVehiculoInicializado(Long id) throws GeneralDataAccessException;

	public void updateFechasVigenciaHasta(Servicio servicio) throws GeneralDataAccessException;

	/**
	 * 
	 * @param id
	 * @throws GeneralDataAccessException
	 */
    public Map<Long,VehiculoServicio> getVehiculosCertificables(Long id)throws GeneralDataAccessException;
    
    /**
     * 
     * @param idVs
     * @throws GeneralDataAccessException
     */
    public Map<Long,VehiculoServicio> getVehiculosCertificables(List<Long> idsVs)throws GeneralDataAccessException;

    /**
     * 
     * @param id
     * @return
     */
    public Map<Long,List<ConductorVehiculo>> getConductoresVehiculoServicio(Servicio servicio) throws GeneralDataAccessException;

    /**
     * 
     * @param servicio
     * @return
     * @throws GeneralDataAccessException
     */
	public Map<Long, List<AtributoInstancia>> getAtributosInstanciaVehiculoServicio(Servicio servicio) throws GeneralDataAccessException;

	/**
	 * Datos de Vehiculo necesarios para mostrar en reemplazo/reemplazado
	 * @param idVs
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public VehiculoServicio getReemplazo(Long idVs) throws GeneralDataAccessException;

    /**
     * 
     * @param tipoServicio
     * @param anioDesde
     * @param anioHasta
     * @param tipoBusqueda
     * @param fechaSalida
     * @param identServicio
     * @param region
     * @param estadoVehiculo
     */
    public List<VehiculoServicio> getVehiculosByFiltros(TipoServicio tipoServicio, Integer anioDesde, Integer anioHasta, String tipoBusqueda, Date fechaSalida,
            Long identServicio, Region region, Integer estadoVehiculo) throws GeneralDataAccessException;

    /**
     * 
     * @param id
     * @param rev
     * @throws GeneralDataAccessException
     */
    public Long getTipoCancelacionHistoricoByRevision(Long id, Long rev) throws GeneralDataAccessException;

    /**
     * 
     * @param idVs
     * @param revisionReversion
     * @return
     */
    public Long getRevisionRechazoReversion(Long idVs, Long revisionReversion)throws GeneralDataAccessException;

    /**
     * 
     * @param idVs
     * @throws GeneralDataAccessException
     */
    public void eliminarVehiculoServicio(Long idVs) throws GeneralDataAccessException;

	public void recuperarCertificadoAnterior(Long idVehiculoServicio) throws GeneralDataAccessException;

	public void eliminarCertificadoAnterior(Long idVehiculoServicio) throws GeneralDataAccessException;


    
    
}
