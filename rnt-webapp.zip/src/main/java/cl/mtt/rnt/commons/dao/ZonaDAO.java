package cl.mtt.rnt.commons.dao;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.core.ZonaComuna;
import cl.mtt.rnt.commons.model.core.ZonaLocalidad;
import cl.mtt.rnt.commons.model.core.ZonaRegion;

public interface ZonaDAO extends GenericDAO<Zona> {

    /**
     * 
     * @param idTarifa
     * @return
     * @throws GeneralDataAccessException
     */
	public List<Long> getZonasSubsidioIdsByServicio(Long idTarifa) throws GeneralDataAccessException;

	/**
	 * 
	 * @param zonas
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public List<String> getRegionesIdsfromZonas(List<Zona> zonas) throws GeneralDataAccessException;

    /**
     * 
     * @param zonas
     * @return
     * @throws GeneralDataAccessException
     */
    public List<Integer> getLocalidadesIdsfromZonas(List<Zona> zonas) throws GeneralDataAccessException;

    /**
     * 
     * @param zonas
     * @return
     * @throws GeneralDataAccessException
     */
    public List<String> getComunasIdsfromZonas(List<Zona> zonas) throws GeneralDataAccessException;

    
    /**
     * 
     * @return
     * @throws GeneralDataAccessException
     */
    public List<Zona> getAllZonas() throws GeneralDataAccessException;

    
    /**
     * 
     * @return
     * @throws GeneralDataAccessException
     */
    public List<ZonaComuna> getAllZC() throws GeneralDataAccessException;
    
    /**
     * 
     * @return
     * @throws GeneralDataAccessException
     */
    public List<ZonaRegion> getAllZR() throws GeneralDataAccessException;
    
    /**
     * 
     * @return
     * @throws GeneralDataAccessException
     */
    public List<ZonaLocalidad> getAllZL() throws GeneralDataAccessException;
}
