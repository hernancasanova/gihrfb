package cl.mtt.rnt.commons.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.AtributoDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Atributo;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicioAtributo;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class AtributoDAOImpl extends GenericDAOImpl<Atributo> implements AtributoDAO {

	Logger log = Logger.getLogger(this.getClass());

	public AtributoDAOImpl(Class<Atributo> objectType) {
		super(objectType);

	}

	@SuppressWarnings("unchecked")
    @Override
	public List<Atributo> getAtributosByTipoServicioAplicaA(Long idTipoServicio, String aplicaA) throws GeneralDataAccessException {
		List<Atributo> resultados = new ArrayList<Atributo>();
		try {
			String hql = "SELECT  A FROM Atributo AS A inner join A.tipoServicioAtributos AS TS WHERE A.aplicaA = '" + aplicaA + "' "
					+ " and TS.tipoServicio.id = " + idTipoServicio + " order by A.ordenParcial ";

			Query query = getSession().createQuery(hql);
			resultados = (List<Atributo>) query.list();

			String hqlMap = "select tsa from TipoServicioAtributo tsa where tsa.tipoServicio.id = :idTipoServicio";
			List<TipoServicioAtributo> tsaRes = getSession().createQuery(hqlMap).setParameter("idTipoServicio", idTipoServicio).list();
			Map<Long, TipoServicioAtributo> map = new HashMap<Long, TipoServicioAtributo>();
			for (TipoServicioAtributo tipoServicioAtributo : tsaRes) {
			    if (tipoServicioAtributo.getAtributo()!=null) {
			        map.put(tipoServicioAtributo.getAtributo().getId(), tipoServicioAtributo);
			    }
			}
			for (Atributo atr : resultados) {
				TipoServicioAtributo tsa = map.get(atr.getId());
				if(tsa!=null){
					atr.setObligatorio(tsa.getObligatorio());
					atr.setPrincipal(tsa.getPrincipal());
				}else{
					atr.setObligatorio(false);
					atr.setPrincipal(false);
				}
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<Atributo> getAtributosSinIntanciaByAplicaA(Servicio servicio, String aplicaA) throws GeneralDataAccessException {
		List<Atributo> resultados = new ArrayList<Atributo>();
		try {
			String hql = "	  SELECT  A " + "			FROM Atributo AS A" + "			inner join A.tipoServicioAtributos AS TS " + "			WHERE " + "			A.aplicaA = '" + aplicaA + "' " + "			and TS.id= "
					+ servicio.getTipoServicio().getId() + "			and " + "		    A.id not in (SELECT A2.id FROM AtributoInstancia AS AI " + "								inner join AI.servicio AS S  "
					+ "								inner join AI.atributo AS A2 WHERE S.id=" + servicio.getId() + ")" + "           order by A.ordenParcial ";

			Query query = getSession().createQuery(hql);
			resultados = (List<Atributo>) query.list();

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	// Mejoras 201409 Nro: 78
	@Override
	public String getValueAtributoInstancia(Long idServico, String descriptor,
			String aplicaA) throws GeneralDataAccessException {
		try {
			AtributoInstancia ai;
			String hql = "Select  AI from AtributoInstancia  AI "
						 +" where AI.atributo.descriptor = '"+descriptor+"'"
						 +" and   AI.atributo.aplicaA = '"+aplicaA+"'"  
						 +" and   AI.servicio.id = '" +idServico+"'";

			Query query = getSession().createQuery(hql);
			ai =  (AtributoInstancia) query.uniqueResult();
			if(ai != null)
				return ai.getValor();

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

    @SuppressWarnings("unchecked")
    @Override
    public List<Atributo> getAtributosByAplica(String aplicaA) throws GeneralDataAccessException {
        List<Atributo> resultados = new ArrayList<Atributo>();
        try {
            String hql = "SELECT  AT FROM Atributo AS AT "
                    + " WHERE AT.aplicaA = :aplicacion ";

            
            Query query = getSession().createQuery(hql);
            resultados = (List<Atributo>) query.setParameter("aplicacion", aplicaA).list();
            for (Atributo atributo : resultados) {
                Hibernate.initialize(atributo.getTipoServicioAtributos());
            }
                
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
        }

        return resultados;
    }

}
