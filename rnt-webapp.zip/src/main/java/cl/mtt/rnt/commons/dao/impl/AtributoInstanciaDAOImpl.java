package cl.mtt.rnt.commons.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.AtributoInstanciaDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.encargado.dto.AtributoServicioLogDTO;
import cl.mtt.rnt.encargado.dto.VehiculoServicioDTO;

public class AtributoInstanciaDAOImpl extends GenericDAOImpl<AtributoInstancia> implements AtributoInstanciaDAO {

	Logger log = Logger.getLogger(this.getClass());

	public AtributoInstanciaDAOImpl(Class<AtributoInstancia> objectType) {
		super(objectType);

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AtributoInstancia> getAtributosInstanciaServicio(Servicio servicio) throws GeneralDataAccessException {
		List<AtributoInstancia> resultados = new ArrayList<AtributoInstancia>();
		try {
			String hql = "SELECT  distinct ATI FROM AtributoInstancia AS ATI "
			        + " join fetch ATI.atributo ATR "
			        + " join ATR.tipoServicioAtributos TSA "
			        + " WHERE ATI.servicio.id = " + servicio.getId()
			        + " AND TSA.tipoServicio.id = :idTipoServicio ";
			
			Query query = getSession().createQuery(hql);
			resultados = (List<AtributoInstancia>) query.setParameter("idTipoServicio", servicio.getTipoServicio().getId()).list();

//			String hqlMap = "select tsa from TipoServicioAtributo tsa where tsa.tipoServicio.id = :idTipoServicio";
//			List<TipoServicioAtributo> tsaRes = getSession().createQuery(hqlMap).setParameter("idTipoServicio", servicio.getTipoServicio().getId()).list();
//			Map<Long, TipoServicioAtributo> map = new HashMap<Long, TipoServicioAtributo>();
//			for (TipoServicioAtributo tipoServicioAtributo : tsaRes) {
//			    if (tipoServicioAtributo.getAtributo()!=null) {
//			        map.put(tipoServicioAtributo.getAtributo().getId(), tipoServicioAtributo);
//			    }
//			}
//			for (AtributoInstancia atr : resultados) {
//				TipoServicioAtributo tsa = map.get(atr.getAtributo().getId());
//				if(tsa!=null){
//					atr.getAtributo().setObligatorio(tsa.getObligatorio());
//					atr.getAtributo().setPrincipal(tsa.getPrincipal());
//				}else{
//					atr.getAtributo().setObligatorio(false);
//					atr.getAtributo().setPrincipal(false);
//				}
//			}
				
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AtributoInstancia> getAtributosInstanciaVehiculo(Vehiculo vehiculo) throws GeneralDataAccessException {
		List<AtributoInstancia> resultados = new ArrayList<AtributoInstancia>();
		try {
		    String hql = "SELECT  ATI FROM AtributoInstancia AS ATI "
                    + " join fetch ATI.atributo ATR "
//		            + " left join fetch ATR.fuenteDeDatos"
                    + " WHERE ATI.vehiculo.id = " + vehiculo.getId();
            
            Query query = getSession().createQuery(hql);
            resultados = (List<AtributoInstancia>) query.list();


		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	@SuppressWarnings("unchecked")
	@Override
    public List<AtributoServicioLogDTO> getAtributosLogInstanciaServicio(Long id) throws GeneralDataAccessException{
		try {
			String hql = " SELECT A.id, A.atributo.id, A.valor FROM AtributoInstancia AS A WHERE A.servicio.id = " + id;
			List<AtributoServicioLogDTO> resultados = new ArrayList<AtributoServicioLogDTO>();

			Query query = getSession().createQuery(hql);
			List<Object[]> res = query.list();
			for (Object[] objects : res) {
				AtributoServicioLogDTO att = new AtributoServicioLogDTO();
				att.setId((Long)objects[0]);
				att.setIdAtributo((Long)objects[1]);
				att.setValor((String)objects[2]);
				resultados.add(att);	
			}
			return resultados;
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	@Override
	public void updateLineaVsAud(Servicio servicio, String valor)	throws GeneralDataAccessException {
		// Se obtiene el Vehiculo Servicio Aud con mayor valor REV
		String sql = "SELECT MAX(REV) FROM NULLID.RNT_SERVICIO_AUD WHERE ID=" + String.valueOf(servicio.getId());
		Query query = getSession().createSQLQuery(sql);
		List resultset = query.list();
		Integer maxRev = null;
		if (resultset.size()==1) {
			maxRev = (Integer) resultset.get(0);
		}	
		
		if (maxRev != null) {
			for (VehiculoServicioDTO vs : servicio.getVehiculosSkeleton()) {
				
				if (vs.getEstado()!=null && (vs.getEstado().intValue() == 1)) {
					String sql2 = "SELECT COUNT(REV) FROM NULLID.RNT_VEHICULO_SERVICIO_AUD WHERE ID=" + String.valueOf(vs.getId()) + " AND REV = " + String.valueOf(maxRev);
					Query query2 = getSession().createSQLQuery(sql2);
					List resultset2 = query2.list();
					Integer cant2 = null;
					if (resultset2.size()==1) {
						cant2 = (Integer) resultset2.get(0);
					}	
					if (cant2.intValue() == 0) {
						String sqlInsert = "insert into nullid.RNT_VEHICULO_SERVICIO_AUD "
								+"	(ID,REV,REVTYPE,CREATION,MODIFIED,REGION_DESTINO,ESTADO,FECHA_ESTADO,RESOLUCION_CANCELACION_FECHA,RESOLUCION_CANCELACION_LINK,NUMERO_RESOLUCION,OBSERVACION_CANCELACION,FECHA_INGRESO, "
								+"	FECHA_LOGO,OBSERVACION,TIENE_CERTIFICADO_PROVISORIO,ID_USER_CREATION,ID_USER_MODIFIED,ID_TIPO_CANCELACION,TIPOSERVICIOSALIENTE_ID,ID_SERVICIO,ID_TIPO_INGRESO,ID_VEHICULO, "
								+"	RESPUESTA_FIRMADOR,MENSAJE_FIRMADOR,GLOSA,ID_REGLAMENTACION,ID_ZONA,ID_VEHICULO_REEMPLAZA,ID_VEHICULO_REEMPLAZADO,FECHA_VENCIMIENTO,ID_DOCUMENTO_BIBLIOTECA_CANCELACION, "
								+"	ID_DOCUMENTO_BIBLIOTECA_INSCRIPCION,NUMERO_LINEA) "
								+"	select ID,"+maxRev+",1,CREATION,MODIFIED,REGION_DESTINO,ESTADO,FECHA_ESTADO,RESOLUCION_CANCELACION_FECHA,RESOLUCION_CANCELACION_LINK,NUMERO_RESOLUCION,OBSERVACION_CANCELACION,FECHA_INGRESO, "
								+"	FECHA_LOGO,'CAMBIO DE LINEA',TIENE_CERTIFICADO_PROVISORIO,ID_USER_CREATION,ID_USER_MODIFIED,ID_TIPO_CANCELACION,TIPOSERVICIOSALIENTE_ID,ID_SERVICIO,ID_TIPO_INGRESO,ID_VEHICULO, "
								+"	RESPUESTA_FIRMADOR,MENSAJE_FIRMADOR,GLOSA,ID_REGLAMENTACION,ID_ZONA,ID_VEHICULO_REEMPLAZA,ID_VEHICULO_REEMPLAZADO,FECHA_VENCIMIENTO,ID_DOCUMENTO_BIBLIOTECA_CANCELACION, "
								+"	ID_DOCUMENTO_BIBLIOTECA_INSCRIPCION,'"+valor+"'  from nullid.RNT_VEHICULO_SERVICIO where id = " +String.valueOf(vs.getId());
						Query updateQuery = getSession().createSQLQuery(sqlInsert);
						updateQuery.executeUpdate();
					}
					else {
						String sqlUpdate = "UPDATE NULLID.RNT_VEHICULO_SERVICIO_AUD SET NUMERO_LINEA='" + valor + "' WHERE ID=" + String.valueOf(vs.getId()) + " AND REV=" + String.valueOf(maxRev);
						Query updateQuery = getSession().createSQLQuery(sqlUpdate);
						updateQuery.executeUpdate();
					}
					// Se actualiza el registro correspondiente en Vehiculo Servicio Aud 
				}
				
			}
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getValorAtributoInstanciaByIdServicioAndDescriptor(Long id,String descriptor, String aplicaAServicio)	throws GeneralDataAccessException {
		List<String> resultados = null;
		try {
		    String hql = "SELECT  ATI.valor FROM AtributoInstancia AS ATI "
                    + " join ATI.atributo ATR "
                    + " WHERE ATI.servicio.id = " + id
                    +  " AND ATR.descriptor = '"+descriptor+"'"
                    +  " AND ATR.aplicaA = '"+aplicaAServicio+"'";
            
            Query query = getSession().createQuery(hql);
            resultados = (List<String>) query.list();
            if ((resultados != null) && (!resultados.isEmpty())) {
            	return resultados.get(0);
            }
            return null;

		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}
}
