package cl.mtt.rnt.commons.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.AutorizacionMovimientoDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.util.StringUtil;

public class AutorizacionMovimientoDAOImpl  extends GenericDAOImpl<AutorizacionMovimiento>  implements AutorizacionMovimientoDAO {

	public AutorizacionMovimientoDAOImpl(
			Class<AutorizacionMovimiento> objectType) {
		super(objectType);
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<AutorizacionMovimiento> getAutorizacionesMovimientoPag(User user,int first,
			int rows, List<String> orderFields)
			throws GeneralDataAccessException {
		
		StringBuffer hql = new StringBuffer();
		hql.append("SELECT distinct AM " + " FROM AutorizacionMovimiento AS AM " + 
				   "inner join AM.autorizacion. grupoResponsable GR " +
				   "inner join GR.usuarios U " +
				    "WHERE  U.id = " + user.getId());
		
		if (orderFields == null || orderFields.size()==0){
			hql.append(" order by AM.creation DESC");
		}else{
			hql.append(" order by ");
			for (int i = 0; i < orderFields.size(); i++) {
				hql.append("AM."+orderFields.get(i));
				if(i!=orderFields.size()-1)
					hql.append(", ");
				hql.append(" ");
			}
		}
		
		Query query = getSession().createQuery(hql.toString());
		query.setFirstResult(first).setMaxResults(rows);

		List<AutorizacionMovimiento> resultados = new ArrayList<AutorizacionMovimiento>();
		resultados = (List<AutorizacionMovimiento>) query.list();
		if (resultados == null)
			resultados = new ArrayList<AutorizacionMovimiento>();

		return resultados;
	}

	@Override
	public long getAutorizacionesMovimientoCount(User user)
			throws GeneralDataAccessException {
		StringBuffer hql = new StringBuffer();
		hql.append("SELECT  Count(distinct AM) " + "FROM AutorizacionMovimiento AS AM " + 
				   "inner join AM.autorizacion. grupoResponsable GR " +
				   "inner join GR.usuarios U " +
				    "WHERE  U.id = " + user.getId());
		
		Query query = getSession().createQuery(hql.toString());
		
		return (Long)query.uniqueResult();	
	}

    @SuppressWarnings("unchecked")
    @Override
    public List<Grupo> getGrupoAutorizantesRevertir(Servicio servicio) throws GeneralDataAccessException {
        StringBuffer hql = new StringBuffer();
        hql.append("SELECT distinct GR " + " FROM Grupo AS GR " + 
                   "left outer join fetch GR.usuarios as USU " +
                   "inner join fetch GR.tipoTransporte as TT " +
                   "inner join fetch GR.medioTransporte as MT " +
                   "inner join fetch GR.categoriaTransporte as CT " +
                   
                   "where  " +
                    "  TT.id = " + servicio.getTipoServicio().getTipoTransporte().getId() +
                    " and  MT.id = " + servicio.getTipoServicio().getMedioTransporte().getId() +
                    " and  CT.id = " + servicio.getTipoServicio().getCategoriaTransporte().getId() +
                    " and  GR.nombre = 'AUTORIZA REVERTIR MOVIMIENTO' " +
                    " and  ( GR.codRegion = '00' or GR.codRegion = '" + servicio.getCodigoRegion() +"') ");
        
        
        
        Query query = getSession().createQuery(hql.toString());
        List<Grupo> resultados = (List<Grupo>) query.list();
        if (resultados == null)
            resultados = new ArrayList<Grupo>();

        return resultados;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Grupo> getGruposByCriteria(List<Region> regiones,List<Long> tipoTransporte, List<Long> medioTransporte,List<Long> categoriaTransporte) throws GeneralDataAccessException {
        if(regiones == null || regiones.isEmpty()){
            return null;
        }
        List<String> codigoRegiones = new ArrayList<String>();
        for(Region r : regiones){
            codigoRegiones.add(r.getCodigo());
        }       
        
        StringBuffer hql = new StringBuffer();
        hql.append("SELECT distinct GR " + " FROM Grupo AS GR " + 
                   "inner join fetch GR.tipoTransporte as TT " +
                   "inner join fetch GR.medioTransporte as MT " +
                   "inner join fetch GR.categoriaTransporte as CT " +
                   "where  " +
                    "   GR.nombre <> 'AUTORIZA REVERTIR MOVIMIENTO' " +
                    " and  GR.codRegion in " + StringUtil.getInClauseString(codigoRegiones));
        
        
        
        Query query = getSession().createQuery(hql.toString());
        List<Grupo> resultados = (List<Grupo>) query.list();
        if (resultados == null)
            resultados = new ArrayList<Grupo>();

        return resultados;
    }


}
