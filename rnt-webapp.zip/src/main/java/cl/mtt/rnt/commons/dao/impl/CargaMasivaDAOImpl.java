package cl.mtt.rnt.commons.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.dao.CargaMasivaDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.CargaMasiva;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoCargaMasiva;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.model.view.UserWrapper;

public class CargaMasivaDAOImpl extends GenericDAOImpl<CargaMasiva> implements CargaMasivaDAO {
	
	Logger log = Logger.getLogger(this.getClass());
	
	public CargaMasivaDAOImpl(Class<CargaMasiva> objectType) {
		super(objectType);
	}	
	
	@Override	
	public List<CargaMasiva> getCargasMasivas(User user, CategoriaTransporteSeleccionble categoria, Region region) throws GeneralDataAccessException {
		List<CargaMasiva> resultado = null;
		try{
			UserWrapper wrapper = (UserWrapper)user;
			Map<String, Object> obligatoryCriteria = new HashMap<String, Object>();
			obligatoryCriteria.put("categoria.id", categoria.getCategoria().getId());
			obligatoryCriteria.put("tipoTransporte.id", categoria.getTipoTransporte().getId());
			obligatoryCriteria.put("medio.id", categoria.getMedio().getId());
			obligatoryCriteria.put("codigoRegion", region.getCodigo());
			
			Map<String, Object> opt1=new HashMap<String, Object>();
			opt1.put("userCreation.id", wrapper.getUser().getId());
			opt1.put("compartido", false);

			Map<String, Object> opt2=new HashMap<String, Object>();
			opt2.put("compartido", true);
			
			List<Map<String, Object>> optionalCriteria=new ArrayList<Map<String,Object>>();
			optionalCriteria.add(opt1);
			optionalCriteria.add(opt2);
			
			List<String> sort= new ArrayList<String>();
			sort.add("estadoUltEjecucion");
			sort.add("modified desc");
			resultado = this.findBySimpleOptionalCriteria(obligatoryCriteria, optionalCriteria,sort);
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(), e);
		}
		return resultado;
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<TipoCargaMasiva> getTiposCargaMasiva() throws GeneralDataAccessException {
		List<TipoCargaMasiva> resultado = null;
		try{
			resultado = this.getSession().createCriteria(TipoCargaMasiva.class).list();
		}catch(Exception e){
			
		}
		return resultado;
	}

	@Override
	public int updateFechasVigencia(Servicio servicio) throws GeneralDataAccessException {
	    try{	    	
			String hqlUpdate = "update Servicio s set s.vigenciaDesde = :vigenciaDesdeParam, s.vigenciaHasta = :vigenciaHastaParam"
					+ " where s.id=:id";
			// or String hqlUpdate = "update Customer set name = :newName where name = :oldName";
			int updatedEntities = this.getSession().createQuery( hqlUpdate )
									.setLong("id", servicio.getId())
							        .setDate("vigenciaDesdeParam", servicio.getVigenciaDesde())
							        .setDate("vigenciaHastaParam", servicio.getVigenciaHasta())
							        .executeUpdate();
			return updatedEntities;
	    }catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(), e);
		}
		
	}

}
