package cl.mtt.rnt.commons.dao.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import cl.mtt.rnt.commons.dao.CertificadoDAO;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.CertificadoMigradoException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.comparator.CertificadoComparator;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.filter.CertificadoFilter;

import com.google.common.base.Joiner;

public class CertificadoDAOImpl extends GenericDAOImpl<Certificado> implements CertificadoDAO {

	Logger log = Logger.getLogger(this.getClass());

	@Autowired()
	@Qualifier("TipoCertificadoDAO")
	private GenericDAO<TipoCertificado> tipoCertificadoDAO;
	
	public CertificadoDAOImpl(Class<Certificado> objectType) {
		super(objectType);
	}

	@SuppressWarnings("unchecked")
	public List<Certificado> getCertificadosByFilter(CertificadoFilter filtro, CategoriaTransporte ct, User user, List<Long> ids) throws GeneralDataAccessException {
		List<Certificado> resultados = new ArrayList<Certificado>();
		try {

			StringBuffer hql = new StringBuffer();
			hql.append("SELECT  C " + " FROM Certificado AS C ")
			.append(" inner join C.vehiculo AS VS ")
			.append(" inner join VS.vehiculo AS V ")
			.append(" inner join VS.servicio AS S ")
			.append(" inner join S.tipoServicio AS TS ")
			.append(" left outer join C.tipoCertificado AS TC ")
			.append(" left outer join TC.claseTipoCertificado AS CTC ")
			.append(" inner join TS.tipoTransporte AS TT  ") 
			.append(" inner join TS.medioTransporte AS MT  ")
			.append(" inner join TS.categoriaTransporte AS CT  ")
//			.append(" WHERE C.fechaDesde <= '" + Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' and ")
//			.append(" C.fechaHasta >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()))
			.append(" WHERE C.creation <= '" + Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' and ")
			.append(" C.creation >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()))
			.append( "' and CT.id =  " + ct.getId() + " and MT.id in ("+ Joiner.on(",").join(user.getContext().getAllIdsMediosTransporte()) + ")")
			.append(" and TT.id in (" + Joiner.on(",").join(user.getContext().getAllIdsTiposTransportes()) + ")")
			.append(" and S.codigoRegion in ('" + Joiner.on("','").join(user.getContext().getAllCodigosRegiones()) + "') ")
			.append(" and (C.tipoCertificado is null OR CTC.objeto='vehiculo')");
			
			if(ids!=null && !ids.isEmpty()){
				hql.append(" and C.id in (" + Joiner.on(",").join(ids) + ")");
			}

			if (filtro.getTipoCertificado() != null && filtro.getTipoCertificado() != 0) {
				hql.append(" and TC.id = " + filtro.getTipoCertificado());
			}
			if (filtro.getTipoServicio() != null && filtro.getTipoServicio() != 0) {
				hql.append("  and TS.id = " + filtro.getTipoServicio());
			}
			if(filtro.getEstadosFirma()!=null && !filtro.getEstadosFirma().isEmpty()){				
				agregarCondicionEstadosFirma(filtro, hql);
			}
//			if(filtro.getFechaEmision()!=null){
//				hql.append(" and C.creation>='").append(Constants.dateFormatDB.format(filtro.getFechaEmision())).append(" 00:00:00'")
//				   .append(" and C.creation<='").append(Constants.dateFormatDB.format(filtro.getFechaEmision())).append(" 23:59:59.999'");
//			}
			if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty()){
				hql.append(" and V.ppu='").append(filtro.getPpu().toUpperCase()).append("'");
			}
			if(filtro.getNombreRecorrido()!=null && !filtro.getNombreRecorrido().isEmpty() ){
				hql.append(" and C.recorrido.nombre like '%").append(filtro.getNombreRecorrido()).append("%'");
			}

			if(filtro.getIdentServicio()!=null){
				hql.append(" and S.identServicio=").append(filtro.getIdentServicio());
			}
			if(filtro.getIdentificadorWS()!=null){
				hql.append(" and C.identificadorWS=").append(filtro.getIdentificadorWS());
			}
			hql.append(appendFiltroEstado(filtro));

			Query query = getSession().createQuery(hql.toString());
			resultados = (List<Certificado>) query.list();
			if (resultados == null)
				resultados = new ArrayList<Certificado>();
			
			if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty()){
				return resultados;
			}
			
			hql = new StringBuffer();
			hql.append("SELECT  C FROM Certificado AS C ")
			.append("inner join C.recorrido AS RS ") 
			.append("inner join RS.servicio AS S ")
			.append("inner join S.tipoServicio AS TS ")
			.append("inner join C.tipoCertificado AS TC ") 
			.append(" inner join TC.claseTipoCertificado AS CTC ")
			.append("inner join TS.tipoTransporte AS TT ") 
			.append("inner join TS.medioTransporte AS MT ")
			.append("inner join TS.categoriaTransporte AS CT ")
			.append("WHERE C.fechaDesde <= '"+ Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' and ")
			.append("C.fechaHasta >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()))
			.append("'  and CT.id =  " + ct.getId() + "       	and MT.id in (")
			.append(Joiner.on(",").join(user.getContext().getAllIdsMediosTransporte()) + ")")
			.append(" and TT.id in (" + Joiner.on(",").join(user.getContext().getAllIdsTiposTransportes()) + ")")
			.append(" and S.codigoRegion in ('" + Joiner.on("','").join(user.getContext().getAllCodigosRegiones()) + "') ")
			.append(" and CTC.objeto='recorrido'");

			if (filtro.getTipoCertificado() != null && filtro.getTipoCertificado() != 0) {
				hql.append(" and TC.id = " + filtro.getTipoCertificado());
			}
			if (filtro.getTipoServicio() != null && filtro.getTipoServicio() != 0) {
				hql.append("  and TS.id = " + filtro.getTipoServicio());
			}
			if(filtro.getNombreRecorrido()!=null && !filtro.getNombreRecorrido().isEmpty() ){
				hql.append(" and C.recorrido.nombre like '%").append(filtro.getNombreRecorrido()).append("%'");
			}
			hql.append(appendFiltroEstado(filtro));
			if(filtro.getEstadosFirma()!=null && !filtro.getEstadosFirma().isEmpty()){				
				agregarCondicionEstadosFirma(filtro, hql);
			}
			

			query = getSession().createQuery(hql.toString());
			List<Certificado> resultados2 = (List<Certificado>) query.list();
			if (resultados2 != null)
				resultados.addAll(resultados2);

			Collections.sort(resultados, new CertificadoComparator());

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	/**
	 * @param filtro
	 * @param hql
	 */
	private String appendFiltroEstado(CertificadoFilter filtro) {
		StringBuffer hql=new StringBuffer();
		if(filtro.getEstadoCertificado()!=null){
			String hoy = Constants.dateFormatDB.format(new Date())+" 23:59:59.999";
			int e=filtro.getEstadoCertificado().intValue();
			if(e == GenericCancellableModelObject.ESTADO_VENCIDO){
				hql.append(" and ( ( ");
				hql.append(" C.estado=").append(GenericCancellableModelObject.ESTADO_VIGENTE).append(" ");
				hql.append(" and C.fechaHasta <='").append(hoy).append("' ");
				hql.append(" ) or ( ");
				hql.append(" C.estado=").append(GenericCancellableModelObject.ESTADO_VENCIDO).append(" ");
				hql.append(" )) ");
			}else if(e == GenericCancellableModelObject.ESTADO_VIGENTE){
				hql.append(" and C.estado=").append(GenericCancellableModelObject.ESTADO_VIGENTE).append(" ");
				hql.append(" and C.fechaHasta >'").append(hoy).append("' ");
			}else if(e == GenericCancellableModelObject.ESTADO_CANCELADO){
				hql.append(" and C.estado=").append(GenericCancellableModelObject.ESTADO_CANCELADO).append(" ");
			}
		}
		return hql.toString();
	}
	
	@SuppressWarnings("unchecked")
    public List<Certificado> getCertificadosByFilter(CertificadoFilter filtro) throws GeneralDataAccessException{
		List<Certificado> resultados = new ArrayList<Certificado>();
		try {

			StringBuffer hql = new StringBuffer();
			hql.append("SELECT  C " + " FROM Certificado AS C ")
			.append(" inner join C.vehiculo AS VS ")
			.append(" inner join VS.vehiculo AS V ")
			.append(" inner join VS.servicio AS S ")
			.append(" inner join S.tipoServicio AS TS ")
			.append(" inner join C.tipoCertificado AS TC ")
			.append(" inner join TC.claseTipoCertificado AS CTC ")
			.append(" inner join TS.tipoTransporte AS TT  ") 
			.append(" inner join TS.medioTransporte AS MT  ")
			.append(" inner join TS.categoriaTransporte AS CT  ")
			.append(" WHERE CTC.objeto='vehiculo' ");
			if(filtro.getFechaHasta()!=null){
				hql.append(" and C.creation <= '" + Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' ");
			}
			if(filtro.getFechaDesde()!=null){
				hql.append(" and C.creation >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()));
			}
			if (filtro.getTipoCertificado() != null && filtro.getTipoCertificado() != 0) {
				hql.append(" and TC.id = " + filtro.getTipoCertificado());
			}
			if (filtro.getTipoServicio() != null && filtro.getTipoServicio() != 0) {
				hql.append("  and TS.id = " + filtro.getTipoServicio());
			}
			if(filtro.getEstadosFirma()!=null && !filtro.getEstadosFirma().isEmpty()){				
				agregarCondicionEstadosFirma(filtro, hql);
			}
//			if(filtro.getFechaEmision()!=null){
//				hql.append(" and C.creation>='").append(Constants.dateFormatDB.format(filtro.getFechaEmision())).append(" 00:00:00'")
//				   .append(" and C.creation<='").append(Constants.dateFormatDB.format(filtro.getFechaEmision())).append(" 23:59:59.999'");
//			}
			if(filtro.getFechaHasta()!=null){
				hql.append(" and C.creation <= '" + Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' ");
			}
			if(filtro.getFechaDesde()!=null){
				hql.append(" and C.creation >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()) + "' ");
			}
			if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty()){
				hql.append(" and V.ppu='").append(filtro.getPpu().toUpperCase()).append("'");
			}
			if(filtro.getIdentServicio()!=null){
				hql.append(" and S.identServicio=").append(filtro.getIdentServicio());
			}
			if(filtro.getIdentificadorWS()!=null){
				hql.append(" and C.identificadorWS=").append(filtro.getIdentificadorWS());
			}
			hql.append(appendFiltroEstado(filtro));

			Query query = getSession().createQuery(hql.toString());
			resultados = (List<Certificado>) query.list();
			if (resultados == null)
				resultados = new ArrayList<Certificado>();
			
			if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty()){
				return resultados;
			}
			
			hql = new StringBuffer();
			hql.append("SELECT  C FROM Certificado AS C ")
			.append("inner join C.recorrido AS RS ") 
			.append("inner join RS.servicio AS S ")
			.append("inner join S.tipoServicio AS TS ")
			.append("inner join C.tipoCertificado AS TC ") 
			.append(" inner join TC.claseTipoCertificado AS CTC ")
			.append("inner join TS.tipoTransporte AS TT ") 
			.append("inner join TS.medioTransporte AS MT ")
			.append("inner join TS.categoriaTransporte AS CT ")
			.append("WHERE CTC.objeto='recorrido' ");

			if (filtro.getTipoCertificado() != null && filtro.getTipoCertificado() != 0) {
				hql.append(" and TC.id = " + filtro.getTipoCertificado());
			}
			if (filtro.getTipoServicio() != null && filtro.getTipoServicio() != 0) {
				hql.append("  and TS.id = " + filtro.getTipoServicio());
			}
			if(filtro.getEstadosFirma()!=null && !filtro.getEstadosFirma().isEmpty()){				
				agregarCondicionEstadosFirma(filtro, hql);
			}
			if(filtro.getFechaHasta()!=null){
				hql.append(" and C.creation <= '" + Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' ");
			}
			if(filtro.getFechaDesde()!=null){
				hql.append(" and C.creation >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()) + "' ");
			}
			hql.append(appendFiltroEstado(filtro));
			

			query = getSession().createQuery(hql.toString());
			List<Certificado> resultados2 = (List<Certificado>) query.list();
			if (resultados2 != null)
				resultados.addAll(resultados2);

			Collections.sort(resultados, new CertificadoComparator());

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	@SuppressWarnings("unchecked")
	public List<Long> getIdsCertificadosByFilter(CertificadoFilter filtro, CategoriaTransporte ct, User user) throws GeneralDataAccessException {
		List<Long> resultados = new ArrayList<Long>();
		try {

			StringBuffer hql = new StringBuffer();
			hql.append("SELECT  C.id " + " FROM Certificado AS C ")
			.append(" inner join C.vehiculo AS VS ")
			.append(" inner join VS.servicio AS S ")
			.append(" inner join VS.vehiculo AS V ")
			.append(" inner join S.tipoServicio AS TS ")
			.append(" left outer join C.tipoCertificado AS TC ")
			.append(" left outer join TC.claseTipoCertificado AS CTC ")
			.append(" inner join TS.tipoTransporte AS TT  ") 
			.append(" inner join TS.medioTransporte AS MT  ")
			.append(" inner join TS.categoriaTransporte AS CT  ")
			.append(" WHERE C.creation <= '" + Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' and ")
			.append(" C.creation >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()))
			.append( "' and CT.id =  " + ct.getId() + " and MT.id in ("+ Joiner.on(",").join(user.getContext().getAllIdsMediosTransporte()) + ")")
			.append(" and TT.id in (" + Joiner.on(",").join(user.getContext().getAllIdsTiposTransportes()) + ")")
			.append(" and S.codigoRegion in ('" + Joiner.on("','").join(user.getContext().getAllCodigosRegiones()) + "') ")
			.append(" and (C.tipoCertificado is null OR CTC.objeto='vehiculo') ");

			if (filtro.getTipoCertificado() != null && filtro.getTipoCertificado() != 0) {
				hql.append(" and TC.id = " + filtro.getTipoCertificado());
			}
			if (filtro.getTipoServicio() != null && filtro.getTipoServicio() != 0) {
				hql.append("  and TS.id = " + filtro.getTipoServicio());
			}
			
			if(filtro.getEstadosFirma()!=null && !filtro.getEstadosFirma().isEmpty()){				
				agregarCondicionEstadosFirma(filtro, hql);
			}
			
//			if(filtro.getFechaEmision()!=null){
//				hql.append(" and C.creation>='").append(Constants.dateFormatDB.format(filtro.getFechaEmision())).append(" 00:00:00'")
//				   .append(" and C.creation<='").append(Constants.dateFormatDB.format(filtro.getFechaEmision())).append(" 23:59:59.999'");
//			}
			if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty()){
				hql.append(" and V.ppu = '").append(filtro.getPpu().toUpperCase()).append("'");
			}
			if(filtro.getNombreRecorrido()!=null && !filtro.getNombreRecorrido().isEmpty() ){
				hql.append(" and C.recorrido.nombre like '%").append(filtro.getNombreRecorrido()).append("%'");
			}
			hql.append(appendFiltroEstado(filtro));
			if(filtro.getIdentServicio()!=null){
				hql.append(" and S.identServicio=").append(filtro.getIdentServicio());
			}
			if(filtro.getIdentificadorWS()!=null){
				hql.append(" and C.identificadorWS=").append(filtro.getIdentificadorWS());
			}
			
			Query query = getSession().createQuery(hql.toString());
			resultados = (List<Long>) query.list();
			if (resultados == null)
				resultados = new ArrayList<Long>();
			
			if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty()){// no debería hacer el script de recorridos ya que filtra por ppu
				return resultados;
			}

			hql = new StringBuffer();
			hql.append("SELECT  C.id FROM Certificado AS C ")
			.append("inner join C.recorrido AS RS ") 
			.append("inner join RS.servicio AS S ")
			.append("inner join S.tipoServicio AS TS ")
			.append("inner join C.tipoCertificado AS TC ") 
			.append("inner join TC.claseTipoCertificado AS CTC ")
			.append("inner join TS.tipoTransporte AS TT ") 
			.append("inner join TS.medioTransporte AS MT ")
			.append("inner join TS.categoriaTransporte AS CT ")
			.append("WHERE C.fechaDesde <= '"+ Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' and ")
			.append("C.fechaHasta >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()))
			.append("'  and CT.id =  " + ct.getId() + "       	and MT.id in (")
			.append(Joiner.on(",").join(user.getContext().getAllIdsMediosTransporte()) + ")")
			.append(" and TT.id in (" + Joiner.on(",").join(user.getContext().getAllIdsTiposTransportes()) + ")")
			.append(" and S.codigoRegion in ('" + Joiner.on("','").join(user.getContext().getAllCodigosRegiones()) + "') ")
			.append(" and CTC.objeto='recorrido'");

			if (filtro.getTipoCertificado() != null && filtro.getTipoCertificado() != 0) {
				hql.append(" and TC.id = " + filtro.getTipoCertificado());
			}
			if (filtro.getTipoServicio() != null && filtro.getTipoServicio() != 0) {
				hql.append("  and TS.id = " + filtro.getTipoServicio());
			}
			if(filtro.getNombreRecorrido()!=null && !filtro.getNombreRecorrido().isEmpty() ){
				hql.append(" and C.recorrido.nombre like '%").append(filtro.getNombreRecorrido()).append("%'");
			}
			hql.append(appendFiltroEstado(filtro));
			if(filtro.getEstadosFirma()!=null && !filtro.getEstadosFirma().isEmpty()){				
				agregarCondicionEstadosFirma(filtro, hql);
			}

			query = getSession().createQuery(hql.toString());
			List<Long> resultados2 = (List<Long>) query.list();
			if (resultados2 != null)
				resultados.addAll(resultados2);

			Collections.sort(resultados);

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	private void agregarCondicionEstadosFirma(CertificadoFilter filtro,StringBuffer hql) {
		
		hql.append(" and C.estadoFirma in ('");
		hql.append(Joiner.on("','").join(filtro.getCheckedEstadosFirma()));
		hql.append("')");

//		boolean first = true;
//		for(SelectionItem estadoFirma : filtro.getEstadosFirma()){
//			if(estadoFirma.isChecked()){
//				if(first){
//					hql.append(" and (");
//				}else{
//					hql.append(" or");
//				}			
//				hql.append(" C.estadoFirma='").append(estadoFirma.getLabel()).append("'");
//				first=false;
//			}
//		}
//		hql.append(")");
	}

	@Override
	public Certificado getCurrentCertificado(Long vsId) throws GeneralDataAccessException, CertificadoMigradoException {
		try {
			String hql = "	  SELECT  C " + "			FROM Certificado AS C " + "			join fetch C.tipoCertificado AS TC" + "			join fetch TC.seccion AS TS" + "			WHERE " + "			C.vehiculo.id = " + vsId
					+ "           and C.estado = 1" + "			order by C.creation desc";
			Query query = getSession().createQuery(hql);
			@SuppressWarnings("unchecked")
			List<Certificado> resultados2 = (List<Certificado>) query.list();
			if ((resultados2 != null) && (!resultados2.isEmpty())) {
				Certificado cert = resultados2.get(0); 
				if (cert.getTipoCertificado().getModified().before(cert.getModified())){
					return cert;
				}else {
					throw new CertificadoMigradoException("Certificado Modificado");
				}
			} else {
				hql = " SELECT  C FROM Certificado AS C WHERE C.vehiculo.id = " + vsId + " and C.estado = 1";
				query = getSession().createQuery(hql);
				resultados2 = (List<Certificado>) query.list();
				if ((resultados2 != null) && (!resultados2.isEmpty())) {
					throw new CertificadoMigradoException("Certificado Migrado");
				}
			}
		} catch (CertificadoMigradoException e) {
			throw new CertificadoMigradoException("Certificado Migrado");
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
		return null;
	}

	public List<Certificado> getCurrentCertificados(Long servicioId) throws GeneralDataAccessException, CertificadoMigradoException {
		try {
			
			String hql = " SELECT  C  FROM Certificado AS C join fetch C.tipoCertificado AS TC join fetch TC.seccion AS TS WHERE  C.vehiculo.servicio.id = " + servicioId
					+ " and C.estado = 1 ";
			Query query = getSession().createQuery(hql);
			return (List<Certificado>) query.list();
			
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}


	public List<Certificado> getCurrentsCertificadosByVS(Long vsId) throws GeneralDataAccessException{
		try {
			
			String hql = " SELECT  C  FROM Certificado AS C left outer join fetch C.tipoCertificado AS TC left outer join fetch TC.claseTipoCertificado AS CC left outer join fetch C.xml WHERE  C.vehiculo.id = " + vsId
					+ " and C.estado = 1 ";
			Query query = getSession().createQuery(hql);
			return (List<Certificado>) query.list();
			
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	@Override
	public Certificado getCurrentCertificado(Long vsId, Long recoId) throws GeneralDataAccessException, CertificadoMigradoException {
		try {
			String hql = "	  SELECT  C " + "			FROM Certificado AS C " + "			join fetch C.tipoCertificado AS TC" + "			join fetch TC.seccion AS TS" + "			WHERE " + "			C.vehiculo.id = " + vsId
					+ "			and C.recorrido.id = " + recoId + "           and C.estado = 1" + "			order by C.creation desc";
			Query query = getSession().createQuery(hql);
			@SuppressWarnings("unchecked")
			List<Certificado> resultados2 = (List<Certificado>) query.list();
			if ((resultados2 != null) && (!resultados2.isEmpty())) {
				Certificado cert = resultados2.get(0); 
				if (cert.getTipoCertificado().getModified().before(cert.getModified())){
					return cert;
				}else {
					throw new CertificadoMigradoException("Certificado Modificado");
				}
			} else {
				hql =  " SELECT  C FROM Certificado AS C WHERE C.vehiculo.id = " + vsId	+ " and C.recorrido.id = " + recoId + " and C.estado = 1";
				query = getSession().createQuery(hql);
				resultados2 = (List<Certificado>) query.list();
				if ((resultados2 != null) && (!resultados2.isEmpty())) {
					throw new CertificadoMigradoException("Certificado Migrado");
				}
			}
		} catch (CertificadoMigradoException e) {
			throw new CertificadoMigradoException("Certificado Migrado");
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Certificado> getCertificadosByServicio(Long id, String objeto, int first, int rows, CertificadoFilter filtro, List<String> orderFields,List<Long> idsVS) throws GeneralDataAccessException {
		if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty() && objeto.equals(TipoCertificado.OBJETO_RECORRIDO)){
			return new ArrayList<Certificado>();
		}

		StringBuffer hql = getCertificadoByServicioHQL(id, objeto, filtro,idsVS);
		
		if (orderFields == null || orderFields.size()==0){
			hql.append(" order by C.creation DESC");
		}else{
			hql.append(" order by ");
			for (int i = 0; i < orderFields.size(); i++) {
				hql.append("C."+orderFields.get(i));
				if(i!=orderFields.size()-1)
					hql.append(", ");
				hql.append(" ");
			}
		}
		
		Query query = getSession().createQuery(hql.toString());
		query.setFirstResult(first).setMaxResults(rows);

		List<Certificado> resultados = new ArrayList<Certificado>();
		resultados = (List<Certificado>) query.list();
		if (resultados == null)
			resultados = new ArrayList<Certificado>();

		return resultados;
	}

	private StringBuffer getCertificadoByServicioCountHQL(Long idServicio,String objeto, CertificadoFilter filtro,List<Long> idsVS) {
		StringBuffer hql = new StringBuffer();
		hql.append("SELECT  Count(C.id)  FROM Certificado AS C ");
		
		getCertificadoByServicioQueryTailHQL(idServicio, objeto, filtro, hql,idsVS);
		return hql;
	}
	
	private StringBuffer getCertificadoByServicioHQL(Long idServicio,String objeto, CertificadoFilter filtro,List<Long> idsVS) {
		StringBuffer hql = new StringBuffer();
		hql.append("SELECT  C " + " FROM Certificado AS C "
		        + " left outer join fetch C.xml AS XML1 ");
		
		getCertificadoByServicioQueryTailHQL(idServicio, objeto, filtro, hql,idsVS);
		return hql;
	}

	private void getCertificadoByServicioQueryTailHQL(Long idServicio,
			String objeto, CertificadoFilter filtro, StringBuffer hql,List<Long> idsVS) {

//		hql.append(" join C.tipoCertificado AS TC ");

//		if (objeto.equals(TipoCertificado.OBJETO_VEHICULO)) {
//			if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty()){
//				hql.append(" inner join C.vehiculo AS VS");
//				hql.append(" inner join VS.vehiculo AS V");
//			}
//		}
//			else {
//			hql.append(" inner join C.recorrido AS RS inner join C.tipoCertificado AS TC ");
//		}

//		hql.append(" inner join TC.claseTipoCertificado AS CTC ");
		hql.append(" left outer join C.tipoCertificado AS TC ");
		hql.append(" left outer join TC.claseTipoCertificado AS CTC ");
		
		
		hql.append(" WHERE");
//		.append(" WHERE " + " S.id = " + idServicio );
		
		if ((idsVS!=null)&&(!idsVS.isEmpty())) {
        		if (objeto.equals(TipoCertificado.OBJETO_VEHICULO)) {
        			hql.append(" C.vehiculo.id in (");
        		}else{
        			hql.append(" C.recorrido.id in (");
        		}
        		hql.append(Joiner.on(',').join(idsVS));
        		hql.append(")");
		}
		else  {
		    if (objeto.equals(TipoCertificado.OBJETO_VEHICULO)) {
                hql.append(" C.vehiculo.id = 0 ");
            }else{
                hql.append(" C.recorrido.id = 0 ");
            }
		}

	    if (objeto.equals(TipoCertificado.OBJETO_VEHICULO)) {
	    	hql.append(" and (C.tipoCertificado is null OR CTC.objeto='"+objeto+"') ");
	    }else{
        	hql.append(" and CTC.objeto='"+objeto+"' ");
        }
		

		if (filtro.getFechaHasta() != null) {
			hql.append(" and C.creation <= '" + Constants.dateFormatDB.format(filtro.getFechaHasta()) + " 23:59:59.999' ");
		}		
		if (filtro.getFechaDesde() != null) {
			hql.append(" and C.creation >= '" + Constants.dateFormatDB.format(filtro.getFechaDesde()) + "' ");
		}

		
		if (filtro.getTipoCertificado() != null && filtro.getTipoCertificado() != 0) {
			hql.append(" and C.tipoCertificado.id = " + filtro.getTipoCertificado());
		}
//		if (filtro.getTipoServicio() != null && filtro.getTipoServicio() != 0) {
//			hql.append("  and TS.id = " + filtro.getTipoServicio());
//		}
		hql.append(appendFiltroEstado(filtro));

		if(filtro.getEstadosFirma()!=null && !filtro.getEstadosFirma().isEmpty()){				
			agregarCondicionEstadosFirma(filtro, hql);
		}
//		if(filtro.getFechaEmision()!=null){
//			hql.append(" and C.creation>='").append(Constants.dateFormatDB.format(filtro.getFechaEmision())).append(" 00:00:00'")
//			   .append(" and C.creation<='").append(Constants.dateFormatDB.format(filtro.getFechaEmision())).append(" 23:59:59.999'");
//		}
		if(filtro.getPpu()!=null && !filtro.getPpu().isEmpty() && objeto.equals(TipoCertificado.OBJETO_VEHICULO)){
			hql.append(" and C.vehiculo.vehiculo.ppu='").append(filtro.getPpu().toUpperCase()).append("'");
		}
		if(filtro.getNombreRecorrido()!=null && !filtro.getNombreRecorrido().isEmpty() ){
			hql.append(" and upper(C.recorrido.nombre) like '%").append(filtro.getNombreRecorrido().toUpperCase()).append("%'");
		}
//		if(filtro.getIdentServicio()!=null){
//			hql.append(" and S.identServicio=").append(filtro.getIdentServicio());
//		}
		if(filtro.getIdentificadorWS()!=null){
			hql.append(" and C.identificadorWS=").append(filtro.getIdentificadorWS());
		}
	}
	
	public long getCertificadosByServicioCount(Long id, String objeto,CertificadoFilter filter,List<Long> idsVS) throws GeneralDataAccessException {
		if(filter.getPpu()!=null && !filter.getPpu().isEmpty() && objeto.equals(TipoCertificado.OBJETO_RECORRIDO)){
			return 0l;
		}
		StringBuffer hql = getCertificadoByServicioCountHQL(id, objeto, filter,idsVS);
		Query query = getSession().createQuery(hql.toString());
		
		return (Long)query.uniqueResult();
		
	}
	
	public TipoCertificado getTipoCertificadoByReglamentacioTipoServicio(String movimiento, String objeto,Long idReglamentacion, Long idTipoServicio) throws GeneralDataAccessException {
		try {
			StringBuffer sql = new StringBuffer();
			sql.append(" SELECT TC.id FROM NULLID.RNT_TIPO_SERVICIO AS TS ")
				.append(" INNER JOIN nullid.RNT_TIPO_CERTIFICADO_REG_TIPO_SERVICIO AS TCTS ON TS.ID = TCTS.ID_TIPO_SERVICIO ")
				.append(" INNER JOIN nullid.RNT_TIPO_CERTIFICADO_REGLAMENTADO TCR on TCR.ID = TCTS.ID_TIPO_CERTIFICADO_REG and TCR.ID_REGLAMENTACION = "+idReglamentacion.toString()+" ")
				.append(" INNER JOIN NULLID.RNT_TIPO_CERTIFICADO AS TC ON TCR.ID_TIPO_CERTIFICADO=TC.ID  ")
				.append(" INNER JOIN NULLID.RNT_CLASE_TIPO_CERTIFICADO AS CTC ON TC.ID_CLASE_TIPO_CERTIFICADO=CTC.ID ") 
				.append(" WHERE CTC.movimiento = '"+movimiento+"' and objeto = '"+objeto+"' ")
				.append(" and   TS.id = " + idTipoServicio);
			
			Query query = getSession().createSQLQuery(sql.toString());
			BigInteger bg = (BigInteger) query.uniqueResult();
			if (bg!=null) {
				return tipoCertificadoDAO.getByPrimaryKey(bg.longValue());
			}
		}
		catch (Exception e) {
			throw new GeneralDataAccessException(e.getMessage());
		}
		return null;	
	}

	@Override
	public TipoCertificado getTipoCertificadoTipoServicioDefault(String movimiento, String objeto, Long idTipoServicio) throws GeneralDataAccessException {
		try {
			StringBuffer sql = new StringBuffer();
			sql.append(" SELECT TC.id FROM NULLID.RNT_TIPO_SERVICIO AS TS ")
				.append(" INNER JOIN nullid.RNT_TIPO_CERTIFICADO_REG_TIPO_SERVICIO AS TCTS ON TS.ID = TCTS.ID_TIPO_SERVICIO ")
				.append(" INNER JOIN nullid.RNT_TIPO_CERTIFICADO_REGLAMENTADO TCR on TCR.ID = TCTS.ID_TIPO_CERTIFICADO_REG and TCR.ID_REGLAMENTACION IS NULL ")
				.append(" INNER JOIN NULLID.RNT_TIPO_CERTIFICADO AS TC ON TCR.ID_TIPO_CERTIFICADO=TC.ID  ")
				.append(" INNER JOIN NULLID.RNT_CLASE_TIPO_CERTIFICADO AS CTC ON TC.ID_CLASE_TIPO_CERTIFICADO=CTC.ID ") 
				.append(" WHERE CTC.movimiento = '"+movimiento+"' and objeto = '"+objeto+"' ")
				.append(" and   TS.id = " + idTipoServicio);
			
			Query query = getSession().createSQLQuery(sql.toString());
			BigInteger bg = (BigInteger) query.uniqueResult();
			if (bg!=null) {
				return tipoCertificadoDAO.getByPrimaryKey(bg.longValue());
			}
		}
		catch (Exception e) {
			throw new GeneralDataAccessException(e.getMessage());
		}
		return null;	
	}
	
	public Long getCountCertificadosByTipoCertificadoAndEstado(String estadoFirma, boolean soloVigentes, Long idTipoCertificado)throws GeneralDataAccessException{
		try {
    	    StringBuffer hql = new StringBuffer();
    		hql.append("SELECT  Count(C.id)  FROM Certificado AS C ")
    			.append( " WHERE estadoFirma = '"+estadoFirma+"' ");
    		if(soloVigentes){
    			hql.append( " AND C.fechaHasta >= current_date ");
    		}
    		hql.append( " AND tipoCertificado.id = "+idTipoCertificado+" ");
    		
    		Query query = getSession().createQuery(hql.toString());
    		
    		return (Long)query.uniqueResult();
		}
        catch (Exception e) {
            Logger.getLogger(CertificadoDAOImpl.class).error(e.getLocalizedMessage(), e);
            throw new GeneralDataAccessException(e.getMessage());
        }
	}

	public Long getCountCertificadosByServicioAndEstado(String estadoFirma, Long idServicio)throws GeneralDataAccessException{
	    try {
    		StringBuffer hql = new StringBuffer();
//    		hql.append("SELECT  Count(C.id) AS cantidad " + " FROM Certificado AS C ")
//    			.append( " left outer join C.recorrido AS R left outer join C.vehiculo AS V ")
//    			.append( " WHERE C.estadoFirma = '"+estadoFirma+"' ")
//    			.append( " AND C.estado = 1 AND C.fechaHasta >= CURRENT_DATE()")
//    			.append( " AND ( R.servicio.id = "+idServicio+" ")
//    		.append( " OR V.servicio.id = "+idServicio+" ) ");
    		
          hql.append(" select sum(col_0_0_) from ");
          hql.append("(select count(certificad0_.ID) as col_0_0_ from NULLID.RNT_CERTIFICADO certificad0_ left outer join NULLID.RNT_RECORRIDO recorrido1_ on certificad0_.ID_RECORRIDO=recorrido1_.ID left outer join NULLID.RNT_VEHICULO_SERVICIO vehiculose2_ on certificad0_.ID_VEHICULO_SERVICIO=vehiculose2_.ID where certificad0_.ESTADO_FIRMA='"+estadoFirma+"' "); 
          hql.append("and certificad0_.ESTADO=1 and certificad0_.FECHA_HASTA>=current date  ");
          hql.append("and vehiculose2_.ID_SERVICIO="+idServicio+" ");
          hql.append("union all ");
          hql.append("select count(certificad0_.ID) as col_0_0_ from NULLID.RNT_CERTIFICADO certificad0_ left outer join NULLID.RNT_RECORRIDO recorrido1_ on certificad0_.ID_RECORRIDO=recorrido1_.ID left outer join NULLID.RNT_VEHICULO_SERVICIO vehiculose2_ on certificad0_.ID_VEHICULO_SERVICIO=vehiculose2_.ID where certificad0_.ESTADO_FIRMA='"+estadoFirma+"' "); 
          hql.append("and certificad0_.ESTADO=1 and certificad0_.FECHA_HASTA>=current date  ");
          hql.append("and recorrido1_.ID_SERVICIO="+idServicio+") DATA1 ");
    		
    	  Query query = getSession().createSQLQuery(hql.toString());
    		
    	  return ((Integer)query.uniqueResult()).longValue();
    	}
        catch (Exception e) {
            Logger.getLogger(CertificadoDAOImpl.class).error(e.getLocalizedMessage(), e);
            throw new GeneralDataAccessException(e.getMessage());
        }
	}
	
	public Certificado getCountCertificadosByVehiculoAndEstado(String estadoFirma, Long idVehiculo) throws GeneralDataAccessException{
	    try {
    		StringBuffer hql = new StringBuffer();
//    		hql.append("SELECT  Count(C.id) AS cantidad " + " FROM Certificado AS C ")
//    			.append( " left outer join C.recorrido AS R left outer join C.vehiculo AS V ")
//    			.append( " WHERE C.estadoFirma = '"+estadoFirma+"' ")
//    			.append( " AND C.estado = 1 AND C.fechaHasta >= CURRENT_DATE()")
//    			.append( " AND ( R.servicio.id = "+idServicio+" ")
//    		.append( " OR V.servicio.id = "+idServicio+" ) ");
    		
          hql.append("select certificad0_.ID as col_0_0_ from NULLID.RNT_CERTIFICADO certificad0_ left outer join NULLID.RNT_RECORRIDO recorrido1_ on certificad0_.ID_RECORRIDO=recorrido1_.ID left outer join NULLID.RNT_VEHICULO_SERVICIO vehiculose2_ on certificad0_.ID_VEHICULO_SERVICIO=vehiculose2_.ID where certificad0_.ESTADO_FIRMA='"+estadoFirma+"' "); 
          hql.append("and certificad0_.ESTADO=1 and certificad0_.FECHA_HASTA>=current date  ");
          hql.append("and vehiculose2_.ID_VEHICULO="+idVehiculo+" ");
    		
    	  Query query = getSession().createSQLQuery(hql.toString());
    	  BigInteger uniqueResult = (BigInteger)query.uniqueResult();
    	  if(uniqueResult==null){
    		  return null;
    	  }
    	  Long id = uniqueResult.longValue();
    		
    	  return getByPrimaryKey(id);
    	}
        catch (Exception e) {
            Logger.getLogger(CertificadoDAOImpl.class).error(e.getLocalizedMessage(), e);
            throw new GeneralDataAccessException(e.getMessage());
        }
	}


	
	@SuppressWarnings("unchecked")
	@Override
    public List<Long> getReglamentacionesEnTiposCertificado() throws GeneralDataAccessException {
	    try {
    	    StringBuffer hql = new StringBuffer();
            hql.append("SELECT distinct TCR.reglamentacion.id FROM TipoCertificadoReglamentado AS TCR ");
            Query query = getSession().createQuery(hql.toString());
            return query.list();
	    }
	    catch (Exception e) {
	        Logger.getLogger(CertificadoDAOImpl.class).error(e.getLocalizedMessage(), e);
	        throw new GeneralDataAccessException(e.getMessage());
	    }
	}
	
	@SuppressWarnings("unchecked")
    @Override
    public List<Long> getTiposDeServicioAllReglamentacionesEnTiposCertificado() throws GeneralDataAccessException {
        try {
            StringBuffer hql = new StringBuffer();
            hql.append("SELECT distinct TS.id FROM TipoCertificadoReglamentado AS TCR "
                    + " join TCR.tiposServicio as TS"
                    + " where TCR.reglamentacion is null ");
            Query query = getSession().createQuery(hql.toString());
            return query.list();
        }
        catch (Exception e) {
            Logger.getLogger(CertificadoDAOImpl.class).error(e.getLocalizedMessage(), e);
            throw new GeneralDataAccessException(e.getMessage());
        }
    }


}
