package cl.mtt.rnt.commons.dao.impl;

import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.ConductorServicioDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class ConductorServicioDAOImpl extends GenericDAOImpl<ConductorServicio>  implements ConductorServicioDAO {

	public ConductorServicioDAOImpl(Class<ConductorServicio> objectType) {
		super(objectType);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void deleteConductorServicioRechazada(ConductorServicio cs)throws GeneralDataAccessException {
		try {
			String hql;
			String sql;
			Query query;
			
			//conductor vehiculo
			sql = " DELETE FROM NULLID.RNT_CONDUCTOR_VEHICULO_AUD WHERE ID_CONDUCTOR_SERVICIO ="+cs.getId();
			query = getSession().createSQLQuery(sql);
			query.executeUpdate();
			
			hql = " DELETE   FROM ConductorVehiculo CV  WHERE CV.conductorServicio.id  ="+cs.getId();
			query = getSession().createQuery(hql);
			query.executeUpdate();

			//conductor servicio
			sql = "DELETE FROM NULLID.RNT_CONDUCTOR_SERVICIO_AUD WHERE ID ="+cs.getId();
			query = getSession().createSQLQuery(sql);
			query.executeUpdate();
			
			hql = " DELETE   FROM ConductorServicio CS  WHERE CS.id ="+cs.getId();
			query = getSession().createQuery(hql);
			query.executeUpdate();
			
			} catch (Exception e) {;
				log.error(GeneralDataAccessException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
				throw new GeneralDataAccessException(GeneralDataAccessException.DELETE_ERROR, e);
			}
	}

}
