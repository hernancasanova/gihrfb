package cl.mtt.rnt.commons.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.ContactoDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Contacto;
import cl.mtt.rnt.commons.model.core.Servicio;

public class ContactoDAOImpl extends GenericDAOImpl<Contacto> implements ContactoDAO {

	public ContactoDAOImpl(Class<Contacto> objectType) {
		super(objectType);
		// TODO Auto-generated constructor stub
	}

	Logger log = Logger.getLogger(this.getClass());

	@Override
	public int getCountServicesByContacto(Contacto contacto) throws GeneralDataAccessException {
		String sqlQuery = "SELECT COUNT(SC.ID_SERVICIO) FROM NULLID.RNT_SERVICIO_CONTACTO as SC " + "WHERE ID_CONTACTO=" + contacto.getId();

		Query query = getSession().createSQLQuery(sqlQuery);
		return (Integer) query.uniqueResult();
	}

    @SuppressWarnings("unchecked")
    @Override
    public List<Servicio> getServiciosDelContacto(Contacto contacto) throws GeneralDataAccessException {
        StringBuffer hqlBuffer = new StringBuffer();
        hqlBuffer.append("SELECT  S")//10
                .append(" FROM Contacto CS")
                .append(" join CS.servicios AS S")
                .append(" WHERE CS.id = " + contacto.getId());       
        try{
            Query query = getSession().createQuery(hqlBuffer.toString());
            List<Servicio> servs =  query.list();  
            if (servs==null) {
                return new ArrayList<Servicio>();
            }
            return servs;
        }catch(Exception e){
            throw new GeneralDataAccessException(e.getMessage(),e);
        }
    }

}
