package cl.mtt.rnt.commons.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.FlushMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.impl.CriteriaImpl;
import org.hibernate.loader.OuterJoinLoader;
import org.hibernate.loader.criteria.CriteriaJoinWalker;
import org.hibernate.loader.criteria.CriteriaLoader;
import org.hibernate.loader.criteria.CriteriaQueryTranslator;
import org.hibernate.persister.entity.OuterJoinLoadable;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.OperationDAO;
import cl.mtt.rnt.commons.exception.CriteriaDefinitionException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.view.UserWrapper;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.filter.DataTableFilter;

public class GenericDAOImpl<T> extends HibernateDaoSupport implements GenericDAO<T> {

	protected Class<T> objectType;

	Logger log = Logger.getLogger(this.getClass());

	// defino un valor que nunca aparezca en un campo, para poder buscar por NOT
	// NULL
//	public static final String IS_NOT_NULL = "<** IS_NOT_NULL **>";
	
	private static final Set<String> CRITERION_PREFIX_MAP;
    static {
    	CRITERION_PREFIX_MAP = new HashSet<String>();
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_LIKE);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_ILIKE);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_NOT_EQUALS);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_EQUALS);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_EQUALS_IGNORE_CASE);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_LESS_THAN);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_GREATER_THAN);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_LESS_EQUALS_THAN);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_GREATER_EQUALS_THAN);
    }
    
	public GenericDAOImpl(Class<T> objectType) {
		this.objectType = objectType;
	}

	public void save(T newInstance) throws GeneralDataAccessException {
		try {
			java.util.Date utilDate = new java.util.Date();
			long lnMilisegundos = utilDate.getTime();
			GenericModelObject gmo = (GenericModelObject) newInstance;
			CurrentSessionBean csb = (CurrentSessionBean) ELFacesResolver.getManagedObject("currentSessionBean");
			if (csb != null) {
				try {
					gmo.setUserCreation(((UserWrapper) csb.getUser()).getUser());
				} catch (Exception e) {
					gmo.setUserCreation(csb.getUser());
				}
				try {
					gmo.setUserModified(((UserWrapper) csb.getUser()).getUser());
				} catch (Exception e) {
					gmo.setUserModified(csb.getUser());
				}
			}
			gmo.setCreation(new Timestamp(lnMilisegundos));
			gmo.setModified(gmo.getCreation());
			getSession().setFlushMode(FlushMode.AUTO);
			getHibernateTemplate().save(gmo);
			getHibernateTemplate().flush();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	public void update(T persistenceInstance) throws GeneralDataAccessException {
		try {
			java.util.Date utilDate = new java.util.Date();
			long lnMilisegundos = utilDate.getTime();
			GenericModelObject gmo = (GenericModelObject) persistenceInstance;
			CurrentSessionBean csb = (CurrentSessionBean) ELFacesResolver.getManagedObject("currentSessionBean");
			if (csb != null) {
				try {
					gmo.setUserCreation(((UserWrapper) gmo.getUserCreation()).getUser());
				} catch (Exception e) {
					// creation es usuario
				}
				try {
					gmo.setUserModified(((UserWrapper) csb.getUser()).getUser());
				} catch (Exception e) {
					gmo.setUserModified(csb.getUser());
				}
			}
			gmo.setModified(new Timestamp(lnMilisegundos));
			getSession().setFlushMode(FlushMode.AUTO);
			getHibernateTemplate().update(persistenceInstance);
			getHibernateTemplate().flush();
		} catch (DataIntegrityViolationException e) {

			log.error(IntegrityViolationException.UPDATE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new IntegrityViolationException(IntegrityViolationException.UPDATE_ERROR, e);
		} catch (DataAccessException e) {

 			log.error(GeneralDataAccessException.UPDATE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.UPDATE_ERROR, e);
		}
	}

	public void remove(T persistenceInstance) throws GeneralDataAccessException {
		try {
			getSession().setFlushMode(FlushMode.AUTO);
			getHibernateTemplate().delete(persistenceInstance);
			getHibernateTemplate().flush();
		} catch (DataIntegrityViolationException e) {
			log.error(IntegrityViolationException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new IntegrityViolationException(IntegrityViolationException.DELETE_ERROR, e);
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.DELETE_ERROR, e);
		}
	}

	@SuppressWarnings("unchecked")
	public List<T> getAll() throws GeneralDataAccessException {
		try {
			// getSession().setFlushMode(FlushMode.MANUAL);
			return getHibernateTemplate().find("from " + objectType.getSimpleName());

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	@SuppressWarnings("unchecked")
	public T getByPrimaryKey(Object id) throws GeneralDataAccessException {
		T returnValue = null;
		// getSession().setFlushMode(FlushMode.MANUAL);
		try {

			if (id instanceof BigDecimal) {
				id = ((BigDecimal) id).longValue();
			}

			returnValue = (T) getHibernateTemplate().get(objectType.getName(), (Serializable) id);

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return returnValue;
	}

	public void clearCache() throws GeneralDataAccessException {
		getHibernateTemplate().clear();
	}

	public void saveOrUpdateAll(List<T> objects) throws GeneralDataAccessException {
		try {
			CurrentSessionBean csb = (CurrentSessionBean) ELFacesResolver.getManagedObject("currentSessionBean");
			java.util.Date utilDate = new java.util.Date();
			long lnMilisegundos = utilDate.getTime();
			for (T o : objects) {
				GenericModelObject gmo = (GenericModelObject) o;
				if (gmo.getCreation() == null) {
					gmo.setCreation(new Timestamp(lnMilisegundos));
					try {
						gmo.setUserCreation(((UserWrapper) csb.getUser()).getUser());
					} catch (Exception e) {
						gmo.setUserCreation(csb.getUser());
					}
					try {
						gmo.setUserModified(((UserWrapper) csb.getUser()).getUser());
					} catch (Exception e) {
						gmo.setUserModified(csb.getUser());
					}

				} else {
					gmo.setModified(new Timestamp(lnMilisegundos));
					try {
						gmo.setUserCreation(((UserWrapper) gmo.getUserCreation()).getUser());
					} catch (Exception e) {
						// creation es usuario
					}
					try {
						gmo.setUserModified(((UserWrapper) csb.getUser()).getUser());
					} catch (Exception e) {
						gmo.setUserModified(csb.getUser());
					}
				}
			}
			getSession().setFlushMode(FlushMode.AUTO);
			getHibernateTemplate().saveOrUpdateAll(objects);
			getHibernateTemplate().flush();
		} catch (DataIntegrityViolationException e) {
			log.error(IntegrityViolationException.UPDATE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new IntegrityViolationException(IntegrityViolationException.DELETE_ERROR, e);
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.UPDATE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.DELETE_ERROR, e);
		}
	}

	public void proceedAccordingDBAction(List<T> objects) throws GeneralDataAccessException {
		for (T o : objects) {
			GenericModelObject object = (GenericModelObject) o;
			switch (object.getDbAction()) {
			case GenericModelObject.ACTION_SAVE:
				save(o);
				break;
			case GenericModelObject.ACTION_UPDATE:
				update(o);
				break;
			case GenericModelObject.ACTION_DELETE:
				remove(o);
				break;
			default:
				break;
			}
		}
	}

	public void removeAll(List<T> objects) throws GeneralDataAccessException {
		try {
			getSession().setFlushMode(FlushMode.AUTO);
			getHibernateTemplate().deleteAll(objects);
			getHibernateTemplate().flush();
		} catch (DataIntegrityViolationException e) {
			log.error(IntegrityViolationException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new IntegrityViolationException(IntegrityViolationException.DELETE_ERROR, e);
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.DELETE_ERROR, e);
		}
	}

	private String getPrefix(String column) {
		if (column.contains(".")) {
			return column.substring(0, column.lastIndexOf('.'));
		}
		return column;
	}

	private String getOperationPrefix(String column) {
		if (column.contains(".")) {
			return column.substring(0, column.indexOf('.'));
		}
		return column;
	}

	private Criterion getCriterion(Criteria criteria, Map<String, Object> res, Map<String, String> aliases) throws CriteriaDefinitionException {
		Criterion criterion = null;

		for (Iterator iter = res.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String column = new String(name);
			String prefixOperation = getOperationPrefix(column);
			if(CRITERION_PREFIX_MAP.contains(prefixOperation)){
				column = column.replaceFirst(prefixOperation+".", "");
			} else {
				prefixOperation = CRITERION_PREFIX_EQUALS;
			}
			String alias = aliases.get(getPrefix(column));
			String field = "";
			if (alias == null) {
				field = generateAlias(criteria, column, aliases);
				// aliases.put(getPrefix(name), field);//lo hace generateAlias
			} else {
				field = getPrefix(alias) + column.substring(column.lastIndexOf('.'));
			}
			Criterion cr = null;
			if (res.get(name) != null) {
//				if (res.get(name).equals(GenericDAOImpl.IS_NOT_NULL)) {
//					cr = Restrictions.isNotNull(name);
//				} else 
				if (res.get(name) instanceof Collection) {
					Collection coll = (Collection) res.get(name);
					if (coll.isEmpty()){
						throw new CriteriaDefinitionException("Empty Collection in Criteria");
					}
					if (CRITERION_PREFIX_EQUALS.equals(prefixOperation)){
						cr = Restrictions.in(field, coll);
					}else{
						cr = Restrictions.not(Restrictions.in(field, coll));
					}
				} else {
					if (CRITERION_PREFIX_EQUALS.equals(prefixOperation)){
						cr = Restrictions.eq(field, res.get(name));
					} else if (CRITERION_PREFIX_NOT_EQUALS.equals(prefixOperation)){
						cr = Restrictions.ne(field, res.get(name));
					} else if (CRITERION_PREFIX_EQUALS_IGNORE_CASE.equals(prefixOperation)){
						cr = Restrictions.ilike(field,res.get(name));
					} else if (CRITERION_PREFIX_LIKE.equals(prefixOperation)){
						cr = Restrictions.like(field, "%"+res.get(name)+"%");
					} else if (CRITERION_PREFIX_ILIKE.equals(prefixOperation)){
						cr = Restrictions.ilike(field, "%"+res.get(name)+"%");
					} else if (CRITERION_PREFIX_LESS_THAN.equals(prefixOperation)){
						cr = Restrictions.lt(field, res.get(name));
					} else if (CRITERION_PREFIX_GREATER_THAN.equals(prefixOperation)){
						cr = Restrictions.gt(field, res.get(name));
					} else if (CRITERION_PREFIX_LESS_EQUALS_THAN.equals(prefixOperation)){
						cr = Restrictions.le(field, res.get(name));
					} else if (CRITERION_PREFIX_GREATER_EQUALS_THAN.equals(prefixOperation)){
						cr = Restrictions.ge(field, res.get(name));
					}
				}
			} else {
				if (CRITERION_PREFIX_EQUALS.equals(prefixOperation))
					cr = Restrictions.isNull(field);
				else
					cr = Restrictions.isNotNull(field);
			}
			criterion = (criterion == null) ? cr : Restrictions.and(criterion, cr);
		}
		return criterion;
	}
	
	@Deprecated
	private Criterion getCriterionWithOperator(Criteria criteria, Map<String, WithOperatorCriteria> res, Map<String, String> aliases) {
		Criterion criterion = null;

		for (Iterator iter = res.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String alias = aliases.get(getPrefix(name));
			String field = "";
			if (alias == null) {
				field = generateAlias(criteria, name, aliases);
				// aliases.put(getPrefix(name), field);//lo hace generateAlias
			} else {
				field = getPrefix(alias) + name.substring(name.lastIndexOf('.'));
			}
			Criterion cr = null;
			if (res.get(name) != null) {
//				if (res.get(name).equals(GenericDAOImpl.IS_NOT_NULL)) {
//					cr = Restrictions.isNotNull(name);
//				} else 
				if (res.get(name) instanceof Collection) {
					WithOperatorCriteria coll = (WithOperatorCriteria) res.get(name);
					if (coll.getOperator().equals(WithOperatorCriteria.OPERATOR_EQUAL))
						cr = Restrictions.in(field, (Collection) coll.getValue());
					else if (coll.getOperator().equals(WithOperatorCriteria.OPERATOR_NOT_EQUAL)) {
						cr = Restrictions.not(Restrictions.in(field, (Collection) coll.getValue()));
					}
				} else {
					WithOperatorCriteria clause = (WithOperatorCriteria) res.get(name);
					if (clause.getOperator().equals(WithOperatorCriteria.OPERATOR_EQUAL))
						cr = Restrictions.eq(field, clause.getValue());
					else if (clause.getOperator().equals(WithOperatorCriteria.OPERATOR_NOT_EQUAL)) {
						cr = Restrictions.not(Restrictions.eq(field, clause.getValue()));
					}
				}
			} else
				cr = Restrictions.isNull(name);
			criterion = (criterion == null) ? cr : Restrictions.and(criterion, cr);
		}
		return criterion;
	}

	private Criteria getCriteria(Map<String, Object> res) throws CriteriaDefinitionException {
		Criteria criteria = getSession().createCriteria(objectType);
		Map<String, String> aliases = new HashMap<String, String>();
		Criterion cr = getCriterion(criteria, res, aliases);
		if (cr != null)
			criteria.add(cr);
		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		return criteria;
	}
	@Deprecated
	private Criteria getCriteriaWithOperator(Map<String, WithOperatorCriteria> res) {
		Criteria criteria = getSession().createCriteria(objectType);
		Map<String, String> aliases = new HashMap<String, String>();
		Criterion cr = getCriterionWithOperator(criteria, res, aliases);
		if (cr != null)
			criteria.add(cr);
		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		return criteria;
	}

	private Criteria getCriteria(Map<String, Object> res, List<Map<String, Object>> optRes) throws CriteriaDefinitionException {
		if (optRes == null || optRes.size() == 0)
			return getCriteria(res);

		Criteria criteria = getSession().createCriteria(objectType);
		Map<String, String> aliases = new HashMap<String, String>();
		Criterion optCriterion = null;
		for (Map<String, Object> map : optRes) {
			Criterion cr = getCriterion(criteria, map, aliases);
			optCriterion = (optCriterion == null) ? cr : Restrictions.or(optCriterion, cr);
		}

		if (res != null && res.size() > 0)
			criteria.add(Restrictions.and(getCriterion(criteria, res, aliases), optCriterion));
		else
			criteria.add(optCriterion);

		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		return criteria;
	}

	@SuppressWarnings("unchecked")
	public List<T> findBySimpleCriteria(Map<String, Object> res) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			Criteria criteria = this.getCriteria(res);

			// Se agrego la conversion por medio de setResultTransformer ya que
			// recuperaba instancias duplicadas de la variable
			result = criteria.list();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<T> findBySimpleCriteriaOrders(Map<String, Object> res, List<Order> ordenamientos) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			Criteria criteria = this.getCriteria(res);
			for (Order order : ordenamientos) {
				criteria = criteria.addOrder(order);
			}
			// Se agrego la conversion por medio de setResultTransformer ya que
			// recuperaba instancias duplicadas de la variable
			result = criteria.list();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

	public List<T> findBySimpleOptionalCriteria(Map<String, Object> obligatoryCriteria, List<Map<String, Object>> optionalCriteria) throws GeneralDataAccessException {
		List<T> result = new ArrayList<T>();
		try {
			// parte obligatoria
			Criteria criteria = this.getCriteria(obligatoryCriteria, optionalCriteria);
			// Se agrego la conversion por medio de setResultTransformer ya que
			// recuperaba instancias duplicadas de la variable
			result = criteria.list();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;

	}
	
	public List<T> findBySimpleOptionalCriteria(Map<String, Object> obligatoryCriteria, List<Map<String, Object>> optionalCriteria,List<String> sortingList) throws GeneralDataAccessException{
		List<T> result = new ArrayList<T>();
		try {
			// parte obligatoria
			Criteria criteria = this.getCriteria(obligatoryCriteria, optionalCriteria);
			Map<String, String> aliases = new HashMap<String, String>();
			for (String column : sortingList) {
				if (column.indexOf(" desc") != -1) {
					String subs = column.substring(0, column.indexOf(" desc"));
					String field = generateAlias(criteria, subs, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.desc(field));
				} else {
					String field = generateAlias(criteria, column, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.asc(field));
				}
			}
			// Se agrego la conversion por medio de setResultTransformer ya que
			// recuperaba instancias duplicadas de la variable
			result = criteria.list();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}


	/**
	 * Obtiene la consulta SQL de una criteria.
	 * 
	 * @param criteria
	 * @return
	 */
	private String getSQLQuery(Criteria criteria) {
		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		String sql = null;
		Object[] parameters = null;
		try {
			CriteriaImpl c = (CriteriaImpl) criteria;
			SessionFactoryImplementor factory = (SessionFactoryImplementor) getHibernateTemplate().getSessionFactory();
			String[] implementors = factory.getImplementors(c.getEntityOrClassName());
			// esta línea se comento porque la clase CriteriaLoader no tiene el
			// método con el quinto parámetro Map
			// CriteriaLoader loader = new CriteriaLoader((OuterJoinLoadable)
			// factory.getEntityPersister(implementors[0]), factory, c,
			// implementors[0], c.getSession().getEnabledFilters());

			CriteriaLoader loader = new CriteriaLoader((OuterJoinLoadable) factory.getEntityPersister(implementors[0]), factory, c, implementors[0], c.getSession().getLoadQueryInfluencers());

			// obtnemos el sql de la criteria
			java.lang.reflect.Field f = OuterJoinLoader.class.getDeclaredField("sql");
			f.setAccessible(true);
			sql = (String) f.get(loader);
			// obtenemos los parametros ordenados por posicion
			java.lang.reflect.Field field = CriteriaLoader.class.getDeclaredField("translator");
			field.setAccessible(true);
			CriteriaQueryTranslator translator = (CriteriaQueryTranslator) field.get(loader);
			parameters = translator.getQueryParameters().getPositionalParameterValues();
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		if (sql != null) {
			int fromPos = sql.indexOf(" from ");
			sql = " SELECT * " + sql.substring(fromPos);
			// parseamos la consulta cambiando ? por los valores
			if (parameters != null && parameters.length > 0) {
				for (int i = 0; i < parameters.length; i++) {
					Object val = parameters[i];
					String value = "%";
					if (val instanceof Boolean) {
						value = ((Boolean) val) ? "1" : "0";
					} else if (val instanceof String) {
						value = "'" + val + "'";
					}
					sql.replaceFirst("\\?", value);
				}
			}
		}
		return sql;
	}

	@SuppressWarnings("unchecked")
	public List<T> findBySimpleHQL(Map<String, Object> res) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			String query = "from " + objectType.getName() + " as c where " + getHQLqueryFieldsList_AND(res);
			result = getHibernateTemplate().find(query);

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<T> findBySimpleHQL(Map<String, Object> res, List<String> sortingColumns, boolean desc) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			String query = "from " + objectType.getName() + " as c ";
			if (res.keySet().size() > 0)
				query = query + "where " + getHQLqueryFieldsList_AND(res);
			query = query + " ORDER BY";
			if (desc)
				query = query + "DESC ";

			for (Iterator iterator = sortingColumns.iterator(); iterator.hasNext();) {
				String col = (String) iterator.next();
				query = (iterator.hasNext()) ? query + " c." + col + "," : query + " c." + col;
			}
			result = getHibernateTemplate().find(query);

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<T> findBySimpleHQL(Map<String, Object> res, List<String> sortingColumns, Map<String, Object> likeFields, boolean desc) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			String query = "from " + objectType.getName() + " as c ";
			if (res.keySet().size() > 0 || likeFields.keySet().size() > 0)
				query = query + "where " + getHQLqueryFieldsList_AND(res);
			if (likeFields.keySet().size() > 0 && res.keySet().size() > 0)
				query = query + " and ";
			if (likeFields.keySet().size() > 0)
				query += "(";
			for (Iterator iter = likeFields.keySet().iterator(); iter.hasNext();) {
				String name = (String) iter.next();
				Object value = likeFields.get(name);
				if (iter.hasNext())
					query = query + " ( upper(c." + name + ") like upper('%" + value + "%') ) or ";
				else
					query = query + " ( upper(c." + name + ") like upper('%" + value + "%') ) )";
			}

			query = query + " ORDER BY ";
			if (desc)
				query = query + " DESC ";

			for (Iterator iterator = sortingColumns.iterator(); iterator.hasNext();) {
				String col = (String) iterator.next();
				query = (iterator.hasNext()) ? query + " c." + col + "," : query + " c." + col;
			}
			// System.out.println(query);
			result = getHibernateTemplate().find(query);

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<T> findBySimpleHQL(List<OperationDAO> list) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			String query = "from " + objectType.getName() + " as c where ";
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				OperationDAO item = (OperationDAO) iter.next();
				String field = item.getField();
				String operator = item.getOperator();
				Object value = item.getValue();
				if (value != null && (value.getClass().getName().equals("java.lang.String") || value.getClass().getName().equals("java.util.Date")))
					value = "'" + value + "'";
				// comienzo a armar query
				query = query + " c." + field + " " + operator;
				// si no es con operador NULL le agrego value
				if (!item.getOperator().equals(OperationDAO.OPERATION_IS_NOT_NULL) && !item.getOperator().equals(OperationDAO.OPERATION_IS_NULL)
						&& !item.getOperator().equals(OperationDAO.OPERATION_IN) && !item.getOperator().equals(OperationDAO.OPERATION_NOT_IN))
					query += " " + value;
				if (item.getOperator().equals(OperationDAO.OPERATION_IN) || item.getOperator().equals(OperationDAO.OPERATION_NOT_IN)) // TODO
																																		// mejorar
					query += " " + ListToString(value);
				if (iter.hasNext())
					query += " and ";

			}
			// System.out.println(query);
			result = getHibernateTemplate().find(query);

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

	/**
	 * 
	 * @param list
	 * @param sortingColumns
	 * @param desc
	 * @return
	 * @throws GeneralDataAccessException
	 */
	@SuppressWarnings("unchecked")
	public List<T> findBySimpleHQL(List<OperationDAO> list, List<String> sortingColumns, boolean desc) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			String query = "from " + objectType.getName() + " as c where ";
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				OperationDAO item = (OperationDAO) iter.next();
				String field = item.getField();
				String operator = item.getOperator();
				Object value = item.getValue();
				if (value != null && (value.getClass().getName().equals("java.lang.String") || value.getClass().getName().equals("java.util.Date")))
					value = "'" + value + "'";
				// comienzo a armar query
				query = query + " c." + field + " " + operator;
				// si no es con operador NULL le agrego value
				if (!item.getOperator().equals(OperationDAO.OPERATION_IS_NOT_NULL) && !item.getOperator().equals(OperationDAO.OPERATION_IS_NULL)
						&& !item.getOperator().equals(OperationDAO.OPERATION_IN) && !item.getOperator().equals(OperationDAO.OPERATION_NOT_IN))
					query += " " + value;
				if (item.getOperator().equals(OperationDAO.OPERATION_IN) || item.getOperator().equals(OperationDAO.OPERATION_NOT_IN)) // TODO
																																		// mejorar
					query += " " + ListToString(value);
				if (iter.hasNext())
					query += " and ";

			}
			// System.out.println(query);
			query = query + " ORDER BY ";
			if (desc)
				query = query + " DESC ";

			for (Iterator iterator = sortingColumns.iterator(); iterator.hasNext();) {
				String col = (String) iterator.next();
				query = (iterator.hasNext()) ? query + " c." + col + "," : query + " c." + col;
			}
			result = getHibernateTemplate().find(query);

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

	/**
	 * Modificado para soportar listas de String o de numbers (Long, Integer).
	 * 
	 * @author Leonardo Pavone - Feb 1, 2013
	 * @param value
	 * @return
	 */
	private String ListToString(Object value) {
		if (((List) value).isEmpty())
			return "(null)";
		StringBuilder list = new StringBuilder("(");
		for (Object obj : (List) value) {
			if (obj instanceof String) {
				list.append("'").append((String) obj).append("',");
			} else if (obj instanceof Long || obj instanceof Integer) {
				list.append(obj.toString()).append(",");
			}
		}
		return list.deleteCharAt(list.length() - 1).append(")").toString();
	}

	@SuppressWarnings("unchecked")
	public List<T> findBySimpleCriteria(Map<String, Object> res, List<String> sortingColumns) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			Criteria criteria = this.getCriteria(res);
			Map<String, String> aliases = new HashMap<String, String>();
			for (String column : sortingColumns) {
				if (column.indexOf(" desc") != -1) {
					String subs = column.substring(0, column.indexOf(" desc"));
					String field = generateAlias(criteria, subs, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.desc(field));
				} else {
					String field = generateAlias(criteria, column, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.asc(field));
				}
			}

			result = criteria.list();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<T> getPagedData(int start, int page) throws GeneralDataAccessException {
		try {
			// getSession().setFlushMode(FlushMode.MANUAL);
			Criteria criteria = getSession().createCriteria(objectType);
			// Build Criteria object here
			criteria.setFirstResult(start);
			criteria.setMaxResults(page);
			return criteria.list();
		} catch (HibernateException hibernateException) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(hibernateException));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, hibernateException);
		}
	}

	@SuppressWarnings("unchecked")
	public List<T> getPagedData(List<String> sortingColumns, int start, int page) throws GeneralDataAccessException {
		try {
			// getSession().setFlushMode(FlushMode.MANUAL);
			Criteria criteria = getSession().createCriteria(objectType);
			// Build Criteria object here
			criteria.setFirstResult(start);
			criteria.setMaxResults(page);
			
			Map<String, String> aliases = new HashMap<String, String>();
			for (String column : sortingColumns) {
				if (column.endsWith(" desc")) {
					int i = column.indexOf("desc");
					column = column.substring(0, i - 1);
					String field = generateAlias(criteria, column, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.desc(field));
				} else{
					String field = generateAlias(criteria, column, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.asc(field));
				}
			}

			return criteria.list();
		} catch (HibernateException hibernateException) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(hibernateException));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, hibernateException);
		}
	}

	public int getDataCount() throws GeneralDataAccessException {
		try {
			getSession().setFlushMode(FlushMode.MANUAL);
			Criteria criteria = getSession().createCriteria(objectType);
			criteria.setProjection(Projections.rowCount());

			// Build Criteria object here
			Number nuofRecords = ((Number) criteria.uniqueResult());
			return nuofRecords == null ? 0 : nuofRecords.intValue();
		} catch (DataAccessException e) {

			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	public int getDataCount(Map<String, Object> simpleCriteria) throws GeneralDataAccessException {
		try {
			// getSession().setFlushMode(FlushMode.MANUAL);
			Criteria criteria = this.getCriteria(simpleCriteria);

			criteria.setProjection(Projections.rowCount());
			// Build Criteria object here
			Number nuofRecords = ((Number) criteria.uniqueResult());
			

			return nuofRecords == null ? 0 : nuofRecords.intValue();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	public long getDataCount(DataTableFilter filter) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		long count;
		try {

			String hqlFilter = "";
			if (filter != null) {
				hqlFilter = " where " + filter.getHQLCode("c");
			}

			String query = "select count(c.id) from " + objectType.getName() + " as c " + hqlFilter;
			// System.out.println(query);
			Object o = (getSession().createQuery(query).uniqueResult());
			count = (Long) o;
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		// System.out.println(count);
		return count;
	}

	public List<T> getPagedData(DataTableFilter filter, List<String> sortingColumns, int start, int page) throws GeneralDataAccessException {
		try {

			// genero el código asociado a los filtros
			String hqlFilter = "";
			if (filter != null) {
				hqlFilter = " where " + filter.getHQLCode("c");
			}

			// El ordenamiento, cuando es por campos de otra tabla, elimina las
			// filas donde esta tabla es null, por eso vamos a verificarlo y
			// solucionarlo
			// esto va a funcionar solamente cuando hay UN SOLO campo de
			// ordenamiento
			if (sortingColumns == null || sortingColumns.size() != 1 || !sortingColumns.get(0).contains(".")) { // caso normal, no se o se hace por
																												// el campo de la misma tabla

				String query = "from " + objectType.getName() + " as c " + hqlFilter + getOrderQuerySection(sortingColumns, "c", false);

				Query q = getSession().createQuery(query);

				q.setFirstResult(start);
				q.setMaxResults(page);
				return q.list();
			} else { // Caso eventual, se ordena por el campo de una tabla
						// externa (ej: ciudad.nombre)
				String firstSortingColumn = sortingColumns.get(0);
				String externalTableName = firstSortingColumn.substring(0, firstSortingColumn.lastIndexOf("."));

				String queryStringForNullData = "from " + objectType.getName() + " as c " + ((hqlFilter != "") ? hqlFilter + " AND " : "WHERE ") + externalTableName + " is NULL ";
				String queryStringForNotNullData = "from " + objectType.getName() + " as c " + hqlFilter + getOrderQuerySection(sortingColumns, "c", false);

				Long nullDataCount = (Long) (getSession().createQuery(
						"select count(c.id) from " + objectType.getName() + " as c " + ((hqlFilter != "") ? hqlFilter + " AND " : "WHERE ") + externalTableName + " is NULL ").uniqueResult());
				Long notNullDataCount = (Long) (getSession().createQuery(
						"select count(c.id) from " + objectType.getName() + " as c " + ((hqlFilter != "") ? hqlFilter + " AND " : "WHERE ") + externalTableName + " is not NULL ").uniqueResult());

				// Primero averiguo se es ascendente o descendente
				if (!firstSortingColumn.endsWith(" desc")) {// Es Ascendente
					if (start >= nullDataCount) { // Caso que muestra solo datos
													// no nulos, es decir, el
													// primer elemento sobrepasa
													// los datos nulos
						Query qres = getSession().createQuery(queryStringForNotNullData);
						qres.setFirstResult((int) (start - nullDataCount));
						qres.setMaxResults(page);
						return qres.list();
					} else if ((start + page) < nullDataCount) { // caso en que
																	// se
																	// muestran
																	// solo
																	// datos
																	// nulos, el
																	// último
																	// elemento
																	// queda
																	// dentro de
																	// los
																	// elementos
																	// nulos
						Query qres = getSession().createQuery(queryStringForNullData);
						qres.setFirstResult(start);
						qres.setMaxResults(page);
						return qres.list();
					} else {// caso en que se muestran datos combinados
						Query qres1 = getSession().createQuery(queryStringForNullData);
						qres1.setFirstResult(start);
						qres1.setMaxResults(page);

						Query qres2 = getSession().createQuery(queryStringForNotNullData);
						qres2.setFirstResult(0);
						qres2.setMaxResults((int) (page - nullDataCount % page));

						List<T> listRes = qres1.list();
						listRes.addAll(qres2.list());
						return listRes;
					}
				} else { // Es descendente
					if (start >= notNullDataCount) { // Caso que muestra solo datos nulos, es decir, el primer elemento sobrepasa los datos no nulos
						Query qres = getSession().createQuery(queryStringForNullData);
						qres.setFirstResult((int) (start - notNullDataCount));
						qres.setMaxResults(page);
						return qres.list();
					} else if ((start + page) < notNullDataCount) { // caso en que se muestran solo datos no nulos, el último elemento queda dentro de los elementos no nulos
						Query qres = getSession().createQuery(queryStringForNotNullData);
						qres.setFirstResult(start);
						qres.setMaxResults(page);
						return qres.list();
					} else {// caso en que se muestran datos combinados
						Query qres2 = getSession().createQuery(queryStringForNullData);
						qres2.setFirstResult(0);
						qres2.setMaxResults((int) (page - notNullDataCount % page));

						Query qres1 = getSession().createQuery(queryStringForNotNullData);
						qres1.setFirstResult(start);
						qres1.setMaxResults(page);

						List<T> listRes = qres1.list();
						List<T> list2 = qres2.list();
						Collections.reverse(list2);// se invierte la lista de
													// elementos nulos para que
													// quede bién en el orden
													// descendente
						listRes.addAll(list2);
						return listRes;
					}

				}
			}
		} catch (HibernateException hibernateException) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(hibernateException));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, hibernateException);
		}
	}

	@SuppressWarnings("unchecked")
	public List<T> getPagedData(Map<String, Object> simpleCriteria, int start, int page) throws GeneralDataAccessException {
		try {
			// getSession().setFlushMode(FlushMode.MANUAL);
			Criteria criteria = this.getCriteria(simpleCriteria);
			// Build Criteria object here
			criteria.setFirstResult(start);
			criteria.setMaxResults(page);

			return criteria.list();
		} catch (HibernateException hibernateException) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(hibernateException));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, hibernateException);
		}
	}

	@SuppressWarnings("unchecked")
	public List<T> getPagedData(Map<String, Object> simpleCriteria, List<String> sortingColumns, int start, int page) throws GeneralDataAccessException {
		try {
			// getSession().setFlushMode(FlushMode.MANUAL);
			Criteria criteria = this.getCriteria(simpleCriteria);
			Map<String, String> aliases = new HashMap<String, String>();
			for (String column : sortingColumns) {
				if (column.indexOf(" desc") != -1) {
					String subs = column.substring(0, column.indexOf(" desc"));
					String field = generateAlias(criteria, subs, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.desc(field));
				} else {
					String field = generateAlias(criteria, column, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.asc(field));
				}
			}
			
			criteria.setFirstResult(start);
			criteria.setMaxResults(page);
			return criteria.list();
		} catch (HibernateException hibernateException) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(hibernateException));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, hibernateException);
		}
	}

	@SuppressWarnings("unchecked")
	public List<Long> getIdsPagedData(Map<String, Object> simpleCriteria, List<Map<String, Object>> optionalsCriteria) throws GeneralDataAccessException {
		try {
			Criteria criteria = this.getCriteria(simpleCriteria, optionalsCriteria);

			criteria.setProjection(Projections.distinct(Projections.property("id")));

			return criteria.list();
		} catch (HibernateException hibernateException) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(hibernateException));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, hibernateException);
		}
	}

	@SuppressWarnings("unchecked")
	public List<T> getPagedData(Map<String, Object> simpleCriteria, List<Map<String, Object>> optionalsCriteria, List<String> sortingColumns, int start, int page) throws GeneralDataAccessException {
		try {
			Criteria criteria = this.getCriteria(simpleCriteria, optionalsCriteria);

			Map<String, String> aliases = new HashMap<String, String>();
			for (String column : sortingColumns) {
				if (column.indexOf(" desc") != -1) {
					String subs = column.substring(0, column.indexOf(" desc"));
					String field = generateAlias(criteria, subs, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.desc(field));
				} else {
					String field = generateAlias(criteria, column, aliases,Criteria.LEFT_JOIN);
					criteria.addOrder(Order.asc(field));
				}
			}
			
			criteria.setFirstResult(start);
			criteria.setMaxResults(page);

			return criteria.list();
		} catch (HibernateException hibernateException) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(hibernateException));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, hibernateException);
		}
	}
	protected String generateAlias(Criteria criteria, String column, Map<String, String> aliases) {
		return generateAlias(criteria, column, aliases,Criteria.INNER_JOIN);
	}
	
	protected String generateAlias(Criteria criteria, String column, Map<String, String> aliases,int joinType) {
		// Si hay un campo de profundidad mayor a uno (ej: 'domicilio.calle'),
		// hay que hacer un alias. fuentes:
		// http://forum.hibernate.org/viewtopic.php?p=2375242 y
		// http://www.forodejava.com/showthread.php?t=162
		String ret = "";
		String key = "";
		String postfix = new String(column);
		while (postfix.contains(".")) {
			String prefix = postfix.substring(0, postfix.indexOf('.'));
			postfix = postfix.substring(postfix.indexOf('.') + 1);
			String lastAlias = "";
			if (!aliases.containsKey(key + ("".equals(key) ? "" : ".") + prefix)) {
				long rand = Math.round(Math.random() * 100000);
				lastAlias = rand + prefix;
				criteria.createAlias(ret + ("".equals(ret) ? "" : ".") + prefix, lastAlias, joinType);
				aliases.put(key + ("".equals(key) ? "" : ".") + prefix, lastAlias);
			} else {
				lastAlias = aliases.get(key + ("".equals(key) ? "" : ".") + prefix);
			}
			if (!postfix.contains("."))
				return lastAlias + "." + postfix;
			else {
				ret += ("".equals(ret) ? "" : ".") + lastAlias;
				key += ("".equals(key) ? "" : ".") + prefix;
			}
		}
		return column;
	}

	private String getOrderQuerySection(List<String> sortingColumns, String alias, boolean desc) {
		if (sortingColumns == null || sortingColumns.size() == 0)
			return "";
		String query = " ORDER BY ";
		if (desc)
			query = query + "DESC ";

		for (Iterator iterator = sortingColumns.iterator(); iterator.hasNext();) {
			String col = (String) iterator.next();
			query = (iterator.hasNext()) ? query + " " + alias + "." + col + "," : query + " " + alias + "." + col;
		}
		return query;
	}

	public Object getMaxValueByColumn(String columnName) throws GeneralDataAccessException {
		String hqlQuery = "select max(t." + columnName + ") from " + objectType.getName() + " as t";
		Object result = getSession().createQuery(hqlQuery).uniqueResult();
		return result;
	}

	public Object getMaxValueByColumnWithConditions(String columnName, List<OperationDAO> list) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		try {
			String query = "select max(c." + columnName + ") from " + objectType.getName() + " as c where ";
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				OperationDAO item = (OperationDAO) iter.next();
				String field = item.getField();
				String operator = item.getOperator();
				Object value = item.getValue();
				if (value != null && (value.getClass().getName().equals("java.lang.String") || value.getClass().getName().equals("java.util.Date")))
					value = "'" + value + "'";
				// comienzo a armar query
				query = query + " c." + field + " " + operator;
				// si no es con operador NULL le agrego value
				if (!item.getOperator().equals(OperationDAO.OPERATION_IS_NOT_NULL) && !item.getOperator().equals(OperationDAO.OPERATION_IS_NULL))
					query += " " + value;
				if (iter.hasNext())
					query += " and ";

			}
			// System.out.println(query);
			return getSession().createQuery(query).uniqueResult();

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	public Object getMinValueByColumn(String columnName) throws GeneralDataAccessException {
		String hqlQuery = "select min(t." + columnName + ") from " + objectType.getName() + " as t";
		Object result = getSession().createQuery(hqlQuery).uniqueResult();
		return result;
	}

	public Object getMinValueByColumnWithConditions(String columnName, List<OperationDAO> list) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		try {
			String query = "select min(c." + columnName + ") from " + objectType.getName() + " as c where ";
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				OperationDAO item = (OperationDAO) iter.next();
				String field = item.getField();
				String operator = item.getOperator();
				Object value = item.getValue();
				if (value != null && (value.getClass().getName().equals("java.lang.String") || value.getClass().getName().equals("java.util.Date")))
					value = "'" + value + "'";
				// comienzo a armar query
				query = query + " c." + field + " " + operator;
				// si no es con operador NULL le agrego value
				if (!item.getOperator().equals(OperationDAO.OPERATION_IS_NOT_NULL) && !item.getOperator().equals(OperationDAO.OPERATION_IS_NULL))
					query += " " + value;
				if (iter.hasNext())
					query += " and ";

			}
			// System.out.println(query);
			return getSession().createQuery(query).uniqueResult();

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	public void rollBack() throws GeneralDataAccessException {
		try {
			if (this.getSession().getTransaction() != null) {
				this.getSession().getTransaction().rollback();
			}
		} catch (HibernateException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			log.error(GeneralDataAccessException.GET_ERROR);
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	public void beginTransaccion() throws GeneralDataAccessException {
		try {
			this.getSession().beginTransaction();
		} catch (HibernateException e) {

			log.error(GeneralDataAccessException.GET_ERROR);
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	private String getHQLqueryFieldsList_AND(Map<String, Object> criteria) {
		String query = "";
		for (Iterator iter = criteria.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			Object value = criteria.get(name);
			if (value == null) {
				if (iter.hasNext())
					query = query + " c." + name + " is null and ";
				else
					query = query + " c." + name + " is null";
			} else {
				if (value instanceof List) {
					String val = " (";
					List l = (List) value;
					for (Object object : l) {
						val += ((object.getClass().getName().equals("java.lang.String")) ? "'" + object + "'" : object) + ",";
					}
					val = val.substring(0, val.lastIndexOf(",")) + ") ";
					if (iter.hasNext())
						query += " c." + name + " in " + val + " and ";
					else
						query += " c." + name + " in " + val;
				} else {
					value = (value.getClass().getName().equals("java.lang.String")) ? "'" + value + "'" : value;
					if (iter.hasNext())
						query += " c." + name + "=" + value + " and ";
					else
						query += " c." + name + "=" + value;
				}
			}
		}
		return query;
	}

	public List<T> findByHQLwithOptionalCriteria(Map<String, Object> obligatoryCriteria, List<Map<String, Object>> optionalCriteria) throws GeneralDataAccessException {
		List<T> result = new ArrayList<T>();
		try {
			String query = "from " + objectType.getName() + " as c where " + getHQLqueryFieldsList_AND(obligatoryCriteria);
			if (optionalCriteria.size() > 0) {
				query += " and (";
				for (Iterator iterator = optionalCriteria.iterator(); iterator.hasNext();) {
					Map<String, Object> optional = (Map<String, Object>) iterator.next();
					query += " ( " + getHQLqueryFieldsList_AND(optional) + " ) ";
					if (iterator.hasNext())
						query += "or ";
				}
				query += ")";
			}

			result = getHibernateTemplate().find(query);

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;

	}

	public List<T> findByHQLwithOptionalCriteria(Map<String, Object> obligatoryCriteria, List<Map<String, Object>> optionalCriteria, List<String> sortingColumns, boolean desc)
			throws GeneralDataAccessException {
		List<T> result = new ArrayList<T>();
		try {
			String query = "from " + objectType.getName() + " as c where " + getHQLqueryFieldsList_AND(obligatoryCriteria);
			if (optionalCriteria.size() > 0) {
				query += " and (";
				for (Iterator iterator = optionalCriteria.iterator(); iterator.hasNext();) {
					Map<String, Object> optional = (Map<String, Object>) iterator.next();
					query += " ( " + getHQLqueryFieldsList_AND(optional) + " ) ";
					if (iterator.hasNext())
						query += "or ";
				}
				query += ")";
			}
			if (sortingColumns != null && !sortingColumns.isEmpty()) {
				query = query + " ORDER BY";
				if (desc)
					query = query + "DESC ";

				for (Iterator iterator = sortingColumns.iterator(); iterator.hasNext();) {
					String col = (String) iterator.next();
					query = (iterator.hasNext()) ? query + " c." + col + "," : query + " c." + col;
				}
			}

			result = getHibernateTemplate().find(query);

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;

	}

	public List<T> getRevisions(T instance) {
		GenericModelObject gmo = (GenericModelObject) instance;

		AuditReader reader = AuditReaderFactory.get(this.getSession());
		// AuditQuery query =
		// reader.createQuery().forRevisionsOfEntity(instance.getClass(), false,
		// true).add(AuditEntity.id().eq(gmo.getId()));

		List<Object[]> raw_results = reader.createQuery().forRevisionsOfEntity(instance.getClass(), false, true).add(AuditEntity.id().eq(gmo.getId())).addOrder(AuditEntity.revisionNumber().desc()).getResultList();// query.getResultList();
		// List<Object[]> complete_results = new
		// ArrayList<Object[]>(raw_results.size());
		//
		// for (Object[] data : raw_results) {
		// int rev_id = ((DefaultRevisionEntity) data[1]).getId();
		// AuditQuery q =
		// reader.createQuery().forRevisionsOfEntity(instance.getClass(), false,
		// true)
		// .add(AuditEntity.revisionNumber().eq(rev_id));
		// List<Object[]> real_data = q.getResultList();
		// complete_results.addAll(real_data);
		// }

		List<T> complete_results = new ArrayList<T>(raw_results.size());

		for (Object[] data : raw_results) {
			// int rev_id = ((DefaultRevisionEntity) data[1]).getId();
			// AuditQuery q =
			// reader.createQuery().forRevisionsOfEntity(instance.getClass(),
			// false, true)
			// .add(AuditEntity.revisionNumber().eq(rev_id));
			// List<Object[]> real_data = q.getResultList();
			GenericModelObject gmoRes = (GenericModelObject) data[0];
			// Hibernate.initialize(gmoRes.getUserCreation());
			// Hibernate.initialize(gmoRes.getUserModified());
			// System.out.println(gmoRes.getUserCreation().getNombreUsuario());
			if (gmoRes.getUserModified() != null)
			//	System.out.println(gmoRes.getUserModified().getNombreUsuario());
			complete_results.add((T) data[0]);
		}
		return complete_results;
	}

	public int getDataCount(Map<String, Object> simpleCriteria, List<Map<String, Object>> optionalsCriteria) throws GeneralDataAccessException {
		try {
			Criteria criteria = this.getCriteria(simpleCriteria, optionalsCriteria);
			criteria.setProjection(Projections.countDistinct("id"));

			// Build Criteria object here
			Number nuofRecords = ((Number) criteria.uniqueResult());
			return nuofRecords == null ? 0 : nuofRecords.intValue();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	// Para mostrar el sql de un criterio, solo utilizar para pruebas, no subir
	// a producción con la impesión de los sql
	private void showSql(Criteria criteria) {
		CriteriaImpl criteriaImpl = (CriteriaImpl) criteria;
		SessionImplementor session = criteriaImpl.getSession();
		SessionFactoryImplementor factory = session.getFactory();
		CriteriaQueryTranslator translator = new CriteriaQueryTranslator(factory, criteriaImpl, criteriaImpl.getEntityOrClassName(), CriteriaQueryTranslator.ROOT_SQL_ALIAS);
		String[] implementors = factory.getImplementors(criteriaImpl.getEntityOrClassName());

		CriteriaJoinWalker walker = new CriteriaJoinWalker((OuterJoinLoadable) factory.getEntityPersister(implementors[0]), translator, factory, criteriaImpl, criteriaImpl.getEntityOrClassName(),
				session.getLoadQueryInfluencers());

		String sql = walker.getSQLString();

		
	}

	@Override
	@Deprecated
	public List<T> findByWithOperatorCriteria(HashMap<String, cl.mtt.rnt.commons.dao.GenericDAO.WithOperatorCriteria> criteria) throws GeneralDataAccessException {
		Criteria hcri = null;
		if (criteria != null) {
			hcri = this.getCriteriaWithOperator(criteria);
		} else {
			hcri = getSession().createCriteria(objectType);
		}
		return hcri.list();

	}

	@Override
	@Deprecated
	public List<T> findByWithOperatorCriteria(HashMap<String, cl.mtt.rnt.commons.dao.GenericDAO.WithOperatorCriteria> criteria, List<String> ordenamientos) throws GeneralDataAccessException {
		Criteria hcri = null;
		if (criteria != null) {
			hcri = this.getCriteriaWithOperator(criteria);
		} else {
			hcri = getSession().createCriteria(objectType);
		}
		for (String order : ordenamientos) {
			Order hOrder = Order.asc(order);
			hcri = hcri.addOrder(hOrder);
		}

		return hcri.list();
	}

}
