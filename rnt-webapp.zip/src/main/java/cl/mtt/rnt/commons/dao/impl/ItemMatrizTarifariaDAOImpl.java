package cl.mtt.rnt.commons.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.ItemMatrizTarifariaDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.ItemMatrizTarifaria;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class ItemMatrizTarifariaDAOImpl extends GenericDAOImpl<ItemMatrizTarifaria> implements ItemMatrizTarifariaDAO {

	Logger log = Logger.getLogger(this.getClass());

	public ItemMatrizTarifariaDAOImpl(Class<ItemMatrizTarifaria> objectType) {
		super(objectType);
	}

	public void removeItemMatrizTarifaria(ItemMatrizTarifaria itemMT) throws GeneralDataAccessException{
		try {
			String sqlIds3 = "delete from NULLID.RNT_ITEM_MATRIZ_TARIFARIA IMT where ID = "+itemMT.getId();
			Query query3 = getSession().createSQLQuery(sqlIds3);
			query3.executeUpdate();
		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	
	}
	
	public void updateItemMatrizTarifaria(ItemMatrizTarifaria itemMT) throws GeneralDataAccessException{
		try {
			String sqlIds3 = "select id from NULLID.RNT_ITEM_MATRIZ_TARIFARIA IMT where ID = "+itemMT.getId();
			Query query3 = getSession().createSQLQuery(sqlIds3);
			List res = query3.list();
			if(res.isEmpty()){
				itemMT.anonimize();
				this.save(itemMT);
			}else{
				this.update(itemMT);
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

}
