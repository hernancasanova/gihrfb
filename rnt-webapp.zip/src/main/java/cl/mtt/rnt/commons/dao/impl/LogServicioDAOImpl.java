package cl.mtt.rnt.commons.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.FlushMode;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import cl.mtt.rnt.commons.dao.LogServicioDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.LogServicio;
import cl.mtt.rnt.commons.util.StackTraceUtil;


public class LogServicioDAOImpl extends HibernateDaoSupport implements LogServicioDAO {

	Logger log = Logger.getLogger(this.getClass());

	public void save(LogServicio newInstance) throws GeneralDataAccessException {
		try {
			getSession().setFlushMode(FlushMode.AUTO);
			getHibernateTemplate().save(newInstance);
			getHibernateTemplate().flush();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}


	@SuppressWarnings("unchecked")
	public List<LogServicio> getLog(Long idServicio, Long rev) throws GeneralDataAccessException {
		try {
			return getHibernateTemplate().find("from LogServicio where servicio.id="+idServicio+" and rev="+rev);		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	
}
