package cl.mtt.rnt.commons.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.MandatarioDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Mandatario;

public class MandatarioDAOImpl extends GenericDAOImpl<Mandatario> implements MandatarioDAO {

	Logger log = Logger.getLogger(this.getClass());

	public MandatarioDAOImpl(Class<Mandatario> objectType) {
		super(objectType);
	}

	@Override
	public int getCountServicesByMandatario(Mandatario mandatario) throws GeneralDataAccessException {
		String sqlQuery = "SELECT SUM (CANT) FROM (" + "	SELECT COUNT(SR.ID_SERVICIO) AS CANT FROM NULLID.RNT_SERVICIO_MANDATARIO AS SR WHERE ID_MANDATARIO=" + mandatario.getId() + "	UNION ALL "
				+ "	SELECT COUNT(RLM.ID_REPRESENTANTE_LEGAL) AS CANT FROM NULLID.RNT_REPRESENTANTE_LEGAL_MANDATARIO AS RLM WHERE ID_MANDATARIO=" + mandatario.getId() + "	) all_cond";

		Query query = getSession().createSQLQuery(sqlQuery);
		return (Integer) query.uniqueResult();
	}

}
