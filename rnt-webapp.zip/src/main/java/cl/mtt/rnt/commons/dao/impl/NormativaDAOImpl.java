package cl.mtt.rnt.commons.dao.impl;

import java.util.List;

import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.NormativaDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class NormativaDAOImpl extends GenericDAOImpl<Normativa> implements NormativaDAO {

	public NormativaDAOImpl(Class<Normativa> objectType) {
		super(objectType);
	}

    @SuppressWarnings("unchecked")
    @Override
    public List<Normativa> getReglamentacionesByReglamentacion(Long idReglamentacion) throws GeneralDataAccessException {
        try {
            String hql = " SELECT N FROM Normativa AS N "
                    + " left join fetch N.autorizacion"
                    + " WHERE N.reglamentacion.id = " + idReglamentacion.toString() + " ";

            Query query = getSession().createQuery(hql);
            List<Normativa> result = query.list();
            return result;
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }

	@Override
	public void deleteNormativaItemDataWhenIsNull(Long normativaItemId)
			throws GeneralDataAccessException {
		 try {
	            String sql = "DELETE FROM NULLID.RNT_NORMATIVA_ITEM_DATA WHERE  ID_NORMATIVA_ITEM = " + normativaItemId;

	            Query query = getSession().createSQLQuery(sql);
	            
	            query.executeUpdate();
	         
	            
	        } catch (Exception e) {
	            log.error(GeneralDataAccessException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
	            throw new GeneralDataAccessException(GeneralDataAccessException.DELETE_ERROR, e);
	        }
		
	}

	
	 
	

}
