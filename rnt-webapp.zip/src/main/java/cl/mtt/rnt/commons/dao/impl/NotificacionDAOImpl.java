package cl.mtt.rnt.commons.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.NotificacionDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.autorizacion.Notificacion;
import cl.mtt.rnt.commons.model.userrol.User;

public class NotificacionDAOImpl extends GenericDAOImpl<Notificacion> implements NotificacionDAO {

	public NotificacionDAOImpl(Class<Notificacion> objectType) {
		super(objectType);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Notificacion> getNotificacionesPag(User user, Integer tipo, int first,
			int rows, List<String> orderFields)
			throws GeneralDataAccessException {
		
		StringBuffer hql = new StringBuffer();
		hql.append("SELECT  N " + " FROM Notificacion AS N where N.usuarioDestino.id = "+user.getId());
		if(tipo != null)
			hql.append(" and N.tipo = "+tipo);
		
		if (orderFields == null || orderFields.size()==0){
			hql.append(" order by N.creation DESC");
		}else{
			hql.append(" order by ");
			for (int i = 0; i < orderFields.size(); i++) {
				hql.append("N."+orderFields.get(i));
				if(i!=orderFields.size()-1)
					hql.append(", ");
				hql.append(" ");
			}
		}
		
		Query query = getSession().createQuery(hql.toString());
		query.setFirstResult(first).setMaxResults(rows);

		List<Notificacion> resultados = new ArrayList<Notificacion>();
		resultados = (List<Notificacion>) query.list();
		if (resultados == null)
			resultados = new ArrayList<Notificacion>();

		return resultados;
	}

	@Override
	public long getNotifiacionesCount(User user,boolean solonuevas,Integer tipo)	throws GeneralDataAccessException {
		StringBuffer hql = new StringBuffer();
		hql.append("SELECT  Count(N.id) " + " FROM Notificacion AS N where N.usuarioDestino.id = "+user.getId());
		if (solonuevas) {
			hql.append(" and N.estado = "+Notificacion.ESTADO_NO_LEIDO);
		}
		if(tipo!=null){
			hql.append(" and N.tipo = "+tipo);
		}
		Query query = getSession().createQuery(hql.toString());
		
		return (Long)query.uniqueResult();	
	}

	 
	

}
