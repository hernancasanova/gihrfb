package cl.mtt.rnt.commons.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.ParaderoDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Paradero;

public class ParaderoDAOImpl extends GenericDAOImpl<Paradero> implements ParaderoDAO {

	Logger log = Logger.getLogger(this.getClass());

	public ParaderoDAOImpl(Class<Paradero> objectType) {
		super(objectType);
	}

	public Long getIdParadero(String tipoParadero, String nombreParadero,String domicilioParadero,String numero, String comunaParadero) throws GeneralDataAccessException{
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT P.id")
		.append(" FROM Paradero P")
		.append(" WHERE P.tipoParadero = '" + tipoParadero.toUpperCase() +"'")		
		.append(" and P.nombre = '"+nombreParadero+"'")
		.append(" and P.codigoComuna = '"+comunaParadero+"'")
		.append(" and ( trim(concat(P.domicilio,' ',coalesce(P.numeroDomicilio,''))) = '"+domicilioParadero+"'")
		.append(" or trim(concat(P.domicilio,' ',coalesce(P.numeroDomicilio,''))) = '"+domicilioParadero+" "+numero+"'")
		.append(" or trim(P.domicilio) = '"+domicilioParadero+" "+numero+"' )");
		
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			return (Long)query.uniqueResult();
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
	}
	
}
