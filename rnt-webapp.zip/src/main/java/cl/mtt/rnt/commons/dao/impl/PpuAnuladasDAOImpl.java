package cl.mtt.rnt.commons.dao.impl;

import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;

import cl.mtt.rnt.commons.dao.PpuAnuladasDAO;
import cl.mtt.rnt.commons.dao.VehiculoServicioDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.VehiculoServicioRemplazadoException;
import cl.mtt.rnt.commons.model.core.PpuAnulada;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.util.Resources;

public class PpuAnuladasDAOImpl extends GenericDAOImpl<PpuAnulada> implements
		PpuAnuladasDAO {

	@Autowired
	private VehiculoServicioDAO vehiculoServicioDAO;

	public PpuAnuladasDAOImpl(Class<PpuAnulada> objectType) {
		super(objectType);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void AnularPPU(PpuAnulada ppuAnulada, Long idVehiculo,
			Long idVehiculoServicio) throws GeneralDataAccessException,VehiculoServicioRemplazadoException {
			if (!vehiculoServicioDAO.isRemplazadoAllVs(idVehiculo)) {
				String hql;
				String sql;
				Query query;

				vehiculoServicioDAO.isRemplazaAllVs(idVehiculo);

				// log
				hql = " DELETE   FROM LogServicio L WHERE L.message LIKE :ppu";
				query = getSession().createQuery(hql);
				query.setParameter("ppu", ppuAnulada.getPpu() + "%");
				query.executeUpdate();

				// notificacion
				hql = " DELETE   FROM Notificacion N WHERE N.autorizacionMovimiento.id IN "
						+ " (SELECT AM.id FROM AutorizacionMovimiento AM WHERE AM.idMovimiento  IN"
						+ " (SELECT VS.id FROM VehiculoServicio VS where VS.vehiculo.id = "
						+ idVehiculo
						+ " ) "
						+ "  AND AM.tipoMovimiento IN ( "
	                    + AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL + ","
	                    + AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION  + ") )";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// AutorizacionMovimiento
				hql = " DELETE   FROM AutorizacionMovimiento AM WHERE AM.idMovimiento IN "
						+ " (SELECT VS.id FROM VehiculoServicio VS where VS.vehiculo.id = "
						+ idVehiculo
						+ " )"
						+ "  AND AM.tipoMovimiento IN ( "
	                    + AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL + ","
	                    + AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION  + ") ";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// pasajeros
				sql = " DELETE FROM NULLID.RNT_PASAJERO_AUD WHERE ID_VEHICULO_SERVICIO IN (SELECT ID FROM NULLID.RNT_VEHICULO_SERVICIO WHERE ID_VEHICULO = "
						+ idVehiculo + " )";
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				hql = " DELETE   FROM Pasajero P  WHERE P.vehiculoServicio.id IN "
						+ " (SELECT VS.id FROM VehiculoServicio VS where VS.vehiculo.id = "
						+ idVehiculo + " )";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// ConductorVehiculo
				sql = "DELETE FROM NULLID.RNT_CONDUCTOR_VEHICULO_AUD WHERE ID_VEHICULO_SERVICIO IN (SELECT ID FROM NULLID.RNT_VEHICULO_SERVICIO WHERE ID_VEHICULO = "
						+ idVehiculo + " )";
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				hql = " DELETE   FROM ConductorVehiculo CV  WHERE CV.vehiculoServicio.id IN "
						+ " (SELECT VS.id FROM VehiculoServicio VS where VS.vehiculo.id = "
						+ idVehiculo + " )";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// propietario
				sql = " DELETE FROM NULLID.RNT_PROPIETARIO_AUD WHERE ID_ADQUISICION = (SELECT id FROM NULLID.RNT_ADQUISICION WHERE ID = (SELECT ID_ADQUISICION FROM NULLID.RNT_VEHICULO WHERE ID = "
						+ idVehiculo + " ))";
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				hql = " DELETE   FROM Propietario P  WHERE P.adquisicion.id = "
						+ " (SELECT A.id FROM Adquisicion A where A.id = "
						+ "(SELECT V.adquisicion.id From Vehiculo V WHERE  V.id = "
						+ idVehiculo + " ) )";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// adquisicion
				sql = " DELETE FROM NULLID.RNT_ADQUISICION_AUD WHERE ID = (SELECT ID_ADQUISICION FROM NULLID.RNT_VEHICULO WHERE ID = "
						+ idVehiculo + ")";
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				hql = " UPDATE  Adquisicion A SET A.ppu = 'XXXXXX'  WHERE A.id = "
						+ "(SELECT V.adquisicion.id From Vehiculo V WHERE  V.id = "
						+ idVehiculo + " ) )";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " UPDATE  Vehiculo V SET V.adquisicion.id = NULL  WHERE V.id = "
						+ idVehiculo;
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " DELETE   FROM Adquisicion A  WHERE A.ppu = 'XXXXXX' ";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// REVISION TECNICA
				sql = " DELETE FROM NULLID.RNT_REVISION_GASES_DATOS_AUD WHERE ID = (SELECT ID_REVISION_TECNICA FROM NULLID.RNT_VEHICULO WHERE ID = "
						+ idVehiculo + ")";
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				sql = " DELETE FROM NULLID.RNT_REVISION_TECNICA_DATOS_AUD WHERE ID = (SELECT ID_REVISION_TECNICA FROM NULLID.RNT_VEHICULO WHERE ID = "
						+ idVehiculo + ")";
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				hql = " UPDATE  DatosRevisionGases DG SET DG.codigoprt = 'CODIGO_PRT_BORRAR'  WHERE DG.id IN "
						+ " (SELECT RT.revisionGases.id FROM RevisionTecnica RT WHERE RT.id ="
						+ " (SELECT V.revisionTecnica.id FROM Vehiculo V WHERE V.id = "
						+ idVehiculo + " ))";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " UPDATE  RevisionTecnica RT SET RT.revisionGases.id = null  WHERE RT.id = "
						+ " (SELECT V.revisionTecnica.id FROM Vehiculo V WHERE V.id = "
						+ idVehiculo + " )";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " DELETE FROM  DatosRevisionGases DG WHERE DG.codigoprt = 'CODIGO_PRT_BORRAR' ";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " UPDATE  DatosRevisionTecnica DR SET DR.codigoprt = 'CODIGO_PRT_BORRAR'  WHERE DR.id IN "
						+ " (SELECT RT.revisionTecnica.id FROM RevisionTecnica RT WHERE RT.id ="
						+ " (SELECT V.revisionTecnica.id FROM Vehiculo V WHERE V.id = "
						+ idVehiculo + " ))";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " UPDATE  RevisionTecnica RT SET RT.revisionTecnica.id = null  WHERE RT.id = "
						+ " (SELECT V.revisionTecnica.id FROM Vehiculo V WHERE V.id = "
						+ idVehiculo + " )";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " DELETE FROM  DatosRevisionTecnica DR WHERE DR.codigoprt = 'CODIGO_PRT_BORRAR' ";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				sql = " DELETE FROM NULLID.RNT_REVISION_TECNICA_AUD WHERE ID = (SELECT ID_REVISION_TECNICA FROM NULLID.RNT_VEHICULO WHERE ID = "
						+ idVehiculo + ")";
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				hql = " UPDATE  RevisionTecnica RT SET RT.ppu= 'XXXXXX'  WHERE RT.id = "
						+ " (SELECT V.revisionTecnica.id FROM Vehiculo V WHERE V.id = "
						+ idVehiculo + " )";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " UPDATE  Vehiculo V SET V.revisionTecnica.id = null  WHERE V.id = "
						+ idVehiculo;
				query = getSession().createQuery(hql);
				query.executeUpdate();

				hql = " DELETE FROM RevisionTecnica RT  WHERE RT.ppu = 'XXXXXX'";
				query = getSession().createQuery(hql);
				query.executeUpdate();
				
				hql = " DELETE FROM SubInscripcionVehiculo SV  WHERE SV.vehiculo.id = " + idVehiculo;
                query = getSession().createQuery(hql);
                query.executeUpdate();
				
                hql = " DELETE FROM LimitacionVehiculo LV  WHERE LV.vehiculo.id = " + idVehiculo;
                query = getSession().createQuery(hql);
                query.executeUpdate();

				// atributaInstancia
			/*	sql = " DELETE FROM NULLID.RNT_ATRIBUTO_INSTANCIA_AUD WHERE ID_VEHICULO = "
						+ idVehiculo;
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();  */

				hql = " DELETE FROM AtributoInstancia AI  WHERE AI.vehiculo.id = "
						+ idVehiculo;
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// certificado
		/*		sql = " DELETE FROM NULLID.RNT_CERTIFICADO_DATO_AUD WHERE ID_CERTIFICADO IN (SELECT ID FROM  NULLID.RNT_CERTIFICADO WHERE ID_VEHICULO_SERVICIO IN (SELECT ID FROM NULLID.RNT_VEHICULO_SERVICIO WHERE ID_VEHICULO = "
						+ idVehiculo + " ))";
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();*/

			/*	hql = " DELETE FROM CertificadoDato CD  WHERE CD.certificado.id IN"
						+ " (SELECT C.id  FROM Certificado C WHERE C.vehiculo.id IN "
						+ " (SELECT VS.id FROM VehiculoServicio VS WHERE VS.vehiculo.id = "
						+ idVehiculo + " ) ) ";
				query = getSession().createQuery(hql);
				query.executeUpdate();*/

				hql = " DELETE FROM XmlCertificado XC  WHERE XC.certificado.id IN"
						+ " (SELECT C.id  FROM Certificado C WHERE C.vehiculo.id IN "
						+ " (SELECT VS.id FROM VehiculoServicio VS WHERE VS.vehiculo.id = "
						+ idVehiculo + " ) ) ";
				query = getSession().createQuery(hql);
				query.executeUpdate();


				hql = " DELETE FROM Certificado C  WHERE C.vehiculo.id IN (SELECT VS.id FROM VehiculoServicio VS where VS.vehiculo.id = "
						+ idVehiculo + ") ";
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// vehiculoservicio

				sql = " DELETE FROM NULLID.RNT_VEHICULO_SERVICIO_AUD WHERE ID_VEHICULO = "
						+ idVehiculo;
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				hql = " DELETE FROM VehiculoServicio VS  WHERE VS.vehiculo.id = "
						+ idVehiculo;
				query = getSession().createQuery(hql);
				query.executeUpdate();

				// vehiculo
				sql = " DELETE FROM NULLID.RNT_VEHICULO_AUD WHERE ID = "
						+ idVehiculo;
				query = getSession().createSQLQuery(sql);
				query.executeUpdate();

				hql = " DELETE FROM Vehiculo V  WHERE V.id = " + idVehiculo;
				query = getSession().createQuery(hql);
				query.executeUpdate();

				save(ppuAnulada);
				
			} else {
				throw new VehiculoServicioRemplazadoException(Resources.getString("vehiculoServicio.reemplazadoException.message"));
			}
	}

}
