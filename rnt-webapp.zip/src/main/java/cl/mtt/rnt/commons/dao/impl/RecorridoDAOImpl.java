package cl.mtt.rnt.commons.dao.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.RecorridoDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.encargado.dto.RecorridoDTO;

public class RecorridoDAOImpl extends GenericDAOImpl<Recorrido> implements RecorridoDAO {

	Logger log = Logger.getLogger(this.getClass());

	public RecorridoDAOImpl(Class<Recorrido> objectType) {
		super(objectType);
	}

	@SuppressWarnings("unchecked")
	@Override
	public LinkedList<RecorridoDTO> getRecorridosSkeleton(Servicio servicio, String currentOrder) throws GeneralDataAccessException {
		try {
			String joinsNeeded = "";
			if (currentOrder.startsWith("parOri")) {
				joinsNeeded += " left outer join nullid.RNT_EXTREMO_RECORRIDO ori on ori.ID = rc.ID_ORIGEN " + " left outer join NULLID.RNT_PARADERO parOri on parOri.id=ori.id_paradero ";
			}

			if (currentOrder.startsWith("parDes")) {
				joinsNeeded += "left outer join nullid.RNT_EXTREMO_RECORRIDO des on des.ID = rc.ID_DESTINO " + " left outer join NULLID.RNT_PARADERO parDes on parDes.id=des.id_paradero ";
			}

			String sqlIds = "select rc.ID,rc.nombre from nullid.RNT_RECORRIDO rc " + joinsNeeded + " where rc.ID_SERVICIO=" + servicio.getId() + " order by " + currentOrder;

			Query query = getSession().createSQLQuery(sqlIds);
			List<Object[]> resultset = query.list();

			if (resultset != null) {
				LinkedList<RecorridoDTO> ids = new LinkedList<RecorridoDTO>();
				for (Object[] dato : resultset) {
					RecorridoDTO vsDto = new RecorridoDTO();
					vsDto.setId(new Long(dato[0].toString()).longValue());
					vsDto.setNombre(dato[1].toString());
					ids.add(vsDto);
				}
				return ids;
			}

			return new LinkedList<RecorridoDTO>();
		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public void loadRecorridosPaginados(Servicio servicio, int pagina, Integer cantidadRegistros, String orderBy) throws GeneralDataAccessException {

		Integer rdesde = (pagina - 1) * cantidadRegistros;
		Integer rhasta = ((pagina - 1) * cantidadRegistros) + cantidadRegistros;

		try {

			if (rhasta > servicio.getRecorridosSkeleton().size()) {
				rhasta = servicio.getRecorridosSkeleton().size();
			}
			List<RecorridoDTO> subList = servicio.getRecorridosSkeleton().subList(rdesde, rhasta);

			List<Long> ids = new ArrayList<Long>();
			for (RecorridoDTO recDTO : subList) {
				if ((recDTO.getId() != null) && (recDTO.getRecorrido() == null)) {
					ids.add(recDTO.getId());
				}
			}
			if (ids.size() > 0) {
				Query query = getSession().createQuery("Select item FROM Recorrido item "
				        + "left outer join fetch item.origen as O "
				        + "left outer join fetch item.destino as D "
				        + "left outer join fetch O.paradero op "
				        + "left outer join fetch D.paradero dp "
				        + "left outer join fetch item.tarifa as T "
				        + "left outer join fetch item.userCreation as UC "
				        + "left outer join fetch item.userModified as UM "
				        + "WHERE item.id IN (:ids) order by item.estado");
				query.setParameterList("ids", ids);
				List<Recorrido> items = (List<Recorrido>) query.list();
				if (items != null) {
					for (Recorrido recorrido : items) {
						for (RecorridoDTO recDto : servicio.getRecorridosSkeleton()) {
							if (recDto.getId() != null) {
								if (recDto.getId().longValue() == recorrido.getId().longValue()) {
//									Hibernate.initialize(recorrido.getUserCreation());
//									Hibernate.initialize(recorrido.getUserModified());
									recDto.setRecorrido(recorrido);
								}
							}
						}
					}
				}
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}


	public Long getIdRecorridoByServicioYNombre(Long idServicio,String nombreRecorrido) throws GeneralDataAccessException{
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT R.id")
		.append(" FROM Recorrido R")
		.append(" WHERE R.servicio.id = " + idServicio)		
		.append(" and R.nombre = '"+nombreRecorrido+"'");
		
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			return (Long)query.uniqueResult();
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}

	}
	
	public void updateRecorridoEstadoFirma(Recorrido recorrido) throws GeneralDataAccessException{
		if (recorrido.getId() != null) {
			Long recId = recorrido.getId();
			String recMensajeFirmador = recorrido.getMensajeFirmador();
			Integer recRespuestaFirmador = (recorrido.getRespuestaFirmador()==null)?0:recorrido.getRespuestaFirmador();

			try {
				Query updateQuery = getSession().createSQLQuery(
						"update nullid.rnt_recorrido set MENSAJE_FIRMADOR = '" + recMensajeFirmador + "', RESPUESTA_FIRMADOR = '" + recRespuestaFirmador + "'  where id = " + recId + " ");
				int updated = updateQuery.executeUpdate();
			} catch (Exception e) {
				log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
				throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
			}
		}
	}

    @Override
    public Recorrido getRecorridoById(Long id) throws GeneralDataAccessException {
        StringBuffer hqlBuffer = new StringBuffer();
        hqlBuffer.append("SELECT R")
        .append(" FROM Recorrido R")
        .append(" WHERE R.id = " + id);
        
        try{
            Query query = getSession().createQuery(hqlBuffer.toString());
            Recorrido r = (Recorrido) query.uniqueResult();
            return r;
        }catch(Exception e){
            throw new GeneralDataAccessException(e.getMessage(),e);
        }
    }


    @SuppressWarnings("unchecked")
    @Override
    public List<Recorrido> getRecorridosHqlByServicio(Long id) throws GeneralDataAccessException {
        StringBuffer hqlBuffer = new StringBuffer();
        hqlBuffer.append("SELECT R")
        .append(" FROM Recorrido R")
        .append(" left outer join fetch R.origen as O ")
        .append(" left outer join fetch O.paradero as PO ")
        .append(" left outer join fetch PO.ubicacionTerminal as UTO ")
        .append(" left outer join fetch R.destino as D ")
        .append(" left outer join fetch D.paradero as PD ")
        .append(" left outer join fetch PD.ubicacionTerminal as UTD ")
        .append(" left outer join fetch R.tarifa as T ")
        .append(" WHERE R.servicio.id = " + id);
        
        try{
            Query query = getSession().createQuery(hqlBuffer.toString());
            List<Recorrido> r = (List<Recorrido>) query.list();
            return r;
        }catch(Exception e){
            throw new GeneralDataAccessException(e.getMessage(),e);
        }
    }
    
    
}
