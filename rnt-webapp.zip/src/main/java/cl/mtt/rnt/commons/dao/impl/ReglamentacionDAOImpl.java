package cl.mtt.rnt.commons.dao.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import cl.mtt.rnt.admin.reglamentacion.util.ItemCupo;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.ReglamentacionDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GlosaReglamentacion;
import cl.mtt.rnt.commons.model.core.ItemGlosaReglamentacion;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.view.ServicioReglamentadosVO;
import cl.mtt.rnt.commons.model.view.VehiculoReglamentadosVO;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class ReglamentacionDAOImpl extends GenericDAOImpl<Reglamentacion> implements ReglamentacionDAO {

	Logger log = Logger.getLogger(this.getClass());


	@Autowired()
	@Qualifier("ItemGlosaReglamentacionDAO")
	private GenericDAO<ItemGlosaReglamentacion> itemGlosaReglamentacionDAO;
	
	public ReglamentacionDAOImpl(Class<Reglamentacion> objectType) {
		super(objectType);
	}
	
	

    /* (non-Javadoc)
     * @see cl.mtt.rnt.commons.dao.impl.GenericDAOImpl#getByPrimaryKey(java.lang.Object)
     */
    @Override
    public Reglamentacion getByPrimaryKey(Object id) throws GeneralDataAccessException {
        String hql = "SELECT R FROM Reglamentacion R "
                + " left outer join fetch R.tipoReglamentacion as TR "
                + " left outer join fetch R.normativas as N "
                + " left outer join fetch N.autorizacion as A "
                + " left outer join fetch R.glosaVehiculo as GV "
                + " left outer join fetch R.glosaCertificado as GC "
                + " WHERE R.id="+ id; 
        try{
            Query query = getSession().createQuery(hql);
            Reglamentacion res =  (Reglamentacion) query.uniqueResult();
            if (res==null){
            	return res;
            }

            addItemsGlosa(res.getGlosaVehiculo());
			addItemsGlosa(res.getGlosaCertificado());
		    
            return res;
        }catch(Exception e){
            throw new GeneralDataAccessException(e.getMessage(),e);
        }   
    }



	/**
	 * @param glosa
	 * @throws GeneralDataAccessException
	 */
	private void addItemsGlosa(GlosaReglamentacion glosa) throws GeneralDataAccessException {
		if(glosa!=null){
		    Map<String, Object> critV=new HashMap<String, Object>();
		    critV.put("glosaReglamentacion.id", glosa.getId());
		    glosa.setItems(itemGlosaReglamentacionDAO.findBySimpleHQL(critV));
		}
	}
	

	@SuppressWarnings("rawtypes")
    public Integer getCantidadZonasUsadas(Long idReglamentacion, Long idZona) throws GeneralDataAccessException {
		try {
			String sql = "SELECT (SELECT COUNT(1) from NULLID.RNT_SERVICIO WHERE NULLID.RNT_SERVICIO.ID_ZONA = " + idZona + " AND NULLID.RNT_SERVICIO.ID_REGLAMENTACION = " + idReglamentacion + ") +"
					+ "(SELECT COUNT(1) from NULLID.RNT_VEHICULO_SERVICIO WHERE NULLID.RNT_VEHICULO_SERVICIO.ID_ZONA = " + idZona + " AND NULLID.RNT_VEHICULO_SERVICIO.ID_REGLAMENTACION = "
					+ idReglamentacion + ") " + "CANTIDAD FROM SYSIBM.SYSDUMMY1 ";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Integer dato = (Integer) datoPlano;
				return dato;
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

	@SuppressWarnings("rawtypes")
    public Integer getCantidadRegionesUsadas(Long idReglamentacion, String idRegion) throws GeneralDataAccessException {
		try {
			String sql = "SELECT (SELECT COUNT(1) from NULLID.RNT_SERVICIO WHERE NULLID.RNT_SERVICIO.CODIGO_REGION = '" + idRegion + "' AND NULLID.RNT_SERVICIO.ID_REGLAMENTACION = "
					+ idReglamentacion + ") CANTIDAD FROM SYSIBM.SYSDUMMY1";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Integer dato = (Integer) datoPlano;
				return dato;
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

	// Mejoras 201409 Nro: 3
		public int getCantidadReglamentacionesUsadas(Long idReglamentacion) throws GeneralDataAccessException{
			try {
				String sql1 = "SELECT (SELECT COUNT(1) from NULLID.RNT_SERVICIO WHERE NULLID.RNT_SERVICIO.ID_REGLAMENTACION = "
						+ idReglamentacion + ") CANTIDAD FROM SYSIBM.SYSDUMMY1";
				Query query1 = getSession().createSQLQuery(sql1);
				Integer result1 = (Integer)query1.uniqueResult();

				String sql2 = "SELECT (SELECT COUNT(1) from NULLID.RNT_VEHICULO_SERVICIO WHERE NULLID.RNT_VEHICULO_SERVICIO.ID_REGLAMENTACION = "
						+ idReglamentacion + ") CANTIDAD FROM SYSIBM.SYSDUMMY1";
				Query query2 = getSession().createSQLQuery(sql2);
				Integer result2 = (Integer)query2.uniqueResult();
				
				return result1.intValue()+result2.intValue();
			} catch (Exception e) {
				log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
				throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
			}
		}
	// Mejoras 201409 Nro: 3

	// public List<Long> getIdReglamentacionesWidthCupo() throws
	// GeneralDataAccessException{
	// String sql = "select unique(r.id) from nullid.RNT_REGLAMENTACION r "+
	// "JOIN nullid.RNT_NORMATIVA n on n.ID_REGLAMENTACION = r.ID "+
	// "JOIN nullid.RNT_NORMATIVA_REGISTRO nr on nr.ID_NORMATIVA = n.ID "+
	// "JOIN nullid.RNT_NORMATIVA_ITEM ni on ni.ID_NORMATIVA_REGISTRO = nr.ID "+
	// "JOIN nullid.RNT_NORMATIVA_ITEM_DATA nid on nid.ID_NORMATIVA_ITEM = ni.ID "+
	// "WHERE  "+
	// "n.DESCRIPTOR = 'ingreso_por_reemplazo' and "+
	// "nr.DESCRIPTOR = 'se_permite_ingresar' and "+
	// "ni.RNT_KEY='incorpora_cupos' and "+
	// "nid.VALUE='true' ";
	// Query query = getSession().createSQLQuery(sql);
	// return query.list();
	//
	// }

	 private List<ItemCupo> getItemsCupoVacios(Long idReglamentacion, Long idTipoServicio, String codigoRegion, Long idZona) throws GeneralDataAccessException {
			List<ItemCupo> resultados = new ArrayList<ItemCupo>();
			try {
				String sql = "select ID,NOMBRE,regid, MAX(VIGENCIA_DESDE) VIGENCIA_DESDE, MAX(VIGENCIA_HASTA) VIGENCIA_HASTA, MAX(ID_TIPO_SERVICIO) ID_TIPO_SERVICIO, MAX(ID_REGION_ZONA) ID_REGION_ZONA, MAX(VALOR_CUPO) VALOR_CUPO, APLICABLE_A "
						+ "from (select r.id,r.NOMBRE,N.ID as normaid,nr.ID as regid "
						+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='vigencia_desde' then nid.VALUE else null end VIGENCIA_DESDE "
						+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='vigencia_hasta' then nid.VALUE else null end VIGENCIA_HASTA "
						+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='tipo_servicio' then nid.VALUE else null end ID_TIPO_SERVICIO "
						+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='region_zona' then nid.VALUE else null end ID_REGION_ZONA "
						+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='valor_cupo' then nid.VALUE else null end VALOR_CUPO "
						+ ",mg.APLICABLE_A as APLICABLE_A "
						+ "from nullid.RNT_REGLAMENTACION r  "
						+ "join nullid.RNT_MARCO_GEOGRAFICO mg on r.ID_MARCO_GEOGRAFICO=mg.ID  "
						+ "join nullid.RNT_NORMATIVA n on r.ID = n.ID_REGLAMENTACION "
						+ "join nullid.RNT_NORMATIVA_REGISTRO nr on n.ID = nr.ID_NORMATIVA "
						+ "join nullid.RNT_NORMATIVA_ITEM ni on nr.ID = ni.ID_NORMATIVA_REGISTRO " + "join nullid.RNT_NORMATIVA_ITEM_DATA nid on ni.ID = NID.ID_NORMATIVA_ITEM " + "where ";

				if (idReglamentacion != null)
					sql += "r.id = " + idReglamentacion + " and ";

				sql += "n.DESCRIPTOR = 'ingreso_por_reemplazo' and nr.descriptor = 'cupos_servicios' ) CUPOS_SERIALES " + "where exists (select 1 from nullid.RNT_NORMATIVA auxN "
						+ "join nullid.RNT_NORMATIVA_REGISTRO auxNr on auxN.ID = auxNr.ID_NORMATIVA " + "join nullid.RNT_NORMATIVA_ITEM auxNi on auxNr.ID = auxNi.ID_NORMATIVA_REGISTRO "
						+ "join nullid.RNT_NORMATIVA_ITEM_DATA auxNid on auxNi.ID = auxNid.ID_NORMATIVA_ITEM "
						+ "where auxN.DESCRIPTOR = 'ingreso_por_reemplazo' and auxNr.DESCRIPTOR = 'se_permite_ingresar' and auxNi.RNT_KEY='incorpora_cupos' and "
						+ "auxNid.VALUE='true' and auxN.ID = CUPOS_SERIALES.normaid )"
						+ "group by ID,NOMBRE,regid,APLICABLE_A";

				Query query = getSession().createSQLQuery(sql);
				@SuppressWarnings("rawtypes")
                List resultset = query.list();
				for (Object datoPlano : resultset) {
					Object[] dato = (Object[]) datoPlano;
					ItemCupo sdao = new ItemCupo();
					sdao.setIdReglamentacion(((BigInteger) dato[0]).longValue());
					sdao.setNombreReglamentacion((String) dato[1]);
					sdao.setVigenciaDesde(Constants.dateFormat.parse((String) dato[3]));
					if (dato[4] != null)
						sdao.setVigenciaHasta(Constants.dateFormat.parse((String) dato[4]));
					sdao.setIdTipoServicio(Long.valueOf((String) dato[5]));
					if("ZON".equals((String)dato[8])){
						sdao.setIdZona((dato[6] != null) ? Long.valueOf((String) dato[6]).longValue() : null);
					} else {
						sdao.setCodigoRegion((String) dato[6]);	
					}
					sdao.setValorCupo(Integer.valueOf((String)dato[7]));
					sdao.setCantidadUsada(0);
					sdao.setDiferencia(sdao.getValorCupo());
					
					if( (idTipoServicio==null || idTipoServicio.equals(sdao.getIdTipoServicio())) &&
						(codigoRegion==null || codigoRegion.equals(sdao.getCodigoRegion())) &&	
						(idZona==null || idZona.equals(sdao.getIdZona())) ){
						resultados.add(sdao);
					}
				}

			} catch (Exception e) {
				log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
				throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
			}

			return resultados;
		}
	
	@SuppressWarnings("rawtypes")
    public List<ItemCupo> getItemsCupo(Long idReglamentacion, Long idTipoServicio, String codigoRegion, Long idZona) throws GeneralDataAccessException {
		List<ItemCupo> resultadosVacios = getItemsCupoVacios(idReglamentacion, idTipoServicio, codigoRegion, idZona); 
		List<ItemCupo> resultados = new ArrayList<ItemCupo>();
		try {
			String sql = "SELECT ID, NOMBRE, VIGENCIA_DESDE, VIGENCIA_HASTA, ID_TIPO_SERVICIO, ID_REGION, ID_ZONA, CAST(VALOR_CUPO as INT) VALOR_CUPO, COUNT(1) CANTIDAD_VS, CAST((VALOR_CUPO - COUNT(1)) as INT)  DIFERENCIA "
					+ "from (select CUPOS_NORMAS.ID, CUPOS_NORMAS.NOMBRE, CUPOS_NORMAS.VIGENCIA_DESDE, CUPOS_NORMAS.VIGENCIA_HASTA, CUPOS_NORMAS.ID_TIPO_SERVICIO, case when vs.id_ZONA IS null then CUPOS_NORMAS.ID_REGION_ZONA else null end ID_REGION, case when vs.id_ZONA IS not null then CUPOS_NORMAS.ID_REGION_ZONA else null end ID_ZONA, CUPOS_NORMAS.VALOR_CUPO "
					+ "from (select ID,NOMBRE,regid, MAX(VIGENCIA_DESDE) VIGENCIA_DESDE, MAX(VIGENCIA_HASTA) VIGENCIA_HASTA, MAX(ID_TIPO_SERVICIO) ID_TIPO_SERVICIO, MAX(ID_REGION_ZONA) ID_REGION_ZONA, MAX(VALOR_CUPO) VALOR_CUPO "
					+ "from (select r.id,r.NOMBRE,N.ID as normaid,nr.ID as regid "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='vigencia_desde' then nid.VALUE else null end VIGENCIA_DESDE "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='vigencia_hasta' then nid.VALUE else null end VIGENCIA_HASTA "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='tipo_servicio' then nid.VALUE else null end ID_TIPO_SERVICIO "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='region_zona' then nid.VALUE else null end ID_REGION_ZONA "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='valor_cupo' then nid.VALUE else null end VALOR_CUPO "
					+ "from nullid.RNT_REGLAMENTACION r  "
					+ "join nullid.RNT_NORMATIVA n on r.ID = n.ID_REGLAMENTACION "
					+ "join nullid.RNT_NORMATIVA_REGISTRO nr on n.ID = nr.ID_NORMATIVA "
					+ "join nullid.RNT_NORMATIVA_ITEM ni on nr.ID = ni.ID_NORMATIVA_REGISTRO " + "join nullid.RNT_NORMATIVA_ITEM_DATA nid on ni.ID = NID.ID_NORMATIVA_ITEM " + "where ";

			if (idReglamentacion != null)
				sql += "r.id = " + idReglamentacion + " and ";

			sql += "n.DESCRIPTOR = 'ingreso_por_reemplazo' and nr.descriptor = 'cupos_servicios' ) CUPOS_SERIALES " + "where exists (select 1 from nullid.RNT_NORMATIVA auxN "
					+ "join nullid.RNT_NORMATIVA_REGISTRO auxNr on auxN.ID = auxNr.ID_NORMATIVA " + "join nullid.RNT_NORMATIVA_ITEM auxNi on auxNr.ID = auxNi.ID_NORMATIVA_REGISTRO "
					+ "join nullid.RNT_NORMATIVA_ITEM_DATA auxNid on auxNi.ID = auxNid.ID_NORMATIVA_ITEM "
					+ "where auxN.DESCRIPTOR = 'ingreso_por_reemplazo' and auxNr.DESCRIPTOR = 'se_permite_ingresar' and auxNi.RNT_KEY='incorpora_cupos' and "
					+ "auxNid.VALUE='true' and auxN.ID = CUPOS_SERIALES.normaid )"
					+ "group by ID,NOMBRE,regid) CUPOS_NORMAS join nullid.RNT_VEHICULO_SERVICIO vs on CUPOS_NORMAS.ID = vs.ID_REGLAMENTACION join nullid.RNT_SERVICIO s on vs.ID_SERVICIO = s.ID "
					+ "where CAST(CUPOS_NORMAS.ID_TIPO_SERVICIO as INT) = s.ID_TIPO_SERVICIO ";

			if (idTipoServicio != null)
				sql += " and s.ID_TIPO_SERVICIO = " + idTipoServicio + " ";

			if (codigoRegion != null)
				sql += " and s.CODIGO_REGION = '" + codigoRegion + "' ";
			else if (idZona != null)
				sql += " and vs.ID_ZONA = " + idZona + " ";

			sql += "and ((vs.id_zona is null and CUPOS_NORMAS.ID_REGION_ZONA = s.CODIGO_REGION) OR (vs.id_zona is not null and CAST(CUPOS_NORMAS.ID_REGION_ZONA as INT) = vs.ID_ZONA)) "
					+ ") AGRUPADOS group by ID, NOMBRE, VIGENCIA_DESDE, VIGENCIA_HASTA, ID_TIPO_SERVICIO, ID_REGION, ID_ZONA, VALOR_CUPO ";

			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				ItemCupo sdao = new ItemCupo();
				sdao.setIdReglamentacion(((BigInteger) dato[0]).longValue());
				sdao.setNombreReglamentacion((String) dato[1]);
				sdao.setVigenciaDesde(Constants.dateFormat.parse((String) dato[2]));
				if (dato[3] != null)
					sdao.setVigenciaHasta(Constants.dateFormat.parse((String) dato[3]));
				sdao.setIdTipoServicio(Long.valueOf((String) dato[4]));
				sdao.setCodigoRegion((String) dato[5]);
				sdao.setIdZona((dato[6] != null) ? Long.valueOf((String) dato[6]).longValue() : null);
				sdao.setValorCupo((Integer) dato[7]);
				sdao.setCantidadUsada((Integer) dato[8]);
				sdao.setDiferencia((Integer) dato[9]);
				resultados.add(sdao);
			}

			for (ItemCupo itemCupoLleno : resultados) {
				for (ItemCupo itemCupovacio : resultadosVacios) {
					if(itemCupoLleno.getIdReglamentacion().equals(itemCupovacio.getIdReglamentacion()) && 
							itemCupoLleno.getIdTipoServicio().equals(itemCupovacio.getIdTipoServicio()) &&
							(itemCupoLleno.getCodigoRegion()==null || itemCupoLleno.getCodigoRegion().equals(itemCupovacio.getCodigoRegion())) &&
							(itemCupoLleno.getIdZona()==null || itemCupoLleno.getIdZona().equals(itemCupovacio.getIdZona())) ){
						itemCupovacio.setCantidadUsada(itemCupoLleno.getCantidadUsada());
						itemCupovacio.setDiferencia(itemCupoLleno.getDiferencia());
					}
				}
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}

		return resultadosVacios;
	}

	@SuppressWarnings({ "unused", "rawtypes" })
    public Integer getCantUsadosCupo(Long idReglamentacion, Long idTipoServicio, String codigoRegion, Long idZona) throws GeneralDataAccessException {
		List<ItemCupo> resultados = new ArrayList<ItemCupo>();
		try {
			String sql = "SELECT ID, NOMBRE, VIGENCIA_DESDE, VIGENCIA_HASTA, ID_TIPO_SERVICIO, ID_REGION, ID_ZONA, CAST(VALOR_CUPO as INT) VALOR_CUPO, COUNT(1) CANTIDAD_VS, CAST((VALOR_CUPO - COUNT(1)) as INT)  DIFERENCIA "
					+ "from (select CUPOS_NORMAS.ID, CUPOS_NORMAS.NOMBRE, CUPOS_NORMAS.VIGENCIA_DESDE, CUPOS_NORMAS.VIGENCIA_HASTA, CUPOS_NORMAS.ID_TIPO_SERVICIO, case when vs.id_ZONA IS null then CUPOS_NORMAS.ID_REGION_ZONA else null end ID_REGION, case when vs.id_ZONA IS not null then CUPOS_NORMAS.ID_REGION_ZONA else null end ID_ZONA, CUPOS_NORMAS.VALOR_CUPO "
					+ "from (select ID,NOMBRE,regid, MAX(VIGENCIA_DESDE) VIGENCIA_DESDE, MAX(VIGENCIA_HASTA) VIGENCIA_HASTA, MAX(ID_TIPO_SERVICIO) ID_TIPO_SERVICIO, MAX(ID_REGION_ZONA) ID_REGION_ZONA, MAX(VALOR_CUPO) VALOR_CUPO "
					+ "from (select r.id,r.NOMBRE,N.ID as normaid,nr.ID as regid "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='vigencia_desde' then nid.VALUE else null end VIGENCIA_DESDE "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='vigencia_hasta' then nid.VALUE else null end VIGENCIA_HASTA "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='tipo_servicio' then nid.VALUE else null end ID_TIPO_SERVICIO "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='region_zona' then nid.VALUE else null end ID_REGION_ZONA "
					+ ",case when nr.DESCRIPTOR = 'cupos_servicios' and ni.RNT_KEY='valor_cupo' then nid.VALUE else null end VALOR_CUPO "
					+ "from nullid.RNT_REGLAMENTACION r  "
					+ "join nullid.RNT_NORMATIVA n on r.ID = n.ID_REGLAMENTACION "
					+ "join nullid.RNT_NORMATIVA_REGISTRO nr on n.ID = nr.ID_NORMATIVA "
					+ "join nullid.RNT_NORMATIVA_ITEM ni on nr.ID = ni.ID_NORMATIVA_REGISTRO "
					+ "join nullid.RNT_NORMATIVA_ITEM_DATA nid on ni.ID = NID.ID_NORMATIVA_ITEM "
					+ "where r.id = "
					+ idReglamentacion
					+ " and "
					+ "n.DESCRIPTOR = 'ingreso_por_reemplazo' and nr.descriptor = 'cupos_servicios' ) CUPOS_SERIALES "
					+ "where exists (select 1 from nullid.RNT_NORMATIVA auxN "
					+ "join nullid.RNT_NORMATIVA_REGISTRO auxNr on auxN.ID = auxNr.ID_NORMATIVA "
					+ "join nullid.RNT_NORMATIVA_ITEM auxNi on auxNr.ID = auxNi.ID_NORMATIVA_REGISTRO "
					+ "join nullid.RNT_NORMATIVA_ITEM_DATA auxNid on auxNi.ID = auxNid.ID_NORMATIVA_ITEM "
					+ "where auxN.DESCRIPTOR = 'ingreso_por_reemplazo' and auxNr.DESCRIPTOR = 'se_permite_ingresar' and auxNi.RNT_KEY='incorpora_cupos' and "
					+ "auxNid.VALUE='true' and auxN.ID = CUPOS_SERIALES.normaid )"
					+ "group by ID,NOMBRE,regid) CUPOS_NORMAS join nullid.RNT_VEHICULO_SERVICIO vs on CUPOS_NORMAS.ID = vs.ID_REGLAMENTACION join nullid.RNT_SERVICIO s on vs.ID_SERVICIO = s.ID "
					+ "where CAST(CUPOS_NORMAS.ID_TIPO_SERVICIO as INT) = s.ID_TIPO_SERVICIO " + " and s.ID_TIPO_SERVICIO = " + idTipoServicio + " ";

			if (codigoRegion != null)
				sql += " and s.CODIGO_REGION = '" + codigoRegion + "' ";
			else if (idZona != null)
				sql += " and vs.ID_ZONA = " + idZona + " ";

			sql += "and ((vs.id_zona is null and CUPOS_NORMAS.ID_REGION_ZONA = s.CODIGO_REGION) OR (vs.id_zona is not null and CAST(CUPOS_NORMAS.ID_REGION_ZONA as INT) = vs.ID_ZONA)) "
					+ ") AGRUPADOS group by ID, NOMBRE, VIGENCIA_DESDE, VIGENCIA_HASTA, ID_TIPO_SERVICIO, ID_REGION, ID_ZONA, VALOR_CUPO ";

			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				return (Integer) dato[8];
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}

		return 0;
	}


	@SuppressWarnings("unchecked")
    public List<Long> getReglamentacionesVehiculoIds(TipoServicio tipoServicio) throws GeneralDataAccessException{
		String hql = "SELECT DISTINCT R.id FROM VehiculoServicio VS "
				+ " inner join VS.reglamentacion as R"
				+ " inner join VS.servicio as S"
				+ " inner join S.tipoServicio as TS"
				+ " WHERE TS.id="+tipoServicio.getId(); 
		try{
			Query query = getSession().createQuery(hql);
			List<Long> res =  (List<Long>)query.list();
			return res;
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}	
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<Long> getReglamentacionesSubordinadasIds(Long idReglamentacion)throws GeneralDataAccessException {
		String hql = "SELECT DISTINCT RS.id FROM Reglamentacion R "
				+ " inner join R.reglamentacionesSubordinadas as RS"
				+ " WHERE R.id="+idReglamentacion; 
		try{
			Query query = getSession().createQuery(hql);
			List<Long> res =  (List<Long>)query.list();
			return res;
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}	
	}
	

	@SuppressWarnings("rawtypes")
    public List<ServicioReglamentadosVO> getServiciosAsociados(Reglamentacion reg) throws GeneralDataAccessException{
		String hql = "SELECT TS.id, S.identServicio, S.codigoRegion, S.vigenciaDesde, S.vigenciaHasta, S.estado FROM Servicio S "
				+ " inner join S.reglamentacion as R"
				+ " inner join S.tipoServicio as TS "
				+ " WHERE R.id="+reg.getId(); 
		try{
			
			Query query = getSession().createQuery(hql);
			List resultset = query.list();
			List<ServicioReglamentadosVO> resultados=new ArrayList<ServicioReglamentadosVO>(resultset.size());
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				
				ServicioReglamentadosVO vo = new ServicioReglamentadosVO();
				vo.setIdTipoServicio((Long) dato[0]);
				vo.setIdentServicio((Long) dato[1]);
				vo.setCodigoRegion((String) dato[2]);
				vo.setVigenciaDesde((Date) dato[3]);
				vo.setVigenciaHasta((Date) dato[4]);
				vo.setEstado((Integer) dato[5]);

				resultados.add(vo);
			}
			
			return resultados;
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}	
	}
	
	@SuppressWarnings("rawtypes")
    public List<VehiculoReglamentadosVO> getVehiculosAsociados(Reglamentacion reg) throws GeneralDataAccessException{
		String hql = "SELECT TS.id, S.identServicio, S.codigoRegion,  V.fechaIngreso, VS.fechaVencimiento, VS.estado, V.ppu FROM VehiculoServicio VS "
				+ " inner join VS.servicio as S"
				+ " inner join VS.vehiculo as V"
				+ " inner join VS.reglamentacion as R"
				+ " inner join S.tipoServicio as TS "
				+ " WHERE R.id="+reg.getId(); 
		try{
			
			Query query = getSession().createQuery(hql);
			List resultset = query.list();
			List<VehiculoReglamentadosVO> resultados=new ArrayList<VehiculoReglamentadosVO>(resultset.size());
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				
				VehiculoReglamentadosVO vo = new VehiculoReglamentadosVO();
				vo.setIdTipoServicio((Long) dato[0]);
				vo.setIdentServicio((Long) dato[1]);
				vo.setCodigoRegion((String) dato[2]);
				vo.setVigenciaDesde((Date) dato[3]);
				vo.setVigenciaHasta((Date) dato[4]);
				vo.setEstado((Integer) dato[5]);
				vo.setPpu((String) dato[6]);

				resultados.add(vo);
			}
			
			return resultados;
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}	
	}
	
	
	
	@SuppressWarnings("rawtypes")
    public List<Long> getReglamentacionesIdsSeleccionables(Long idTipoServicio, String codigoRegion, boolean aplicaNacion) throws GeneralDataAccessException {
	    List<Long> resultados = new ArrayList<Long>();
	    try {
            String sql = " select distinct R.ID " + 
                    " from nullid.RNT_REGLAMENTACION R " + 
                    " join nullid.RNT_REGLAMENTACION_TIPO_SERVICIO RTS on R.ID = RTS.REGLAMENTACION_ID " + 
                    " join nullid.RNT_MARCO_GEOGRAFICO MG on MG.ID = R.ID_MARCO_GEOGRAFICO " + 
                    " where  " + 
                    " (   ";
   
               sql += " (MG.APLICABLE_A  = 'NAC') OR ";
       
            sql += " (MG.APLICABLE_A = 'REG' AND EXISTS (SELECT ID FROM NULLID.RNT_MARCO_GEOGRAFICO_LOCALIZABLE MGL WHERE MGL.ID_MARCO_GEOGRAFICO = MG.ID AND ID_LOCALIZABLE = '" +codigoRegion+ "') ) OR " + 
                    "     (MG.APLICABLE_A = 'ZON' AND EXISTS (SELECT MGL.ID FROM NULLID.RNT_MARCO_GEOGRAFICO_LOCALIZABLE MGL JOIN NULLID.RNT_ZONA Z ON MGL.ID_LOCALIZABLE = Z.ID AND Z.ID_REGION = '"+codigoRegion+"' WHERE MGL.ID_MARCO_GEOGRAFICO = MG.ID) ) " + 
                    " ) " + 
                    " AND R.ESTADO = 'estadoReglamentacion.activa'  " + 
                    " AND CURRENT_DATE >= R.VIGENCIA_DESDE AND CURRENT_DATE <= (CASE WHEN VIGENCIA_HASTA IS NULL THEN CURRENT_DATE ELSE VIGENCIA_HASTA END)  " +
                    "  AND R.SELECCIONABLE_VEHICULO = 1 " +
                    " AND R.VISIBLE_ENCARGADO = 1 " +
                    " AND RTS.TIPO_SERVICIO_ID = " + idTipoServicio;
            
            Query query = getSession().createSQLQuery(sql);
            
            List resultset = query.list();
            for (Object datoPlano : resultset) {
                BigInteger dato = (BigInteger) datoPlano;
                resultados.add(dato.longValue());
            }
            return resultados;

        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
        }
    }





	
}
