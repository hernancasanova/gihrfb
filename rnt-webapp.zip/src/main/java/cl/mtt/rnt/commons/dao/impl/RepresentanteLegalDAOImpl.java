package cl.mtt.rnt.commons.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.RepresentanteLegalDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.RepresentanteLegal;

public class RepresentanteLegalDAOImpl extends GenericDAOImpl<RepresentanteLegal> implements RepresentanteLegalDAO {

	Logger log = Logger.getLogger(this.getClass());

	public RepresentanteLegalDAOImpl(Class<RepresentanteLegal> objectType) {
		super(objectType);

	}

	@Override
	public int getCountServicesByRepresentante(RepresentanteLegal representante) throws GeneralDataAccessException {
		String sqlQuery = "SELECT COUNT(SR.ID_SERVICIO) FROM NULLID.RNT_SERVICIO_REPRESENTANTE as SR " + "WHERE ID_REPRESENTANTE_SERVICIO=" + representante.getId();

		Query query = getSession().createSQLQuery(sqlQuery);
		return (Integer) query.uniqueResult();
	}

}
