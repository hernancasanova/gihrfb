package cl.mtt.rnt.commons.dao.impl;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.ServicioDAO;
import cl.mtt.rnt.commons.dao.sgprt.TipoVehiculoSGRPTDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Atributo;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.Conductor;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.Persona;
import cl.mtt.rnt.commons.model.core.Propietario;
import cl.mtt.rnt.commons.model.core.RepresentanteLegal;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.Tenedor;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.util.ArraylistUtils;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.AtributoCargaMasivaDTO;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.ServicioCargaMasivaDTO;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.TarifaFVCargaMasivaDTO;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.VehiculoServicioCargaMasivaDTO;
import cl.mtt.rnt.encargado.dto.PropietarioDTO;
import cl.mtt.rnt.encargado.dto.ServicioDTO;
import cl.mtt.rnt.encargado.dto.ServicioHistoricoDTO;
import cl.mtt.rnt.encargado.dto.ServicioLogDTO;

public class ServicioDAOImpl extends GenericDAOImpl<Servicio> implements ServicioDAO {

	Logger log = Logger.getLogger(this.getClass());

	@Autowired
	@Qualifier("TipoServicioDAO")
	GenericDAO<TipoServicio> tipoServicioDAO;

	@Autowired
	@Qualifier("TipoVehiculoDAO")
	TipoVehiculoSGRPTDAO tipoVehiculoSGRPTDAO;

	public ServicioDAOImpl(Class<Servicio> objectType) {
		super(objectType);
	}

	@SuppressWarnings("rawtypes")
	public List<ServicioDTO> getServiciosResponsable(Long id) throws GeneralDataAccessException {
		List<ServicioDTO> resultados = new ArrayList<ServicioDTO>();
		try {
			String hql = "	  SELECT  S.id " + "			,S.identServicio" + "			,TT.nombre as tipotransporte" + "			,MT.nombre as medio" + "			,CT.nombre as categoria" + "			,TSA.nombre as tiposervarea"
					+ "			,M.nombre  as modalidad" + " 			,RS.codigoComuna as codigoComuna " + " 			,RS.codigoRegion as codigoRegion " + "			FROM Servicio AS S"
					+ "			inner join S.tipoServicio AS TS " + "			inner join TS.tipoTransporte as TT " + "			inner join TS.medioTransporte as MT " + "			inner join TS.categoriaTransporte AS CT"
					+ "			inner join TS.tipoServicioArea AS TSA" + "			inner join TS.modalidad AS M" + "			inner join S.responsable AS RS " + "   WHERE" + "		RS.id = '" + id.toString() + "'";

			Query query = getSession().createQuery(hql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				ServicioDTO sdao = new ServicioDTO();
				sdao.setId((Long) dato[0]);
				sdao.setIdentServicio((Long) dato[1]);
				sdao.setTipoTransporte((String) dato[2]);
				sdao.setMedioTransporte((String) dato[3]);
				sdao.setCategoriaTransporte((String) dato[4]);
				sdao.setTipoServicioArea((String) dato[5]);
				sdao.setModalidad((String) dato[6]);
				sdao.setCodigoComuna((String) dato[7]);
				sdao.setCodigoRegion((String) dato[8]);
				resultados.add(sdao);

			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	@SuppressWarnings("rawtypes")
	public List<ServicioDTO> getServiciosByRutCategoria(Persona persona, List<TipoServicio> tiposServicio, User user) throws GeneralDataAccessException {
		List<ServicioDTO> resultados = new ArrayList<ServicioDTO>();
		try {
		    
		    if (tiposServicio == null) {
		        return new ArrayList<ServicioDTO>(0);
		    }
		    String tsIn = " IN (";
		    boolean primero = true;
		    boolean consultaPasajero = false;
		    for (TipoServicio ts :  tiposServicio) {
		        if (!primero) {
		            tsIn+= ",";
		        }
		        tsIn += ts.getId();
		        primero = false;
		        if (ts.getHabilitarPasajero()) {
		            consultaPasajero = true;
		        }
		    }
		    tsIn += ") ";
			String consultaSql = this.obtenerSQLRutResposable(persona, tsIn, user) 
			        + "\n UNION ALL " + this.obtenerSQLRutContacto(persona, tsIn, user)
			        + "\n UNION ALL " + this.obtenerSQLRutRepresentanteLegal(persona, tsIn, user)
			        + "\n UNION ALL " + this.obtenerSQLRutMandatario(persona, tsIn, user)
					+ "\n UNION ALL " + this.obtenerSQLRutConductor(persona, tsIn, user)
					+ "\n UNION ALL " + this.obtenerSQLRutPropietario(persona, tsIn, user);
			
			//Si al menos un tipo de servicio de la categoría permite pasajeros
			if (consultaPasajero) {
			    consultaSql += "\n UNION ALL " + this.obtenerSQLRutPasajeros(persona, tsIn, user);
			}
	
			Query query = getSession().createSQLQuery(consultaSql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				ServicioDTO sdao = new ServicioDTO();
				sdao.setId(((BigInteger) dato[0]).longValue());
				sdao.setIdentServicio(((BigInteger) dato[1]).longValue());
				sdao.setTipoTransporte((String) dato[2]);
				sdao.setMedioTransporte((String) dato[3]);
				sdao.setCategoriaTransporte((String) dato[4]);
				sdao.setTipoServicioArea((String) dato[5]);
				sdao.setModalidad((String) dato[6]);
				sdao.setActivo(((Short) dato[7] == 1));
				sdao.setTipoRelacionServicio((String) dato[8]);
				sdao.setCodigoRegion((String) dato[9]);
				sdao.setFechaInscripcion((Date) dato[10]);
				sdao.setVigenciaDesde((Date) dato[11]);
				sdao.setVigenciaHasta((Date) dato[12]);
				sdao.setDomicilio((String) dato[13]);
				sdao.setTelefono((String) dato[14]);
				sdao.setFax((String) dato[15]);
				sdao.setEmail((String) dato[16]);
				sdao.setCodigoComuna((String) dato[17]);
				sdao.setIdTipoServicio(((BigInteger) dato[18]).longValue());

				//Se debe hacer en manager x cache
				//sdao.setTipoServicio(tipoServicioDAO.getByPrimaryKey(sdao.getIdTipoServicio()));

				resultados.add(sdao);
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	private String obtenerSQLRutContacto(Persona persona, String tsIn, User user) {
	    String consulta = " SELECT S.id, S.ident_servicio, TT.nombre as tipotransporte, MT.nombre as medio, CT.nombre as categoria, " + " TSA.nombre as tiposervarea, "
                + " M.nombre  as modalidad, S.activo as activo, '" + ServicioDTO.TIPO_RELACION_CONTACTO + "' as tipoRelacionServicio, S.codigo_region as codigoRegion, "
                + " S.creation as fechaInscripcion, S.vigencia_desde as vigenciaDesde, S.vigencia_hasta as vigenciaHasta, "
                + " C.domicilio as domicilio, C.telefono as telefono, C.fax as fax, C.email as email, C.codigo_comuna as codigoComuna ,TS.id as idTipoServicio "
                + " FROM (SELECT * FROM \"NULLID\".\"RNT_CONTACTO\" WHERE ID_PERSONA = "+ persona.getId() +"  ) C "
                + " inner join \"NULLID\".\"RNT_SERVICIO_CONTACTO\" AS SC ON SC.id_contacto= C.id " 
                + " inner join \"NULLID\".\"RNT_SERVICIO\" AS S ON SC.id_servicio = S.id " 
                + " inner join \"NULLID\".\"RNT_TIPO_SERVICIO\" AS TS ON S.id_tipo_servicio= TS.id "
                + " inner join \"NULLID\".\"RNT_TIPO_TRANSPORTE\" as TT ON TS.id_tipo_transporte= TT.id " + " inner join \"NULLID\".\"RNT_MEDIO_TRANSPORTE\" as MT ON TS.id_medio_transporte= MT.id "
                + " inner join \"NULLID\".\"RNT_CATEGORIA_TRANSPORTE\" AS CT ON TS.id_categoria_transporte= CT.id "
                + " inner join \"NULLID\".\"RNT_TIPO_SERVICIO_AREA\" AS TSA ON TS.id_tipo_servicio_area= TSA.id " + " inner join \"NULLID\".\"RNT_MODALIDAD\" AS M ON TS.id_modalidad= M.id ";
//                + "  where ";
//                consulta += " TS.ID " + tsIn;
        return consulta;
    }

    private String obtenerSQLRutResposable(Persona persona, String tsIn, User user) {
		String consulta = "SELECT S.id, S.ident_servicio, TT.nombre as tipotransporte, MT.nombre as medio, CT.nombre as categoria, "
				+ " TSA.nombre as tiposervarea, M.nombre  as modalidad, S.activo as activo,'" + ServicioDTO.TIPO_RELACION_RESPONSABLE + "' as tipoRelacionServicio, "
				+ " S.codigo_region as codigoRegion, S.creation as fechaInscripcion, S.vigencia_desde as vigenciaDesde, "
				+ " S.vigencia_hasta as vigenciaHasta, RS.domicilio as domicilio, RS.telefono as telefono, RS.fax as fax, RS.email as email, "
				+ " RS.codigo_comuna as codigoComuna ,TS.id as idTipoServicio "
				+ " FROM (select * from NULLID.RNT_RESPONSABLE_SERVICIO WHERE id_persona = " + persona.getId() + " ) AS RS  " 
				+ " inner join \"NULLID\".\"RNT_SERVICIO\" AS S ON S.id_responsable_servicio= RS.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO\" AS TS ON S.id_tipo_servicio= TS.id " + " inner join \"NULLID\".\"RNT_TIPO_TRANSPORTE\" as TT ON TS.id_tipo_transporte= TT.id "
				+ " inner join \"NULLID\".\"RNT_MEDIO_TRANSPORTE\" as MT ON TS.id_medio_transporte= MT.id "
				+ " inner join \"NULLID\".\"RNT_CATEGORIA_TRANSPORTE\" AS CT ON TS.id_categoria_transporte= CT.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO_AREA\" AS TSA ON TS.id_tipo_servicio_area= TSA.id " + " inner join \"NULLID\".\"RNT_MODALIDAD\" AS M ON TS.id_modalidad= M.id ";
//				+ "  where ";
//		consulta += " TS.ID " + tsIn;
	/*	consulta += vigente ? " '" + Constants.dateFormatDB.format(new Date()) + "' BETWEEN S.vigencia_desde and S.vigencia_hasta and S.activo=1 " : " (not('"
				+ Constants.dateFormatDB.format(new Date()) + "' BETWEEN S.vigencia_desde and S.vigencia_hasta) or S.activo<>1)";*/
		return consulta;
	}

	private String obtenerSQLRutRepresentanteLegal(Persona persona, String tsIn, User user) {
		String consulta = " SELECT S.id, S.ident_servicio, TT.nombre as tipotransporte, MT.nombre as medio, CT.nombre as categoria, " + " TSA.nombre as tiposervarea, "
				+ " M.nombre  as modalidad, S.activo as activo, '" + ServicioDTO.TIPO_RELACION_REPRESENTANTE_LEGAL + "' as tipoRelacionServicio, S.codigo_region as codigoRegion, "
				+ " S.creation as fechaInscripcion, S.vigencia_desde as vigenciaDesde, S.vigencia_hasta as vigenciaHasta, "
				+ " RL.domicilio as domicilio, RL.telefono as telefono, RL.fax as fax, RL.email as email, RL.codigo_comuna as codigoComuna ,TS.id as idTipoServicio "
				+ " FROM (select * from NULLID.RNT_REPRESENTATE_LEGAL where id_persona = " +persona.getId()+ ") RL "
				+ " inner join \"NULLID\".\"RNT_SERVICIO_REPRESENTANTE\" AS SR  ON RL.id= SR.id_representante_servicio"
				+ " inner join \"NULLID\".\"RNT_SERVICIO\" AS S ON SR.id_servicio = S.id " 
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO\" AS TS ON S.id_tipo_servicio= TS.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_TRANSPORTE\" as TT ON TS.id_tipo_transporte= TT.id " + " inner join \"NULLID\".\"RNT_MEDIO_TRANSPORTE\" as MT ON TS.id_medio_transporte= MT.id "
				+ " inner join \"NULLID\".\"RNT_CATEGORIA_TRANSPORTE\" AS CT ON TS.id_categoria_transporte= CT.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO_AREA\" AS TSA ON TS.id_tipo_servicio_area= TSA.id " + " inner join \"NULLID\".\"RNT_MODALIDAD\" AS M ON TS.id_modalidad= M.id ";
//				+ " WHERE  ";
//		consulta += " TS.ID " + tsIn;
		
		return consulta;
	}

	private String obtenerSQLRutMandatario(Persona persona, String tsIn, User user) {
		String consulta = "SELECT S.id, S.ident_servicio, TT.nombre as tipotransporte, MT.nombre as medio, CT.nombre as categoria, "
				+ " TSA.nombre as tiposervarea, M.nombre  as modalidad, S.activo as activo,'" + ServicioDTO.TIPO_RELACION_MANDATARIO + "' as tipoRelacionServicio, "
				+ " S.codigo_region as codigoRegion, S.creation as fechaInscripcion, S.vigencia_desde as vigenciaDesde, "
				+ " S.vigencia_hasta as vigenciaHasta, MAND.domicilio as domicilio, MAND.telefono as telefono, MAND.fax as fax, MAND.email as email, "
				+ " MAND.codigo_comuna as codigoComuna ,TS.id as idTipoServicio "
				+ " FROM (select * FROM \"NULLID\".\"RNT_MANDATARIO\" where id_persona = "+ persona.getId() +") MAND "
				+ " inner join \"NULLID\".\"RNT_SERVICIO_MANDATARIO\" AS SMAND ON MAND.id= SMAND.id_mandatario " 
				+ " inner join \"NULLID\".\"RNT_SERVICIO\" AS S ON SMAND.id_servicio= S.id"
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO\" AS TS ON S.id_tipo_servicio= TS.id " + " inner join \"NULLID\".\"RNT_TIPO_TRANSPORTE\" as TT ON TS.id_tipo_transporte= TT.id "
				+ " inner join \"NULLID\".\"RNT_MEDIO_TRANSPORTE\" as MT ON TS.id_medio_transporte= MT.id "
				+ " inner join \"NULLID\".\"RNT_CATEGORIA_TRANSPORTE\" AS CT ON TS.id_categoria_transporte= CT.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO_AREA\" AS TSA ON TS.id_tipo_servicio_area= TSA.id " + " inner join \"NULLID\".\"RNT_MODALIDAD\" AS M ON TS.id_modalidad= M.id ";
//				+ " WHERE ";
//		        consulta += " TS.ID " + tsIn;
		
		return consulta;
	}

	private String obtenerSQLRutConductor(Persona persona, String tsIn, User user) {
		String consulta = " SELECT S.id, S.ident_servicio, TT.nombre as tipotransporte, MT.nombre as medio, CT.nombre as categoria, " + " TSA.nombre as tiposervarea, "
				+ " M.nombre  as modalidad, S.activo as activo, "  
		        + " case COND.tipo_Conductor when 'CONDUCTOR' then '"+ServicioDTO.TIPO_RELACION_CONDUCTOR+"' else '"+ServicioDTO.TIPO_RELACION_AUXILIAR+"' end as tipoRelacionServicio, "
		        + "S.codigo_region as codigoRegion, "
				+ " S.creation as fechaInscripcion, S.vigencia_desde as vigenciaDesde, S.vigencia_hasta as vigenciaHasta, "
				+ " COND.domicilio as domicilio, COND.telefono as telefono, COND.fax as fax, COND.email as email, COND.codigo_comuna as codigoComuna ,TS.id as idTipoServicio "
				+ " FROM (select * from  \"NULLID\".\"RNT_CONDUCTOR\" where id_persona = " +persona.getId()+ ") AS COND "
				+ " inner join \"NULLID\".\"RNT_CONDUCTOR_SERVICIO\" AS CS ON COND.id= CS.id_conductor " 
				+ " inner join \"NULLID\".\"RNT_SERVICIO\" AS S  ON CS.id_servicio = S.id " 
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO\" AS TS ON S.id_tipo_servicio= TS.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_TRANSPORTE\" as TT ON TS.id_tipo_transporte= TT.id " + " inner join \"NULLID\".\"RNT_MEDIO_TRANSPORTE\" as MT ON TS.id_medio_transporte= MT.id "
				+ " inner join \"NULLID\".\"RNT_CATEGORIA_TRANSPORTE\" AS CT ON TS.id_categoria_transporte= CT.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO_AREA\" AS TSA ON TS.id_tipo_servicio_area= TSA.id " + " inner join \"NULLID\".\"RNT_MODALIDAD\" AS M ON TS.id_modalidad= M.id ";
//				+ " WHERE ";
//		        consulta += " TS.ID " + tsIn;

		return consulta;
	}

	

	private String obtenerSQLRutPropietario(Persona persona, String tsIn, User user) {
		String consulta = " SELECT distinct S.id, S.ident_servicio, TT.nombre as tipotransporte, MT.nombre as medio, CT.nombre as categoria, " + " TSA.nombre as tiposervarea, "
				+ " M.nombre  as modalidad, S.activo as activo, '" + ServicioDTO.TIPO_RELACION_PROPIETARIO + "' as tipoRelacionServicio, S.codigo_region as codigoRegion, "
				+ " S.creation as fechaInscripcion, S.vigencia_desde as vigenciaDesde, S.vigencia_hasta as vigenciaHasta, "
				+ " pers.domicilio as domicilio, pers.telefono as telefono, pers.fax as fax, pers.email as email, pers.codigo_comuna as codigoComuna ,TS.id as idTipoServicio "
				+ " FROM (select * from \"NULLID\".\"RNT_PROPIETARIO\" where id_persona = "+persona.getId()+") AS PROP "
				+ " inner join \"NULLID\".\"RNT_PERSONA\" AS pers on pers.id = PROP.id_persona  "
				+ " inner join \"NULLID\".\"RNT_ADQUISICION\" AS ADQ on ADQ.id = PROP.id_adquisicion and propietario_actual = 1 "
				+ " inner join \"NULLID\".\"RNT_VEHICULO\" AS V on V.id_adquisicion = ADQ.id "
				+ " inner join \"NULLID\".\"RNT_VEHICULO_SERVICIO\" AS VS ON V.id= VS.id_vehiculo " 
				+ " inner join \"NULLID\".\"RNT_SERVICIO\" AS S ON VS.id_servicio = S.id " 
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO\" AS TS ON S.id_tipo_servicio= TS.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_TRANSPORTE\" as TT ON TS.id_tipo_transporte= TT.id " + " inner join \"NULLID\".\"RNT_MEDIO_TRANSPORTE\" as MT ON TS.id_medio_transporte= MT.id "
				+ " inner join \"NULLID\".\"RNT_CATEGORIA_TRANSPORTE\" AS CT ON TS.id_categoria_transporte= CT.id "
				+ " inner join \"NULLID\".\"RNT_TIPO_SERVICIO_AREA\" AS TSA ON TS.id_tipo_servicio_area= TSA.id " + " inner join \"NULLID\".\"RNT_MODALIDAD\" AS M ON TS.id_modalidad= M.id ";
//				+ " WHERE ";
//                consulta += " TS.ID " + tsIn;
		return consulta;
	}
	
	
	private String obtenerSQLRutPasajeros(Persona persona, String tsIn, User user) {
        String consulta = " SELECT distinct S.id, S.ident_servicio, TT.nombre as tipotransporte, MT.nombre as medio, CT.nombre as categoria, " + " TSA.nombre as tiposervarea, "
                + " M.nombre  as modalidad, S.activo as activo, '" + ServicioDTO.TIPO_RELACION_PASAJERO + "' as tipoRelacionServicio, S.codigo_region as codigoRegion, "
                + " S.creation as fechaInscripcion, S.vigencia_desde as vigenciaDesde, S.vigencia_hasta as vigenciaHasta, "
                + " pers.domicilio as domicilio, pers.telefono as telefono, pers.fax as fax, pers.email as email, pers.codigo_comuna as codigoComuna ,TS.id as idTipoServicio "
                + " FROM (select * from \"NULLID\".\"RNT_PASAJERO\" where id_persona = "+persona.getId()+") AS PASAJ "
                + " inner join \"NULLID\".\"RNT_PERSONA\" AS pers on pers.id = PASAJ.id_persona     "
                + " inner join \"NULLID\".\"RNT_VEHICULO_SERVICIO\" AS VS ON VS.id= PASAJ.ID_VEHICULO_SERVICIO " 
                + " inner join \"NULLID\".\"RNT_SERVICIO\" AS S ON VS.id_servicio = S.id " 
                + " inner join \"NULLID\".\"RNT_TIPO_SERVICIO\" AS TS ON S.id_tipo_servicio= TS.id "
                + " inner join \"NULLID\".\"RNT_TIPO_TRANSPORTE\" as TT ON TS.id_tipo_transporte= TT.id " + " inner join \"NULLID\".\"RNT_MEDIO_TRANSPORTE\" as MT ON TS.id_medio_transporte= MT.id "
                + " inner join \"NULLID\".\"RNT_CATEGORIA_TRANSPORTE\" AS CT ON TS.id_categoria_transporte= CT.id "
                + " inner join \"NULLID\".\"RNT_TIPO_SERVICIO_AREA\" AS TSA ON TS.id_tipo_servicio_area= TSA.id " + " inner join \"NULLID\".\"RNT_MODALIDAD\" AS M ON TS.id_modalidad= M.id ";
//                + " WHERE ";
//        consulta += " TS.ID " + tsIn;
        consulta += " UNION ";
        consulta += " SELECT distinct S.id, S.ident_servicio, TT.nombre as tipotransporte, MT.nombre as medio, CT.nombre as categoria, " + " TSA.nombre as tiposervarea, "
        + " M.nombre  as modalidad, S.activo as activo, '" + ServicioDTO.TIPO_RELACION_PASAJERO + "' as tipoRelacionServicio, S.codigo_region as codigoRegion, "
        + " S.creation as fechaInscripcion, S.vigencia_desde as vigenciaDesde, S.vigencia_hasta as vigenciaHasta, "
        + " pers.domicilio as domicilio, pers.telefono as telefono, pers.fax as fax, pers.email as email, pers.codigo_comuna as codigoComuna ,TS.id as idTipoServicio "
        + " FROM (select * from \"NULLID\".\"RNT_PASAJERO\" where id_persona = "+persona.getId()+") AS PASAJ "
        + " inner join \"NULLID\".\"RNT_PERSONA\" AS pers on pers.id = PASAJ.id_persona     "
        + " inner join \"NULLID\".\"RNT_SERVICIO\" AS S ON PASAJ.id_servicio = S.id " 
        + " inner join \"NULLID\".\"RNT_TIPO_SERVICIO\" AS TS ON S.id_tipo_servicio= TS.id "
        + " inner join \"NULLID\".\"RNT_TIPO_TRANSPORTE\" as TT ON TS.id_tipo_transporte= TT.id " + " inner join \"NULLID\".\"RNT_MEDIO_TRANSPORTE\" as MT ON TS.id_medio_transporte= MT.id "
        + " inner join \"NULLID\".\"RNT_CATEGORIA_TRANSPORTE\" AS CT ON TS.id_categoria_transporte= CT.id "
        + " inner join \"NULLID\".\"RNT_TIPO_SERVICIO_AREA\" AS TSA ON TS.id_tipo_servicio_area= TSA.id " + " inner join \"NULLID\".\"RNT_MODALIDAD\" AS M ON TS.id_modalidad= M.id ";
//        + " WHERE ";
//        consulta += " TS.ID " + tsIn;
        
        consulta = "select * from (" + consulta + ")";
        return consulta;
    }

	@SuppressWarnings("rawtypes")
	@Override
	public Long getNewIdentificadorServicio() throws GeneralDataAccessException {

		try {
			String sql = "SELECT (NEXTVAL FOR NULLID.IDENT_SERVICIO_SEQ ) as NEXT_VAL FROM SYSIBM.SYSDUMMY1 ";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Integer dato = (Integer) datoPlano;
				Long id = new Long(dato);
				return id;
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

	@Override
	public List<ServicioDTO> getServiciosRepresentante(Long representanteID) throws GeneralDataAccessException {
		List<ServicioDTO> resultados = new ArrayList<ServicioDTO>();
		try {
			String hql = "	  SELECT  S.id " + "			,S.identServicio" 
					+ "			,TT.nombre as tipotransporte" 
					+ "			,MT.nombre as medio" 
					+ "			,CT.nombre as categoria" 
					+ "			,TSA.nombre as tiposervarea"
					+ "			,M.nombre  as modalidad" 
					+ " 			,RL.codigoComuna as codigoComuna " 
					+ " 			,RL.codigoRegion as codigoRegion " 
					+ "			FROM Servicio AS S"
					+ "			inner join S.tipoServicio AS TS " 
					+ "			inner join TS.tipoTransporte as TT " 
					+ "			inner join TS.medioTransporte as MT " 
					+ "			inner join TS.categoriaTransporte AS CT"
					+ "			inner join TS.tipoServicioArea AS TSA" 
					+ "			inner join TS.modalidad AS M" 
					+ "			inner join S.representantesLegales AS RL" 
					+ "   WHERE RL.id = " + representanteID.toString() + "";

			Query query = getSession().createQuery(hql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				ServicioDTO sdao = new ServicioDTO();
				sdao.setId((Long) dato[0]);
				sdao.setIdentServicio((Long) dato[1]);
				sdao.setTipoTransporte((String) dato[2]);
				sdao.setMedioTransporte((String) dato[3]);
				sdao.setCategoriaTransporte((String) dato[4]);
				sdao.setTipoServicioArea((String) dato[5]);
				sdao.setModalidad((String) dato[6]);
				sdao.setCodigoComuna((String) dato[7]);
				sdao.setCodigoRegion((String) dato[8]);
				resultados.add(sdao);

			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;

	}

	@SuppressWarnings("unchecked")
	public List<Propietario> getPropietariosVehiculosByServicio(Servicio servicio) throws GeneralDataAccessException {
		List<Propietario> resultados = new ArrayList<Propietario>();
		try {
			String hql = "	  SELECT  P " + "			FROM Servicio AS S" + "			inner join S.vehiculos AS VS " + "   		inner join VS.vehiculo AS V " + "			inner join V.adquisicion AS A "
					+ "			inner join A.propietarios AS P " + "			WHERE " + "			S.id = " + servicio.getId();

			Query query = getSession().createQuery(hql);
			resultados = (List<Propietario>) query.list();

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

//	@SuppressWarnings("rawtypes")
//	@Override
//	public List<ServicioDTO> getServiciosByPPUCategoria(String ppu, CategoriaTransporte categoria,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user, boolean vigente) throws GeneralDataAccessException {
//		List<ServicioDTO> resultados = new ArrayList<ServicioDTO>();
//		try {//TODO no verifica tipotransporte y medioTransporte
//			StringBuffer consultaSql = new StringBuffer();
//			consultaSql.append("SELECT S.id,S.identServicio,S.codigoRegion,TT.nombre,MT.nombre,CT.nombre,TSA.nombre,")
//					   .append("M.nombre,S.vigenciaDesde,S.vigenciaHasta,VS.creation,V.id,VS.estado,VS.fechaCambioEstado,TC.nombre,")
//					   .append("VA.id,TS.id, RE.nombre, TI.nombre, VS.reemplaza.id, VS.reemplazado.id, VS.codigoRegionDestino")
//					   .append(" FROM Servicio as S")
//					   .append(" inner join S.tipoServicio as TS")
//					   .append(" inner join TS.tipoTransporte AS TT")
//					   .append(" inner join TS.medioTransporte AS MT")
//					   .append(" inner join TS.categoriaTransporte AS CT")
//					   .append(" inner join TS.tipoServicioArea AS TSA") 
//					   .append(" inner join TS.modalidad AS M")
//					   .append(" inner join S.vehiculos AS VS") 
//					   .append(" inner join VS.vehiculo AS V")
//					   .append(" inner join V.adquisicion AS VA")
//					   .append(" left join VS.tipoCancelacion AS TC ")
//					   .append(" inner join S.reglamentacion AS RE ")
//					   .append(" left join VS.tipoIngreso AS TI ")
//					   .append(" WHERE V.ppu = '"+ppu+"'")			
//					   .append(" and TT.id="+ tipoTransporte.getId())
//					   .append(" and CT.id="+ categoria.getId())
//					   .append(" and MT.id="+ medioTransporte.getId()+" ");
//
//			if (vigente) {
//				consultaSql.append(" and '" + Constants.dateFormatDB.format(new Date())
//						+ "' BETWEEN S.vigenciaDesde and S.vigenciaHasta and S.activo= 1");
//			} else {
//				consultaSql.append(" and ( (not('" + Constants.dateFormatDB.format(new Date())
//						+ "' BETWEEN S.vigenciaDesde and S.vigenciaHasta)) or S.activo = 0)");
//			}
//
//			Query query = getSession().createQuery(consultaSql.toString());
//			List resultset = query.list();
//			for (Object datoPlano : resultset) {
//				Object[] dato = (Object[]) datoPlano;
//				ServicioDTO sdao = new ServicioDTO();
//				sdao.setId((Long)dato[0]);
//				sdao.setIdentServicio((Long) dato[1]);
//				sdao.setCodigoRegion((String) dato[2]);
//				sdao.setTipoTransporte((String) dato[3]);
//				sdao.setMedioTransporte((String) dato[4]);
//				sdao.setCategoriaTransporte((String) dato[5]);
//				sdao.setTipoServicioArea((String) dato[6]);
//				sdao.setModalidad((String) dato[7]);
//				sdao.setVigenciaDesde((Date) dato[8]);
//				sdao.setVigenciaHasta((Date) dato[9]);
//				sdao.setFechaInscripcion((Date) dato[10]);
//				sdao.setIdVehiculoActual((Long) dato[11]);
//				sdao.setEstadoVehiculo((Integer) dato[12]);
//				sdao.setFechaEstado((Date) dato[13]);
//				sdao.setDescripcionTipoCancelacion(dato[14] != null ? (String) dato[14] : "");
//				if (dato[15] != null) {
//					sdao.setIdAdquisicionActual((Long) dato[15]);
//				}
//				sdao.setIdTipoServicio((Long) dato[16]);
//				sdao.setDescripcionReglamentacion(dato[17]!=null ? (String) dato[17] : "");
//				
//				sdao.setDescripcionTipoIngreso(dato[18]!=null ? (String) dato[18] : "");
//				
//				if(dato[19] != null){
//					sdao.setRemplazaAID((Long) dato[19]);
//				}
//				
//				if(dato[20] != null){
//					sdao.setRemplazadoPorID((Long) dato[20]);
//				} 
//				
//				if(dato[21] != null ){
//					sdao.setRegionDestino(new Region());
//					sdao.getRegionDestino().setCodigo((String) dato[21]);
//				}
//				resultados.add(sdao);
//			}
//
//		} catch (Exception e) {
//			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
//			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
//		}
//
//		return resultados;
//
//	}
	

	@SuppressWarnings("rawtypes")
	@Override
	public List<ServicioDTO> getServiciosByPPUSinCategoria(String ppu, boolean vigente) throws GeneralDataAccessException {
		List<ServicioDTO> resultados = new ArrayList<ServicioDTO>();
		try {
			StringBuffer consultaSql = new StringBuffer();
			consultaSql.append("SELECT S.id,S.identServicio,S.codigoRegion,TT.nombre,MT.nombre,CT.nombre,TSA.nombre,")
					   .append("M.nombre,S.vigenciaDesde,S.vigenciaHasta,VS.creation,V.id,VS.estado,VS.fechaCambioEstado,TC.nombre,")
					   .append("VA.id,TS.id, RE.nombre, TI.nombre, VS.reemplaza.id, VS.reemplazado.id, VS.codigoRegionDestino")
					   .append(" FROM Servicio as S")
					   .append(" inner join S.tipoServicio as TS")
					   .append(" inner join TS.tipoTransporte AS TT")
					   .append(" inner join TS.medioTransporte AS MT")
					   .append(" inner join TS.categoriaTransporte AS CT")
					   .append(" inner join TS.tipoServicioArea AS TSA") 
					   .append(" inner join TS.modalidad AS M")
					   .append(" inner join S.vehiculos AS VS") 
					   .append(" inner join VS.vehiculo AS V")
					   .append(" inner join V.adquisicion AS VA")
					   .append(" left join VS.tipoCancelacion AS TC ")
					   .append(" left outer join S.reglamentacion AS RE ")
					   .append(" left join VS.tipoIngreso AS TI ")
					   .append(" WHERE V.ppu = '"+ppu+"'");

			if (vigente) {
				consultaSql.append(" and '" + Constants.dateFormatDB.format(new Date())
						+ "' BETWEEN S.vigenciaDesde and S.vigenciaHasta and S.estado= 1");
			} else {
				consultaSql.append(" and ( (not('" + Constants.dateFormatDB.format(new Date())
						+ "' BETWEEN S.vigenciaDesde and S.vigenciaHasta)) or S.estado <> 1)");
			}

			Query query = getSession().createQuery(consultaSql.toString());
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				ServicioDTO sdao = new ServicioDTO();
				sdao.setId((Long)dato[0]);
				sdao.setIdentServicio((Long) dato[1]);
				sdao.setCodigoRegion((String) dato[2]);
				sdao.setTipoTransporte((String) dato[3]);
				sdao.setMedioTransporte((String) dato[4]);
				sdao.setCategoriaTransporte((String) dato[5]);
				sdao.setTipoServicioArea((String) dato[6]);
				sdao.setModalidad((String) dato[7]);
				sdao.setVigenciaDesde((Date) dato[8]);
				sdao.setVigenciaHasta((Date) dato[9]);
				sdao.setFechaInscripcion((Date) dato[10]);
				sdao.setIdVehiculoActual((Long) dato[11]);
				sdao.setEstadoVehiculo((Integer) dato[12]);
				sdao.setFechaEstado((Date) dato[13]);
				sdao.setDescripcionTipoCancelacion(dato[14] != null ? (String) dato[14] : "");
				if (dato[15] != null) {
					sdao.setIdAdquisicionActual((Long) dato[15]);
				}
				sdao.setIdTipoServicio((Long) dato[16]);
				sdao.setDescripcionReglamentacion(dato[17]!=null ? (String) dato[17] : "");
				
				sdao.setDescripcionTipoIngreso(dato[18]!=null ? (String) dato[18] : "");
				
				if(dato[19] != null){
					sdao.setRemplazaAID((Long) dato[19]);
				}
				
				if(dato[20] != null){
					sdao.setRemplazadoPorID((Long) dato[20]);
				} 
				
				if(dato[21] != null ){
					sdao.setRegionDestino(new Region());
					sdao.getRegionDestino().setCodigo((String) dato[21]);
				}
				resultados.add(sdao);
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;

	}
	
	
	
	

	@Override
	public List<ServicioDTO> getServiciosByPPUCategoria(String ppu) throws GeneralDataAccessException {
		List<ServicioDTO> resultados = new ArrayList<ServicioDTO>();
		try {
			StringBuffer consultaSql = new StringBuffer();
			consultaSql.append("SELECT S.id, ")
					.append("S.identServicio, ")
					.append("S.codigoRegion, ")
					.append("TT.nombre, ")
					.append("MT.nombre, ")
					.append("CT.nombre, ")
					.append("TSA.nombre, ")
					.append("M.nombre, ")
					.append("S.vigenciaDesde, ")
					.append("S.vigenciaHasta, ")
					.append("VS.creation ,")
					.append("V.id, ")
					.append("VS.estado, ")
					.append("VS.modified, ")
					.append("TC.nombre, ")
					.append("VA.id, ")
					.append("TS.id, ")
					.append("RS.id ")
					.append("FROM Servicio AS S ")
					.append("inner join S.tipoServicio AS TS ")
					.append("inner join TS.tipoTransporte AS TT ")
					.append("inner join TS.medioTransporte AS MT ")
					.append("inner join TS.categoriaTransporte AS CT ")
					.append("inner join TS.tipoServicioArea AS TSA ")
					.append("inner join TS.modalidad as M ")
					.append("inner join S.vehiculos AS VS ") 
					.append("inner join VS.vehiculo AS V ")
					.append("inner join V.adquisicion AS VA ")
					.append("inner join S.responsable AS RS ")
					.append("left join VS.tipoCancelacion AS TC ")
					.append("WHERE V.ppu = '" + ppu + "' " );
//					.append("and '" + Constants.dateFormatDB.format(new Date()))
//					.append("' BETWEEN S.vigenciaDesde and S.vigenciaHasta and S.activo=1");

			Query query = getSession().createQuery(consultaSql.toString());
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				ServicioDTO sdao = new ServicioDTO();
				sdao.setId((Long) dato[0]);
				sdao.setIdentServicio((Long)dato[1]);
				sdao.setCodigoRegion((String) dato[2]);
				sdao.setTipoTransporte((String) dato[3]);
				sdao.setMedioTransporte((String) dato[4]);
				sdao.setCategoriaTransporte((String) dato[5]);
				sdao.setTipoServicioArea((String) dato[6]);
				sdao.setModalidad((String) dato[7]);
				sdao.setVigenciaDesde((Date) dato[8]);
				sdao.setVigenciaHasta((Date) dato[9]);
				sdao.setFechaInscripcion((Date) dato[10]);
				sdao.setIdVehiculoActual((Long) dato[11]);
				sdao.setEstadoVehiculo((Integer) dato[12]);
				sdao.setFechaEstado((Date) dato[13]);
				sdao.setDescripcionTipoCancelacion(dato[14] != null ? (String) dato[14] : "");
				sdao.setIdAdquisicionActual((Long) dato[15]);
				sdao.setIdTipoServicio((Long) dato[16]);
				sdao.setIdResponsableServicio((Long) dato[17]);

				resultados.add(sdao);
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;

	}
	
	public Boolean getZonaUsada(Zona zona) throws GeneralDataAccessException {
		try {
			String sql = "SELECT COUNT(VALUE) FROM( " + "SELECT distinct value  from ( " + "Select * " + "from  NULLID.RNT_NORMATIVA_ITEM NI2 where ID_NORMATIVA_REGISTRO in ( "
					+ "select ID from NULLID.RNT_NORMATIVA_REGISTRO where ID in ( " + "SELECT ID_NORMATIVA_REGISTRO from NULLID.RNT_NORMATIVA_ITEM NI "
					+ "where NI.RNT_KEY = 'marco_geografico_aplicable_a' "
					+ "and EXISTS (SELECT 1 from  NULLID.RNT_NORMATIVA_ITEM_DATA IDD where IDD.VALUE = 'ZON' and iDD.ID_NORMATIVA_ITEM = NI.ID))) " + "and  NI2.RNT_KEY = 'marco_geografico' ) xx "
					+ "join NULLID.RNT_NORMATIVA_ITEM_DATA NID on NID.ID_NORMATIVA_ITEM = xx.ID " + "union all " + "SELECT distinct value  from ( " + "Select * "
					+ "from  NULLID.RNT_NORMATIVA_ITEM NI2 where ID_NORMATIVA_REGISTRO in ( " + "select ID from NULLID.RNT_NORMATIVA_REGISTRO where ID in ( "
					+ "SELECT ID_NORMATIVA_REGISTRO from NULLID.RNT_NORMATIVA_ITEM NI " + "where NI.RNT_KEY = 'marco_geografico_origen_aplicable_a' "
					+ "and EXISTS (SELECT 1 from  NULLID.RNT_NORMATIVA_ITEM_DATA IDD where IDD.VALUE = 'ZON' and iDD.ID_NORMATIVA_ITEM = NI.ID))) "
					+ "and  NI2.RNT_KEY = 'marco_geografico_origen' ) xx " + "join NULLID.RNT_NORMATIVA_ITEM_DATA NID on NID.ID_NORMATIVA_ITEM = xx.ID " + "union all "
					+ "SELECT distinct value  from ( " + "Select * " + "from  NULLID.RNT_NORMATIVA_ITEM NI2 where ID_NORMATIVA_REGISTRO in ( "
					+ "select ID from NULLID.RNT_NORMATIVA_REGISTRO where ID in ( " + "SELECT ID_NORMATIVA_REGISTRO from NULLID.RNT_NORMATIVA_ITEM NI "
					+ "where NI.RNT_KEY = 'marco_geografico_destino_aplicable_a' "
					+ "and EXISTS (SELECT 1 from  NULLID.RNT_NORMATIVA_ITEM_DATA IDD where IDD.VALUE = 'ZON' and iDD.ID_NORMATIVA_ITEM = NI.ID))) "
					+ "and  NI2.RNT_KEY = 'marco_geografico_destino' ) xx " + "join NULLID.RNT_NORMATIVA_ITEM_DATA NID on NID.ID_NORMATIVA_ITEM = xx.ID " + ") ZONASIDS " + "WHERE VALUE = '"
					+ zona.getIdentifier() + "'";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Integer dato = (Integer) datoPlano;
				return dato > 0;
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

	@Override
	public List<String> getRutsSinDV() throws GeneralDataAccessException {
		List<String> ruts = new ArrayList<String>();
		try {
			String sql = "select rut from nullid.rnt_persona where rut not like '%-%'";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				String dato = (String) datoPlano;
				ruts.add(dato);
			}
			return ruts;
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	@Override
	public void updateRutPersona(String rut, String newRut) throws GeneralDataAccessException {
		try {
			Query updateQuery = getSession().createSQLQuery("update nullid.rnt_persona set rut = '" + newRut + "' where rut = '" + rut + "'");
			updateQuery.executeUpdate();
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	@Override
	public List<PropietarioDTO> getPropietariosVehiculosByServicioDTO(Servicio servicio) throws GeneralDataAccessException {

		String sqlQuery = "select prop.ID,rp.NOMBRE,rp.RUT,ra.FECHA_ADQUISICION,ra.REPERTORIO," + "ra.NUMERO_REPERTORIO,ra.OFICINA_REGISTRO_CIVIL,rv.PPU,rv.TIPO_VEHICULO,rt.RUT,rt.NOMBRE, vs.ESTADO   "
				+ "from nullid.RNT_VEHICULO_SERVICIO vs " + "join nullid.RNT_VEHICULO rv on vs.ID_VEHICULO = rv.ID " + "join nullid.RNT_ADQUISICION ra on rv.ID_ADQUISICION = ra.ID "
				+ "join nullid.RNT_PROPIETARIO prop on ra.ID = prop.ID_ADQUISICION " + "join nullid.RNT_PERSONA rp on prop.ID_PERSONA = rp.ID "
				+ " left outer join nullid.RNT_LIMITACION_VEHICULO lv on vs.ID_VEHICULO = lv.ID " + " left outer join nullid.RNT_TENEDOR rt on lv.ID = rt.ID_LIMITACION_VEHICULO " + " where "
				+ " vs.ID_SERVICIO = " + servicio.getId();

		Query query = getSession().createSQLQuery(sqlQuery);
		List resultset = query.list();
		List<PropietarioDTO> props = new ArrayList<PropietarioDTO>();
		for (Object datoPlano : resultset) {
			PropietarioDTO p = new PropietarioDTO();
			Object[] dato = (Object[]) datoPlano;
			p.setId(((BigInteger) dato[0]).longValue());
			p.setNombre((String) dato[1]);
			p.setRut((String) dato[2]);
			p.setFechaAdquisicion(new Date(((Timestamp) dato[3]).getTime()));
			p.setRepertorio((String) dato[4]);
			p.setNumeroRepertorio((String) dato[5]);
			// Mejoras 201409 Nro: 43
			if(dato[11] != null){
				p.setEstadoVehiculo((Integer)dato[11]);
			}
			// Mejoras 201409 Nro: 43
			if (dato[6] != null)
				p.setOficina((String) dato[6]);
			p.setPpu((String) dato[7]);
			Integer tipoVehiculoId = (Integer) dato[8];
			p.setTipoVehiculo(tipoVehiculoSGRPTDAO.getByPrimaryKey(tipoVehiculoId));
			p.setTenedores(new ArrayList<Tenedor>());
			if (props.contains(p)) {
				for (PropietarioDTO existente : props) {
					if (existente.equals(p)) {
						String rutTenedor = (String) dato[9];
						String nombreTenedor = (String) dato[10];
						if (rutTenedor != null) {
							List<Tenedor> tenedores = existente.getTenedores();
							Tenedor tn = new Tenedor();
							tn.setRut(rutTenedor);
							tn.setNombre(nombreTenedor);
							tenedores.add(tn);
						}
					}
				}
			} else {
				String rutTenedor = (String) dato[9];
				String nombreTenedor = (String) dato[10];
				if (rutTenedor != null) {
					Tenedor tn = new Tenedor();
					tn.setRut(rutTenedor);
					tn.setNombre(nombreTenedor);
					p.getTenedores().add(tn);
				}
				props.add(p);
			}

		}

		return props;
	}
	
	// Mejoras 201409 Nro: 43
	@Override
	public List<PropietarioDTO> getPropietariosVehiculosVigentesByServicioDTO(Servicio servicio) throws GeneralDataAccessException {

		String sqlQuery = "select prop.ID,rp.NOMBRE,rp.RUT,ra.FECHA_ADQUISICION,ra.REPERTORIO," + "ra.NUMERO_REPERTORIO,ra.OFICINA_REGISTRO_CIVIL,rv.PPU,rv.TIPO_VEHICULO,rt.RUT,rt.NOMBRE, vs.ESTADO   "
				+ "from nullid.RNT_VEHICULO_SERVICIO vs " + "join nullid.RNT_VEHICULO rv on vs.ID_VEHICULO = rv.ID " + "join nullid.RNT_ADQUISICION ra on rv.ID_ADQUISICION = ra.ID "
				+ "join nullid.RNT_PROPIETARIO prop on ra.ID = prop.ID_ADQUISICION " + "join nullid.RNT_PERSONA rp on prop.ID_PERSONA = rp.ID "
				+ " left outer join nullid.RNT_LIMITACION_VEHICULO lv on vs.ID_VEHICULO = lv.ID " + " left outer join nullid.RNT_TENEDOR rt on lv.ID = rt.ID_LIMITACION_VEHICULO " + " where "
				+ " vs.ID_SERVICIO = " + servicio.getId() + " AND  ((vs.ESTADO = 1 AND vs.FECHA_ESTADO <= CURRENT TIMESTAMP) OR (vs.ESTADO =2 AND vs.FECHA_ESTADO > CURRENT timestamp) OR (vs.ESTADO =3 AND vs.FECHA_ESTADO > CURRENT timestamp))";

		Query query = getSession().createSQLQuery(sqlQuery);
		List resultset = query.list();
		List<PropietarioDTO> props = new ArrayList<PropietarioDTO>();
		for (Object datoPlano : resultset) {
			PropietarioDTO p = new PropietarioDTO();
			Object[] dato = (Object[]) datoPlano;
			p.setId(((BigInteger) dato[0]).longValue());
			p.setNombre((String) dato[1]);
			p.setRut((String) dato[2]);
			p.setFechaAdquisicion((dato[3]!=null)?(new Date(((Timestamp) dato[3]).getTime())):null);
			p.setRepertorio((String) dato[4]);
			p.setNumeroRepertorio((String) dato[5]);
			if (dato[6] != null)
				p.setOficina((String) dato[6]);
			// Mejoras 201409 Nro: 43
				if(dato[11] != null){
					p.setEstadoVehiculo((Integer)dato[11]);
				}
			// Mejoras 201409 Nro: 43
			p.setPpu((String) dato[7]);
			Integer tipoVehiculoId = (Integer) dato[8];
			p.setTipoVehiculo(tipoVehiculoSGRPTDAO.getByPrimaryKey(tipoVehiculoId));
			p.setTenedores(new ArrayList<Tenedor>());
			if (props.contains(p)) {
				for (PropietarioDTO existente : props) {
					if (existente.equals(p)) {
						String rutTenedor = (String) dato[9];
						String nombreTenedor = (String) dato[10];
						if (rutTenedor != null) {
							List<Tenedor> tenedores = existente.getTenedores();
							Tenedor tn = new Tenedor();
							tn.setRut(rutTenedor);
							tn.setNombre(nombreTenedor);
							tenedores.add(tn);
						}
					}
				}
			} else {
				String rutTenedor = (String) dato[9];
				String nombreTenedor = (String) dato[10];
				if (rutTenedor != null) {
					Tenedor tn = new Tenedor();
					tn.setRut(rutTenedor);
					tn.setNombre(nombreTenedor);
					p.getTenedores().add(tn);
				}
				props.add(p);
			}

		}

		return props;
	}
	
	// Mejoras 201409 Nro: 43

	@Override
	public boolean getConductorTieneCancelacionByCategoria(String rut, TipoServicio tipoServicio) throws GeneralDataAccessException {
		String sqlQuery = "select sum(cant) from (" + "select count(C.ID) cant from nullid.RNT_CONDUCTOR C " + "join nullid.RNT_CONDUCTOR_SERVICIO CS on C.ID = CS.ID_CONDUCTOR "
				+ "join nullid.RNT_SERVICIO S on CS.ID_SERVICIO = S.ID " + "join nullid.RNT_TIPO_SERVICIO TS on TS.ID = S.ID_TIPO_SERVICIO  "
				+ "join nullid.RNT_TIPO_CANCELACION TC on TC.ID = CS.ID_TIPO_CANCELACION " + "join nullid.RNT_PERSONA PE on C.ID_PERSONA = PE.ID " + "where PE.RUT = '"
				+ rut
				+ "' "
				+ "and TS.ID_TIPO_TRANSPORTE = "
				+ tipoServicio.getTipoTransporte().getId()
				+ " "
				+ "and TS.ID_MEDIO_TRANSPORTE = "
				+ tipoServicio.getMedioTransporte().getId()
				+ " "
				+ "and TS.ID_CATEGORIA_TRANSPORTE = "
				+ tipoServicio.getCategoriaTransporte().getId()
				+ " "
				+ "and CS.ESTADO in (2,3) "
				+ "and TC.TIPO = 'definitiva' "
				+ "union all "
				+ "select count(C.ID)  cant from nullid.RNT_CONDUCTOR C  "
				+ "join nullid.RNT_CONDUCTOR_SERVICIO CS on C.ID = CS.ID_CONDUCTOR  "
				+ "join nullid.RNT_CONDUCTOR_VEHICULO CV on CS.ID = CV.ID_CONDUCTOR_SERVICIO  "
				+ "join nullid.RNT_SERVICIO S on CS.ID_SERVICIO = S.ID  "
				+ "join nullid.RNT_TIPO_SERVICIO TS on TS.ID = S.ID_TIPO_SERVICIO   "
				+ "join nullid.RNT_TIPO_CANCELACION TC on TC.ID = CV.ID_TIPO_CANCELACION  "
				+ "join nullid.RNT_PERSONA PE on C.ID_PERSONA = PE.ID  "
				+ "where PE.RUT = '"
				+ rut
				+ "' "
				+ "and TS.ID_TIPO_TRANSPORTE = "
				+ tipoServicio.getTipoTransporte().getId()
				+ " "
				+ "and TS.ID_MEDIO_TRANSPORTE = "
				+ tipoServicio.getMedioTransporte().getId()
				+ " "
				+ "and TS.ID_CATEGORIA_TRANSPORTE = "
				+ tipoServicio.getCategoriaTransporte().getId()
				+ " "
				+ "and CV.ESTADO in (2,3) " + "and TC.TIPO = 'definitiva' ) all_cond";

		Query query = getSession().createSQLQuery(sqlQuery);
		return ((Integer) query.uniqueResult()) > 0;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ServicioHistoricoDTO> getServicioHistoricoByServicio(Long id) throws GeneralDataAccessException {
				
		String sqlQuery = "	SELECT sa.id, sa.rev, u.NOMBRE_COMPLETO, sa.REVTYPE, ri.REVTSTMP, sa.IDENT_SERVICIO, sa.OBSERVACION "
					+ "FROM nullid.rnt_servicio_aud as sa	";
		sqlQuery += "	join nullid.RNT_USER u on u.id = sa.ID_USER_MODIFIED ";
		sqlQuery += "	join nullid.REVINFO ri on ri.rev = sa.rev ";
		sqlQuery += "	WHERE sa.ID = " + id;
		sqlQuery += "	ORDER BY sa.rev DESC";
		
		Query query = getSession().createSQLQuery(sqlQuery);		
		List<ServicioHistoricoDTO> resultados = new ArrayList<ServicioHistoricoDTO>();
		List resultset = query.list();
		for (Object datoPlano : resultset) {
			Object[] dato = (Object[]) datoPlano;
			ServicioHistoricoDTO sdao = new ServicioHistoricoDTO();
			sdao.setId(((BigInteger) dato[0]).longValue());
			sdao.setRev(((Integer) dato[1]).longValue());
			sdao.setNombreUsuario((String) dato[2]);
			sdao.setRevType(((String) dato[3].toString()));
			sdao.setFechaInscripcion(new Date(((BigInteger)dato[4]).longValue()));
			sdao.setIdentServicio(((BigInteger) dato[5]).longValue());
			sdao.setObservacion(((String) dato[6]));
			resultados.add(sdao);
		}
		return resultados;
		
	}
	
	@Override
	public ServicioCargaMasivaDTO getServicioCargaMasivaDTO(Long identificador, CategoriaTransporte categoriaTransporte,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException {
		StringBuffer hqlBuffer = new StringBuffer();
		ServicioCargaMasivaDTO resultset = null;
		hqlBuffer.append("SELECT  S.id,S.identServicio,TS.id,TS.permiteRecorrido,S.estado,S.vigenciaDesde,S.vigenciaHasta")
		.append(" FROM Servicio S")
		.append(" inner join S.tipoServicio AS TS")
		.append(" WHERE S.identServicio = " + identificador)		
		.append(" and TS.categoriaTransporte.id = " +categoriaTransporte.getId())		
		.append(" and TS.tipoTransporte.id = " +tipoTransporte.getId())		
		.append(" and TS.medioTransporte.id = " +medioTransporte.getId())		
		.append(" and S.codigoRegion ='" + user.getContext().getRegionSeleccionada().getCodigo()+"'");
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();
			if(res!=null){
				resultset = new ServicioCargaMasivaDTO();
				resultset.setIdServicio((Long)res[0]);
				resultset.setIdentServicio((Long)res[1]);
				resultset.setIdTipoServicio((Long)res[2]);
				resultset.setPermiteRecorrido(Boolean.parseBoolean(res[3].toString()));
				resultset.setEstado((Integer)res[4]);
				resultset.setVigenciaDesde((Date)res[5]);
				resultset.setVigenciaHasta((Date)res[6]);
			}
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
		return resultset;
	}

	@Override
	public VehiculoServicioCargaMasivaDTO getVehiculoServicioCargaMasivaDTO(Long identificador, String ppu, CategoriaTransporte categoriaTransporte,
			TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException{
		VehiculoServicioCargaMasivaDTO resultset = null;

		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT VS.id,S.identServicio,S.tipoServicio.id,VS.estado,V.id,V.ppu,R.id")
		.append(" FROM VehiculoServicio VS")
		.append(" inner join VS.servicio AS S")
		.append(" inner join S.tipoServicio AS TS")
		.append(" inner join VS.vehiculo AS V")
		.append(" left outer join VS.reglamentacion AS R")
		.append(" WHERE S.identServicio = " + identificador)		
		.append(" and TS.categoriaTransporte.id = " +categoriaTransporte.getId())	
		.append(" and TS.tipoTransporte.id = " +tipoTransporte.getId())		
		.append(" and TS.medioTransporte.id = " +medioTransporte.getId())		
		.append(" and V.ppu = '" +ppu+"'")		
		.append(" and S.codigoRegion ='" + user.getContext().getRegionSeleccionada().getCodigo()+"'");
		
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();
			resultset = new VehiculoServicioCargaMasivaDTO();
			resultset.setIdServicio((Long)res[0]);
			resultset.setIdentServicio((Long)res[1]);
			resultset.setIdTipoServicio((Long)res[2]);
			resultset.setEstado((Integer)res[3]);
			resultset.setIdVehiculo((Long)res[4]);
			resultset.setPpu((String)res[5]);
			resultset.setIdReglamentacion((Long)res[6]);
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
		return resultset;
	}
	
	private AtributoCargaMasivaDTO getAtributoDefServicio(Long id, String atributo,CategoriaTransporte categoria,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException {
		AtributoCargaMasivaDTO resultset = null;
		
		//busco la instancia de atributo
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT A.id, S.identServicio,S.tipoServicio.id,S.estado,TSA.obligatorio,A.tipo,S.id")
		.append(" FROM Servicio S")
		.append(" inner join S.tipoServicio AS TS")
		.append(" inner join TS.tipoServicioAtributos AS TSA")
		.append(" inner join TSA.atributo AS A")
		.append(" WHERE S.identServicio = " + id)		
		.append(" and TSA.atributo.id = A.id")
		.append(" and TS.categoriaTransporte.id = " +categoria.getId())		
		.append(" and TS.tipoTransporte.id = " +tipoTransporte.getId())		
		.append(" and TS.medioTransporte.id = " +medioTransporte.getId())		
		.append(" and lower(A.etiqueta) = lower('" +atributo+"')")		
		.append(" and S.codigoRegion ='" + user.getContext().getRegionSeleccionada().getCodigo()+"'");
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();
			if(res==null){
				return null;
			}else{
				resultset = new AtributoCargaMasivaDTO();
				resultset.setIdAtributo((Long)res[0]);
				resultset.setIdentServicio((Long)res[1]);
				resultset.setIdTipoServicio((Long)res[2]);
				resultset.setEstado((Integer)res[3]);
				resultset.setObligatorio((Boolean)res[4]);
				resultset.setTipoDato((String)res[5]);
				resultset.setIdServicio((Long)res[6]);
				
				agregarFuenteDatosAtributo(resultset);

			}
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
		return resultset;	
	}
	public AtributoCargaMasivaDTO getAtributoServicioCargaMasivaDTO(Long id, String atributo,CategoriaTransporte categoria,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException{
		AtributoCargaMasivaDTO resultset = null;

		//busco la instancia de atributo
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT A.id, AI.id, S.identServicio,S.tipoServicio.id,S.estado,AI.valor,TSA.obligatorio,A.tipo,S.id")
		.append(" FROM AtributoInstancia AI")
		.append(" inner join AI.atributo AS A")
		.append(" inner join AI.servicio AS S")
		.append(" inner join S.tipoServicio AS TS")
		.append(" inner join TS.tipoServicioAtributos AS TSA")
		.append(" WHERE S.identServicio = " + id)		
		.append(" and TSA.atributo.id = A.id")
		.append(" and TS.categoriaTransporte.id = " +categoria.getId())		
		.append(" and TS.tipoTransporte.id = " +tipoTransporte.getId())		
		.append(" and TS.medioTransporte.id = " +medioTransporte.getId())		
		.append(" and lower(A.etiqueta) = lower('" +atributo+"')")		
		.append(" and S.codigoRegion ='" + user.getContext().getRegionSeleccionada().getCodigo()+"'");
		
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();
			if (res==null){
				return getAtributoDefServicio(id,atributo,categoria,tipoTransporte,medioTransporte,user);
			}
			resultset = new AtributoCargaMasivaDTO();
			resultset.setIdAtributo((Long)res[0]);
			resultset.setIdInstancia((Long)res[1]);
			resultset.setIdentServicio((Long)res[2]);
			resultset.setIdTipoServicio((Long)res[3]);
			resultset.setEstado((Integer)res[4]);
			resultset.setValor((String)res[5]);
			resultset.setObligatorio((Boolean)res[6]);
			resultset.setTipoDato((String)res[7]);
			resultset.setIdServicio((Long)res[8]);
			
			agregarFuenteDatosAtributo(resultset);

		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
		return resultset;	
	}

	private void agregarFuenteDatosAtributo(AtributoCargaMasivaDTO resultset) {
		//en caso de ser lista, busco la fuente de datos
		if(resultset.getTipoDato().equals(Atributo.lista)){
			resultset.setSource("[");

			//forma ejemplo del string: ["Kia", "Nissan", "Toyota", "Honda"]
			//busco el source
			StringBuffer hqlBufferFuente = new StringBuffer();
			hqlBufferFuente.append("SELECT F.valor")
			.append(" FROM FuenteDato F")
			.append(" inner join F.atributo AS A")
			.append(" WHERE A.id = " + resultset.getIdAtributo() );		
			Query queryFuente = getSession().createQuery(hqlBufferFuente.toString());
			List<Object> resFuente =  queryFuente.list();
			for (Object object : resFuente) {
				resultset.setSource(resultset.getSource()+"'"+ object +"',");
			}
			resultset.setSource(resultset.getSource().substring(0,resultset.getSource().lastIndexOf(',')));
			resultset.setSource(resultset.getSource()+"]");
		}else{
			resultset.setSource(null);
		}
	}
	private AtributoCargaMasivaDTO getAtributoDefVehiculo(String atributo) throws GeneralDataAccessException {
		AtributoCargaMasivaDTO resultset = null;
		
		//busco la instancia de atributo
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT A.id, A.tipo, ")
		.append(" (select count(TSA.id) from TipoServicioAtributo AS TSA where TSA.atributo.id = A.id and TSA.obligatorio = true) ")
		.append(" FROM AtributoInstancia AI")
		.append(" inner join AI.atributo AS A")
		.append(" inner join AI.vehiculo AS V")
		.append(" WHERE lower(A.etiqueta) = lower('" +atributo+"')");
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();
			if(res==null){
				return null;
			}else{
				resultset = new AtributoCargaMasivaDTO();
				resultset.setIdAtributo((Long)res[0]);
				resultset.setObligatorio((Boolean)res[1]);
				resultset.setTipoDato((String)res[2]);
				
				agregarFuenteDatosAtributo(resultset);

			}
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
		return resultset;	
	}

	public AtributoCargaMasivaDTO getAtributoVehiculoCargaMasivaDTO(String ppu, String atributo) throws GeneralDataAccessException{
		AtributoCargaMasivaDTO resultset = null;

		//busco la instancia de atributo
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT V.id, AI.id, V.ppu,AI.valor, ")
		.append(" (select count(TSA.id) from TipoServicioAtributo AS TSA where TSA.atributo.id = A.id and TSA.obligatorio = true),A.tipo , A.id ")
		.append(" FROM AtributoInstancia AI")
		.append(" inner join AI.atributo AS A")
		.append(" inner join AI.vehiculo AS V")
		.append(" WHERE V.ppu = '" + ppu +"'")		
		.append(" and lower(A.etiqueta) = lower('" +atributo+"')");
	
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();
			if(res==null){
				return getAtributoDefVehiculo(atributo);
			}
			resultset = new AtributoCargaMasivaDTO();
			resultset.setIdVehiculo((Long)res[0]);
			resultset.setIdInstancia((Long)res[1]);
			resultset.setPpu((String)res[2]);
			resultset.setValor((String)res[3]);
			resultset.setObligatorio((Long)res[4]>0);
			resultset.setTipoDato((String)res[5]);
			resultset.setIdAtributo((Long)res[6]);
			agregarFuenteDatosAtributo(resultset);
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
		return resultset;	
	}

	@Override
	public TarifaFVCargaMasivaDTO getTarifaFVCargaMasivaDTO(Long identificador, CategoriaTransporte categoriaTransporte,TipoTransporte tipoTransporte,MedioTransporte medioTransporte, User user) throws GeneralDataAccessException {
		StringBuffer hqlBuffer = new StringBuffer();
		TarifaFVCargaMasivaDTO resultset = null;
		hqlBuffer.append("SELECT  S.id,"//0
							   + "S.identServicio,"//1
							   + "TS.id,"//2
							   + "TS.permiteRecorrido,"//3
							   + "S.estado,"//4
							   + "S.vigenciaDesde,"//5
							   + "S.vigenciaHasta,"//6
							   + "T.tipoTarifa,"//7
							   + "T.montoFijo,"//8
							   + "T.montoMinimo,"//9
							   + "T.montoMaximo")//10
				.append(" FROM Servicio S")
				.append(" inner join S.tipoServicio AS TS")
				.append(" left join S.tarifa as T")
				.append(" WHERE S.identServicio = " + identificador)		
				.append(" and TS.tipoTransporte.id = " +tipoTransporte.getId())		
				.append(" and TS.medioTransporte.id = " +medioTransporte.getId())		
				.append(" and TS.categoriaTransporte.id = " +categoriaTransporte.getId())		
				.append(" and S.codigoRegion ='" + user.getContext().getRegionSeleccionada().getCodigo()+"'");
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();			
			if(res!=null){
				resultset = new TarifaFVCargaMasivaDTO((Long)res[0], 
													    (Long)res[1], 
													    (Long)res[2], 
													    (Integer)res[4], 
													    (Date)res[5], 
													    (Date)res[6], 
													    Boolean.parseBoolean(res[3].toString()), 
													    res[8], 
													    res[9], 
													    res[10], 
													    (String)res[7]);						
			
			}
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
		return resultset;
	}
	
	
	@Override
	public Servicio getServicioHistoricoByRevision(Long id, Long rev) throws GeneralDataAccessException {
		Servicio servicio;		
		try {
			AuditReader reader = AuditReaderFactory.get(getSession());
			servicio= reader.find(Servicio.class, id, rev.intValue());
		}
		catch (Exception e) {
			throw new GeneralDataAccessException(e.getMessage());
		}
		return servicio;	
		
	}
	
	@Override
	public Long getLastRevisionNumber(Servicio servicio) throws GeneralDataAccessException{
		String sqlQuery = "	SELECT max(sa.rev) FROM nullid.rnt_servicio_aud as sa ";
		sqlQuery += "	WHERE sa.ID = " + servicio.getId();
				
		Query query = getSession().createSQLQuery(sqlQuery);
		return new Long((Integer)query.uniqueResult());

	}
	
	@SuppressWarnings("rawtypes")
	public ServicioLogDTO getServicioLog(Long id) throws GeneralDataAccessException {
		try {
			String hql = " SELECT  S.id " + " ,S.identServicio" + " , S.vigenciaDesde, S.vigenciaHasta, S.reglamentacion.id, S.tipoSubsidio.id, S.tipoContrato.id "
					+ " ,R.persona.rut, R.formaActuanRepresentantes, R.gremio.id, R.domicilio, R.codigoComuna, R.telefono, R.fax, R.email "
					+ " FROM Servicio AS S INNER JOIN S.responsable AS R "
					+ " WHERE" + " S.id = " + id.toString() + " ";

			Query query = getSession().createQuery(hql);
			Object[] result = (Object[])query.uniqueResult();

			ServicioLogDTO sdao = new ServicioLogDTO();
			sdao.setId((Long) result[0]);
			sdao.setIdentServicio((Long) result[1]);
			sdao.setVigenciaDesde((Date) result[2]);
			sdao.setVigenciaHasta((Date) result[3]);
			sdao.setIdReglamentacion((Long) result[4]);
			sdao.setIdTipoSubsidio((Long) result[5]);
			sdao.setIdTipoContrato((Long) result[6]);
			sdao.setRutRepresentante((String) result[7]);
			sdao.setFormaActuanRepresentantes((String) result[8]);
			sdao.setIdGremioRepresentante((Long) result[9]);
			sdao.setDomicilioRepresentante((String) result[10]);
			sdao.setCodigoComunaRepresentante((String) result[11]);
			sdao.setTelefonoRepresentante((String) result[12]);
			sdao.setFaxRepresentante((String) result[13]);
			sdao.setEmailRepresentante((String) result[14]);
			
			//agrego las tarifas
			String hqlT = " SELECT  T.tipoTarifa ,T.montoFijo, T.montoMinimo, T.montoMaximo  "
					+ " FROM Servicio S INNER JOIN S.tarifa AS T "
					+ " WHERE S.id = " + id.toString() + " ";

			Query queryT = getSession().createQuery(hqlT);
			Object[] resultT = (Object[])queryT.uniqueResult();
			
			if(resultT!=null){
				sdao.setTipoTarifa((String)resultT[0]);
				sdao.setMontoFijoTarifa((Float)resultT[1]);
				sdao.setMontoMinimoTarifa((Float)resultT[2]);
				sdao.setMontoMaximoTarifa((Float)resultT[3]);
			}
			
			return sdao;

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

    @SuppressWarnings("unchecked")
    @Override
    public Servicio getServicioInicializado(Long identificador, CategoriaTransporteSeleccionble categoriaTransporte, String regionSeleccionada) throws GeneralDataAccessException {
        StringBuffer hqlBuffer = new StringBuffer();
        hqlBuffer.append("SELECT  S")//10
                .append(" FROM Servicio S")
                .append(" join S.tipoServicio AS TS")
                .append(" left join fetch S.responsable AS rserv")
                .append(" left join fetch S.userCreation AS suc")
                .append(" left join fetch S.userModified AS sum")
                .append(" left join fetch S.tipoSubsidio AS sts")
                .append(" left join fetch S.tarifa AS tarifa")
                .append(" left join fetch S.documentoCancelacion AS sts")
                .append(" left join fetch S.documentoInscripcion AS sts")
                .append(" left join fetch S.zonaServicio AS sts")
                
                .append(" WHERE S.identServicio = " + identificador)        
                .append(" and TS.tipoTransporte.id = " +categoriaTransporte.getTipoTransporte().getId())     
                .append(" and TS.medioTransporte.id = " +categoriaTransporte.getMedio().getId())       
                .append(" and TS.categoriaTransporte.id = " +categoriaTransporte.getCategoria().getId())       
                .append(" and S.codigoRegion ='" + regionSeleccionada+"'");
        try{
            Query query = getSession().createQuery(hqlBuffer.toString());
            List<Servicio> servs =  query.list();  
            if ((servs!=null)&&(!servs.isEmpty())) {
                Servicio serv = servs.get(0);
                Hibernate.initialize(serv.getRepresentantesLegales());
                if (serv.getRepresentantesLegales()!=null) {
                    for (RepresentanteLegal rl: serv.getRepresentantesLegales()) {
                        Hibernate.initialize(rl.getMandatarios());
                    }
                }
//                Hibernate.initialize(serv.getUserCreation());
//                Hibernate.initialize(serv.getUserModified());
                Hibernate.initialize(serv.getContactos());
                Hibernate.initialize(serv.getMandatarios());
//                Hibernate.initialize(serv.getTipoSubsidio());
                Hibernate.initialize(serv.getPasajeros());
//                Hibernate.initialize(serv.getPeriodosVigencia());
                Hibernate.initialize(serv.getOficinasVentaPasajeServicio());
                Hibernate.initialize(serv.getConductoresServicio());
                for (ConductorServicio cs : serv.getConductoresServicio()) {
                    Hibernate.initialize(cs.getConductoresVehiculo());
				}
                Hibernate.initialize(serv.getZonasSubsidio());
                return serv;
            }
           return null;
        }catch(Exception e){
            throw new GeneralDataAccessException(e.getMessage(),e);
        }
    }

    
    
    @SuppressWarnings("unchecked")
    @Override
    public Servicio getServicioInicializado(Long id) throws GeneralDataAccessException {
        StringBuffer hqlBuffer = new StringBuffer();
        hqlBuffer.append("SELECT  S")//10
                .append(" FROM Servicio S")
                .append(" join S.tipoServicio AS TS")
                .append(" left join fetch S.responsable AS rserv")
                .append(" left join fetch S.userCreation AS suc")
                .append(" left join fetch S.userModified AS sum")
                .append(" left join fetch S.tipoSubsidio AS sts")
                .append(" left join fetch S.tarifa AS tarifa")
                .append(" left join fetch S.documentoCancelacion AS sts")
                .append(" left join fetch S.documentoInscripcion AS sts")
                .append(" left join fetch S.zonaServicio AS sts")
                
                .append(" WHERE S.id = " + id);        
        try{
            Query query = getSession().createQuery(hqlBuffer.toString());
            List<Servicio> servs =  query.list();  
            if ((servs!=null)&&(!servs.isEmpty())) {
                Servicio serv = servs.get(0);
                Hibernate.initialize(serv.getRepresentantesLegales());
                if (serv.getRepresentantesLegales()!=null) {
                    for (RepresentanteLegal rl: serv.getRepresentantesLegales()) {
                        Hibernate.initialize(rl.getMandatarios());
                    }
                }
//                Hibernate.initialize(serv.getUserCreation());
//                Hibernate.initialize(serv.getUserModified());
                Hibernate.initialize(serv.getContactos());
                Hibernate.initialize(serv.getMandatarios());
//                Hibernate.initialize(serv.getTipoSubsidio());
                Hibernate.initialize(serv.getPasajeros());
//                Hibernate.initialize(serv.getPeriodosVigencia());
                Hibernate.initialize(serv.getOficinasVentaPasajeServicio());
                Hibernate.initialize(serv.getConductoresServicio());
                Hibernate.initialize(serv.getZonasSubsidio());
                return serv;
            }
           return null;
        }catch(Exception e){
            throw new GeneralDataAccessException(e.getMessage(),e);
        }
    }

	public boolean isTieneCertificadosFaltantes(Long idServicio) throws GeneralDataAccessException{
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT COUNT(ID) FROM ")
				.append("( select RS.ID,C.ID AS ID_CERT ")
				.append("from NULLID.RNT_SERVICIO s JOIN NULLID.RNT_VEHICULO_SERVICIO RS ON RS.ID_SERVICIO = S.ID AND RS.ESTADO = 1 ")
				.append("LEFT OUTER JOIN NULLID.RNT_CERTIFICADO C ON  C.ID_VEHICULO_SERVICIO = RS.ID AND C.ESTADO = 1 AND FECHA_HASTA > CURRENT DATE  AND C.ESTADO_FIRMA <> 'certificado migrado' ")
				.append(" WHERE S.ID = "+idServicio+" AND ID_OLD IS NOT NULL) VEHICULOS_NO_CERT WHERE VEHICULOS_NO_CERT.ID_CERT IS NULL ");
			
			Query query = getSession().createSQLQuery(sql.toString());
			Integer bg = (Integer) query.uniqueResult();
			if (bg!=null) {
				return !bg.equals(0);
			}
			return false;
		} catch (Exception e) {
			throw new GeneralDataAccessException(e.getMessage());
		}
	
	}

}
