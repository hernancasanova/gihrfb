package cl.mtt.rnt.commons.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.TarifaDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Sector;
import cl.mtt.rnt.commons.model.core.Tarifa;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.ItemMatrizTarifariaDTO;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.TramoTarifarioCargaMasivaDTO;

public class TarifaDAOImpl extends GenericDAOImpl<Tarifa> implements TarifaDAO {

	Logger log = Logger.getLogger(this.getClass());

	public TarifaDAOImpl(Class<Tarifa> objectType) {
		super(objectType);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void removeItemTramoTarifarioWithoutSectorTramoTarifario(Long idTarifa) throws GeneralDataAccessException {
		try {
			StringBuffer sqlIds = new StringBuffer();
			sqlIds.append("delete from ItemMatrizTarifaria AS IMT where ")
			.append("IMT.tramoTarifario.id ")
			.append("in (select TT.id from TramoTarifario AS TT where TT.tarifa.id = ").append(idTarifa).append(") ")
			.append("and ")
			.append("(")
			.append("not exists (select STT.id from SectorTramoTarifario AS STT where STT.sector.id = IMT.sectorInicial.id and STT.extremo = 0 ) ")
			.append("or ")
			.append("not exists (select STT.id from SectorTramoTarifario AS STT where STT.sector.id = IMT.sectorFinal.id and STT.extremo = 1 )")
			.append(")");

			Query query = getSession().createQuery(sqlIds.toString());
			query.executeUpdate();

		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public void removeDataFromTramoTarifario(Long idTramoTarifario) throws GeneralDataAccessException {
		try {
			String sqlIds = "delete from NULLID.RNT_ITEM_MATRIZ_TARIFARIA IMT where ID_TRAMO_TARIFARIO = "+idTramoTarifario;
			Query query = getSession().createSQLQuery(sqlIds);
			query.executeUpdate();

			String sqlIds2 = "delete from NULLID.RNT_ITEM_TRAMO_TARIFARIO IMT where ID_TRAMO_TARIFARIO = "+idTramoTarifario;
			Query query2 = getSession().createSQLQuery(sqlIds2);
			query2.executeUpdate();

//			String sqlIds3 = "delete from NULLID.RNT_SECTOR_TRAMO_TARIFARIO IMT where ID_TARIFA = "+idTramoTarifario;
//			Query query3 = getSession().createSQLQuery(sqlIds3);
//			query3.executeUpdate();

		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}

	}
	

	public void cleanSectorTramoTarifario(Sector sector) throws GeneralDataAccessException{
		try {
			String sqlIds3 = "delete from NULLID.RNT_SECTOR_TRAMO_TARIFARIO IMT where ID_SECTOR = "+sector.getId();
			Query query3 = getSession().createSQLQuery(sqlIds3);
			query3.executeUpdate();
		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	
	}

	@Override
	public List<TramoTarifarioCargaMasivaDTO> getTramoTarifarioByServicioYNombre(Long idServicio, String nombreTramo) throws GeneralDataAccessException{
		StringBuffer hqlBuffer = new StringBuffer();
		List<TramoTarifarioCargaMasivaDTO> resultset = null;
		hqlBuffer.append("SELECT  S.id,"//0
							   + "S.identServicio,"//1
							   + "T.tipoTarifa,"//2
							   + "TT.id,"//3
							   + "TT.nombre,"//4
							   + "PO.etiqueta,"//5
							   + "TT.tipoIngreso,"//6
							   + "ITT.horaInicial,"//7
							   + "ITT.horaFinal,"//8
							   + "ITT.monto,"//9
							   + "ITT.montoSecundario")//10
				.append(" FROM Servicio S")
				.append(" inner join S.tarifa as T")
				.append(" inner join T.tramosTarifarios as TT")
				.append(" inner join TT.publicoObjetivo as PO")
				.append(" left join TT.itemsTramoTarifario as ITT")
				.append(" WHERE S.id = " + idServicio)		
				.append(" and TT.nombre= '" + nombreTramo+"'");
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			List<Object[]> res =  (List<Object[]>)query.list();			
			if(res!=null && !res.isEmpty()){
				resultset = new ArrayList<TramoTarifarioCargaMasivaDTO>();
				for(Object[] each : res){
					
					TramoTarifarioCargaMasivaDTO t = new TramoTarifarioCargaMasivaDTO((Long)each[0], 
						    (Long)each[1], 
						    each[2].toString(), 
						    (Long)each[3], 
						    each[4].toString(), 
						    each[5].toString(), 
						    each[6].toString(),
						    each[7],
						    each[8],
						    each[9],
						    each[10]);
					resultset.add(t);
				}
			}
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
		return resultset;
	}
	

	private TramoTarifarioCargaMasivaDTO getTramoTarifarioByRecorridoSinNombre(Long idRecorrido) throws GeneralDataAccessException{
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT  R.id idRec,"//0
							   + "T.tipoTarifa,"//1
							  )
				.append(" FROM Recorrido R")
				.append(" inner join R.tarifa as T")
				.append(" WHERE idRec = " + idRecorrido);	
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();			
			if(res!=null){
				TramoTarifarioCargaMasivaDTO t = new TramoTarifarioCargaMasivaDTO();
				t.setIdRecorrido((Long)res[0]);
				t.setTipoTarifa(res[1].toString());
				return t;
			}else{
				return null;
			}
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
	}

	public TramoTarifarioCargaMasivaDTO getTramoTarifarioByRecorridoYNombre(Long idRecorrido, String tramoTarifario) throws GeneralDataAccessException{
		if(tramoTarifario==null || "".equals(tramoTarifario))
			return getTramoTarifarioByRecorridoSinNombre(idRecorrido);

		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT  R.id,"//0
							   + "T.tipoTarifa,"//1
							   + "TT.id,"//2
							   + "TT.nombre,"//3
							   + "TT.publicoObjetivo.etiqueta,"//4
							   + "TT.tipoIngreso,"//5
							   + "TT.horaDesde,"//6
							   + "TT.horaHasta"//7
							  )
				.append(" FROM Recorrido R")
				.append(" inner join R.tarifa as T")
				.append(" inner join T.tramosTarifarios as TT")
				.append(" WHERE R.id = " + idRecorrido)		
				.append(" and TT.nombre= '" + tramoTarifario+"'");
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();			
			if(res!=null){
				TramoTarifarioCargaMasivaDTO t = new TramoTarifarioCargaMasivaDTO();
				t.setIdRecorrido((Long)res[0]);
				t.setTipoTarifa(res[1].toString());
				t.setIdTramo((Long)res[2]);
				t.setNombreTramo(res[3].toString());	
				t.setPublicoObjetivo(res[4].toString());
				t.setTipoIngreso(res[5].toString());		
				t.setHoraDesde(res[6].toString());		
				t.setHoraHasta(res[7].toString());		
				return t;
			} else {
				return getTramoTarifarioByRecorridoSinNombre(idRecorrido);
			}
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
	}

	public ItemMatrizTarifariaDTO getItemMatrizTarifaria(Long idTramo,String tramoInicial, String tramoFinal) throws GeneralDataAccessException{
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT  IMT.id,"//0
							   + "TT.id,"//1
							   + "TT.nombre,"//2
							   + "SEC1.id,"//3
							   + "SEC2.id,"//4
							   + "IMT.monto,"//5
							   + "IMT.montoSecundario"//6
							  )
				.append(" FROM ItemMatrizTarifaria IMT")
				.append(" inner join IMT.tramoTarifario as TT")
				.append(" inner join IMT.sectorInicial as SEC1")
				.append(" inner join IMT.sectorFinal as SEC2")
				.append(" WHERE TT.id = " + idTramo)		
				.append(" and SEC1.nombre= '" + tramoInicial+"'")
				.append(" and SEC2.nombre= '" + tramoFinal+"'");
		
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			Object[] res =  (Object[])query.uniqueResult();			
			if(res!=null){
				ItemMatrizTarifariaDTO t = new ItemMatrizTarifariaDTO();
				t.setIdSectorInicial((Long)res[3]);
				t.setIdSectorFinal((Long)res[4]);
				t.setMonto(Float.valueOf(res[5].toString()));
				t.setMontoSecundario(Float.valueOf(res[6].toString()));
				return t;
			} else {
				return null;
			}
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}
	
	}


}
