/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.mtt.rnt.commons.dao.impl;

import cl.mtt.rnt.commons.dao.TelAutorizacionDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.TelAutorizacion;
import org.apache.log4j.Logger;
import org.hibernate.Query;

/**
 *
 * @author jhenriquez
 */
public class TelAutorizacionDAOImpl extends GenericDAOImpl<TelAutorizacion> implements TelAutorizacionDAO {
    Logger log = Logger.getLogger(this.getClass());

    public TelAutorizacionDAOImpl(Class<TelAutorizacion> objectType) {
        super(objectType);
    }
    
    @Override
    public int getCountResponsablesByAutorizacion(TelAutorizacion telAutorizacion) throws GeneralDataAccessException {
            String sqlQuery = "SELECT COUNT(RA.ID_RESPONSABLE) AS CANT FROM tel.TEL_RESPONSABLE_AUTORIZACION AS RA WHERE ID_AUTORIZACION= " + telAutorizacion.getId() +"";

            Query query = getSession().createSQLQuery(sqlQuery);
            return (Integer) query.uniqueResult();
    }
}
