package cl.mtt.rnt.commons.dao.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.TipoServicioDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Modalidad;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoServicioArea;
import cl.mtt.rnt.commons.model.core.TipoVehiculoServicio;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class TipoServicioDAOImpl extends GenericDAOImpl<TipoServicio> implements TipoServicioDAO {

	public TipoServicioDAOImpl(Class<TipoServicio> objectType) {
		super(objectType);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Long> getTiposServiciosSinTipoCertificado(Long idClaseTipoCertificado) throws GeneralDataAccessException {
		List<Long> resultados = new ArrayList<Long>();

		try {
					
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT tso.id from NULLID.RNT_TIPO_SERVICIO AS TSO where tso.id not in ") 
			.append(" (SELECT DISTINCT TS.id FROM NULLID.RNT_TIPO_SERVICIO AS TS ")  
			.append(" INNER JOIN nullid.RNT_TIPO_CERTIFICADO_REG_TIPO_SERVICIO AS TCTS ON TS.ID = TCTS.ID_TIPO_SERVICIO ")
			.append(" INNER JOIN nullid.RNT_TIPO_CERTIFICADO_REGLAMENTADO TCR on TCR.ID = TCTS.ID_TIPO_CERTIFICADO_REG and TCR.ID_REGLAMENTACION is null ")
			.append(" INNER JOIN NULLID.RNT_TIPO_CERTIFICADO AS TC ON TCR.ID_TIPO_CERTIFICADO=TC.ID  ")
			.append(" INNER JOIN NULLID.RNT_CLASE_TIPO_CERTIFICADO AS CTC ON TC.ID_CLASE_TIPO_CERTIFICADO=CTC.ID ") 
			.append(" WHERE CTC.ID = "+ idClaseTipoCertificado +") ");
			

			Query query = getSession().createSQLQuery(sql.toString());
			List<BigInteger> resultset = query.list();
			for (BigInteger datoPlano : resultset) {
				Long id = (((BigInteger) datoPlano).longValue());
				resultados.add(id);
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
		return resultados;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Long> getTiposServiciosDisponiblesCertificadoReglamentacion(Long idClaseTipoCertificado, Long idReglamentacion) throws GeneralDataAccessException {
		List<Long> resultados = new ArrayList<Long>();

		try {
					
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT tso.id from NULLID.RNT_TIPO_SERVICIO AS TSO where tso.id not in ") 
			.append(" (SELECT DISTINCT TS.id FROM NULLID.RNT_TIPO_SERVICIO AS TS ")  
			.append(" INNER JOIN nullid.RNT_TIPO_CERTIFICADO_REG_TIPO_SERVICIO AS TCTS ON TS.ID = TCTS.ID_TIPO_SERVICIO ")
			.append(" INNER JOIN nullid.RNT_TIPO_CERTIFICADO_REGLAMENTADO TCR on TCR.ID = TCTS.ID_TIPO_CERTIFICADO_REG  and TCR.ID_REGLAMENTACION = " + idReglamentacion.toString())
			.append(" INNER JOIN NULLID.RNT_TIPO_CERTIFICADO AS TC ON TCR.ID_TIPO_CERTIFICADO=TC.ID  ")
			.append(" INNER JOIN NULLID.RNT_CLASE_TIPO_CERTIFICADO AS CTC ON TC.ID_CLASE_TIPO_CERTIFICADO=CTC.ID ") 
			.append(" WHERE CTC.ID = "+ idClaseTipoCertificado +") ");
			

			Query query = getSession().createSQLQuery(sql.toString());
			List<BigInteger> resultset = query.list();
			for (BigInteger datoPlano : resultset) {
				Long id = (((BigInteger) datoPlano).longValue());
				resultados.add(id);
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
		return resultados;
	}

    @SuppressWarnings("unchecked")
    @Override
    public List<TipoServicioArea> getTiposServicioArea(CategoriaTransporteSeleccionble categoria) throws GeneralDataAccessException {
        try {
            String hql = "    SELECT distinct TSA "
                    + "       FROM TipoServicio AS TS"
                    + "       inner join TS.tipoServicioArea AS TSA" 
                    + "       WHERE       TS.tipoTransporte.id = " + categoria.getTipoTransporte().getId() + " "
                    + "       AND   TS.medioTransporte.id = " + categoria.getMedio().getId() + " "
                    + "       AND   TS.categoriaTransporte.id = " + categoria.getCategoria().getId() + " ";

            Query query = getSession().createQuery(hql);
            return query.list();
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<Modalidad> getModalidades(CategoriaTransporteSeleccionble categoria) throws GeneralDataAccessException {
        try {
            String hql = "    SELECT distinct MO "
                    + "       FROM TipoServicio AS TS"
                    + "       inner join TS.modalidad AS MO" 
                    + "       WHERE       TS.tipoTransporte.id = " + categoria.getTipoTransporte().getId() + " "
                    + "       AND   TS.medioTransporte.id = " + categoria.getMedio().getId() + " "
                    + "       AND   TS.categoriaTransporte.id = " + categoria.getCategoria().getId() + " ";

            Query query = getSession().createQuery(hql);
            return query.list();
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<TipoVehiculoServicio> getTiposVehiculoServicio(CategoriaTransporteSeleccionble categoria) throws GeneralDataAccessException {
        try {
            String hql = "    SELECT distinct TV "
                    + "       FROM TipoServicio AS TS"
                    + "       inner join TS.tipoVehiculoServicio AS TV" 
                    + "       WHERE       TS.tipoTransporte.id = " + categoria.getTipoTransporte().getId() + " "
                    + "       AND   TS.medioTransporte.id = " + categoria.getMedio().getId() + " "
                    + "       AND   TS.categoriaTransporte.id = " + categoria.getCategoria().getId() + " ";

            Query query = getSession().createQuery(hql);
            return query.list();
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<TipoServicio> getAllTiposServicio() throws GeneralDataAccessException {
        try {
            String hql = "    SELECT TS "
                    + "       FROM TipoServicio AS TS "
                    + "       inner join fetch TS.tipoTransporte AS TT "
                    + "       inner join fetch TS.medioTransporte AS MT "
                    + "       inner join fetch TS.categoriaTransporte AS CT "
                    + "       inner join fetch TS.tipoServicioArea AS TSA "
                    + "       inner join fetch TS.modalidad AS MO "
                    + "       inner join fetch TS.tipoVehiculoServicio AS TV "
                    + "       left outer join fetch TS.glosaAuxiliar AS GA "
                    + "       left outer join fetch TS.tiposCancelacion AS TSTC ";

            Query query = getSession().createQuery(hql);
            return query.list();
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
    
}
