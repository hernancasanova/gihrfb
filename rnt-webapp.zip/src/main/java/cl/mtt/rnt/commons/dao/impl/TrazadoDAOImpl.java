package cl.mtt.rnt.commons.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.TrazadoDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.recorrido.Trazado;

public class TrazadoDAOImpl extends GenericDAOImpl<Trazado> implements TrazadoDAO {

	Logger log = Logger.getLogger(this.getClass());

	public TrazadoDAOImpl(Class<Trazado> objectType) {
		super(objectType);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Long getIdTrazadoByRecorridoYNombre(Long idRecorrido,String nombreTrazado) throws GeneralDataAccessException{
		StringBuffer hqlBuffer = new StringBuffer();
		hqlBuffer.append("SELECT T.id")
		.append(" FROM Trazado T")
		.append(" WHERE T.recorrido.id = " + idRecorrido)		
		.append(" and T.nombre = '"+nombreTrazado+"'");
		
		try{
			Query query = getSession().createQuery(hqlBuffer.toString());
			return (Long)query.uniqueResult();
		}catch(Exception e){
			throw new GeneralDataAccessException(e.getMessage(),e);
		}

	}

}
