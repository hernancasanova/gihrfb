package cl.mtt.rnt.commons.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;

import cl.mtt.rnt.commons.dao.UsuarioDao;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.userrol.UserContext;
import cl.mtt.rnt.commons.model.userrol.UserContextRegion;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class UsuarioDaoImpl extends GenericDAOImpl<User> implements UsuarioDao {

	public UsuarioDaoImpl(Class<User> objectType) {
		super(objectType);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<User> getUsuariosByRegionyCategoriaTransporte(String codRegion,CategoriaTransporteSeleccionble cts) throws GeneralDataAccessException {
		List<User> resultados = new ArrayList<User>();
		try {
			String hql = "	  SELECT distinct U " + "			FROM User AS U" +  " "
					+ " inner join U.context UC  "
					+ " inner join UC.categorias CAT "
					+ " inner join UC.mediosTransporte MT "
					+ " inner join UC.tiposTransporte TT "
					+ " where U.context.id in ( select UCR.context.id from UserContextRegion as UCR "
					+ "							where UCR.codRegion = '"+codRegion+"')"
					+ "  and CAT.id = " + cts.getCategoria().getId()
					+ "  and MT.id = " + cts.getMedio().getId()
					+ "  and TT.id = " + cts.getTipoTransporte().getId();

			Query query = getSession().createQuery(hql);
			resultados = (List<User>) query.list();

		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}

		return resultados;
	}

	@Override
	public List<User> getUsuariosAplicaNacionyCategoriaTransporte(boolean aplicaNacion,
			CategoriaTransporteSeleccionble cts)throws GeneralDataAccessException {
		List<User> resultados = new ArrayList<User>();
		try {
			String hql = "	  SELECT distinct U " + "			FROM User AS U" +  " "
					+ " inner join U.context UC  "
					+ " inner join UC.categorias CAT "
					+ " inner join UC.mediosTransporte MT "
					+ " inner join UC.tiposTransporte TT "
					+ " where U.aplicaNacion =  "+aplicaNacion
					+ "  and CAT.id = " + cts.getCategoria().getId()
					+ "  and MT.id = " + cts.getMedio().getId()
					+ "  and TT.id = " + cts.getTipoTransporte().getId();

			Query query = getSession().createQuery(hql);
			resultados = (List<User>) query.list();

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	@Override
	public List<User> getUsuariosByCategoriaTransporte(CategoriaTransporteSeleccionble cts)throws GeneralDataAccessException {
		List<User> resultados = new ArrayList<User>();
		try {
			String hql = "	  SELECT distinct U " + "			FROM User AS U" +  " "
					+ " inner join U.context UC  "
					+ " inner join UC.categorias CAT "
					+ " inner join UC.mediosTransporte MT "
					+ " inner join UC.tiposTransporte TT "
					+ " where CAT.id = " + cts.getCategoria().getId()
					+ "  and MT.id = " + cts.getMedio().getId()
					+ "  and TT.id = " + cts.getTipoTransporte().getId();

			Query query = getSession().createQuery(hql);
			resultados = (List<User>) query.list();

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}


	public void updateUserContextRegiones(UserContext userContext, List<Region> regiones) throws GeneralDataAccessException{
	    if (regiones == null) { 
	        return;
	    }
		try {
			String ids="";
			for (Region region : regiones) {
				ids += "'"+region.getCodigo()+"',";
			}
			ids=ids.substring(0, ids.lastIndexOf(","));
			String hql = "delete UserContextRegion where context.id = :idContext and codRegion not in ("+ids+")";
			Query query = getSession().createQuery(hql);
			query.setParameter("idContext", userContext.getId());
			int result = query.executeUpdate();
			
			for (Region region : regiones) {

				String hql2 = "select U from UserContextRegion as U where U.context.id = :idContext and U.codRegion = :codReg";
				Query query2 = getSession().createQuery(hql2);
				query2.setParameter("idContext", userContext.getId());
				query2.setParameter("codReg", region.getCodigo());
				List<UserContextRegion> resultList = query2.list();
				if (resultList.isEmpty()){
					String sql = "insert into nullid.RNT_USER_CONTEXT_REGION (USER_CONTEXT_ID,COD_REGION) values ("+userContext.getId()+",'"+region.getCodigo()+"') ";
					SQLQuery sqlquery = getSession().createSQLQuery(sql);
					int res = sqlquery.executeUpdate();
				}
			}
			
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
		
	}
	
}
