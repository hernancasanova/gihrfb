package cl.mtt.rnt.commons.dao.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import cl.mtt.rnt.commons.dao.VehiculoDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.PeriodoVigencia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoRegistroCivil;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.encargado.dto.ServicioDTO;
import cl.mtt.rnt.encargado.dto.VehiculoServicioDTO;

import com.google.common.base.Joiner;

@SuppressWarnings({"unchecked","rawtypes"})
public class VehiculoDAOImpl extends GenericDAOImpl<Vehiculo> implements VehiculoDAO {

	Logger log = Logger.getLogger(this.getClass());
	
	@Autowired
	@Qualifier("reglamentacionManager")
	ReglamentacionManager reglamentacionManager;

	public VehiculoDAOImpl(Class<Vehiculo> objectType) {
		super(objectType);
	}

	
	public List<ServicioDTO> getServiciosResponsable(Long id) throws GeneralDataAccessException {
		List<ServicioDTO> resultados = new ArrayList<ServicioDTO>();
		try {
			String hql = "	  SELECT  S.id " + "			,S.identServicio" + "			,TT.nombre as tipotransporte" + "			,MT.nombre as medio" + "			,CT.nombre as categoria" + "			,TSA.nombre as tiposervarea"
					+ "			,M.nombre  as modalidad" + " 			,RS.codigoComuna as codigoComuna " + " 			,RS.codigoRegion as codigoRegion " + "			FROM Servicio AS S"
					+ "			inner join S.tipoServicio AS TS " + "			inner join TS.tipoTransporte as TT " + "			inner join TS.medioTransporte as MT " + "			inner join TS.categoriaTransporte AS CT"
					+ "			inner join TS.tipoServicioArea AS TSA" + "			inner join TS.modalidad AS M" + "			inner join S.responsable AS RS " + "   WHERE" + "		RS.id = '" + id.toString() + "'";

			Query query = getSession().createQuery(hql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				ServicioDTO sdao = new ServicioDTO();
				sdao.setId((Long) dato[0]);
				sdao.setIdentServicio((Long) dato[1]);
				sdao.setTipoTransporte((String) dato[2]);
				sdao.setMedioTransporte((String) dato[3]);
				sdao.setCategoriaTransporte((String) dato[4]);
				sdao.setTipoServicioArea((String) dato[5]);
				sdao.setModalidad((String) dato[6]);
				sdao.setCodigoComuna((String) dato[7]);
				sdao.setCodigoRegion((String) dato[8]);
				resultados.add(sdao);

			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	public List<ServicioDTO> getServiciosByRutCategoria(String rut, CategoriaTransporte categoria, User user) throws GeneralDataAccessException {
		List<ServicioDTO> resultados = new ArrayList<ServicioDTO>();
		try {
			String hql = "	  SELECT  S.id " + "			,S.identServicio" + "			,TT.nombre as tipotransporte" + "			,MT.nombre as medio" + "			,CT.nombre as categoria" + "			,TSA.nombre as tiposervarea"
					+ "			,M.nombre  as modalidad" + "			,S.activo as activo" + "			,'Responsable de Servicio' as tipoRelacionServicio" + "			,S.codigoRegion as codigoRegion"
					+ "			,S.creation as fechaInscripcion" + "			,S.vigenciaDesde as vigenciaDesde" + "			,S.vigenciaHasta as vigenciaHasta" + "			,RS.domicilio as domicilio"
					+ "			,RS.telefono as telefono" + "			,RS.fax as fax" + "			,RS.email as email" + " 			,RS.codigoComuna as codigoComuna " + "			FROM Servicio AS S"
					+ "			inner join S.tipoServicio AS TS " + "			inner join TS.tipoTransporte as TT " + "			inner join TS.medioTransporte as MT " + "			inner join TS.categoriaTransporte AS CT"
					+ "			inner join TS.tipoServicioArea AS TSA" + "			inner join TS.modalidad AS M" + "			inner join S.responsable AS RS " + "   WHERE" + "		RS.persona.rut = '" + rut + "'"
					+ "		and CT.id = " + categoria.getId() + "		and CT.id in (" + Joiner.on(",").join(user.getContext().getAllIdsCategoriasTransporte()) + ")" + "		and MT.id in ("
					+ Joiner.on(",").join(user.getContext().getAllIdsMediosTransporte()) + ")" + "		and TT.id in (" + Joiner.on(",").join(user.getContext().getAllIdsTiposTransportes()) + ")"
					+ "		and S.codigoRegion in (" + Joiner.on(",").join(user.getContext().getAllCodigosRegiones()) + ")";

			Query query = getSession().createQuery(hql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				ServicioDTO sdao = new ServicioDTO();
				sdao.setId((Long) dato[0]);
				sdao.setIdentServicio((Long) dato[1]);
				sdao.setTipoTransporte((String) dato[2]);
				sdao.setMedioTransporte((String) dato[3]);
				sdao.setCategoriaTransporte((String) dato[4]);
				sdao.setTipoServicioArea((String) dato[5]);
				sdao.setModalidad((String) dato[6]);
				sdao.setActivo((Boolean) dato[7]);
				sdao.setTipoRelacionServicio((String) dato[8]);
				sdao.setCodigoRegion((String) dato[9]);
				sdao.setFechaInscripcion((Date) dato[10]);
				sdao.setVigenciaDesde((Date) dato[11]);
				sdao.setVigenciaHasta((Date) dato[12]);
				sdao.setDomicilio((String) dato[13]);
				sdao.setTelefono((String) dato[14]);
				sdao.setFax((String) dato[15]);
				sdao.setEmail((String) dato[16]);
				sdao.setCodigoComuna((String) dato[17]);
				resultados.add(sdao);
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return resultados;
	}

	public Integer getCantidadPendientesMigracion() throws GeneralDataAccessException {
		try {
			String sql = "select count(ppu) from NULLID.RNT_VEHICULO where  ANIO_FABRICACION is null ";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Integer dato = (Integer) datoPlano;
				return dato;
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

	@Override
	public List<String> getNextMigraPPU(Integer cantidadEjecutar) throws GeneralDataAccessException {
		List<String> ppus = new ArrayList<String>();
		try {
			String sql = "select ppu from NULLID.RNT_VEHICULO where ANIO_FABRICACION is null fetch first " + cantidadEjecutar + " rows only ";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				String dato = (String) datoPlano;
				ppus.add(dato);
			}
			return ppus;
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

	}

	@Override
	public User getUsuarioMigracion() throws GeneralDataAccessException {
		try {
			String sql = "select ID from NULLID.RNT_USER where NOMBRE_USUARIO = 'adminmtt'";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				BigInteger dato = (BigInteger) datoPlano;
				if (dato != null) {
					User user = new User();
					user.setId(Long.parseLong(dato.toString()));
					user.setNombreUsuario("adminmtt");
					return user;
				}
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

	@Override
	public List<String> getNextMigraPPUEspecifica(String ppu) throws GeneralDataAccessException {
		List<String> ppus = new ArrayList<String>();
		try {
			String sql = "select ppu from NULLID.RNT_VEHICULO where ANIO_FABRICACION is null and PPU = '" + ppu + "'";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				String dato = (String) datoPlano;
				ppus.add(dato);
			}
			return ppus;
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	@Override
	public List<String> getNextMigraPPUServ(String identServ) throws GeneralDataAccessException {
		List<String> ppus = new ArrayList<String>();
		try {
			String sql = " select ppu from NULLID.RNT_VEHICULO join nullid.RNT_VEHICULO_SERVICIO on nullid.RNT_VEHICULO_SERVICIO.ID_VEHICULO = NULLID.RNT_VEHICULO.ID "
					+ " JOIN nullid.RNT_SERVICIO on NULLID.RNT_SERVICIO.ID = nullid.RNT_VEHICULO_SERVICIO.ID_SERVICIO "
					+ " where "
					+ "  NULLID.RNT_VEHICULO.ANIO_FABRICACION is null and NULLID.RNT_SERVICIO.IDENT_SERVICIO = " + identServ + " ";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				String dato = (String) datoPlano;
				ppus.add(dato);
			}
			return ppus;
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	public Integer getCantCertificadosAnteriores(Long idVehiculoServicio, Date fechaUltimoCert) throws GeneralDataAccessException {
		try {
			String sql = "SELECT COUNT(DISTINCT VARCHAR_FORMAT(NULLID.RNT_CERTIFICADO.CREATION, 'YYYY/MM/DD HH:MI')) CANTIDAD, MAX(FECHA_HASTA) FECHA_MAX_PROVISORIO from NULLID.RNT_CERTIFICADO "
					+ " join NULLID.RNT_TIPO_CERTIFICADO on NULLID.RNT_CERTIFICADO.ID_TIPO_CERTIFICADO = NULLID.RNT_TIPO_CERTIFICADO.ID"
					+ " JOIN NULLID.RNT_CLASE_TIPO_CERTIFICADO on NULLID.RNT_TIPO_CERTIFICADO.ID_CLASE_TIPO_CERTIFICADO = NULLID.RNT_CLASE_TIPO_CERTIFICADO.ID"
					+ " 	WHERE movimiento = 'inscripcion' AND ID_VEHICULO_SERVICIO = " + idVehiculoServicio;
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Integer dato = (Integer) ((Object[]) datoPlano)[0];
				Date f = (Date) ((Object[]) datoPlano)[1];
				if (f != null)
					fechaUltimoCert.setTime(f.getTime());
				return dato;
			}
		}
		catch (NumberFormatException nfe) {
			return 0;
		}
		catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

	public Date getFechaInicioUltimaVigencia(Long idVehiculoServicio) throws GeneralDataAccessException {
		try {
			String sql = "select MAX(FECHA_ESTADO) from NULLID.RNT_VEHICULO_SERVICIO_AUD where ESTADO = 1 " + "and ID = " + idVehiculoServicio;
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Date dato = (Date) datoPlano;
				return dato;
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

	@Override
	public void loadVehiculosPaginados(Servicio servicio, int pagina, Integer cantidadRegistros, String orderBy) throws GeneralDataAccessException {

		Integer rdesde = (pagina - 1) * cantidadRegistros;
		Integer rhasta = ((pagina - 1) * cantidadRegistros) + cantidadRegistros;

		try {

			if (rhasta > servicio.getVehiculosSkeleton().size()) {
				rhasta = servicio.getVehiculosSkeleton().size();
			}
			List<VehiculoServicioDTO> subList = servicio.getVehiculosSkeleton().subList(rdesde, rhasta);

			List<Long> ids = new ArrayList<Long>();
			for (VehiculoServicioDTO vsdto : subList) {
				if ((vsdto.getId() != null) && (vsdto.getVs() == null)) {
					ids.add(vsdto.getId());
				}
			}
			if (ids.size() > 0) {
				Query query = getSession().createQuery("FROM VehiculoServicio item WHERE item.id IN (:ids) order by item.estado");
				query.setParameterList("ids", ids);
				List<VehiculoServicio> items = (List<VehiculoServicio>) query.list();
				if (items != null) {
					for (VehiculoServicio vehiculoServicio : items) {
						for (VehiculoServicioDTO vsDto : servicio.getVehiculosSkeleton()) {
							if (vsDto.getId().longValue() == vehiculoServicio.getId().longValue()) {
								Hibernate.initialize(vehiculoServicio.getUserCreation());
								Hibernate.initialize(vehiculoServicio.getUserModified());
								vsDto.setVs(vehiculoServicio);
							}
						}
					}
				}
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	@Override
	public Integer getCantidadVehiulosServicio(Servicio servicio) throws GeneralDataAccessException {
		try {
			String sqlIds = "select COUNT(vehiculos.id)  from  " + " nullid.RNT_VEHICULO_SERVICIO vs  where vs.ID_SERVICIO=" + servicio.getId();

			Query query = getSession().createSQLQuery(sqlIds);
			return (Integer) query.uniqueResult();
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	@Override
	public LinkedList<VehiculoServicioDTO> getVehiculosSkeleton(Servicio servicio, String currentOrder) throws GeneralDataAccessException {
		try {
			String joinsNeeded = "";
			String selectNeeded = "";
			if (currentOrder.startsWith("vr")) {
				joinsNeeded += " left outer join nullid.RNT_VEHICULO vr on vr.ID = vs.ID_VEHICULO_REEMPLAZA ";
			}

			if (currentOrder.startsWith("vr2")) {
				joinsNeeded += " left outer join nullid.RNT_VEHICULO vr2 on vr2.ID = vs.ID_VEHICULO_REEMPLAZADO ";
			}

			if (currentOrder.startsWith("CAST")) {
				selectNeeded = " ,CAST( SUBSTR(RPE.RUT,1,length(rpe.RUT)-2) as BIGINT) ";
				joinsNeeded += " join nullid.RNT_ADQUISICION ra on v.ID_ADQUISICION = ra.id and ra.PROPIETARIO_ACTUAL = 1 "
						+ " join (select min(ID_PERSONA) ID_PERSONA,ID_ADQUISICION from nullid.RNT_PROPIETARIO group by ID_ADQUISICION) rp on rp.ID_ADQUISICION = ra.ID "
						+ " join nullid.RNT_PERSONA rpe on rpe.ID = rp.ID_PERSONA ";
			}

			String sqlIds = "select vs.ID,vs.ESTADO,vs.ID_TIPO_CANCELACION,v.PPU,vs.ID_REGLAMENTACION, v.ANIO_FABRICACION, v.id as idVehiculo " + selectNeeded + " from " + " nullid.RNT_VEHICULO_SERVICIO vs "
					+ " join nullid.RNT_VEHICULO v on vs.ID_VEHICULO = v.ID " 
			        + joinsNeeded + " where vs.ID_SERVICIO=" + servicio.getId() + 
			        " and (vs.ESTADO = 1 OR vs.ID in ( "
			        + " SELECT VS2.ID from  nullid.RNT_VEHICULO_SERVICIO_AUD VS2 "
                    +  "    join ( "
                    +  "   select vx.ID, (select max(rev) from  nullid.RNT_VEHICULO_SERVICIO_AUD aux where ID_VEHICULO = vx.ID) REVISION from nullid.RNT_VEHICULO vx join "
                    +  "   nullid.RNT_VEHICULO_SERVICIO vsx on vx.ID = vsx.ID_VEHICULO and vsx.ID_SERVICIO = "+ servicio.getId() +" ) ULTIMOS on ULTIMOS.ID = VS2.ID_VEHICULO and ULTIMOS.REVISION = VS2.REV  " 
                    + " )) "
			        + " order by " + currentOrder + ", vs.id desc ";

			Query query = getSession().createSQLQuery(sqlIds);
			List<Object[]> resultset = (List<Object[]>) query.list();

			if (resultset != null) {
				LinkedList<VehiculoServicioDTO> ids = new LinkedList<VehiculoServicioDTO>();
				for (Object[] dato : resultset) {
					VehiculoServicioDTO vsDto = new VehiculoServicioDTO();
					vsDto.setId(new Long((String.valueOf(dato[0]))).longValue());
					vsDto.setEstado((Integer) dato[1]);
					if (dato[2] != null)
						vsDto.setTipoCancelacionId(new Long((String.valueOf(dato[2]))).longValue());
					vsDto.setPpu((String) dato[3]);
					if (dato[4] != null)
						vsDto.setIdReglamentacion(new Long((String.valueOf(dato[4]))).longValue());
					if(dato[5] != null){
						vsDto.setAnioFabricacion((Integer)dato[5]);
					}
					if(dato[6] != null){
						vsDto.setIdVehiculo(new Long((String.valueOf(dato[6]))).longValue());
					}
					vsDto.setIsnew(false);
					ids.add(vsDto);
				}
				return ids;
			}

			return new LinkedList<VehiculoServicioDTO>();
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

	}

	
	@Override
	public void loadVehiculosPaginados(List<VehiculoServicioDTO> vehiculosFiltrados, int pagina, int cantPorPagina, String order) throws GeneralDataAccessException {
		Integer rdesde = (pagina - 1) * cantPorPagina;
		Integer rhasta = ((pagina - 1) * cantPorPagina) + cantPorPagina;

		try {

			if (rhasta > vehiculosFiltrados.size()) {
				rhasta = vehiculosFiltrados.size();
			}
			List<VehiculoServicioDTO> subList = vehiculosFiltrados.subList(rdesde, rhasta);

			List<Long> ids = new ArrayList<Long>();
			for (VehiculoServicioDTO vsdto : subList) {
				if ((vsdto.getId() != null) && (!vsdto.isHavingAllData())) {
					ids.add(vsdto.getId());
				}
			}
			if (ids.size() > 0) {
//				obtengo periodos de vigencia
				Query queryPV = getSession().createQuery(
						"select item FROM PeriodoVigencia item  " + 
						        "	inner join fetch item.vehiculoServicio vs " + 
								"   WHERE vs.id IN (:ids) ");
				queryPV.setParameterList("ids", ids);
				List<PeriodoVigencia> itemsPV = (List<PeriodoVigencia>) queryPV.list();
				Map<Long,List<PeriodoVigencia>> periodoVigenciaMap = new HashMap<Long, List<PeriodoVigencia>>();
				for (PeriodoVigencia periodoVigencia : itemsPV) {
					Long idVS=periodoVigencia.getVehiculoServicio().getId();
					if(!periodoVigenciaMap.containsKey(idVS)){
						periodoVigenciaMap.put(idVS, new ArrayList<PeriodoVigencia>());
					}
					periodoVigenciaMap.get(idVS).add(periodoVigencia);
				}
				
				Query query = getSession().createQuery(
						"select item FROM VehiculoServicio item  " + 
						        "	left outer join fetch item.userCreation cr " + 
						        "	left outer join fetch item.userModified mod "	+ 
						        "   left outer join fetch item.vehiculo veh " +
						        "   left outer join fetch veh.adquisicion adq" +
						        "   left outer join fetch adq.propietarios prop " +
						        "   left outer join fetch prop.persona pers" +
						        "   left outer join fetch veh.revisionTecnica rt " +
						        "   left outer join fetch item.tipoIngreso ti " +
						        "   left outer join fetch item.zonaVehiculo zv" +
								"   WHERE item.id IN (:ids) ");
				query.setParameterList("ids", ids);
				List<VehiculoServicio> items = (List<VehiculoServicio>) query.list();
				if (items != null) {
					for (VehiculoServicio vehiculoServicio : items) {
						for (VehiculoServicioDTO vsDto : vehiculosFiltrados) {
							if (vsDto.getId() != null) {// no cuento los nuevos como posibles
								vehiculoServicio.setPeriodosVigencia(periodoVigenciaMap.get(vsDto.getId()));
								vehiculoServicio.setReglamentacion(reglamentacionManager.getReglamentacionById(vehiculoServicio.getIdReglamentacion()));
								if (vsDto.getId().longValue() == vehiculoServicio.getId().longValue()) {
									vsDto.setVs(vehiculoServicio);
								}
							}
						}
					}
				}
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

	}
	// Mejoras 201409 Nro: 69
	
	private List<PeriodoVigencia> getPeriodosVigencia(Long id) {
        Query query = getSession().createQuery(
                "select item FROM PeriodoVigencia item  " + 
                        "   WHERE item.vehiculoServicio = :id ");
        query.setLong("id", id);
        List<PeriodoVigencia> items = (List<PeriodoVigencia>) query.list();
		return items;
	}


	@Override
	public List<VehiculoServicio> loadVehiculosIndexados(List<Long> ids) throws GeneralDataAccessException {
        try {
            if (ids.size() > 0) {
                Query query = getSession().createQuery(
                        "select item FROM VehiculoServicio item  " + 
                                "   left outer join fetch item.userCreation cr " + 
                                "   left outer join fetch item.userModified mod "   + 
                                "   left outer join fetch item.vehiculo veh " +
                                "   left outer join fetch veh.adquisicion adq" +
                                "   left outer join fetch adq.propietarios prop " +
                                "   left outer join fetch prop.persona pers" +
                                "   left outer join fetch veh.revisionTecnica rt " +
                                "   left outer join fetch item.tipoIngreso ti " +
                                "   left outer join fetch item.zonaVehiculo zv" +
                                "   WHERE item.id IN (:ids) ");
                query.setParameterList("ids", ids);
                List<VehiculoServicio> items = (List<VehiculoServicio>) query.list();
                if (items != null) {
                    for (VehiculoServicio vehiculoServicio : items) {
                       vehiculoServicio.setReglamentacion(reglamentacionManager.getReglamentacionById(vehiculoServicio.getIdReglamentacion()));
                    }
                }
                return items;
            }

        } catch (Exception e) {
            log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
        return new ArrayList<VehiculoServicio>(0);
	        
	}
	
	
	
	
	@Override
	public void getNotInVehiculosPaginados(List<VehiculoServicio> vehiculosS , Long idServicio) throws GeneralDataAccessException {
		try {
			List<Long> ids = new ArrayList<Long>();
			for (VehiculoServicio vs : vehiculosS) {
					ids.add(vs.getId());
			}
			if (ids.size() > 0) {
				Query query = getSession().createQuery(
						"FROM VehiculoServicio item   WHERE item.id NOT IN (:ids) and item.servicio.id ="+idServicio+" and ((item.estado = 1 AND item.fechaCambioEstado <= current_timestamp()) OR (item.estado =2 AND item.fechaCambioEstado > current_timestamp()) OR (item.estado =3 AND item.fechaCambioEstado > current_timestamp())) ");
				query.setParameterList("ids", ids);
				List<VehiculoServicio> items = (List<VehiculoServicio>) query.list();
				if (items != null) {
					for(VehiculoServicio vs : items){
					 VehiculoServicio v = new VehiculoServicio();
					 v.setId(vs.getId());
					 v.setServicio(new Servicio());
					 v.getServicio().setId(v.getServicio().getId());
					 v.setVehiculo(new Vehiculo());
					 v.getVehiculo().setId(vs.getVehiculo().getId());
					 v.getVehiculo().setAnioFabricacion(vs.getVehiculo().getAnioFabricacion());
					 vehiculosS.add(v);
					}
				}
			}

		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}
	// Mejoras 201409 Nro: 69

	public boolean getTieneCancelacionByCategoria(Vehiculo vehiculo, TipoServicio tipoServicio) throws GeneralDataAccessException {
		String sqlQuery = "select count(V.ID) from nullid.RNT_VEHICULO V " + "join nullid.RNT_VEHICULO_SERVICIO VS on V.ID = VS.ID_VEHICULO " + "join nullid.RNT_SERVICIO S on VS.ID_SERVICIO = S.ID "
				+ "join nullid.RNT_TIPO_SERVICIO TS on TS.ID = S.ID_TIPO_SERVICIO  " + "join nullid.RNT_TIPO_CANCELACION TC on TC.ID = VS.ID_TIPO_CANCELACION " + "where V.ID = " + vehiculo.getId()
				+ " " + "and TS.ID_TIPO_TRANSPORTE = " + tipoServicio.getTipoTransporte().getId() + " " + "and TS.ID_MEDIO_TRANSPORTE = " + tipoServicio.getMedioTransporte().getId() + " "
				+ "and TS.ID_CATEGORIA_TRANSPORTE = " + tipoServicio.getCategoriaTransporte().getId() + " " + "and VS.ESTADO in (2,3) " + "and TC.TIPO = 'definitiva'";
		Query query = getSession().createSQLQuery(sqlQuery);
		return ((Integer) query.uniqueResult()) > 0;
	}

	public List<VehiculoServicio> getVehiculosServicioByReglamentacion(Long idReglamentacion) throws GeneralDataAccessException {
		return null;
	}


    @Override
    public VehiculoRegistroCivil getVehiculoRegistroCivil(String ppuIngresado) throws GeneralDataAccessException {
        try {
            Query query = getSession().createQuery("select vRC FROM VehiculoRegistroCivil vRC  " + "   WHERE vRC.ppu = '" + ppuIngresado + "' ");

            VehiculoRegistroCivil item = (VehiculoRegistroCivil) query.uniqueResult();
            return item;

        }
        catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
        }
    }


    @Override
    public boolean getVehiculoExistenteCategoria(Vehiculo vehiculo, TipoServicio tipoServicio) {
        String sqlQuery = "select count(V.ID) from nullid.RNT_VEHICULO V " + "join nullid.RNT_VEHICULO_SERVICIO VS on V.ID = VS.ID_VEHICULO " 
                + "join nullid.RNT_SERVICIO S on VS.ID_SERVICIO = S.ID "
                + "join nullid.RNT_TIPO_SERVICIO TS on TS.ID = S.ID_TIPO_SERVICIO  " 
                + "where V.ID = " + vehiculo.getId()
                + " " + "and TS.ID_TIPO_TRANSPORTE = " + tipoServicio.getTipoTransporte().getId() + " " + "and TS.ID_MEDIO_TRANSPORTE = " + tipoServicio.getMedioTransporte().getId() + " "
                + "and TS.ID_CATEGORIA_TRANSPORTE = " + tipoServicio.getCategoriaTransporte().getId() + " ";
        Query query = getSession().createSQLQuery(sqlQuery);
        return ((Integer) query.uniqueResult()) > 0;
    }
    
    
    
    @Override
    public boolean getVehiculoExistente(Vehiculo vehiculo) {
        String sqlQuery = "select count(V.ID) from nullid.RNT_VEHICULO V " 
                + "join nullid.RNT_VEHICULO_SERVICIO VS on V.ID = VS.ID_VEHICULO " 
                + "where V.ID = " + vehiculo.getId();
        
        Query query = getSession().createSQLQuery(sqlQuery);
        return ((Integer) query.uniqueResult()) > 0;
    }
    
    
    @Override
    public boolean getVehiculoExistenteOtraCategoria(Vehiculo vehiculo, TipoServicio tipoServicio) {
        String sqlQuery = "select count(V.ID) from nullid.RNT_VEHICULO V " + "join nullid.RNT_VEHICULO_SERVICIO VS on V.ID = VS.ID_VEHICULO " 
                + "join nullid.RNT_SERVICIO S on VS.ID_SERVICIO = S.ID "
                + "join nullid.RNT_TIPO_SERVICIO TS on TS.ID = S.ID_TIPO_SERVICIO  " 
                + "where V.ID = " + vehiculo.getId()
                + " and TS.ID_CATEGORIA_TRANSPORTE <> " + tipoServicio.getCategoriaTransporte().getId() + " ";
        Query query = getSession().createSQLQuery(sqlQuery);
        return ((Integer) query.uniqueResult()) > 0;
    }

    public List<VehiculoServicio> getUltimoVehiculoServicioByVehiculo(Long idVehiculo) throws GeneralDataAccessException{
        String sqlQuery = "select UNIQUE VS.id from nullid.RNT_VEHICULO_SERVICIO_TOP_VIEW VST "+ 
        				"join nullid.RNT_VEHICULO_SERVICIO VS on VST.ID = VS.ID "+
        				"where VST.ID_VEHICULO = "+idVehiculo+" ";
        Query query = getSession().createSQLQuery(sqlQuery);
        List<BigInteger> ids = query.list();
        if(ids==null || ids.isEmpty()){
        	return null;
        }
        List<Long> idsLong = new ArrayList<Long>();
        for (BigInteger id : ids) {
			idsLong.add(new Long(id.longValue()));
		}
        Query hqlQuery = getSession().createQuery("FROM VehiculoServicio vs "
                + "inner join fetch vs.servicio s "
                + "inner join fetch s.tipoServicio ts " 
        		+ "WHERE vs.id in (:ids)");
        hqlQuery.setParameterList("ids", idsLong);
		List<VehiculoServicio> items = (List<VehiculoServicio>) hqlQuery.list();
		
        return items;
  	
    }
  

}
