package cl.mtt.rnt.commons.dao.impl;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessResourceFailureException;

import cl.mtt.rnt.commons.dao.VehiculoServicioDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Adquisicion;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.LimitacionVehiculo;
import cl.mtt.rnt.commons.model.core.Persona;
import cl.mtt.rnt.commons.model.core.Propietario;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.view.IDRevision;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.StackTraceUtil;
import cl.mtt.rnt.commons.util.Utils;
import cl.mtt.rnt.encargado.bean.controller.util.VehiculoReemplazable;
import cl.mtt.rnt.encargado.dto.VehiculoServicioHistoricoDTO;
import cl.mtt.rnt.reports.services.ConnectionManager;

import com.google.common.base.Joiner;

public class VehiculoServicioDAOImpl extends GenericDAOImpl<VehiculoServicio> implements VehiculoServicioDAO {

	Logger log = Logger.getLogger(this.getClass());

	@Autowired
	@Qualifier("dataSourceCore")
	private DataSource dataSource;
	
	public VehiculoServicioDAOImpl(Class<VehiculoServicio> objectType) {
		super(objectType);
	}

	@SuppressWarnings("unused")
    public void updateVehiculoServicioEstadoFirma(VehiculoServicio vehiculoServicio) throws GeneralDataAccessException {
		if (vehiculoServicio.getId() != null) {
			Long vsId = vehiculoServicio.getId();
			String vsMensajeFirmador = vehiculoServicio.getMensajeFirmador();
			Integer vsRespuestaFirmador = (vehiculoServicio.getRespuestaFirmador()==null)?0:vehiculoServicio.getRespuestaFirmador();

			try {
				Query updateQuery = getSession().createSQLQuery(
						"update nullid.rnt_vehiculo_servicio set MENSAJE_FIRMADOR = '" + vsMensajeFirmador + "', RESPUESTA_FIRMADOR = '" + vsRespuestaFirmador + "'  where id = " + vsId + " ");
				int updated = updateQuery.executeUpdate();
			} catch (Exception e) {
				log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
				throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
			}

		}

	}

	public Long getVehiculoServicioIdTraslado(String ppu, Long idTipoTransporte, Long idMedioTransporte, Long idCategoriaTransporte) throws GeneralDataAccessException {
		try {

			Long ret = null;
			String sql = " select rvs.ID from nullid.rnt_vehiculo rv join nullid.rnt_vehiculo_servicio  rvs on rvs.ID_VEHICULO = rv.ID  "
					+ " join nullid.RNT_SERVICIO rs on rs.ID = rvs.ID_SERVICIO join nullid.RNT_TIPO_SERVICIO rts on rts.ID =  rs.ID_TIPO_SERVICIO " + " where rv.ppu = '" + ppu
					+ "'   and rvs.estado in (2, 3) " + " and rts.ID_TIPO_TRANSPORTE = " + idTipoTransporte.toString() + " and rts.ID_MEDIO_TRANSPORTE = " + idMedioTransporte.toString()
					+ " and rts.ID_CATEGORIA_TRANSPORTE = " + idCategoriaTransporte.toString() + " order by rvs.FECHA_ESTADO desc fetch first 1 rows only ";

			Query query = getSession().createSQLQuery(sql);
			@SuppressWarnings("unchecked")
			List<Object> resultset = (List<Object>) query.list();

			if (resultset != null) {
				for (Object dato : resultset) {
					ret = new Long((String.valueOf(dato))).longValue();
				}

			}
			return ret;
		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}


	public Integer getEstadoVehiculo(Long idVehiculoServicio) throws GeneralDataAccessException{
		try {
			String hql = " SELECT VS.estado FROM VehiculoServicio AS VS "
					+ " WHERE VS.id = " + idVehiculoServicio.toString() + " ";

			Query query = getSession().createQuery(hql);
			Integer result = (Integer)query.uniqueResult();
			return result;
			
		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

	}

	@SuppressWarnings("rawtypes")
    @Override
	public List<VehiculoServicioHistoricoDTO> getVehiculoServicioHistoricoById(Long id)
			throws GeneralDataAccessException {
		String sqlQuery = "	SELECT vs.id, vs.rev, u.NOMBRE_COMPLETO, vs.REVTYPE, vs.MODIFIED, vs.FECHA_INGRESO, vs.FECHA_ESTADO, vs.ESTADO, vs.OBSERVACION, vs.OBSERVACION_CANCELACION "
				+ "FROM nullid.RNT_VEHICULO_SERVICIO_aud as vs	";
		sqlQuery += "	left outer join nullid.RNT_USER u on u.id = vs.ID_USER_MODIFIED ";
		sqlQuery += "	join nullid.REVINFO ri on ri.rev = vs.rev ";
		sqlQuery += "	WHERE vs.ID = " + id;
		sqlQuery += "	and vs.ESTADO IN (1,2,3,7)";
		sqlQuery += "	ORDER BY vs.rev asc";
		
		Query query = getSession().createSQLQuery(sqlQuery);		
		List<VehiculoServicioHistoricoDTO> resultados = new ArrayList<VehiculoServicioHistoricoDTO>();
		List resultset = query.list();
		for (Object datoPlano : resultset) {
			Object[] dato = (Object[]) datoPlano;
			VehiculoServicioHistoricoDTO vsdao = new VehiculoServicioHistoricoDTO();
			vsdao.setId(((BigInteger) dato[0]).longValue());
			vsdao.setRev(((Integer) dato[1]).longValue());
			vsdao.setNombreUsuario((String) dato[2]);
			vsdao.setRevType(((String) dato[3].toString()));
			if(dato[4] != null)
				vsdao.setFechaRev(((Date)dato[4]));
			vsdao.setFechaIngreso(((Date)dato[5]));
			vsdao.setFechaEstado(((Date)dato[6]));
			vsdao.setEstado((Integer) (dato[7]));
			vsdao.setObservacion((String)dato[8]);
			vsdao.setObservacionCancelacion((String)dato[9]);
	
			resultados.add(vsdao);
		}
		return resultados;
	}

	@Override
	public VehiculoServicio getVehiculoServicioHistoricoByRevision(Long id,Long rev) throws GeneralDataAccessException {
		VehiculoServicio vs;		
		try {
			AuditReader reader = AuditReaderFactory.get(getSession());
			vs= reader.find(VehiculoServicio.class, id, rev.intValue());
		}
		catch (Exception e) {
			throw new GeneralDataAccessException(e.getMessage());
		}
		return vs;	
	}

	@Override
	public void deleteVehiculoServicioAud(Long IdvehiculoServicio,Long rev) throws GeneralDataAccessException {
		try{
			String sqlQuery = "DELETE FROM nullid.RNT_VEHICULO_SERVICIO_AUD as VS";
			sqlQuery += "	WHERE VS.ID = " + IdvehiculoServicio+" ";
			sqlQuery += "	and VS.rev > "+rev;
			Query query = getSession().createSQLQuery(sqlQuery);	
			query.executeUpdate();
		}
		catch(Exception ex){
			log.error(GeneralDataAccessException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(ex));
			throw new GeneralDataAccessException(GeneralDataAccessException.DELETE_ERROR, ex);
		}
	}

	@Override
	public void deleteVehiculoServicioRechazada(VehiculoServicio vs)throws GeneralDataAccessException {
		try {
			String hql;
			String sql;
			Query query;
			//pasajeros
			sql = " DELETE FROM NULLID.RNT_PASAJERO_AUD WHERE ID_VEHICULO_SERVICIO ="+vs.getId();
			query = getSession().createSQLQuery(sql);
			query.executeUpdate();
			
			hql = " DELETE   FROM Pasajero P  WHERE P.vehiculoServicio.id  ="+vs.getId();
			query = getSession().createQuery(hql);
			query.executeUpdate();


			//ConductorVehiculo
			sql = "DELETE FROM NULLID.RNT_CONDUCTOR_VEHICULO_AUD WHERE ID_VEHICULO_SERVICIO ="+vs.getId();
			query = getSession().createSQLQuery(sql);
			query.executeUpdate();
			
			hql = " DELETE   FROM ConductorVehiculo CV  WHERE CV.vehiculoServicio.id ="+vs.getId();
			query = getSession().createQuery(hql);
			query.executeUpdate();
			
			//periodovigencia
			sql = "DELETE FROM NULLID.RNT_PERIODO_VIGENCIA_AUD WHERE ID_VEHICULO_SERVICIO ="+vs.getId();
			query = getSession().createSQLQuery(sql);
			query.executeUpdate();
			
			hql = " DELETE FROM PeriodoVigencia PV WHERE PV.vehiculoServicio.id ="+vs.getId();
			query = getSession().createQuery(hql);
			query.executeUpdate();
			
			//certificado
//			sql = " DELETE FROM NULLID.RNT_CERTIFICADO_DATO_AUD WHERE ID_CERTIFICADO IN (SELECT ID FROM  NULLID.RNT_CERTIFICADO WHERE ID_VEHICULO_SERVICIO = " + vs.getId()+ ")";
//			query = getSession().createSQLQuery(sql);
//			query.executeUpdate();
//			
//			hql = " DELETE FROM CertificadoDato CD  WHERE CD.certificado.id IN"
//				+ " (SELECT C.id  FROM Certificado C WHERE C.vehiculo.id = " +vs.getId()+ ") ";
//			query = getSession().createQuery(hql);
//			query.executeUpdate();
			
			
			hql = " DELETE FROM XmlCertificado XC  WHERE XC.certificado.id IN"
					+ " (SELECT C.id  FROM Certificado C WHERE C.vehiculo.id = " +vs.getId()+ ") ";
			query = getSession().createQuery(hql);
			query.executeUpdate();
			
		
			hql = " DELETE FROM Certificado C  WHERE C.vehiculo.id = "+vs.getId();
			query = getSession().createQuery(hql);
			query.executeUpdate();
			
			
			
			
			//vehiculoservicio
			
			sql = " DELETE FROM NULLID.RNT_VEHICULO_SERVICIO_AUD WHERE ID = " +vs.getId();
			query = getSession().createSQLQuery(sql);
			query.executeUpdate();
			
			isRemplaza(vs.getId());
			isRemplazado(vs.getId());
			
			hql = " DELETE FROM VehiculoServicio VS  WHERE VS.id = "+vs.getId();
			query = getSession().createQuery(hql);
			query.executeUpdate();
			
	
			
			} catch (Exception e) {;
				log.error(GeneralDataAccessException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
				throw new GeneralDataAccessException(GeneralDataAccessException.DELETE_ERROR, e);
			}
	}
	
	
	@SuppressWarnings("unchecked")
    @Override
	public List<VehiculoReemplazable> getVehiculosReemplazables(Long idServicio,String codigoRegion,Long idVehiculoServicioOrigen) throws GeneralDataAccessException{
		try {
			List<VehiculoReemplazable> ret = new ArrayList<VehiculoReemplazable>();
//			String hql = " SELECT VS.id, S.id, V.ppu, S.identServicio  FROM VehiculoServicio AS VS "
//					+ " inner join VS.servicio AS S inner join VS.vehiculo AS V inner join VS.tipoCancelacion AS TC "
//					+ " WHERE S.id = '" + idServicio + "' "
//					+ " and S.codigoRegion = '"+codigoRegion+"' "
//					+ " and VS.estado in (2,3) and TC.permiteReemplazo = true "
//					+ " and VS.reemplazado is null "
//					+ " AND vs.id in ( "
//			        + " SELECT VS2.ID from  nullid.RNT_VEHICULO_SERVICIO_AUD VS2 "
//                    +  "    join ( "
//                    +  "   select vx.ID, (select max(rev) from  nullid.RNT_VEHICULO_SERVICIO_AUD aux where ID_VEHICULO = vx.ID) REVISION from nullid.RNT_VEHICULO vx join "
//                    +  "   nullid.RNT_VEHICULO_SERVICIO vsx on vx.ID = vsx.ID_VEHICULO and vsx.ID_SERVICIO = "+ idServicio +" ) ULTIMOS on ULTIMOS.ID = VS2.ID_VEHICULO and ULTIMOS.REVISION = VS2.REV  " 
//                    + " )";
//
//			Query query = getSession().createQuery(hql);
//			List<Object> resultset = query.list();
//			for (Object datoPlano : resultset) {
//				Object[] dato = (Object[]) datoPlano;
//				VehiculoReemplazable sdao = new VehiculoReemplazable();
//				sdao.setIdentServicio((Long) dato[3]);
//				sdao.setIdVehiculoServicio((Long) dato[0]);
//				sdao.setIdServicio((Long) dato[1]);
//				sdao.setPpu((String) dato[2]);
//				ret.add(sdao);
//
//			}
//			return ret;

			String sql = " SELECT VS.id, S.id, V.ppu, S.IDENT_SERVICIO  FROM nullid.RNT_VEHICULO_SERVICIO AS VS "
			+ " inner join nullid.RNT_SERVICIO AS S on s.id = vs.id_servicio "
			+ " inner join nullid.RNT_VEHICULO AS V on v.id = vs.id_vehiculo "
			+ " inner join nullid.RNT_TIPO_CANCELACION AS TC on tc.id = vs.id_tipo_cancelacion "
			+ " WHERE S.id = '" + idServicio + "' "
			+ " and S.codigo_Region = '"+codigoRegion+"' "
			+ " and VS.estado in (2,3) and TC.permite_Reemplazo = 1 "
			+ " and ((VS.id_vehiculo_reemplazado is null and V.tipo_vehiculo = 2) ";
			if(idVehiculoServicioOrigen!=null){
				sql += "or (VS.id_vehiculo_reemplazado = '"+idVehiculoServicioOrigen+"' and V.tipo_vehiculo = 2) ";
			}
			sql += "or (V.tipo_vehiculo <> 2)) "
			+ " AND vs.id in ( "
	        + " SELECT VS2.ID from  nullid.RNT_VEHICULO_SERVICIO_AUD VS2 "
            +  "    join ( "
            +  "   select vx.ID, (select max(rev) from  nullid.RNT_VEHICULO_SERVICIO_AUD aux where ID_VEHICULO = vx.ID) REVISION from nullid.RNT_VEHICULO vx join "
            +  "   nullid.RNT_VEHICULO_SERVICIO vsx on vx.ID = vsx.ID_VEHICULO and vsx.ID_SERVICIO = "+ idServicio +" ) ULTIMOS on ULTIMOS.ID = VS2.ID_VEHICULO and ULTIMOS.REVISION = VS2.REV  " 
            + " )";

			Query query = getSession().createSQLQuery(sql);
			List<Object[]> resultset = (List<Object[]>) query.list();

			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				VehiculoReemplazable sdao = new VehiculoReemplazable();
				sdao.setIdentServicio(((BigInteger) dato[3]).longValue());
				sdao.setIdVehiculoServicio(((BigInteger) dato[0]).longValue());
				sdao.setIdServicio(((BigInteger) dato[1]).longValue());
				sdao.setPpu((String) dato[2]);
				ret.add(sdao);
	
			}
			return ret;

		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

	}
	
	@SuppressWarnings("unchecked")
    @Override
	public List<VehiculoReemplazable> getVehiculosReemplazablesByIdent(Long identServicio,String codigoRegion,String ppuReemplazada) throws GeneralDataAccessException{
		try {
			List<VehiculoReemplazable> ret = new ArrayList<VehiculoReemplazable>();

			String sql = " SELECT VS.id, S.id, V.ppu, S.IDENT_SERVICIO  FROM nullid.RNT_VEHICULO_SERVICIO AS VS "
			+ " inner join nullid.RNT_SERVICIO AS S on s.id = vs.id_servicio "
			+ " inner join nullid.RNT_VEHICULO AS V on v.id = vs.id_vehiculo "
			+ " inner join nullid.RNT_TIPO_CANCELACION AS TC on tc.id = vs.id_tipo_cancelacion ";
			if(ppuReemplazada!=null){
				sql += " LEFT outer JOIN nullid.RNT_VEHICULO_SERVICIO AS VS_reemp ON VS_reemp.id = VS.id_vehiculo_reemplazado "
					+ " LEFT outer JOIN nullid.RNT_VEHICULO AS V_reemp ON VS_reemp.id_vehiculo = V_reemp.id ";
			}
			sql+= " WHERE S.ident_servicio = '" + identServicio + "' "
			+ " and S.codigo_Region = '"+codigoRegion+"' "
			+ " and VS.estado in (2,3) and TC.permite_Reemplazo = 1 ";
			if(ppuReemplazada!=null){
				sql+= " and ( ((VS.id_vehiculo_reemplazado is null and V.tipo_vehiculo = 2) or (V.tipo_vehiculo <> 2)) "
						+ " OR (VS.id_vehiculo_reemplazado is NOT null and V.tipo_vehiculo = 2 AND V_reemp.ppu='"+ppuReemplazada+"' ) )";
			} else {
				sql +=  " and ((VS.id_vehiculo_reemplazado is null and V.tipo_vehiculo = 2) or (V.tipo_vehiculo <> 2)) ";
			} 	
			sql += " AND vs.id in ( "
	        + " SELECT VS2.ID from  nullid.RNT_VEHICULO_SERVICIO_AUD VS2 "
            +  "    join ( "
            +  "   select vx.ID, (select max(rev) from  nullid.RNT_VEHICULO_SERVICIO_AUD aux where ID_VEHICULO = vx.ID) REVISION from nullid.RNT_VEHICULO vx "
            + " join nullid.RNT_VEHICULO_SERVICIO vsx on vx.ID = vsx.ID_VEHICULO "
            + " inner join nullid.RNT_SERVICIO AS Saux on Saux.id = vsx.id_servicio "
            + " and Saux.ident_servicio = '" + identServicio + "' "
			+ " and Saux.codigo_Region = '"+codigoRegion+"' ) ULTIMOS on ULTIMOS.ID = VS2.ID_VEHICULO and ULTIMOS.REVISION = VS2.REV  " 
            + " )";

			Query query = getSession().createSQLQuery(sql);
			List<Object[]> resultset = (List<Object[]>) query.list();

			for (Object datoPlano : resultset) {
				Object[] dato = (Object[]) datoPlano;
				VehiculoReemplazable sdao = new VehiculoReemplazable();
				sdao.setIdentServicio(((BigInteger) dato[3]).longValue());
				sdao.setIdVehiculoServicio(((BigInteger) dato[0]).longValue());
				sdao.setIdServicio(((BigInteger) dato[1]).longValue());
				sdao.setPpu((String) dato[2]);
				ret.add(sdao);
	
			}
			return ret;

		} catch (Exception e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

//		try {
//			List<VehiculoReemplazable> ret = new ArrayList<VehiculoReemplazable>();
//			String hql = " SELECT VS.id, S.id, V.ppu, S.identServicio  FROM VehiculoServicio AS VS "
//					+ " inner join VS.servicio AS S inner join VS.vehiculo AS V inner join VS.tipoCancelacion AS TC "
//					+ " WHERE S.identServicio = '" + identServicio + "' "
//					+ " and S.codigoRegion = '"+codigoRegion+"' "
//					+ " and VS.estado in (2,3) and TC.permiteReemplazo = true "
//					+ " and VS.reemplazado is null ";
//
//			Query query = getSession().createQuery(hql);
//			List<Object> resultset = query.list();
//			for (Object datoPlano : resultset) {
//				Object[] dato = (Object[]) datoPlano;
//				VehiculoReemplazable sdao = new VehiculoReemplazable();
//				sdao.setIdentServicio((Long) dato[3]);
//				sdao.setIdVehiculoServicio((Long) dato[0]);
//				sdao.setIdServicio((Long) dato[1]);
//				sdao.setPpu((String) dato[2]);
//				ret.add(sdao);
//
//			}
//			return ret;
//		} catch (Exception e) {
//			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
//			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
//		}

	}

	@Override
	public void isRemplaza(Long idVs)  throws GeneralDataAccessException{
		try{
		   //cuando es reemplazado por 
		String hql = " UPDATE VehiculoServicio VS SET VS.reemplazado = null where VS.reemplazado.id = "+idVs; 
		Query query = getSession().createQuery(hql);
		query.executeUpdate();
		
		//saco el registro que reemplaza
		hql = " UPDATE VehiculoServicio VS SET VS.reemplaza = null where VS.id = "+idVs; 
        query = getSession().createQuery(hql);
        query.executeUpdate();
		
		// QUITA DE HISTORIA
        String sql = "UPDATE NULLID.RNT_VEHICULO_SERVICIO_AUD SET ID_VEHICULO_REEMPLAZADO = NULL WHERE ID_VEHICULO_REEMPLAZADO = "   + idVs + " ";
        query = getSession().createSQLQuery(sql);
        query.executeUpdate();
        
        sql = "UPDATE NULLID.RNT_VEHICULO_SERVICIO_AUD SET ID_VEHICULO_REEMPLAZA = NULL WHERE ID = "   + idVs + " ";
        query = getSession().createSQLQuery(sql);
        query.executeUpdate();
		
		}catch(Exception e){
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}
	
	
	@Override
    public void isRemplazaAllVs(Long idVehiculo)  throws GeneralDataAccessException{
        try{
           //cuando es reemplazado por 
        String hql = " UPDATE VehiculoServicio VS SET VS.reemplazado = null where VS.reemplazado.id in ("
                + "SELECT VS2.id FROM VehiculoServicio VS2 where VS2.vehiculo.id  = "+idVehiculo +" ) " ;
        Query query = getSession().createQuery(hql);
        query.executeUpdate();
        
        //saco el registro que reemplaza
        hql = " UPDATE VehiculoServicio VS SET VS.reemplaza = null where VS.id in ( " 
                + "SELECT VS2.id FROM VehiculoServicio VS2 where VS2.vehiculo.id  = "+idVehiculo +" ) " ;
        query = getSession().createQuery(hql);
        query.executeUpdate();
        
        // QUITA DE HISTORIA
        String sql = "UPDATE NULLID.RNT_VEHICULO_SERVICIO_AUD SET ID_VEHICULO_REEMPLAZADO = NULL WHERE ID_VEHICULO_REEMPLAZADO in ("
                + " SELECT VS2.ID from nullid.RNT_VEHICULO_SERVICIO_aud VS2 where"
                + " VS2.ID_VEHICULO =  " + idVehiculo + ")";
        query = getSession().createSQLQuery(sql);
        query.executeUpdate();
        
        sql = "UPDATE NULLID.RNT_VEHICULO_SERVICIO_AUD SET ID_VEHICULO_REEMPLAZA = NULL WHERE ID in ( " 
                + " SELECT VS2.ID from nullid.RNT_VEHICULO_SERVICIO_aud VS2 where"
                + " VS2.ID_VEHICULO =  " + idVehiculo + ")";
        query = getSession().createSQLQuery(sql);
        query.executeUpdate();
        
        }catch(Exception e){
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
	
	
	
	
	
	@Override
	public void setRemplaza(VehiculoServicio vs)  throws GeneralDataAccessException{
		try{
		String hql = " UPDATE VehiculoServicio VS SET VS.reemplazado.id = " +vs.getId()+ " where VS.id= "+vs.getReemplaza().getId(); 
		Query query = getSession().createQuery(hql);
		query.executeUpdate();
		}catch(Exception e){
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
	public boolean isRemplazado(Long idVs)  throws GeneralDataAccessException{
		try{
    		String hql = " SELECT  VS FROM VehiculoServicio VS WHERE VS.reemplaza.id = "+idVs;
    		Query query = getSession().createQuery(hql);
    		List<Object[]> res = query.list();
    		if(res == null || res.isEmpty()) {
    		    String sqlQuery = "   SELECT vs.id "
    	                + "FROM nullid.RNT_VEHICULO_SERVICIO_aud as vs  ";
    	        sqlQuery += "   WHERE VS.id_vehiculo_reemplaza = " + idVs;
    	        Query querySql = getSession().createSQLQuery(sqlQuery);        
    	        List resultset = querySql.list();
    	        if(resultset == null || resultset.isEmpty()) {
    	            return false;
    	        }
    	        else {
    	            return true;
    	        }
    		}
    		else {
    			return true;
    		}
		}
		catch(Exception e){
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public boolean isRemplazadoAllVs(Long idVehiculo)  throws GeneralDataAccessException{
        try{
            String hql = " SELECT  VS FROM VehiculoServicio VS WHERE VS.reemplaza.id in ("
                    + "SELECT VS2.id FROM VehiculoServicio VS2 where VS2.vehiculo.id  = "+idVehiculo +" ) " ;
            Query query = getSession().createQuery(hql);
            List<Object[]> res = query.list();
            if(res == null || res.isEmpty()) {
                String sqlQuery = "   SELECT vs.id "
                        + "FROM nullid.RNT_VEHICULO_SERVICIO_aud as vs  ";
                sqlQuery += "   WHERE VS.id_vehiculo_reemplaza in ("
                        + " SELECT VS2.id from nullid.RNT_VEHICULO_SERVICIO_aud VS2 where"
                        + " VS2.ID_VEHICULO =  " + idVehiculo + ")";
                Query querySql = getSession().createSQLQuery(sqlQuery);        
                List resultset = querySql.list();
                if(resultset == null || resultset.isEmpty()) {
                    return false;
                }
                else {
                    return true;
                }
            }
            else {
                return true;
            }
        }
        catch(Exception e){
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
	
	
	

    @SuppressWarnings("rawtypes")
    @Override
    public List<VehiculoServicio> getHistorialVehiculo(Long idVehiculo) throws GeneralDataAccessException {
    	String sqlQuery = "select ID, FECHA_ESTADO, CODIGO_REGION, IDENT_SERVICIO, NUMERO_LINEA, ID_TIPO_SERVICIO, ESTADO, REGION_DESTINO"; 
		sqlQuery+= ", VEHICULO_REEMPLAZA, VEHICULO_REEMPLAZADO, ID_REGLAMENTACION, OBSERVACION";
		sqlQuery+= ", case when ESTADO = 1 then (case when REV <= REVPRIMERO then -1 else -2 end ) else ITC end as ID_TIPO_CANCELACION , MODIFIED";
		sqlQuery+= ", REV ";
		sqlQuery+= " from (";
		sqlQuery+= " select vsa.REV,vsa.ID, vsa.MODIFIED, vsa.FECHA_ESTADO, s.CODIGO_REGION, s.IDENT_SERVICIO, vsa.NUMERO_LINEA, s.ID_TIPO_SERVICIO, vsa.ESTADO, vsa.REGION_DESTINO"; 
		sqlQuery+= ", v1.PPU  || '' AS VEHICULO_REEMPLAZA, v2.PPU  || '' AS VEHICULO_REEMPLAZADO, vsa.ID_REGLAMENTACION , vsa.OBSERVACION,TC.ID as ITC";
		sqlQuery+= ", (select min(REV) from nullid.RNT_VEHICULO_SERVICIO_AUD auxvsa where auxvsa.ID_VEHICULO = vsa.ID_VEHICULO and auxvsa.estado <> 7) REVPRIMERO";
		sqlQuery+= " from NULLID.RNT_VEHICULO_SERVICIO_AUD vsa";
		sqlQuery+= " join NULLID.RNT_SERVICIO s on s.ID=vsa.ID_SERVICIO"; 
		sqlQuery+= " join NULLID.RNT_VEHICULO v on v.ID=vsa.ID_VEHICULO ";
		sqlQuery+= " left outer join NULLID.RNT_VEHICULO_SERVICIO vsa1 on vsa1.ID=vsa.ID_VEHICULO_REEMPLAZA";
		sqlQuery+= " left outer join NULLID.RNT_VEHICULO v1 on v1.ID=vsa1.ID_VEHICULO";
	
		sqlQuery+= " left outer join NULLID.RNT_VEHICULO_SERVICIO vsa2 on vsa2.ID=vsa.ID_VEHICULO_REEMPLAZADO";
		sqlQuery+= " left outer join NULLID.RNT_VEHICULO v2 on v2.ID=vsa2.ID_VEHICULO";
		sqlQuery+= " left outer join NULLID.RNT_TIPO_CANCELACION tc on vsa.ID_TIPO_CANCELACION = tc.ID";
		sqlQuery+= " where vsa.ID_VEHICULO="+String.valueOf(idVehiculo);
//		sqlQuery+= " order by VSA.REV ) DATOS";
		sqlQuery+= " order by FECHA_ESTADO,VSA.REV ) DATOS";

		Query query = getSession().createSQLQuery(sqlQuery);		
		List<VehiculoServicio> resultados = new ArrayList<VehiculoServicio>();
		List resultset = query.list();
		List<Object[]> unicos = new ArrayList<Object[]>();
		int index = 0;
		for (Object datoPlano : resultset) {
			Object[] dato = (Object[]) datoPlano;
			if (!contieneElDato(unicos,dato)) {
			    unicos.add(dato);
    			VehiculoServicio vs = new VehiculoServicio();
    			
    			vs.setId(((BigInteger) dato[0]).longValue());
    			if (dato[10]!=null) {
    			    vs.setIdReglamentacion(((BigInteger) dato[10]).longValue());
    			}
    			vs.setEstado(((Integer) dato[6]).intValue());
    			if (dato[4]!=null) vs.setNroLineaAud((String) dato[4]);
    			vs.setCodigoRegionDestino(String.valueOf(dato[7]));
    			vs.setObservacion(String.valueOf(dato[11]));
    			if (dato[12]!=null) {
        			vs.setTipoCancelacion(new TipoCancelacion()); 
        			vs.getTipoCancelacion().setId(((BigInteger) dato[12]).longValue());
    			}
    			
    			try {
    			    if (index > 0) {
    			        vs.setFechaCambioEstado(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS").parse(String.valueOf(dato[1])));
    			    }
    			} catch (ParseException e) {
    				Logger.getLogger(this.getClass()).error(e);
    			}
    			try {
    			    if (index > 0) {
    			        vs.setModified(new Timestamp(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS").parse(String.valueOf(dato[13])).getTime()));
    			    }
    			} catch (ParseException e) {
    				Logger.getLogger(this.getClass()).error(e);
    			}
    			vs.setVehiculo(new Vehiculo());
    			
    			if (dato[8]!=null) {
    				vs.setReemplaza(new VehiculoServicio());
    				vs.getReemplaza().setVehiculo(new Vehiculo());
    				vs.getReemplaza().getVehiculo().setPpu(String.valueOf(dato[8]));
    			}
    			
    			if (dato[9]!=null) {
    				vs.setReemplazado(new VehiculoServicio());
    				vs.getReemplazado().setVehiculo(new Vehiculo());
    				vs.getReemplazado().getVehiculo().setPpu(String.valueOf(dato[9]));
    			}
    			
    			Servicio s=new Servicio();
    			s.setIdentServicio(((BigInteger) dato[3]).longValue());
    			s.setIdTipoServicio(((BigInteger) dato[5]).longValue());
    			s.setCodigoRegion(String.valueOf(dato[2]));
    			vs.setServicio(s);
    			
    	    	addAdquisicionHistorico(vs,idVehiculo,(Integer)dato[14]);
    			
    			resultados.add(vs);
    			index ++;
			}
			
		}
        return resultados;
    }

	/**
	 * @param idVehiculo
	 * @param dato
	 * @throws HibernateException
	 * @throws DataAccessResourceFailureException
	 * @throws IllegalStateException
	 * @throws ParseException 
	 */
	private void addAdquisicionHistorico(VehiculoServicio vs, Long idVehiculo, Integer rev) throws HibernateException, DataAccessResourceFailureException, IllegalStateException {
		String sqlQueryAdq = "select distinct adq.id, adq.rev, adq.fecha_Adquisicion, per.id, per.nombre, per.rut "
				+ " from nullid.rnt_adquisicion_aud adq "
				+ " inner join nullid.rnt_vehiculo_aud veh on adq.id = veh.id_adquisicion "
				+ " inner join nullid.rnt_propietario_aud prop on prop.id_adquisicion = adq.id "
				+ " inner join nullid.rnt_persona_aud per on per.id = prop.id_persona "
				+ " where veh.id = "+idVehiculo+" and adq.rev <= "+rev
				+ " and adq.rev = ("
					+ " select max(adq2.rev) from nullid.rnt_adquisicion_aud adq2 "
					+ " inner join nullid.rnt_vehiculo_aud veh2 on adq2.id = veh2.id_adquisicion "
					+ " where veh2.id = "+idVehiculo+" and adq2.rev <= "+rev
				+" )";
		
		Query queryAdq = getSession().createSQLQuery(sqlQueryAdq);		
		List resultsetAdq = queryAdq.list();
		
		Adquisicion adq = new Adquisicion();
		adq.setPropietarios(new ArrayList<Propietario>());
		for (Object datoPlanoAdq : resultsetAdq) {
			Object[] dato = (Object[]) datoPlanoAdq;
			adq.setId(((BigInteger) dato[0]).longValue());
	        try {
				adq.setFechaAdquisicion(new Timestamp(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS").parse(String.valueOf(dato[2])).getTime()));
			} catch (ParseException e) {
				Logger.getLogger(this.getClass()).error(e);
			}
	        Propietario prop=new Propietario();
	        prop.setAdquisicion(adq);
	        Persona per = new Persona();
	        per.setNombre((String)dato[4]);
	        per.setRut((String)dato[5]);
	        prop.setPersona(per);
	        adq.getPropietarios().add(prop);
		}
		vs.getVehiculo().setAdquisicion(adq);
	}

    private boolean contieneElDato(List<Object[]> unicos, Object[] dato) {
        if (unicos.isEmpty()) return false;
        for(Object[] existente : unicos){
            boolean todosiguales = true;
            for (int i = 0; i < existente.length; i++) {
                if (!Utils.igualesConNull(existente[i],dato[i])) {
                    todosiguales = false;
                }
            }
            if (todosiguales) {
                return true;
            }
        }
        return false;
    }

    @Override
    public IDRevision getIdReemplazaAud(Long idVs) throws GeneralDataAccessException {
        try {
            String sqlQuery = " select MAX(ID_VEHICULO_REEMPLAZA) ID_REEMPLAZA from nullid.RNT_VEHICULO_SERVICIO_AUD where ID = " + idVs;
            Query query = getSession().createSQLQuery(sqlQuery);        
            Long idVsReemplaza = ((BigInteger) query.uniqueResult()).longValue();
            
            sqlQuery = " select MIN(REV) REVISION from nullid.RNT_VEHICULO_SERVICIO_AUD where ID =  " + idVsReemplaza;
            query = getSession().createSQLQuery(sqlQuery);        
            Long idRevision = ((Integer) query.uniqueResult()).longValue();
            
            IDRevision idr = new IDRevision();
            idr.setId(idVsReemplaza);
            idr.setRevision(idRevision);
            return idr;
        }
        catch  (Exception e){
            Logger.getLogger(VehiculoServicioDAOImpl.class).error(e.getLocalizedMessage(), e);
            throw new GeneralDataAccessException(e.getMessage());
        }
        
    }

    @Override
    public IDRevision getIdReemplazadoAud(Long idVs) throws GeneralDataAccessException {
        try {
            String sqlQuery = " select MAX(ID_VEHICULO_REEMPLAZADO) ID_REEMPLAZADO from nullid.RNT_VEHICULO_SERVICIO_AUD where ID = " + idVs;
            Query query = getSession().createSQLQuery(sqlQuery);        
            Long idVsReemplaza = ((BigInteger) query.uniqueResult()).longValue();
            
            sqlQuery = " select MIN(REV) REVISION from nullid.RNT_VEHICULO_SERVICIO_AUD where ID =  " + idVsReemplaza;
            query = getSession().createSQLQuery(sqlQuery);        
            Long idRevision = ((Integer) query.uniqueResult()).longValue();
            
            IDRevision idr = new IDRevision();
            idr.setId(idVsReemplaza);
            idr.setRevision(idRevision);
            return idr;
        }
        catch  (Exception e){
            Logger.getLogger(VehiculoServicioDAOImpl.class).error(e.getLocalizedMessage(), e);
            throw new GeneralDataAccessException(e.getMessage());
        }
    }

    @Override
    public VehiculoServicio getVehiculoServicioVersionado(Long idVs, Long rev) throws GeneralDataAccessException {
        AuditReader reader = AuditReaderFactory.get(this.getSession());
        VehiculoServicio vs = reader.find(VehiculoServicio.class, idVs, rev.intValue());
        Logger.getLogger(this.getClass()).debug(vs.getVehiculo().getPpu());
        return vs;
    }


    
    /**
     * 
     * 
     * 
private Vehiculo vehiculo;
    
    // Mejoras 201409 Nro: 45
    private Vehiculo vehiculoWs;
    // Mejoras 201409 Nro: 45
    
    private TipoIngresoVehiculo tipoIngreso;
    private VehiculoServicio reemplaza;
    private VehiculoServicio reemplazado;
    private Date fechaOtorgamientoLogo;
    private Servicio servicio;
   
    private Reglamentacion reglamentacion;

 
  
     * 
     */


    @SuppressWarnings("unchecked")
    @Override
    public VehiculoServicio getVehiculoInicializado(Long id) throws GeneralDataAccessException {
        try{
            String hql = " SELECT  vs FROM VehiculoServicio vs "
                    + " left join fetch vs.tipoIngreso tin"
                    + " left join fetch vs.documentoCancelacion dsv"
                    + " left join fetch vs.documentoInscripcion div"
                    + " left join fetch vs.zonaVehiculo zv"
                    + " left join fetch vs.reemplaza vr"
                    + " left join fetch vs.reemplazado vrdo"
                    + " left join fetch vs.vehiculo veh"
                    + " left join fetch vs.tipoCancelacion tcan"
                    + " left join fetch vs.userCreation ucv"
                    + " left join fetch vs.userModified umv"
                    
                    + " WHERE vs.id = "+id;
            Query query = getSession().createQuery(hql);
            List<VehiculoServicio> res = query.list();
            if(res == null || res.isEmpty()) {
                return null;
            }
            else {
                VehiculoServicio vehiculoServicio = res.get(0);
                Hibernate.initialize(vehiculoServicio.getVehiculo().getLimitaciones());
                if (vehiculoServicio.getVehiculo().getLimitaciones() != null) {
                    for (LimitacionVehiculo limit : vehiculoServicio.getVehiculo().getLimitaciones()) {
                        Hibernate.initialize(limit.getTenedores());
                    }
                }
                Hibernate.initialize(vehiculoServicio.getVehiculo().getSubinscripciones());
                Hibernate.initialize(vehiculoServicio.getVehiculo().getRevisionTecnica());
                Hibernate.initialize(vehiculoServicio.getVehiculo().getAtributosInstancia());
                Hibernate.initialize(vehiculoServicio.getPeriodosVigencia());
                
                if(vehiculoServicio.getReemplaza()!=null){
                    Hibernate.initialize(vehiculoServicio.getReemplaza().getVehiculo());
                }
                if(vehiculoServicio.getReemplazado()!=null){
                    Hibernate.initialize(vehiculoServicio.getReemplazado().getVehiculo());
                }
                
//                Hibernate.initialize(vehiculoServicio.getConductoresVehiculo());
                return vehiculoServicio;
            }
        }
        catch(Exception e){
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
	
	public void updateFechasVigenciaHasta(Servicio servicio) throws GeneralDataAccessException{
		try{
			Connection connection = dataSource.getConnection();//ConnectionManager.getConnection();
		
			Statement stmtUpdate = null;
			Statement stmt = null;
			Statement stmtIns = null;
			try{
				connection.setAutoCommit(false);
	
				String sqlUpdate = "update NULLID.RNT_VEHICULO_SERVICIO "
						+ " set FECHA_VENCIMIENTO='"+Constants.dateFormatDB.format(servicio.getVigenciaHasta())+"', "
						+ " FECHA_INGRESO='"+Constants.dateFormatDB.format(servicio.getVigenciaDesde())+"' "
						+ " where ID_SERVICIO="+servicio.getId()+" and ESTADO=1"; 
				
				stmtUpdate = connection.createStatement();
				stmtUpdate.execute(sqlUpdate);
	
				String sql = "update nullid.RNT_VEHICULO_SERVICIO_AUD "
						+ " set FECHA_VENCIMIENTO = TIMESTAMP ('"+Constants.dateFormatDB.format(servicio.getVigenciaHasta())+"'), "
						+ " FECHA_INGRESO = TIMESTAMP ('"+Constants.dateFormatDB.format(servicio.getVigenciaDesde())+"') "
						+ " where REV = (select MAX(REV) from nullid.RNT_SERVICIO_AUD WHERE ID = "+servicio.getId()+") and ID_SERVICIO = "+servicio.getId()+" and estado = 1"; 
	
				stmt = connection.createStatement();
				stmt.execute(sql);
	
				String sqlIns = "INSERT INTO NULLID.RNT_VEHICULO_SERVICIO_AUD (ID,REV,REVTYPE,CREATION,MODIFIED,REGION_DESTINO,ESTADO,FECHA_ESTADO,RESOLUCION_CANCELACION_FECHA,RESOLUCION_CANCELACION_LINK,NUMERO_RESOLUCION,OBSERVACION_CANCELACION,FECHA_INGRESO,FECHA_LOGO,OBSERVACION,TIENE_CERTIFICADO_PROVISORIO,ID_USER_CREATION,ID_USER_MODIFIED,ID_TIPO_CANCELACION,TIPOSERVICIOSALIENTE_ID,ID_SERVICIO,ID_TIPO_INGRESO,ID_VEHICULO,RESPUESTA_FIRMADOR,MENSAJE_FIRMADOR,GLOSA,ID_REGLAMENTACION,ID_ZONA,ID_VEHICULO_REEMPLAZA,ID_VEHICULO_REEMPLAZADO,FECHA_VENCIMIENTO,ID_DOCUMENTO_BIBLIOTECA_CANCELACION,ID_DOCUMENTO_BIBLIOTECA_INSCRIPCION)"
						+ " (SELECT ID,(select MAX(REV) from nullid.RNT_SERVICIO_AUD WHERE ID = "+servicio.getId()+"), 1,CREATION,MODIFIED,REGION_DESTINO,ESTADO,FECHA_ESTADO,RESOLUCION_CANCELACION_FECHA,RESOLUCION_CANCELACION_LINK,NUMERO_RESOLUCION,OBSERVACION_CANCELACION,FECHA_INGRESO,FECHA_LOGO,OBSERVACION,TIENE_CERTIFICADO_PROVISORIO,ID_USER_CREATION,ID_USER_MODIFIED,ID_TIPO_CANCELACION,TIPOSERVICIOSALIENTE_ID,ID_SERVICIO,ID_TIPO_INGRESO,ID_VEHICULO,RESPUESTA_FIRMADOR,MENSAJE_FIRMADOR,GLOSA,ID_REGLAMENTACION,ID_ZONA,ID_VEHICULO_REEMPLAZA,ID_VEHICULO_REEMPLAZADO,FECHA_VENCIMIENTO,ID_DOCUMENTO_BIBLIOTECA_CANCELACION,ID_DOCUMENTO_BIBLIOTECA_INSCRIPCION" 
						+ " FROM NULLID.RNT_VEHICULO_SERVICIO VS WHERE VS.ID_SERVICIO = "+servicio.getId()+" and VS.estado = 1"
						+ " and not exists (select ID FROM NULLID.RNT_VEHICULO_SERVICIO_AUD VSA WHERE VSA.ID = VS.ID and VSA.REV = (select MAX(REV) from nullid.RNT_SERVICIO_AUD WHERE ID = "+servicio.getId()+")))"; 
				
				stmtIns = connection.createStatement();
				stmtIns.execute(sqlIns);
	
				connection.commit();
			}catch(Exception e){
				log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
				throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
			} finally {
				try {
					stmt.close();
					stmtIns.close();
					stmtUpdate.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
//				ConnectionManager.closeConnection(connection);
				connection.close();
			}
		}catch(SQLException e){
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
		}
	}

    @SuppressWarnings("unchecked")
    @Override
    public Map<Long,VehiculoServicio> getVehiculosCertificables(Long id) throws GeneralDataAccessException {
        try {
            String hql = " SELECT VS  FROM VehiculoServicio AS VS "
                    + " inner join fetch VS.vehiculo AS V "
                    + " inner join fetch V.adquisicion AS AD "
                    + " WHERE VS.servicio.id = " + id + " "
                    + " and VS.estado = 1 ";
                   
            Query query = getSession().createQuery(hql);
            List<VehiculoServicio> list = query.list();
            HashMap<Long, VehiculoServicio> result = new HashMap<Long, VehiculoServicio>();
            for (VehiculoServicio vehiculoServicio : list) {
                result.put(vehiculoServicio.getId(), vehiculoServicio);
            }
            return result;
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }

    
    
    
    @SuppressWarnings("unchecked")
    @Override
    public Map<Long,VehiculoServicio> getVehiculosCertificables(List<Long> idsVs) throws GeneralDataAccessException {
        try {
            StringBuffer hql = new StringBuffer();
            hql.append(" SELECT VS  FROM VehiculoServicio AS VS "
                    + " inner join fetch VS.tipoIngreso AS TI "
                    + " left outer join fetch VS.tipoCancelacion AS TC" 
                    + " left outer join fetch VS.zonaVehiculo AS ZV "
                    + " left outer join fetch ZV.tipoZona AS TZONA "
                    + " left outer join fetch ZV.tipoSubsidio AS TSUB "
                    + " inner join fetch VS.vehiculo AS V "
                    + " inner join fetch V.adquisicion AS AD "
                    + " WHERE VS.id in ( ");
            hql.append(Joiner.on(',').join(idsVs));
            hql.append(")");
            Query query = getSession().createQuery(hql.toString());
            List<VehiculoServicio> list = query.list();
            HashMap<Long, VehiculoServicio> result = new HashMap<Long, VehiculoServicio>();
            for (VehiculoServicio vehiculoServicio : list) {
                result.put(vehiculoServicio.getId(), vehiculoServicio);
            }
            return result;
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    @Override
    public Map<Long,List<ConductorVehiculo>> getConductoresVehiculoServicio(Servicio servicio) throws GeneralDataAccessException {
        try {
            String hql = " SELECT CV  FROM ConductorVehiculo AS CV "
                    + " inner join fetch CV.conductorServicio AS CS "
                    + " inner join fetch CS.conductor AS C "    
                    + " inner join fetch C.persona AS P "    
                    + " WHERE CS.idServicio = " + servicio.getId() + " "
                    + " and CV.estado = 1 ";
            
            Map<Long,List<ConductorVehiculo>> ret=new HashMap<Long, List<ConductorVehiculo>>();
            Query query = getSession().createQuery(hql);
            List<ConductorVehiculo> list = query.list();
            for (ConductorVehiculo conductorVehiculo : list) {
            	Long idVehiculoServicio = conductorVehiculo.getIdVehiculoServicio();
				if(!ret.containsKey(idVehiculoServicio)){
					ret.put(idVehiculoServicio, new ArrayList<ConductorVehiculo>());
				}
				conductorVehiculo.getVehiculoServicio().setServicio(servicio);
				ret.get(idVehiculoServicio).add(conductorVehiculo);
			}
            return ret;
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }


	public Map<Long, List<AtributoInstancia>> getAtributosInstanciaVehiculoServicio(Servicio servicio) throws GeneralDataAccessException{
        try {
            String hql = " SELECT AI FROM AtributoInstancia AS AI "
                    + " inner join fetch AI.atributo AS A "
            		+ " inner join  AI.vehiculo as V"
            		+ " inner join  V.vehiculosServicio as VS "
                    + " WHERE VS.servicio.id = " + servicio.getId() + " "
                    + " and VS.estado = 1 ";
            
            Map<Long,List<AtributoInstancia>> ret=new HashMap<Long, List<AtributoInstancia>>();
            Query query = getSession().createQuery(hql);
            @SuppressWarnings("unchecked")
            List<AtributoInstancia> list = query.list();
            for (AtributoInstancia atributoInstancia : list) {
            	Long idVehiculo = atributoInstancia.getIdVehiculo();
				if(!ret.containsKey(idVehiculo)){
					ret.put(idVehiculo, new ArrayList<AtributoInstancia>());
				}
				ret.get(idVehiculo).add(atributoInstancia);
			}
            return ret;
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
	}

    @SuppressWarnings("unchecked")
    @Override
    public VehiculoServicio getReemplazo(Long idVs) throws GeneralDataAccessException {
        try {
            Query query = getSession().createQuery(
                    "select item FROM VehiculoServicio item  "  
                            + "   left outer join fetch item.userCreation cr "
                            + "   left outer join fetch item.userModified mod " 
                            + "   left outer join fetch item.vehiculo veh " 
                            + "   left outer join fetch veh.revisionTecnica rt " 
                            + "   left outer join fetch veh.adquisicion adq "
                            + "   left outer join fetch adq.propietarios prop "
                            + "   left outer join fetch prop.persona pers" 
                            + "   left outer join fetch item.tipoIngreso ti " 
                            + "   left outer join fetch item.zonaVehiculo zv" 
                            + "   WHERE item.id = :ids ");
            query.setParameter("ids", idVs);
            List<VehiculoServicio> items = (List<VehiculoServicio>) query.list();
            if ((items != null) && (!items.isEmpty())) {
                return items.get(0);
            }
            return null;
        }
        catch (Exception e) {
            log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<VehiculoServicio> getVehiculosByFiltros(TipoServicio tipoServicio, Integer anioDesde, Integer anioHasta, String tipoBusqueda, Date fechaSalida,
            Long identServicio, Region region, Integer estadoVehiculo) throws GeneralDataAccessException {
       
        try {
            String hqlStr = "select vs from  VehiculoServicio as vs "
                    + " inner join fetch vs.vehiculo as v  " 
                    + " inner join fetch vs.servicio as s "
                    + " where s.tipoServicio.id = " + tipoServicio.getId() +"  "
                    + " and s.codigoRegion = '" + region.getCodigo() + "' ";
            
            if (estadoVehiculo ==null) {
                hqlStr += " and vs.estado in (1,2) ";
            }
            else {
                if (estadoVehiculo.equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
                    hqlStr += " and vs.estado = 1 ";
                }
                if (estadoVehiculo.equals(GenericCancellableModelObject.ESTADO_CANCELADO)) {
                    hqlStr += " and vs.estado = 2 ";
                }
            }
            
            if(identServicio!=null){
                hqlStr += " and s.identServicio = " + identServicio + " ";
            }
            if(tipoBusqueda.equals("FABRICACION")){
                hqlStr += " and v.anioFabricacion >= " + anioDesde + " ";
                hqlStr += " and v.anioFabricacion <= " + anioHasta + " ";
            }
            
            hqlStr +=  " and ( vs.estado = 1 OR vs.id in ( "
                    + " select vs2.id from VehiculoServicioTop vs2 "
                    + "     where vs2.id = vs.id )) ";

            Query query = getSession().createQuery(hqlStr);
            List<VehiculoServicio> resultset = (List<VehiculoServicio>) query.list();
            return resultset;
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
        
    }

    @Override
    public Long getTipoCancelacionHistoricoByRevision(Long id, Long rev) throws GeneralDataAccessException {
        String sqlQuery = "  Select ID_TIPO_CANCELACION from nullid.RNT_VEHICULO_SERVICIO_AUD where  ID = " + id + " and REV = " + rev + " ";

        Query query = getSession().createSQLQuery(sqlQuery);
        @SuppressWarnings("rawtypes")
        List resultset = query.list();
        for (Object datoPlano : resultset) {
            return ((BigInteger)datoPlano).longValue();
        }
        return null;

    }

    @Override
    public Long getRevisionRechazoReversion(Long idVs, Long revisionReversion) throws GeneralDataAccessException {
        String sqlQuery = "  Select min(REV) AS REV from nullid.RNT_VEHICULO_SERVICIO_AUD where  ID = " + idVs + " and REV > " + revisionReversion + " ";

        Query query = getSession().createSQLQuery(sqlQuery);
        @SuppressWarnings("rawtypes")
        List resultset = query.list();
        for (Object datoPlano : resultset) {
            return ((Integer)datoPlano).longValue();
        }
        return null;
    }

    @Override
    public void eliminarVehiculoServicio(Long idVs) throws GeneralDataAccessException {
        try{
            String hql;
            String sql;
            Query query;

            // notificacion
            hql = " DELETE   FROM Notificacion N WHERE N.autorizacionMovimiento.id IN "
                    + " (SELECT AM.id FROM AutorizacionMovimiento AM WHERE AM.idMovimiento  = "
                    + idVs 
                    + "  AND AM.tipoMovimiento IN ( "
                    + AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL + ","
                    + AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION  + ") )";
            query = getSession().createQuery(hql);
            query.executeUpdate();

            // AutorizacionMovimiento
            hql = " DELETE   FROM AutorizacionMovimiento AM WHERE AM.idMovimiento = "
                    + idVs
                    + "  AND AM.tipoMovimiento IN ( "
                    + AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL + ","
                    + AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION  + ")";
            query = getSession().createQuery(hql);
            query.executeUpdate();

            // pasajeros
            sql = " DELETE FROM NULLID.RNT_PASAJERO_AUD WHERE ID_VEHICULO_SERVICIO  = " + idVs;
            query = getSession().createSQLQuery(sql);
            query.executeUpdate();

            hql = " DELETE   FROM Pasajero P  WHERE P.vehiculoServicio.id = " + idVs;
            query = getSession().createQuery(hql);
            query.executeUpdate();

            // ConductorVehiculo
            sql = "DELETE FROM NULLID.RNT_CONDUCTOR_VEHICULO_AUD WHERE ID_VEHICULO_SERVICIO = " + idVs;
            query = getSession().createSQLQuery(sql);
            query.executeUpdate();

            hql = " DELETE   FROM ConductorVehiculo CV  WHERE CV.vehiculoServicio.id = " + idVs;
            query = getSession().createQuery(hql);
            query.executeUpdate();

            hql = " DELETE FROM XmlCertificado XC  WHERE XC.certificado.id IN"
                    + " (SELECT C.id  FROM Certificado C WHERE C.vehiculo.id = " + idVs
                    + "  ) ";
            query = getSession().createQuery(hql);
            query.executeUpdate();


            hql = " DELETE FROM Certificado C  WHERE C.vehiculo.id = " + idVs;
            query = getSession().createQuery(hql);
            query.executeUpdate();

			//periodovigencia
			sql = "DELETE FROM NULLID.RNT_PERIODO_VIGENCIA_AUD WHERE ID_VEHICULO_SERVICIO ="+idVs;
			query = getSession().createSQLQuery(sql);
			query.executeUpdate();
			
			hql = " DELETE FROM PeriodoVigencia PV WHERE PV.vehiculoServicio.id ="+idVs;
			query = getSession().createQuery(hql);
			query.executeUpdate();

            // vehiculoservicio
            sql = " UPDATE NULLID.RNT_VEHICULO_SERVICIO_AUD SET ID_VEHICULO_REEMPLAZADO = null where ID_VEHICULO_REEMPLAZADO =  " + idVs;  
            query = getSession().createSQLQuery(sql);
            query.executeUpdate();

            sql = " UPDATE NULLID.RNT_VEHICULO_SERVICIO_AUD SET ID_VEHICULO_REEMPLAZA = null where ID_VEHICULO_REEMPLAZA =  " + idVs;  
            query = getSession().createSQLQuery(sql);
            query.executeUpdate();

            sql = " DELETE FROM NULLID.RNT_VEHICULO_SERVICIO_AUD WHERE ID = " + idVs;  
            query = getSession().createSQLQuery(sql);
            query.executeUpdate();
            
            hql = " UPDATE VehiculoServicio set reemplazado = null   WHERE reemplazado.id =  " + idVs;
            query = getSession().createQuery(hql);
            query.executeUpdate();

            hql = " UPDATE VehiculoServicio set reemplaza = null   WHERE reemplaza.id =  " + idVs;
            query = getSession().createQuery(hql);
            query.executeUpdate();
            
            hql = " DELETE FROM VehiculoServicio VS  WHERE VS.id =  " + idVs;
            query = getSession().createQuery(hql);
            query.executeUpdate();

        }
        catch(Exception ex){
            log.error(GeneralDataAccessException.DELETE_ERROR + "\n" + StackTraceUtil.getStackTraceString(ex));
            throw new GeneralDataAccessException(GeneralDataAccessException.DELETE_ERROR, ex);
        }
        
    }
	
	public void recuperarCertificadoAnterior(Long idVehiculoServicio) throws GeneralDataAccessException{
		try {
			Query updateQuery1 = getSession().createSQLQuery(
					"DELETE from nullid.RNT_XML_CERTIFICADO where ID_CERTIFICADO IN "
					+ "(SELECT ID from nullid.RNT_CERTIFICADO "
					+ "where ID_VEHICULO_SERVICIO = "+idVehiculoServicio+" and estado_firma <> 'certificado migrado' and ESTADO = 1)"
			);
			int updated1 = updateQuery1.executeUpdate();
			
			Query updateQuery = getSession().createSQLQuery(
					"delete from nullid.RNT_CERTIFICADO where ID_VEHICULO_SERVICIO = "+idVehiculoServicio+" and estado_firma <> 'certificado migrado' and ESTADO = 1"
			);
			int updated = updateQuery.executeUpdate();
			Query updateQuery2 = getSession().createSQLQuery(
					"merge into nullid.RNT_CERTIFICADO a using "
					+ "(select MAX(ID) ID_CERT, ID_VEHICULO_SERVICIO,ID_RECORRIDO "
					+ "from nullid.RNT_CERTIFICADO where ID_VEHICULO_SERVICIO = "+idVehiculoServicio+" and "
					+ "estado_firma <> 'certificado migrado' and estado = 2 "
					+ "group by ID_VEHICULO_SERVICIO,ID_RECORRIDO) MAXXES on "
					+ "MAXXES.ID_CERT = a.ID when matched then update set a.ESTADO = 1"
			);
			int updated2 = updateQuery2.executeUpdate();
			
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

	}

	public void eliminarCertificadoAnterior(Long idVehiculoServicio) throws GeneralDataAccessException{
		try {
			Query updateQuery1 = getSession().createSQLQuery(
					"DELETE from nullid.RNT_XML_CERTIFICADO where ID_CERTIFICADO IN "
					+ "(select ID_CERT from (select MAX(ID) ID_CERT, ID_VEHICULO_SERVICIO,ID_RECORRIDO "
					+ "from nullid.RNT_CERTIFICADO where ID_VEHICULO_SERVICIO = "+idVehiculoServicio+" and "
							+ "estado_firma <> 'certificado migrado' and estado = 1 "
							+ "group by ID_VEHICULO_SERVICIO,ID_RECORRIDO))"
			);
			int updated1 = updateQuery1.executeUpdate();
			
			Query updateQuery = getSession().createSQLQuery(
					" DELETE from nullid.RNT_CERTIFICADO where ID IN "
					+ "(select ID_CERT from (select MAX(ID) ID_CERT, ID_VEHICULO_SERVICIO,ID_RECORRIDO "
					+ "from nullid.RNT_CERTIFICADO where ID_VEHICULO_SERVICIO = "+idVehiculoServicio+" and "
					+ "estado_firma <> 'certificado migrado' and estado = 1 "
					+ "group by ID_VEHICULO_SERVICIO,ID_RECORRIDO))"
			);
			int updated = updateQuery.executeUpdate();
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}		
	}

}
