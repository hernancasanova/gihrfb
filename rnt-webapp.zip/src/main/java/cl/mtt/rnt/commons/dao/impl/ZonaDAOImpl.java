package cl.mtt.rnt.commons.dao.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.ZonaDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.core.ZonaComuna;
import cl.mtt.rnt.commons.model.core.ZonaLocalidad;
import cl.mtt.rnt.commons.model.core.ZonaRegion;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class ZonaDAOImpl extends GenericDAOImpl<Zona> implements ZonaDAO {

	Logger log = Logger.getLogger(this.getClass());

	public ZonaDAOImpl(Class<Zona> objectType) {
		super(objectType);
	}
	
	@SuppressWarnings("rawtypes")
    @Override
	public List<Long> getZonasSubsidioIdsByServicio(Long idServicio) throws GeneralDataAccessException {
		List<Long> ret=new ArrayList<Long>();
		try {
			String sql = "select s.id_zona from NULLID.RNT_SERVICIO_ZONA_SUBSIDIO s where s.id_servicio = "+idServicio;
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Long dato = Long.parseLong(((BigInteger)datoPlano).toString());
				ret.add(dato);
			}
			return ret;
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

	}
	
	
	@SuppressWarnings("unchecked")
    @Override
    public List<String> getRegionesIdsfromZonas(List<Zona> zonas) throws GeneralDataAccessException {
        try {
            List<Long> zonasIds = new ArrayList<Long>();
            for (Zona zona : zonas) {
                zonasIds.add(zona.getId());
            }
            
            if (zonasIds.size()==0) {
                return new ArrayList<String>(0);
            }
            
            String hql = " SELECT distinct ZR.idRegion FROM ZonaRegion AS ZR "
                    + " WHERE ZR.zona.id in (:ids) ";
            Query query = getSession().createQuery(hql);
            query.setParameterList("ids", zonasIds);
            List<String> result = query.list();
            return result;
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
	

	
	@SuppressWarnings("unchecked")
    @Override
    public List<String> getComunasIdsfromZonas(List<Zona> zonas) throws GeneralDataAccessException {
        try {
            List<Long> zonasIds = new ArrayList<Long>();
            for (Zona zona : zonas) {
                zonasIds.add(zona.getId());
            }
            
            if(zonasIds.size()==0){
            	return new ArrayList<String>();
            }
            String hql = " SELECT distinct ZR.idComuna FROM ZonaComuna AS ZR "
                    + " WHERE ZR.zona.id in (:ids) ";
            Query query = getSession().createQuery(hql);
            query.setParameterList("ids", zonasIds);
            List<String> result = query.list();
            return result;
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }
	
	
	@SuppressWarnings("unchecked")
    @Override
    public List<Integer> getLocalidadesIdsfromZonas(List<Zona> zonas) throws GeneralDataAccessException {
        try {
            List<Long> zonasIds = new ArrayList<Long>();
            for (Zona zona : zonas) {
                zonasIds.add(zona.getId());
            }
            
            String hql = " SELECT distinct ZR.idLocalidad FROM ZonaLocalidad AS ZR "
                    + " WHERE ZR.zona.id in (:ids) ";
            Query query = getSession().createQuery(hql);
            query.setParameterList("ids", zonasIds);
            List<Integer> result = query.list();
            return result;
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Zona> getAllZonas() throws GeneralDataAccessException {
        List<Zona> allzonas = new ArrayList<Zona>();
        try {
            String hql = " SELECT Z FROM Zona AS Z "
                    + "    left outer join fetch Z.tipoZona as TZ ";
            Query query = getSession().createQuery(hql);
            allzonas = query.list();
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
        return allzonas;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ZonaComuna> getAllZC() throws GeneralDataAccessException {
        List<ZonaComuna> allzonas = new ArrayList<ZonaComuna>();
        try {
            String hql = " SELECT Z FROM ZonaComuna AS Z ";
            Query query = getSession().createQuery(hql);
            allzonas = query.list();
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
        return allzonas;
    }
	
    
    @SuppressWarnings("unchecked")
    @Override
    public List<ZonaRegion> getAllZR() throws GeneralDataAccessException {
        List<ZonaRegion> allzonas = new ArrayList<ZonaRegion>();
        try {
            String hql = " SELECT Z FROM ZonaRegion AS Z ";
            Query query = getSession().createQuery(hql);
            allzonas = query.list();
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
        return allzonas;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<ZonaLocalidad> getAllZL() throws GeneralDataAccessException {
        List<ZonaLocalidad> allzonas = new ArrayList<ZonaLocalidad>();
        try {
            String hql = " SELECT Z FROM ZonaLocalidad AS Z ";
            Query query = getSession().createQuery(hql);
            allzonas = query.list();
            
        } catch (Exception e) {
            log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }
        return allzonas;
    }
}
