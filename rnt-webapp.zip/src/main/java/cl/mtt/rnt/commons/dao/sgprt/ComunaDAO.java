package cl.mtt.rnt.commons.dao.sgprt;

import java.util.List;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Localidad;

public interface ComunaDAO extends GenericDAO<Comuna> {

    /**
     * 
     * @return
     * @throws GeneralDataAccessException
     */
    List<Comuna> getAllComunas() throws GeneralDataAccessException;

    /**
     * 
     * @return
     * @throws GeneralDataAccessException
     */
    List<Localidad> getAllLocalidades() throws GeneralDataAccessException;

	
}
