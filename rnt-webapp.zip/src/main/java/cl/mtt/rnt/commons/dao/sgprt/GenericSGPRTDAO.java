package cl.mtt.rnt.commons.dao.sgprt;

import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Order;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;

/**
 * 
 * @author Federico Dukatz
 * 
 * @param <T>
 */
public interface GenericSGPRTDAO<T> {
	
	public static final String CRITERION_PREFIX_LIKE = "LIKE";
	public static final String CRITERION_PREFIX_ILIKE = "ILIKE";
	public static final String CRITERION_PREFIX_NOT_EQUALS = "NOT_EQUALS";
	public static final String CRITERION_PREFIX_EQUALS = "EQUALS";
	public static final String CRITERION_PREFIX_EQUALS_IGNORE_CASE = "EQUALS_IGNORE_CASE";
	public static final String CRITERION_PREFIX_LESS_THAN = "LESS_THAN";
	public static final String CRITERION_PREFIX_GREATER_THAN = "GREATER_THAN";
	public static final String CRITERION_PREFIX_LESS_EQUALS_THAN = "LESS_EQUALS_THAN";
	public static final String CRITERION_PREFIX_GREATER_EQUALS_THAN = "GREATER_EQUALS_THAN";


	public List<T> getAll() throws GeneralDataAccessException;

	public List<T> getAll(String orden) throws GeneralDataAccessException;

	/**
	 * Obtiene un objeto desde la Base de Datos dada su clave primaria
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public T getByPrimaryKey(Object id) throws GeneralDataAccessException;

	public List<T> findBySimpleCriteria(Map<String, Object> res) throws GeneralDataAccessException;

	public List<T> findBySimpleCriteriaOrders(Map<String, Object> res, List<Order> sortingColumns) throws GeneralDataAccessException;

}
