package cl.mtt.rnt.commons.dao.sgprt;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;

public interface TipoVehiculoSGRPTDAO extends GenericSGPRTDAO<TipoVehiculo> {

	public Integer getIdTipoServicioHomologado(String tipoDesc) throws GeneralDataAccessException;

}
