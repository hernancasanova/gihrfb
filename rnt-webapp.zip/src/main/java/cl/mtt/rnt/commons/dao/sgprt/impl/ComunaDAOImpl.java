package cl.mtt.rnt.commons.dao.sgprt.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.impl.GenericDAOImpl;
import cl.mtt.rnt.commons.dao.sgprt.ComunaDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Localidad;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class ComunaDAOImpl extends GenericDAOImpl<Comuna> implements ComunaDAO {

	Logger log = Logger.getLogger(this.getClass());

	public ComunaDAOImpl(Class<Comuna> objectType) {
		super(objectType);

	}
	
	@SuppressWarnings("unchecked")
    @Override
    public List<Comuna> getAllComunas() throws GeneralDataAccessException {
	    List<Comuna> resultados = new ArrayList<Comuna>();
        try {
            String hql = "SELECT C FROM Comuna AS C "
                    + " inner join fetch C.provincia AS P "
                    + " inner join fetch P.region AS R";
            
            Query query = getSession().createQuery(hql);
            resultados = (List<Comuna>) query.list();

        } catch (Exception e) {
            log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }

        return resultados;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Localidad> getAllLocalidades() throws GeneralDataAccessException {
        List<Localidad> resultados = new ArrayList<Localidad>();
        try {
            String hql = "SELECT L FROM Localidad AS L"
                    + " inner join fetch L.comuna AS C "
                    + " inner join fetch C.provincia AS P "
                    + " inner join fetch P.region AS R";
            
            Query query = getSession().createQuery(hql);
            resultados = (List<Localidad>) query.list();

        } catch (Exception e) {
            log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
            throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
        }

        return resultados;
    }


}
