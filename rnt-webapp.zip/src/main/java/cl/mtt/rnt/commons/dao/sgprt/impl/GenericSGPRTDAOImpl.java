package cl.mtt.rnt.commons.dao.sgprt.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import cl.mtt.rnt.commons.dao.impl.GenericDAOImpl;
import cl.mtt.rnt.commons.dao.sgprt.GenericSGPRTDAO;
import cl.mtt.rnt.commons.exception.CriteriaDefinitionException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class GenericSGPRTDAOImpl<T> extends HibernateDaoSupport implements GenericSGPRTDAO<T> {

	protected Class<T> objectType;

	Logger log = Logger.getLogger(this.getClass());

	// defino un valor que nunca aparezca en un campo, para poder buscar por NOT
	// NULL
	//TODO este sistema esta deprecado, ver GenericDAOImpl
//	public static final String IS_NOT_NULL = "<** IS_NOT_NULL **>";

	
	private static final Set<String> CRITERION_PREFIX_MAP;
    static {
    	CRITERION_PREFIX_MAP = new HashSet<String>();
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_LIKE);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_ILIKE);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_NOT_EQUALS);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_EQUALS);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_EQUALS_IGNORE_CASE);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_LESS_THAN);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_GREATER_THAN);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_LESS_EQUALS_THAN);
    	CRITERION_PREFIX_MAP.add(CRITERION_PREFIX_GREATER_EQUALS_THAN);
    }
    

	public GenericSGPRTDAOImpl(Class<T> objectType) {
		this.objectType = objectType;
	}

	@SuppressWarnings("unchecked")
	public List<T> getAll() throws GeneralDataAccessException {
		try {
			// getSession().setFlushMode(FlushMode.MANUAL);
			return getHibernateTemplate().find("from " + objectType.getSimpleName());

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	@SuppressWarnings("unchecked")
	public List<T> getAll(String orden) throws GeneralDataAccessException {
		try {
			Criteria cri = getSession().createCriteria(objectType);
			Order odenamiento = Order.asc(orden);
			cri.addOrder(odenamiento);
			List<T> ret = cri.list();
			if (ret == null) {
				ret = new ArrayList<T>();
			}
			return ret;

		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
	}

	@SuppressWarnings("unchecked")
	public T getByPrimaryKey(Object id) throws GeneralDataAccessException {
		T returnValue = null;
		// getSession().setFlushMode(FlushMode.MANUAL);
		try {
			returnValue = (T) getHibernateTemplate().get(objectType.getName(), (Serializable) id);

		} catch (DataAccessException e) {

			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		} catch (NumberFormatException e) {//workarround para was
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return returnValue;
	}

//	private String getPrefix(String column) {
//		if (column.contains(".")) {
//			return column.substring(0, column.indexOf('.'));
//		}
//		return column;
//	}
//
//	protected String generateAlias(Criteria criteria, String column) {
//		// Si hay un campo de profundidad mayor a uno (ej: 'domicilio.calle'),
//		// hay que hacer un alias. fuentes:
//		// http://forum.hibernate.org/viewtopic.php?p=2375242 y
//		// http://www.forodejava.com/showthread.php?t=162
//		if (column.contains(".")) {
//			String prefix = column.substring(0, column.indexOf('.'));
//			long rand = Math.round(Math.random() * 100000);
//			criteria.createAlias(prefix, rand + prefix, criteria.LEFT_JOIN);
//			return rand + column;
//		}
//		return column;
//	}
//
//	protected String generateAlias(Criteria criteria, String column, Map<String, String> aliases) {
//		// Si hay un campo de profundidad mayor a uno (ej: 'domicilio.calle'),
//		// hay que hacer un alias. fuentes:
//		// http://forum.hibernate.org/viewtopic.php?p=2375242 y
//		// http://www.forodejava.com/showthread.php?t=162
//		String ret = "";
//		String key = "";
//		String postfix = new String(column);
//		while (postfix.contains(".")) {
//			String prefix = postfix.substring(0, postfix.indexOf('.'));
//			postfix = postfix.substring(postfix.indexOf('.') + 1);
//			String lastAlias = "";
//			if (!aliases.containsKey(key + ("".equals(key) ? "" : ".") + prefix)) {
//				long rand = Math.round(Math.random() * 100000);
//				lastAlias = rand + prefix;
//				criteria.createAlias(ret + ("".equals(ret) ? "" : ".") + prefix, lastAlias, criteria.INNER_JOIN);
//				aliases.put(key + ("".equals(key) ? "" : ".") + prefix, lastAlias);
//			} else {
//				lastAlias = aliases.get(key + ("".equals(key) ? "" : ".") + prefix);
//			}
//			if (!postfix.contains("."))
//				return lastAlias + "." + postfix;
//			else {
//				ret += ("".equals(ret) ? "" : ".") + lastAlias;
//				key += ("".equals(key) ? "" : ".") + prefix;
//			}
//		}
//		return column;
//	}
//
//	private Criterion getCriterion(Criteria criteria, Map<String, Object> res, Map<String, String> aliases) {
//		Criterion criterion = null;
//
//		for (Iterator iter = res.keySet().iterator(); iter.hasNext();) {
//			String name = (String) iter.next();
//			String alias = aliases.get(getPrefix(name));
//			String field = "";
//			if (alias == null) {
//				field = generateAlias(criteria, name, aliases);
//				// aliases.put(getPrefix(name), field);//lo hace generateAlias
//			} else {
//				field = getPrefix(alias) + name.substring(name.lastIndexOf('.'));
//			}
//			Criterion cr = null;
//			if (res.get(name) != null) {
//				if (res.get(name).equals(GenericSGPRTDAOImpl.IS_NOT_NULL)) {
//					cr = Restrictions.isNotNull(name);
//				} else if (res.get(name) instanceof Collection) {
//					Collection coll = (Collection) res.get(name);
//					cr = Restrictions.in(field, coll);
//				} else
//					cr = Restrictions.eq(field, res.get(name));
//			} else
//				cr = Restrictions.isNull(name);
//			criterion = (criterion == null) ? cr : Restrictions.and(criterion, cr);
//		}
//		return criterion;
//	}
//
//	private Criteria getCriteria(Map<String, Object> res) {
//		Criteria criteria = getSession().createCriteria(objectType);
//		Map<String, String> aliases = new HashMap<String, String>();
//		Criterion cr = getCriterion(criteria, res, aliases);
//		if (cr != null)
//			criteria.add(cr);
//		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
//		return criteria;
//	}

	private String getPrefix(String column) {
		if (column.contains(".")) {
			return column.substring(0, column.lastIndexOf('.'));
		}
		return column;
	}

	private String getOperationPrefix(String column) {
		if (column.contains(".")) {
			return column.substring(0, column.indexOf('.'));
		}
		return column;
	}
	
	protected String generateAlias(Criteria criteria, String column, Map<String, String> aliases,int joinType) {
		// Si hay un campo de profundidad mayor a uno (ej: 'domicilio.calle'),
		// hay que hacer un alias. fuentes:
		// http://forum.hibernate.org/viewtopic.php?p=2375242 y
		// http://www.forodejava.com/showthread.php?t=162
		String ret = "";
		String key = "";
		String postfix = new String(column);
		while (postfix.contains(".")) {
			String prefix = postfix.substring(0, postfix.indexOf('.'));
			postfix = postfix.substring(postfix.indexOf('.') + 1);
			String lastAlias = "";
			if (!aliases.containsKey(key + ("".equals(key) ? "" : ".") + prefix)) {
				long rand = Math.round(Math.random() * 100000);
				lastAlias = rand + prefix;
				criteria.createAlias(ret + ("".equals(ret) ? "" : ".") + prefix, lastAlias, joinType);
				aliases.put(key + ("".equals(key) ? "" : ".") + prefix, lastAlias);
			} else {
				lastAlias = aliases.get(key + ("".equals(key) ? "" : ".") + prefix);
			}
			if (!postfix.contains("."))
				return lastAlias + "." + postfix;
			else {
				ret += ("".equals(ret) ? "" : ".") + lastAlias;
				key += ("".equals(key) ? "" : ".") + prefix;
			}
		}
		return column;
	}

	protected String generateAlias(Criteria criteria, String column, Map<String, String> aliases) {
		return generateAlias(criteria, column, aliases,Criteria.INNER_JOIN);
	}
	
	private Criterion getCriterion(Criteria criteria, Map<String, Object> res, Map<String, String> aliases) throws CriteriaDefinitionException {
		Criterion criterion = null;

		for (Iterator iter = res.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String column = new String(name);
			String prefixOperation = getOperationPrefix(column);
			if(CRITERION_PREFIX_MAP.contains(prefixOperation)){
				column = column.replaceFirst(prefixOperation+".", "");
			} else {
				prefixOperation = CRITERION_PREFIX_EQUALS;
			}
			String alias = aliases.get(getPrefix(column));
			String field = "";
			if (alias == null) {
				field = generateAlias(criteria, column, aliases);
				// aliases.put(getPrefix(name), field);//lo hace generateAlias
			} else {
				field = getPrefix(alias) + column.substring(column.lastIndexOf('.'));
			}
			Criterion cr = null;
			if (res.get(name) != null) {
//				if (res.get(name).equals(GenericDAOImpl.IS_NOT_NULL)) {
//					cr = Restrictions.isNotNull(name);
//				} else 
				if (res.get(name) instanceof Collection) {
					Collection coll = (Collection) res.get(name);
					if (coll.isEmpty()){
						throw new CriteriaDefinitionException("Empty Collection in Criteria");
					}
					if (CRITERION_PREFIX_EQUALS.equals(prefixOperation)){
						cr = Restrictions.in(field, coll);
					}else{
						cr = Restrictions.not(Restrictions.in(field, coll));
					}
				} else {
					if (CRITERION_PREFIX_EQUALS.equals(prefixOperation)){
						cr = Restrictions.eq(field, res.get(name));
					} else if (CRITERION_PREFIX_NOT_EQUALS.equals(prefixOperation)){
						cr = Restrictions.ne(field, res.get(name));
					} else if (CRITERION_PREFIX_EQUALS_IGNORE_CASE.equals(prefixOperation)){
						cr = Restrictions.ilike(field,res.get(name));
					} else if (CRITERION_PREFIX_LIKE.equals(prefixOperation)){
						cr = Restrictions.like(field, "%"+res.get(name)+"%");
					} else if (CRITERION_PREFIX_ILIKE.equals(prefixOperation)){
						cr = Restrictions.ilike(field, "%"+res.get(name)+"%");
					} else if (CRITERION_PREFIX_LESS_THAN.equals(prefixOperation)){
						cr = Restrictions.lt(field, res.get(name));
					} else if (CRITERION_PREFIX_GREATER_THAN.equals(prefixOperation)){
						cr = Restrictions.gt(field, res.get(name));
					} else if (CRITERION_PREFIX_LESS_EQUALS_THAN.equals(prefixOperation)){
						cr = Restrictions.le(field, res.get(name));
					} else if (CRITERION_PREFIX_GREATER_EQUALS_THAN.equals(prefixOperation)){
						cr = Restrictions.ge(field, res.get(name));
					}
				}
			} else {
				if (CRITERION_PREFIX_EQUALS.equals(prefixOperation))
					cr = Restrictions.isNull(field);
				else
					cr = Restrictions.isNotNull(field);
			}
			criterion = (criterion == null) ? cr : Restrictions.and(criterion, cr);
		}
		return criterion;
	}
	private Criteria getCriteria(Map<String, Object> res, List<Map<String, Object>> optRes) throws CriteriaDefinitionException {
		if (optRes == null || optRes.size() == 0)
			return getCriteria(res);

		Criteria criteria = getSession().createCriteria(objectType);
		Map<String, String> aliases = new HashMap<String, String>();
		Criterion optCriterion = null;
		for (Map<String, Object> map : optRes) {
			Criterion cr = getCriterion(criteria, map, aliases);
			optCriterion = (optCriterion == null) ? cr : Restrictions.or(optCriterion, cr);
		}

		if (res != null && res.size() > 0)
			criteria.add(Restrictions.and(getCriterion(criteria, res, aliases), optCriterion));
		else
			criteria.add(optCriterion);

		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		return criteria;
	}
	
	private Criteria getCriteria(Map<String, Object> res) throws CriteriaDefinitionException {
		Criteria criteria = getSession().createCriteria(objectType);
		Map<String, String> aliases = new HashMap<String, String>();
		Criterion cr = getCriterion(criteria, res, aliases);
		if (cr != null)
			criteria.add(cr);
		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		return criteria;
	}

	@SuppressWarnings("unchecked")
	public List<T> findBySimpleCriteria(Map<String, Object> res) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			Criteria criteria = this.getCriteria(res);

			// Se agrego la conversion por medio de setResultTransformer ya que
			// recuperaba instancias duplicadas de la variable
			result = criteria.list();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	public List<T> findBySimpleCriteriaOrders(Map<String, Object> res, List<Order> ordenamientos) throws GeneralDataAccessException {
		// getSession().setFlushMode(FlushMode.MANUAL);
		List<T> result = new ArrayList<T>();
		try {
			Criteria criteria = this.getCriteria(res);
			for (Order order : ordenamientos) {
				criteria = criteria.addOrder(order);
			}
			// Se agrego la conversion por medio de setResultTransformer ya que
			// recuperaba instancias duplicadas de la variable
			result = criteria.list();
		} catch (DataAccessException e) {
			log.error(GeneralDataAccessException.GET_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.GET_ERROR, e);
		}
		return result;
	}

}
