package cl.mtt.rnt.commons.dao.sgprt.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;

import cl.mtt.rnt.commons.dao.sgprt.TipoVehiculoSGRPTDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;
import cl.mtt.rnt.commons.util.StackTraceUtil;

public class TipoVehiculoSGRPTDAOImpl extends GenericSGPRTDAOImpl<TipoVehiculo> implements TipoVehiculoSGRPTDAO {

	Logger log = Logger.getLogger(this.getClass());

	public TipoVehiculoSGRPTDAOImpl(Class<TipoVehiculo> objectType) {
		super(objectType);

	}

	@SuppressWarnings("rawtypes")
	@Override
	public Integer getIdTipoServicioHomologado(String tipoDesc) throws GeneralDataAccessException {

		try {
			String sql = "SELECT ID from nullid.TIPOVEHICULO ts where ts.DESCRIPCION = '" + tipoDesc + "'";
			Query query = getSession().createSQLQuery(sql);
			List resultset = query.list();
			for (Object datoPlano : resultset) {
				Integer dato = (Integer) datoPlano;
				return dato;
			}
		} catch (Exception e) {
			log.error(GeneralDataAccessException.SAVE_ERROR + "\n" + StackTraceUtil.getStackTraceString(e));
			throw new GeneralDataAccessException(GeneralDataAccessException.SAVE_ERROR, e);
		}

		return null;
	}

}
