package cl.mtt.rnt.commons.exception;

public class CertificadoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5871923558274961052L;

	public CertificadoException(String msg) {
		super(msg);
	}

	public CertificadoException(String msg, Throwable cause) {
		super(msg, cause);
	}
}