package cl.mtt.rnt.commons.exception;

public class CertificadoNotFoundException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -7955299563927610822L;

}
