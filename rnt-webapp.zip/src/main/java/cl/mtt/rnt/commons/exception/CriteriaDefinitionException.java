package cl.mtt.rnt.commons.exception;

public class CriteriaDefinitionException extends GeneralDataAccessException {

	private static final long serialVersionUID = 1L;

	public CriteriaDefinitionException(String msg) {
		super(msg);
	}

	public CriteriaDefinitionException(String msg, Throwable cause) {
		super(msg, cause);
	}
}