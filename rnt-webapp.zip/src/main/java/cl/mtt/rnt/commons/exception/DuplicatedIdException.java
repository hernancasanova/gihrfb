package cl.mtt.rnt.commons.exception;

/**
 * 
 * Esta clase representa la excepcion de guardar dos elementos en la misma tabla
 * que tengan el mismo identificador o mismo valores para el caso de tipo de
 * servicio.
 */

public class DuplicatedIdException extends Exception {

	private static final long serialVersionUID = 1L;
	public final static String DUPLICATE_USER_ERROR = "DUPLICATED_USER_ERROR";
	public final static String DUPLICATE_ROLE_ERROR = "DUPLICATED_ROLE_ERROR";
	public final static String DUPLICATE_TIPO_SERVICIO_ERROR = "DUPLICATED_TIPO_SERVICIO_ERROR";
	public final static String DUPLICATE_TIPO_TRANSPORTE = "DUPLICATE_TIPO_TRANSPORTE";
	public final static String DUPLICATE_TIPO_SERVICIO_AREA = "DUPLICATE_TIPO_SERVICIO_AREA";
	public final static String DUPLICATE_MODALIDAD = "DUPLICATE_MODALIDAD";
	public final static String DUPLICATE_MEDIO_TRANSPORTE = "DUPLICATE_MEDIO_TRANSPORTE";
	public final static String DUPLICATE_CATEGORIA_TRANSPORTE = "DUPLICATE_CATEGORIA_TRANSPORTE";
	public final static String DUPLICATE_TERMINAL = "DUPLICATE_TERMINAL";
	public final static String DUPLICATE_ZONA = "DUPLICATE_ZONA";
	public final static String DUPLICATE_TIPO_CERTIFICADO = "DUPLICATE_TIPO_CERTIFICADO";
	public static final String DUPLICATE_PERSONA_RUT = "DUPLICATE_PERSONA_RUT";
	public static final String DUPLICATE_TIPO_VEHICULO_SERVICIO = "DUPLICATE_TIPO_VEHICULO_SERVICIO";
	public static final String DUPLICATE_OFICINA_VENTA_PASAJE = "DUPLICATE_OFICINA_VENTA_PASAJE";
	public static final String DUPLICATE_OFICINA_VENTA_PASAJE_SERV = "DUPLICATE_OFICINA_VENTA_PASAJE_SERVICIO";

	public DuplicatedIdException(String msg) {
		super(msg);
	}

	public DuplicatedIdException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
