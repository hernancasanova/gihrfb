package cl.mtt.rnt.commons.exception;

import cl.mtt.rnt.admin.reglamentacion.GenericNormativa;

public class EventEvalException extends Exception {

	private static final long serialVersionUID = 1L;

	GenericNormativa norma;
	
	public EventEvalException(String msg,GenericNormativa gn) {
		super(msg);
		this.norma = gn;
	}

	public EventEvalException(String msg, Throwable cause,GenericNormativa gn) {
		super(msg, cause);
		this.norma = gn;
	}

	/**
	 * @return el valor de norma
	 */
	public GenericNormativa getNorma() {
		return norma;
	}

	/**
	 * @param setea el parametro norma al campo norma
	 */
	public void setNorma(GenericNormativa norma) {
		this.norma = norma;
	}

}