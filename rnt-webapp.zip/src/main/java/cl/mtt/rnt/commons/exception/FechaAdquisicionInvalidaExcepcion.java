package cl.mtt.rnt.commons.exception;

public class FechaAdquisicionInvalidaExcepcion extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2154304114842904468L;

}
