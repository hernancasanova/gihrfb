package cl.mtt.rnt.commons.exception;

public class GeneralDataAccessException extends Exception {

	public final static String SAVE_ERROR = "SAVE_ERROR";
	public final static String UPDATE_ERROR = "UPDATE_ERROR";
	public final static String DELETE_ERROR = "DELETE_ERROR";
	public final static String GET_ERROR = "GET_ERROR";

	private static final long serialVersionUID = 1L;

	public GeneralDataAccessException(String msg) {
		super(msg);
	}

	public GeneralDataAccessException(String msg, Throwable cause) {
		super(msg, cause);
	}

    public GeneralDataAccessException(Exception e) {
        super(e);
    }

}