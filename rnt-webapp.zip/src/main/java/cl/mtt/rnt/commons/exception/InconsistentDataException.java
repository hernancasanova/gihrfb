package cl.mtt.rnt.commons.exception;

/**
 * Esta clase representa la excepción de que datos inconsistentes, por ejemplo
 * que un usuario malintencionado modifique datos que se envian desde la página
 * ingresando datos que no existen.
 * 
 * @author Marina Chobadindegui - BISion
 * 
 */
public class InconsistentDataException extends Exception {

	private static final long serialVersionUID = 1L;
	public final static String DATOS_INCONSISTENTES_ERROR = "INCONSISTENT_DATA_ERROR";
	public static final String INVALID_CHARACTER_ERROR = "INVALID_CHARACTER_ERROR";

	public InconsistentDataException() {
	}

	public InconsistentDataException(String msg) {
		super(msg);
	}

	public InconsistentDataException(String msg, Throwable cause) {
		super(msg, cause);
	}
}