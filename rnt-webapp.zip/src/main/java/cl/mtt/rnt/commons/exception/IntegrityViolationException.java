package cl.mtt.rnt.commons.exception;

public class IntegrityViolationException extends GeneralDataAccessException {

	private static final long serialVersionUID = 1L;

	public IntegrityViolationException(String msg) {
		super(msg);
	}

	public IntegrityViolationException(String msg, Throwable cause) {
		super(msg, cause);
	}
}