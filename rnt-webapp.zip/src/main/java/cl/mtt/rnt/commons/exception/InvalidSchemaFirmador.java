package cl.mtt.rnt.commons.exception;

public class InvalidSchemaFirmador extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2288260529882136212L;

}
