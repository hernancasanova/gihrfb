package cl.mtt.rnt.commons.exception;

public class InvalidUploadAlfrescoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -75914013238165718L;
	private String status;
	private String description;

	public InvalidUploadAlfrescoException(String status, String description) {
		this.status = status;
		this.description = description;
	}

	/**
	 * @return el valor de status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param setea el parametro status al campo status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return el valor de description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param setea el parametro description al campo description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	
}
