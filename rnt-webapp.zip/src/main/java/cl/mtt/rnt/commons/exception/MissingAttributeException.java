package cl.mtt.rnt.commons.exception;

public class MissingAttributeException extends Exception {

	private static final long serialVersionUID = 1L;

	public MissingAttributeException(String msg) {
		super(msg);
	}

	public MissingAttributeException(String msg, Throwable cause) {
		super(msg, cause);
	}

}