package cl.mtt.rnt.commons.exception;

public class NoTrazadosException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2073346217973216527L;

}
