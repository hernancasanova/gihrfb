package cl.mtt.rnt.commons.exception;

public class PersonDeadException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 611755280823534349L;

	public PersonDeadException(String msg) {
		super(msg);
	}

	public PersonDeadException(String msg, Throwable throwable) {
		super(msg, throwable);
	}

}
