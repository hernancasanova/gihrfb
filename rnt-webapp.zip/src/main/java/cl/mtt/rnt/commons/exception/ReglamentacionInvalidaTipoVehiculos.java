package cl.mtt.rnt.commons.exception;

import cl.mtt.rnt.commons.util.Resources;

public class ReglamentacionInvalidaTipoVehiculos extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4554678278223481757L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return Resources.getString("reglamentacion.error.tipovehiculo.noreglamenta");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Throwable#getLocalizedMessage()
	 */
	@Override
	public String getLocalizedMessage() {
		return getMessage();
	}

}
