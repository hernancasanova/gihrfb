package cl.mtt.rnt.commons.exception;

public class ReglamentacionNoVigenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5871923558274961052L;

	public ReglamentacionNoVigenteException(String msg) {
		super(msg);
	}

	public ReglamentacionNoVigenteException(String msg, Throwable cause) {
		super(msg, cause);
	}
}