package cl.mtt.rnt.commons.exception;

public class RemoveNotAllowedException extends Exception {

	private static final long serialVersionUID = 1L;

	public final static String REMOVE_TIPO_SERVICIO_ERROR = "REMOVE_TIPO_SERVICIO_ERROR";
	public final static String REMOVE_CATEGORIA_TRANSPORTE_ERROR = "REMOVE_CATEGORIA_TRANSPORTE_ERROR";
	public final static String REMOVE_MEDIO_TRANSPORTE_ERROR = "REMOVE_MEDIO_TRANSPORTE_ERROR";
	public final static String REMOVE_MODALIDAD_TRANSPORTE_ERROR = "REMOVE_MODALIDAD_TRANSPORTE_ERROR";
	public final static String REMOVE_TIPO_SERVICIO_AREA_ERROR = "REMOVE_TIPO_SERVICIO_AREA_ERROR";
	public final static String REMOVE_TIPO_TRANSPORTE_ERROR = "REMOVE_TIPO_TRANSPORTE_ERROR";
	public final static String REMOVE_TERMINAL_ERROR = "REMOVE_TERMINAL_ERROR";
	public final static String REMOVE_ZONA_ERROR = "REMOVE_ZONA_ERROR";
	public final static String REMOVE_TIPO_CERTIFICADO_ERROR = "REMOVE_TIPO_CERTIFICADO_ERROR";
	public final static String REMOVE_TIPO_VEHICULO_SERVICIO_ERROR = "REMOVE_TIPO_VEHICULO_SERVICIO_ERROR";
	public final static String REMOVE_GREMIO_ERROR = "REMOVE_GREMIO_ERROR";

	public RemoveNotAllowedException(String msg) {
		super(msg);
	}

	public RemoveNotAllowedException(String msg, Throwable cause) {
		super(msg, cause);
	}
}