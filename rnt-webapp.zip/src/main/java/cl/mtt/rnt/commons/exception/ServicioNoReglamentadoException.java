package cl.mtt.rnt.commons.exception;

public class ServicioNoReglamentadoException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -5484236612433489052L;

}
