package cl.mtt.rnt.commons.exception;

import cl.mtt.rnt.commons.util.Resources;

public class SinCertificadoCancelacionException extends Exception {



	/**
	 * 
	 */
	private static final long serialVersionUID = -6162148583607874048L;

	public SinCertificadoCancelacionException() {
		super(Resources.getString("error.certificado.cancelacion.inexistente"));
	}

	public SinCertificadoCancelacionException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
