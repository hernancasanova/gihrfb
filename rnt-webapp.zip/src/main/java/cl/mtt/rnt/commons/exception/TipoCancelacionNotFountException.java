package cl.mtt.rnt.commons.exception;

public class TipoCancelacionNotFountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5026812411546542072L;

}
