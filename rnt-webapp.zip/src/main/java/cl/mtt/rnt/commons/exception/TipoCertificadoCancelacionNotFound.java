package cl.mtt.rnt.commons.exception;

public class TipoCertificadoCancelacionNotFound extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -7555681422029662075L;
    private String ppu;
    
    public TipoCertificadoCancelacionNotFound(String ppu) {
        this.ppu = ppu;
    }

    /**
     * @return el valor de ppu
     */
    public String getPpu() {
        return ppu;
    }

    /**
     * @param setea el parametro ppu al campo ppu
     */
    public void setPpu(String ppu) {
        this.ppu = ppu;
    }

}
