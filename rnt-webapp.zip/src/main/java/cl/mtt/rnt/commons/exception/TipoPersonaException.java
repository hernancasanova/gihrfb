package cl.mtt.rnt.commons.exception;

/**
 * 
 * Esta clase representa la excepcion de guardar dos elementos en la misma tabla
 * que tengan el mismo identificador o mismo valores para el caso de tipo de
 * servicio.
 */

public class TipoPersonaException extends Exception {

	private static final long serialVersionUID = 1L;

	public TipoPersonaException(String msg) {
		super(msg);
	}

	public TipoPersonaException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
