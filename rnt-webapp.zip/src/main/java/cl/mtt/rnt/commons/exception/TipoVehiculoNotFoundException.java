package cl.mtt.rnt.commons.exception;

public class TipoVehiculoNotFoundException extends Exception {

    public TipoVehiculoNotFoundException() {
        super();
    }
    
	public TipoVehiculoNotFoundException(String string) {
        super(string);
    }

    /**
	 * 
	 */
	private static final long serialVersionUID = -4121294540201080920L;

}
