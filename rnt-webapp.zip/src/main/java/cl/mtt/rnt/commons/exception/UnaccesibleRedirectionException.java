package cl.mtt.rnt.commons.exception;

public class UnaccesibleRedirectionException extends Exception {

	public UnaccesibleRedirectionException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -679704893797396338L;

}
