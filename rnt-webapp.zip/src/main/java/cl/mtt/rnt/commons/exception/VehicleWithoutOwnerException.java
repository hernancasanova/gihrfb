package cl.mtt.rnt.commons.exception;

public class VehicleWithoutOwnerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5940773158585041809L;

	public VehicleWithoutOwnerException(String msg) {
		super(msg);
	}

	public VehicleWithoutOwnerException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
