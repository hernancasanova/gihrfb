package cl.mtt.rnt.commons.exception;

public class VehiculoNoReglamentadoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5871923558274961052L;

	public VehiculoNoReglamentadoException(String msg) {
		super(msg);
	}

	public VehiculoNoReglamentadoException(String msg, Throwable cause) {
		super(msg, cause);
	}
}