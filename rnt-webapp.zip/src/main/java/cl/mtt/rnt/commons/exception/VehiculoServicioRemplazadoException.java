package cl.mtt.rnt.commons.exception;

public class VehiculoServicioRemplazadoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5660988472781558054L;
	
	public VehiculoServicioRemplazadoException(String msg) {
		super(msg);
	}

	public VehiculoServicioRemplazadoException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
