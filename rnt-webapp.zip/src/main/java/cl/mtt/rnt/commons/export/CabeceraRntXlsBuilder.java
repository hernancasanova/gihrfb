package cl.mtt.rnt.commons.export;

import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;

import cl.mtt.rnt.commons.util.Resources;

public class CabeceraRntXlsBuilder {
    
    private static final int COLUMN_WIDTH_NORMAL = 3700;
    private static final int COLUMN_WIDTH_SHORT = 1230;
    
    
    public static HSSFSheet getHojaConCabecera(HSSFWorkbook libro,XLSCellStyleSetter styleMgr, String nombreHoja, String tituloRep) {
        HSSFSheet hoja = libro.createSheet(nombreHoja);
        hoja.setColumnWidth(1,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(2,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(3,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(4,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(5,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(6,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(7,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(8,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(9,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(10,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(11,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(12,COLUMN_WIDTH_NORMAL );
        hoja.setColumnWidth(13,COLUMN_WIDTH_NORMAL );
        
        HSSFRow fila = hoja.createRow(0);
        HSSFCell celda = fila.createCell(1);
        styleMgr.setStyleHeaderTitle(celda);
        celda.setCellValue(Resources.getString("export.xls.header.mtt"));
        
//        celda = fila.createCell(10);
//        styleMgr.setStyleHeaderTitle(celda);
//        celda.setCellValue(Resources.getString("export.xls.header.pag")+ "  :") ;
        
//        celda = fila.createCell(11);
//        styleMgr.setStyleHeaderTitle(celda);
//        celda.setCellValue(1) ;
//        hoja.addMergedRegion(new CellRangeAddress(fila.getRowNum(),fila.getRowNum(),celda.getColumnIndex(),celda.getColumnIndex()+2));
        
        fila = hoja.createRow(1);
        celda = fila.createCell(1);
        styleMgr.setStyleHeaderTitle(celda);
        celda.setCellValue(Resources.getString("export.xls.header.mtt.rnt"));
        
        celda = fila.createCell(10);
        styleMgr.setStyleHeaderTitle(celda);
        celda.setCellValue(Resources.getString("export.xls.header.fec")+ "  :") ;
        
        celda = fila.createCell(11);
        styleMgr.setStyleHeaderTitleDate(celda);
        celda.setCellValue(new Date());
        hoja.addMergedRegion(new CellRangeAddress(fila.getRowNum(),fila.getRowNum(),celda.getColumnIndex(),celda.getColumnIndex()+2));
        
        
        fila = hoja.createRow(2);
        celda = fila.createCell(1);
        styleMgr.setStyleHeaderTitle(celda);
        celda.setCellValue(Resources.getString("export.xls.header.mtt.rnt2"));
        
        
        //---------------------------TITULO
        
        fila = hoja.createRow(4);
        celda = fila.createCell(4);
        styleMgr.setStyleHeaderTitleCenterd(celda);
        celda.setCellValue(tituloRep);
        hoja.addMergedRegion(new CellRangeAddress(fila.getRowNum(),fila.getRowNum(),celda.getColumnIndex(),celda.getColumnIndex()+4));
        
       

        return hoja;
    }
}
