package cl.mtt.rnt.commons.export;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;

import cl.mtt.rnt.commons.util.ElResolver;



public class XLSCellStyleSetter {
    
    
    private HSSFWorkbook workBook;
    private HSSFCellStyle headerTitle;
    private HSSFCellStyle headerTable;
    private HSSFCellStyle headerTitleDate;
    private HSSFCellStyle simpleText;
    private HSSFCellStyle simpleTextCentered;
    private HSSFCellStyle simpleTextDate;
    private HSSFCellStyle simpleTextFloat;
    private HSSFCellStyle headerTableCentered;
    private HSSFCellStyle simpleTextHour;
    private HSSFCellStyle headerTitleCentered;

    
    
    public XLSCellStyleSetter(HSSFWorkbook workBook) {
        this.workBook = workBook;
        this.headerTitle = createHeaderTitle();
        headerTitleCentered  = createHeaderTitleCentered();
        this.headerTitleDate = createHeaderTitleDate();
        this.headerTable = createHeaderTable();
        this.headerTableCentered = createHeaderTableCentered();
        simpleTextDate = createSimleTextDate();
        simpleTextFloat = createSimleTextFloat();
        simpleText = createSimpleText();
        simpleTextCentered = createSimpleTextCentered();
        simpleTextHour = createSimleTextHour();
        
    }
    
    
    private HSSFCellStyle createSimleTextHour() {
        HSSFCellStyle simple = workBook.createCellStyle();
        simple.setDataFormat(HSSFDataFormat.getBuiltinFormat("h:mm"));
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 9);  
        simple.setFont(font);  
        return simple;
    }
    
    private HSSFCellStyle createSimleTextFloat() {
        HSSFCellStyle simple = workBook.createCellStyle();
        Locale requestLocale = ElResolver.getRequestLocale();
        DecimalFormat format=(DecimalFormat) DecimalFormat.getInstance(requestLocale);
        format.setMaximumFractionDigits(3);
        DecimalFormatSymbols symbols=format.getDecimalFormatSymbols();
        char sep=symbols.getDecimalSeparator();
        simple.setDataFormat(HSSFDataFormat.getBuiltinFormat("0"+sep+"##0"));
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 9);  
        simple.setFont(font);  
        return simple;
    }

    private HSSFCellStyle createSimleTextDate() {
        HSSFCellStyle simple = workBook.createCellStyle();
        simple.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 9);  
        simple.setFont(font);  
        return simple;
    }

    private HSSFCellStyle createSimpleText() {
        HSSFCellStyle simple = workBook.createCellStyle();
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 9);  
        simple.setFont(font);  
        return simple;
    }
    

    private HSSFCellStyle createSimpleTextCentered() {
        HSSFCellStyle simple = workBook.createCellStyle();
        simple.setAlignment(CellStyle.ALIGN_CENTER);
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 9);  
        simple.setFont(font);  
        return simple;
    }

    private HSSFCellStyle createHeaderTitle() {
        HSSFCellStyle headerTitle = workBook.createCellStyle();
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 10);  
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);  
        headerTitle.setFont(font);  
        return headerTitle;
    }
    
    private HSSFCellStyle createHeaderTitleCentered() {
        HSSFCellStyle headerTitle = workBook.createCellStyle();
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 10);  
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);  
        headerTitle.setFont(font);  
        return headerTitle;
    }
    
    private HSSFCellStyle createHeaderTable() {
        HSSFCellStyle headerTable = workBook.createCellStyle();
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 10);  
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);  
        headerTable.setFont(font);  
        return headerTable;
    }
    
    private HSSFCellStyle createHeaderTableCentered() {
        HSSFCellStyle headerTable = workBook.createCellStyle();
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 10);  
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);  
        headerTable.setFont(font);  
        headerTable.setAlignment(CellStyle.ALIGN_CENTER);
        return headerTable;
    }
    
    private HSSFCellStyle createHeaderTitleDate() {
        HSSFCellStyle headerTitle = workBook.createCellStyle();
        headerTitle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));
        Font font = workBook.createFont();
        font.setFontHeightInPoints((short) 10);  
        headerTitle.setFont(font);  
        return headerTitle;
    }

    public HSSFCell setStyleHeaderTitle(HSSFCell acell) {
        acell.setCellStyle(headerTitle);
        return acell;
    }
    
    public HSSFCell setStyleHeaderTitleCenterd(HSSFCell acell) {
        acell.setCellStyle(headerTitleCentered);
        return acell;
    }
    
    public HSSFCell setStyleHeaderTitleDate(HSSFCell acell) {
        acell.setCellStyle(headerTitleDate);
        return acell;
    }

    public HSSFCell setStyleSimpleText(HSSFCell acell) {
        acell.setCellStyle(simpleText);
        return acell;
        
    }
    
    public HSSFCell setStyleSimpleTextDate(HSSFCell acell) {
        acell.setCellStyle(simpleTextDate);
        return acell;
        
    }
    
    public HSSFCell setStyleSimpleTextFloat(HSSFCell acell) {
        acell.setCellStyle(simpleTextFloat);
        return acell;
        
    }
    
    /**
     * Retorna la celda cargada con el valor, para aislar el tiempo es necesario aplicar Formula
     * @param acell  formato hh:mm
     * @param value
     * @return
     */
    public HSSFCell setStyleSimpleTextHour(HSSFCell acell,String value) {
        String[] datosTime = value.split(":");
        acell.setCellFormula("TIME("+ datosTime[0] + "," + datosTime[1] + ",00)"); 
        acell.setCellType(Cell.CELL_TYPE_FORMULA);
        acell.setCellStyle(simpleTextHour);
//      evaluator.evaluateFormulaCell(acell);
        return acell;
        
    }

    public HSSFCell setStyleHeaderData(HSSFCell acell) {
        acell.setCellStyle(headerTable);
        return acell;
        
    }

    public HSSFCell setStyleHeaderDataCentered(HSSFCell acell) {
        acell.setCellStyle(headerTableCentered);
        return acell;
        
    }


    public HSSFCell setStyleSimpleTextCentered(HSSFCell acell) {
        acell.setCellStyle(simpleTextCentered);
        return acell;
        
    }


    
    
    
    
    
    
    

        
    

}
