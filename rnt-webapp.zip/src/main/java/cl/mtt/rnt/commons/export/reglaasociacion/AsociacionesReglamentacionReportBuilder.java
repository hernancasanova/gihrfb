package cl.mtt.rnt.commons.export.reglaasociacion;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletOutputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import cl.mtt.rnt.commons.export.CabeceraRntXlsBuilder;
import cl.mtt.rnt.commons.export.XLSCellStyleSetter;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.view.ServicioReglamentadosVO;
import cl.mtt.rnt.commons.model.view.VehiculoReglamentadosVO;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

public class AsociacionesReglamentacionReportBuilder {
    
    private static final int LIMIT_PAGE_ROWS = 64000;
    public static final String PARAM_VEHICULOS_ASOCIADOS = "VEH";
    public static final String PARAM_SERVICIOS_ASOCIADOS = "SER";
    public static final String PARAM_REGLAMENTACION = "REG";
    

    public static void generateReport(HashMap<String, Object> parametros, ServletOutputStream outputStream) throws IOException {
        HSSFWorkbook libro = new HSSFWorkbook();
        Reglamentacion reg = (Reglamentacion) parametros.get(PARAM_REGLAMENTACION);
        XLSCellStyleSetter sty = new XLSCellStyleSetter(libro);
        
        HSSFSheet hojaConCabeceraAsocReg = CabeceraRntXlsBuilder.getHojaConCabecera(libro,sty
                              ,Resources.getString("export.xls.sheet.asoc.reglamentaciones")
                              ,reg.getTipoReglamentacion().getNombre() + " - " + reg.getNombre().replace("*",""));
        
        addReglamentacionesAsociadas(hojaConCabeceraAsocReg,sty,parametros);
        
        HSSFSheet hojaConCabeceraAsoctTs = CabeceraRntXlsBuilder.getHojaConCabecera(libro,sty
                               ,Resources.getString("export.xls.sheet.asoc.tsasoc")
                               ,reg.getTipoReglamentacion().getNombre() + " - " + reg.getNombre().replace("*",""));
        
        addTiposServiciosAsociados(hojaConCabeceraAsoctTs,sty,parametros);
        
        addServiciosRelacionados(libro,sty,parametros);

        addVehiculosRelacionados(libro,sty,parametros);

        libro.write(outputStream);
    }

    private static void addVehiculosRelacionados(HSSFWorkbook workbook, XLSCellStyleSetter sty, HashMap<String, Object> parametros) {
        Reglamentacion reg = (Reglamentacion) parametros.get(PARAM_REGLAMENTACION);
        List<VehiculoReglamentadosVO> vehiculos = (List<VehiculoReglamentadosVO>) parametros.get(AsociacionesReglamentacionReportBuilder.PARAM_VEHICULOS_ASOCIADOS);
        
        if(vehiculos==null || vehiculos.size()==0){
        	HSSFSheet hoja = CabeceraRntXlsBuilder.getHojaConCabecera(workbook,sty,Resources.getString("export.xls.sheet.asoc.vehiculos")
                    ,reg.getTipoReglamentacion().getNombre() + " - " + reg.getNombre().replace("*",""));
           int currentRow = 12;
           HSSFRow cabe = hoja.createRow(currentRow);
           setHeaderCell(sty, cabe, 1 ,Resources.getString("reglamentacion.reporte.vehiculos.noPosee"));
        	return;
        }
        
        int pages = new Double(Math.ceil( ((double)vehiculos.size()) / ((double)LIMIT_PAGE_ROWS))).intValue();
        for (int pageIndex = 0;pageIndex< pages;pageIndex++) {
            
        	HSSFSheet hoja = CabeceraRntXlsBuilder.getHojaConCabecera(workbook,sty,Resources.getString("export.xls.sheet.asoc.vehiculos")+((pages>1)?(" - "+(pageIndex+1)):"")
                      ,reg.getTipoReglamentacion().getNombre() + " - " + reg.getNombre().replace("*",""));
        	  
             int currentRow = 12;
             
             HSSFRow cabe = hoja.createRow(currentRow);
            
             setHeaderCell(sty, cabe, 1 ,Resources.getString("reglamentacion.reporte.tipoServicio"));
             setHeaderCell(sty, cabe, 2 ,Resources.getString("reglamentacion.reporte.region"));
             setHeaderCell(sty, cabe, 3 ,Resources.getString("reglamentacion.reporte.identServicio"));
             setHeaderCell(sty, cabe, 4 ,Resources.getString("reglamentacion.reporte.ppu"));
             setHeaderCell(sty, cabe, 5 ,Resources.getString("reglamentacion.reporte.fechaIngreso"));
             setHeaderCell(sty, cabe, 6 ,Resources.getString("reglamentacion.reporte.vencimiento"));
             setHeaderCell(sty, cabe, 7 ,Resources.getString("reglamentacion.reporte.estado"));
            
             int ini=pageIndex*LIMIT_PAGE_ROWS;
             int end=Math.min(pageIndex*LIMIT_PAGE_ROWS+LIMIT_PAGE_ROWS, vehiculos.size() );
            		 
             for (int rowIndex = ini;rowIndex< end;rowIndex++){
            	 VehiculoReglamentadosVO vehiculo =vehiculos.get(rowIndex);
            	
                 HSSFRow row = hoja.createRow(++currentRow);

                 HSSFCell celda1 = row.createCell(1);
                 celda1.setCellValue(vehiculo.getTipoServicio().getName());
                 sty.setStyleSimpleText(celda1);

                 HSSFCell celda2 = row.createCell(2);
                 celda2.setCellValue(vehiculo.getRegion().getNombre());
                 sty.setStyleSimpleText(celda2);

                 HSSFCell celda3 = row.createCell(3);
                 celda3.setCellValue(vehiculo.getIdentServicio());
                 sty.setStyleSimpleText(celda3);

                 HSSFCell celdaPpu = row.createCell(4);
                 celdaPpu.setCellValue(vehiculo.getPpu());
                 sty.setStyleSimpleText(celdaPpu);

                 HSSFCell celda4 = row.createCell(5);
                 celda4.setCellValue(vehiculo.getVigenciaDesde());
                 sty.setStyleSimpleTextDate(celda4);

                 HSSFCell celda5 = row.createCell(6);
                 celda5.setCellValue(vehiculo.getVigenciaHasta());
                 sty.setStyleSimpleTextDate(celda5);
                 
                 HSSFCell celda6 = row.createCell(7);
                 if(vehiculo.getEstado().equals(2)){
                     celda6.setCellValue(Resources.getString("reglamentacion.reporte.estado.cancelado"));
                 }else if(ValidacionHelper.esFechaMayor(new Date(),vehiculo.getVigenciaHasta())){
                     celda6.setCellValue(Resources.getString("reglamentacion.reporte.estado.vencido"));
                 }else{
                     celda6.setCellValue(Resources.getString("reglamentacion.reporte.estado.vigente"));
                 }
                 sty.setStyleSimpleText(celda6);
                 
             }
             
         }

    	

        // TODO Auto-generated method stub
    	
    }


    @SuppressWarnings("unchecked")
    private static void addServiciosRelacionados(HSSFWorkbook workbook, XLSCellStyleSetter sty, HashMap<String, Object> parametros) {
        Reglamentacion reg = (Reglamentacion) parametros.get(PARAM_REGLAMENTACION);
        List<ServicioReglamentadosVO> servicios = (List<ServicioReglamentadosVO>) parametros.get(AsociacionesReglamentacionReportBuilder.PARAM_SERVICIOS_ASOCIADOS);

        if(servicios==null || servicios.size()==0){
        	HSSFSheet hoja = CabeceraRntXlsBuilder.getHojaConCabecera(workbook,sty,Resources.getString("export.xls.sheet.asoc.servicios")
                    ,reg.getTipoReglamentacion().getNombre() + " - " + reg.getNombre().replace("*",""));
           int currentRow = 12;
           HSSFRow cabe = hoja.createRow(currentRow);
           setHeaderCell(sty, cabe, 1 ,Resources.getString("reglamentacion.reporte.servicios.noPosee"));
        	return;
        }

        int pages = new Double(Math.ceil( ((double)servicios.size()) / ((double)LIMIT_PAGE_ROWS))).intValue();
        for (int pageIndex = 0;pageIndex< pages;pageIndex++) {
        	HSSFSheet hoja = CabeceraRntXlsBuilder.getHojaConCabecera(workbook,sty,Resources.getString("export.xls.sheet.asoc.servicios")+((pages>1)?(" - "+(pageIndex+1)):"")
                      ,reg.getTipoReglamentacion().getNombre() + " - " + reg.getNombre().replace("*",""));
        	  
             int currentRow = 12;
             
             HSSFRow cabe = hoja.createRow(currentRow);
            
             setHeaderCell(sty, cabe, 1 ,Resources.getString("reglamentacion.reporte.tipoServicio"));
             setHeaderCell(sty, cabe, 2 ,Resources.getString("reglamentacion.reporte.region"));
             setHeaderCell(sty, cabe, 3 ,Resources.getString("reglamentacion.reporte.identServicio"));
             setHeaderCell(sty, cabe, 4 ,Resources.getString("reglamentacion.reporte.vigenciaDesde"));
             setHeaderCell(sty, cabe, 5 ,Resources.getString("reglamentacion.reporte.vigenciaHasta"));
             setHeaderCell(sty, cabe, 6 ,Resources.getString("reglamentacion.reporte.estado"));
            
             int ini=pageIndex*LIMIT_PAGE_ROWS;
             int end=Math.min(pageIndex*LIMIT_PAGE_ROWS+LIMIT_PAGE_ROWS, servicios.size() );
            		 
             for (int rowIndex = ini;rowIndex< end;rowIndex++){
            	ServicioReglamentadosVO servicio =servicios.get(rowIndex);
            	
                 HSSFRow row = hoja.createRow(++currentRow);

                 HSSFCell celda1 = row.createCell(1);
                 celda1.setCellValue(servicio.getTipoServicio().getName());
                 sty.setStyleSimpleText(celda1);

                 HSSFCell celda2 = row.createCell(2);
                 celda2.setCellValue(servicio.getRegion().getNombre());
                 sty.setStyleSimpleText(celda2);

                 HSSFCell celda3 = row.createCell(3);
                 celda3.setCellValue(servicio.getIdentServicio());
                 sty.setStyleSimpleText(celda3);

                 HSSFCell celda4 = row.createCell(4);
                 celda4.setCellValue(servicio.getVigenciaDesde());
                 sty.setStyleSimpleTextDate(celda4);

                 HSSFCell celda5 = row.createCell(5);
                 celda5.setCellValue(servicio.getVigenciaHasta());
                 sty.setStyleSimpleTextDate(celda5);
                 
                 HSSFCell celda6 = row.createCell(6);
                 if(servicio.getEstado().equals(2)){
                     celda6.setCellValue(Resources.getString("reglamentacion.reporte.estado.cancelado"));
                 }else if(ValidacionHelper.esFechaMayor(new Date(),servicio.getVigenciaHasta())){
                     celda6.setCellValue(Resources.getString("reglamentacion.reporte.estado.vencido"));
                 }else{
                     celda6.setCellValue(Resources.getString("reglamentacion.reporte.estado.vigente"));
                 }
                 sty.setStyleSimpleText(celda6);
                 
             }
             
         }

    	
    }


	/**
	 * @param sty
	 * @param cabe
	 * @param string 
	 * @param i 
	 */
	private static void setHeaderCell(XLSCellStyleSetter sty, HSSFRow row, int i, String text) {
		HSSFCell celda = row.createCell(i);
    	 sty.setStyleHeaderData(celda);
    	 celda.setCellValue(text);
	}


    private static void addTiposServiciosAsociados(HSSFSheet hojaConCabeceraAsocReg, XLSCellStyleSetter sty, HashMap<String, Object> parametros) {
    	Reglamentacion reg = (Reglamentacion) parametros.get(PARAM_REGLAMENTACION);
    	 
    	int currentRow = 12;
         
         HSSFRow cabe2 = hojaConCabeceraAsocReg.createRow(currentRow);
         setHeaderCell(sty, cabe2, 1 ,Resources.getString("reglamentacion.reporte.tipoServicio"));
         
         
         List<TipoServicio> tiposServicio = reg.getTiposServicio();
         if(tiposServicio==null || tiposServicio.size()==0){
        	 HSSFRow dato1 = hojaConCabeceraAsocReg.createRow(currentRow+1);
	         HSSFCell celda1 = dato1.createCell(1);
	         celda1.setCellValue("No posee");
	         sty.setStyleSimpleText(celda1);
         }else{
			for (int i=0; i<tiposServicio.size() ; i++) {
		         HSSFRow dato1 = hojaConCabeceraAsocReg.createRow(i+currentRow+1);
		         HSSFCell celda1 = dato1.createCell(1);
		         celda1.setCellValue(tiposServicio.get(i).getName());
		         sty.setStyleSimpleText(celda1);
			}
         }
    }


    private static void addReglamentacionesAsociadas(HSSFSheet hojaConCabeceraAsocReg, XLSCellStyleSetter sty, HashMap<String, Object> parametros) {

    	Reglamentacion reg = (Reglamentacion) parametros.get(PARAM_REGLAMENTACION);
 
    	int currentRow = 12;
         
         HSSFRow cabe = hojaConCabeceraAsocReg.createRow(currentRow);
         setHeaderCell(sty, cabe, 1 ,Resources.getString("reglamentacion.reporte.reglamentacionPadre"));

         HSSFRow dato = hojaConCabeceraAsocReg.createRow(currentRow+1);
         HSSFCell celda = dato.createCell(1);
         if(reg.getReglamentacionDeQueDepende()!=null){
	         celda.setCellValue(reg.getReglamentacionDeQueDepende().getTipoReglamentacion().getNombre() + " - " + reg.getReglamentacionDeQueDepende().getNombre());
         }else{
        	 celda.setCellValue("No posee");
         }
	     sty.setStyleSimpleText(celda);
         
         HSSFRow cabe2 = hojaConCabeceraAsocReg.createRow(currentRow+3);
         setHeaderCell(sty, cabe2, 1 ,Resources.getString("reglamentacion.reporte.reglamentacionesSubordinadas"));
         
         
         List<Reglamentacion> reglamentacionesSubordinadas = reg.getReglamentacionesSubordinadas();
         if(reglamentacionesSubordinadas==null || reglamentacionesSubordinadas.size()==0){
        	 HSSFRow dato1 = hojaConCabeceraAsocReg.createRow(currentRow+4);
	         HSSFCell celda1 = dato1.createCell(1);
	         celda1.setCellValue("No posee");
	         sty.setStyleSimpleText(celda1);
         }else{
			for (int i=0; i<reglamentacionesSubordinadas.size() ; i++) {
		         HSSFRow dato1 = hojaConCabeceraAsocReg.createRow(i+currentRow+4);
		         HSSFCell celda1 = dato1.createCell(1);
		         celda1.setCellValue(reglamentacionesSubordinadas.get(i).getTipoReglamentacion().getNombre() + " - " +  reglamentacionesSubordinadas.get(i).getNombre());
		         sty.setStyleSimpleText(celda1);
			}
         }
		
    }

}
