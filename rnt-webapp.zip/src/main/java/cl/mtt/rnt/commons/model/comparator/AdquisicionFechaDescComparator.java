package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.core.Adquisicion;

public class AdquisicionFechaDescComparator implements Comparator<Adquisicion> {

	@Override
	public int compare(Adquisicion o1, Adquisicion o2) {
		try {
			return (o2.getFechaAdquisicion().compareTo(o1.getFechaAdquisicion()));
		} catch (Exception e) {
			return 0;
		}

	}

}
