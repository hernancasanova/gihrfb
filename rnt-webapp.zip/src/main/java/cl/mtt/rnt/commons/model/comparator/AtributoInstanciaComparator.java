package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.core.AtributoInstancia;

public class AtributoInstanciaComparator implements Comparator<AtributoInstancia> {

	@Override
	public int compare(AtributoInstancia ati1, AtributoInstancia ati2) {
		try{
			if ((ati1.getAtributo().getOrdenParcial() == null) && (ati2.getAtributo().getOrdenParcial() == null)) {
				return 0;
			}
			if (ati1.getAtributo().getOrdenParcial() == null) {
				return -1;
			}
			if (ati2.getAtributo().getOrdenParcial() == null) {
				return 1;
			}
			return ati1.getAtributo().getOrdenParcial().compareTo(ati2.getAtributo().getOrdenParcial());
		}catch(Exception e){
			return 0;
		}
	}

}
