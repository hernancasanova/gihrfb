package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.core.recorrido.DatoDiccionario;

public class CalleComunaComparator implements Comparator<DatoDiccionario> {

	@Override
	public int compare(DatoDiccionario o1, DatoDiccionario o2) {
		int ret = o1.getComuna().getNombre().compareTo(o2.getComuna().getNombre());
		if (ret == 0)
			return o1.getCalle1().compareTo(o2.getCalle1());
		return ret;
	}

}
