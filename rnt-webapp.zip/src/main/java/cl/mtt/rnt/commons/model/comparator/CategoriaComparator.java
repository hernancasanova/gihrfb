package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.core.CategoriaTransporte;

public class CategoriaComparator implements Comparator<CategoriaTransporte> {

	@Override
	public int compare(CategoriaTransporte cat1, CategoriaTransporte cat2) {
		return cat1.getDescriptor().compareTo(cat2.getDescriptor());
	}

}
