package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;

public class CategoriaTransporteSeleccionbleComparator implements Comparator<CategoriaTransporteSeleccionble> {

	@Override
	public int compare(CategoriaTransporteSeleccionble c1, CategoriaTransporteSeleccionble c2) {
		if (c1.getTipoTransporte().getNombre().equals(c2.getTipoTransporte().getNombre())) {
			if (c1.getMedio().getNombre().equals(c2.getMedio().getNombre())) {
				return c1.getCategoria().getNombre().compareTo(c2.getCategoria().getNombre());
			} else {
				return c1.getMedio().getNombre().compareTo(c2.getMedio().getNombre());
			}
		} else {
			return c1.getTipoTransporte().getNombre().compareTo(c2.getTipoTransporte().getNombre());
		}
	}

}
