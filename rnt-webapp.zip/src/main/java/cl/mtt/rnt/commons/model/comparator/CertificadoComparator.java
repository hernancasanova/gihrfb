package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.core.Certificado;

public class CertificadoComparator implements Comparator<Certificado> {

	@Override
	public int compare(Certificado o1, Certificado o2) {
		if (o1.getIdentificadorWS()==null && o2.getIdentificadorWS()==null)
			return 0;
		if (o1.getIdentificadorWS()==null)
			return -1;
		if (o2.getIdentificadorWS()==null)
			return 1;
			
		return o1.getIdentificadorWS().compareTo(o2.getIdentificadorWS());
	}

}
