package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.core.interfaces.NombrableModelObject;

public class PorNombreComparator implements Comparator<NombrableModelObject> {

	@Override
	public int compare(NombrableModelObject o1, NombrableModelObject o2) {
		return o1.getNombre().compareTo(o2.getNombre());
	}

}
