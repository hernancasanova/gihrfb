package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.encargado.dto.PropietarioDTO;

public class PropietarioDTOComparator implements Comparator<PropietarioDTO> {

	@Override
	public int compare(PropietarioDTO o1, PropietarioDTO o2) {
		try {
			return o1.getPpu().compareTo(o2.getPpu());
		} catch (Exception e) {
			return 0;
		}
	}

}
