package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.core.Propietario;

public class PropietarioFechaDescComparator implements Comparator<Propietario> {

	@Override
	public int compare(Propietario o1, Propietario o2) {
		try {
			return (o2.getAdquisicion().getFechaAdquisicion().compareTo(o1.getAdquisicion().getFechaAdquisicion()));
		} catch (Exception e) {
			return 0;
		}

	}

}
