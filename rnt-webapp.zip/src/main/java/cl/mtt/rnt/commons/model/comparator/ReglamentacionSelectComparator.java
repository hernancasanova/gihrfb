package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.admin.reglamentacion.util.SelectionItem;

public class ReglamentacionSelectComparator implements Comparator<SelectionItem> {

	@Override
	public int compare(SelectionItem o1, SelectionItem o2) {
		return o1.getLabel().compareTo(o2.getLabel());
	}

}
