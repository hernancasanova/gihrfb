package cl.mtt.rnt.commons.model.comparator;

import java.util.Comparator;

import cl.mtt.rnt.commons.model.userrol.User;

public class UserComparator implements Comparator<User> {

	@Override
	public int compare(User o1, User o2) {
		return o1.getNombreUsuario().compareTo(o2.getNombreUsuario());
	}

}
