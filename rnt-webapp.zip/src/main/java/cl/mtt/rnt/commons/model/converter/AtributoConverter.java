package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.Atributo;

@FacesConverter("AtributoConverter")
public class AtributoConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		Atributo a = new Atributo();
		String[] ss = s.split("@%@");
		a.setId(Long.valueOf(ss[0]));
		a.setTipo(ss[1]);
		a.setEtiqueta(ss[2]);
		a.setAplicaA(ss[3]);
		return a;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		Atributo a = (Atributo) o;
		return String.valueOf(a.getId()) + "@%@" + a.getTipo() + "@%@" + a.getEtiqueta() + "@%@" + a.getAplicaA();
	}

}