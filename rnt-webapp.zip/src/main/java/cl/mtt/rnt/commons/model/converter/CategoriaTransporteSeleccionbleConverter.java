package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;

@FacesConverter("CategoriaTransporteSeleccionbleConverter")
public class CategoriaTransporteSeleccionbleConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String s) {
		if(s==null || s.isEmpty())
			return null;
		CategoriaTransporteSeleccionble rct = new CategoriaTransporteSeleccionble();
		String[] ss = s.split("@%@");
		if (ss.length<9)
			return null;
		rct.setCategoria(new CategoriaTransporte());
		rct.getCategoria().setId(Long.valueOf(ss[0]));
		rct.getCategoria().setNombre(ss[1]);
		rct.getCategoria().setDescriptor(ss[2]);
		
		rct.setMedio(new MedioTransporte());
		rct.getMedio().setId(Long.valueOf(ss[3]));
		rct.getMedio().setNombre(ss[4]);
		rct.getMedio().setDescriptor(ss[5]);
		
		
		rct.setTipoTransporte(new TipoTransporte());
		rct.getTipoTransporte().setId(Long.valueOf(ss[6]));
		rct.getTipoTransporte().setNombre(ss[7]);
		rct.getTipoTransporte().setDescriptor(ss[8]);
		
		return rct;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		CategoriaTransporteSeleccionble rct = (CategoriaTransporteSeleccionble) o;
		if (rct == null || rct.getCategoria()== null || rct.getMedio()==null || rct.getTipoTransporte()==null)
			return null;
		return String.valueOf(rct.getCategoria().getId()) + "@%@" + rct.getCategoria().getNombre()  + "@%@" + rct.getCategoria().getDescriptor()  
				+ "@%@" + String.valueOf(rct.getMedio().getId()) + "@%@" + rct.getMedio().getNombre()  + "@%@" + rct.getMedio().getDescriptor()
				+ "@%@" + String.valueOf(rct.getTipoTransporte().getId()) + "@%@" + rct.getTipoTransporte().getNombre()  + "@%@" + rct.getTipoTransporte().getDescriptor();
	}

}
