package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.ClaseLicenciaConducir;

@FacesConverter("ClaseLicenciaConducirConverter")
public class ClaseLicenciaConducirConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		ClaseLicenciaConducir tsa = new ClaseLicenciaConducir();
		String[] ss = s.split("@%@");
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setNombre(ss[1]);
		tsa.setTipo(ss[2]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		ClaseLicenciaConducir tsa = (ClaseLicenciaConducir) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getTipo();
	}

}