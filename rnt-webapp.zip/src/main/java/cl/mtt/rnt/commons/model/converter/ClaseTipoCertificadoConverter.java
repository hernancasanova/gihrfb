package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.ClaseTipoCertificado;

@FacesConverter("ClaseTipoCertificadoConverter")
public class ClaseTipoCertificadoConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		ClaseTipoCertificado tsa = new ClaseTipoCertificado();
		String[] ss = s.split("@%@");
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setNombre(ss[1]);
		tsa.setMovimiento(ss[2]);
		tsa.setObjeto(ss[3]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		ClaseTipoCertificado tsa = (ClaseTipoCertificado) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getMovimiento() + "@%@" + tsa.getObjeto();
	}
}
