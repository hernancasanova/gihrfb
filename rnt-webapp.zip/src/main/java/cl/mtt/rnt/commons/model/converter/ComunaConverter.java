package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Provincia;
import cl.mtt.rnt.commons.model.sgprt.Region;

@FacesConverter("ComunaConverter")
public class ComunaConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		Comuna tsa = new Comuna();
		String[] ss = s.split("@%@");
		tsa.setCodigo(ss[0]);
		tsa.setNombre(ss[1]);
		tsa.setProvincia(new Provincia(ss[2], ss[3]));
		tsa.getProvincia().setRegion(new Region(ss[5], ss[4], ss[6]));
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		Comuna tsa = (Comuna) o;
		return String.valueOf(tsa.getCodigo()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getProvincia().getCodigo() + "@%@" + tsa.getProvincia().getNombre() + "@%@"
				+ tsa.getProvincia().getRegion().getCodigo() + "@%@" + tsa.getProvincia().getRegion().getNombre() + "@%@" + tsa.getProvincia().getRegion().getPrefijo();
	}

}