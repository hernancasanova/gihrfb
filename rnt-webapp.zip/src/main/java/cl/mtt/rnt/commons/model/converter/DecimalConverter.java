package cl.mtt.rnt.commons.model.converter;

import java.text.DecimalFormat;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.util.Resources;

@FacesConverter("DecimalConverter")
public class DecimalConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
	    if ((value==null)||("".equals(value)))
            return null;
		try {
			if (value != null && !value.isEmpty()) {
				if (value.contains(".")) {
					FacesMessage msg = new FacesMessage(Resources.getString("validation.message.decimalFormat.error"), Resources.getString("validation.message.decimalFormat.error"));
					msg.setSeverity(FacesMessage.SEVERITY_ERROR);
					throw new ConverterException(msg);
				}
				String valorConPunto = value.replace(",", ".");
				Float f = Float.parseFloat(valorConPunto);
				return f;
			}
			return null;
		} catch (Exception e) {
			FacesMessage msg = new FacesMessage(Resources.getString("validation.message.decimalFormat.error"), Resources.getString("validation.message.decimalFormat.error"));
			msg.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ConverterException(msg);
		}
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
	    if ((value==null) ||("".equals(value)))
            return "";
		DecimalFormat df = new DecimalFormat("0.0");
		String v = df.format(value);
		v = v.replace(".", ",");
		return v;
	}

}
