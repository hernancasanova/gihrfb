package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.Documentacion;

@FacesConverter("DocumentacionConverter")
public class DocumentacionConverter implements Converter {
	
	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
		if(s==null || s.isEmpty())
			return null;
		Documentacion tsa = new Documentacion();
		String[] ss = s.split("@%@");
		if (ss.length<2)
			return null;
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setNombre(ss[1]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null)||("".equals(o)))
            return null;
		Documentacion tsa = (Documentacion) o;
		if (tsa == null)
			return null;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre();
	}
}
