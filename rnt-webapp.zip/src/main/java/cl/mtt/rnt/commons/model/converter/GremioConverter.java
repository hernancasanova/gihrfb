package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.model.core.Gremio;

@FacesConverter("GremioConverter")
public class GremioConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		try {
			Gremio tsa = new Gremio();
			String[] ss = s.split("@%@");
			tsa.setId(Long.valueOf(ss[0]));
			tsa.setNombre(ss[1]);
			tsa.setDescriptor(ss[2]);
			return tsa;
		} catch (NumberFormatException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
	    Gremio tsa = (Gremio) o;
		if (tsa != null)
			return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getDescriptor();
		return "";
	}

}