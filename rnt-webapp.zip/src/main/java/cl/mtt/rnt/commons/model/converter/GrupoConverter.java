package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;

@FacesConverter("GrupoConverter")
public class GrupoConverter implements Converter{
	
	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {

	    if ((s==null)||("".equals(s)))
            return null;
		Grupo u = new Grupo();
		String[] ss = s.split("@%@");
		u.setId(Long.parseLong(ss[0]));
		u.setNombre(ss[1]);
		return u;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		Grupo u = (Grupo) o;
		if (u != null)
			return String.valueOf(u.getId()) + "@%@" + u.getId() + "@%@" + u.getNombre();
		return "";
	}

}
