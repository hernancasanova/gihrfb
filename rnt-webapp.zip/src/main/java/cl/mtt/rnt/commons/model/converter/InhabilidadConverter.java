package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.Inhabilidad;

@FacesConverter("InhabilidadConverter")
public class InhabilidadConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		Inhabilidad tsa = new Inhabilidad();
		String[] ss = s.split("@%@");
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setNombre(ss[1]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		Inhabilidad tsa = (Inhabilidad) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre();
	}

}