package cl.mtt.rnt.commons.model.converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

//Specify converter ID
@FacesConverter(value = "integerConverter")
public class IntegerConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Integer integerValue = null;
		if (value != null && value.trim().length() > 0) {
			try {
				integerValue = Integer.valueOf(value.trim());
			} catch (NumberFormatException e) {
				FacesMessage message = new FacesMessage("Entero no válido.", "El valor debe ser entero");
				message.setSeverity(FacesMessage.SEVERITY_ERROR);
				throw new ConverterException(message);
			}
		}
		return integerValue;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		Integer integerValue = (Integer) value;

		if (integerValue == null) {
			return null;
		}
		return String.valueOf(integerValue);
	}

}