package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.log4j.Logger;

import cl.mtt.rnt.admin.reglamentacion.util.ItemPeriodoNormativa;

@FacesConverter("ItemPeriodoNormativaConverter")
public class ItemPeriodoNormativaConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		try {
			String[] ss = s.split("@%@");
			ItemPeriodoNormativa tsa = new ItemPeriodoNormativa(ss[0],ss[1]);			
			return tsa;
		} catch (NumberFormatException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			return null;
		}
		
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
	    if ((value==null) ||("".equals(value)))
            return "";
		ItemPeriodoNormativa ipn = (ItemPeriodoNormativa)value;
		if (ipn != null)
			return ipn.getNombrePeriodo() + "@%@" + ipn.getTipoVigencia();
		return "";
	}

}
