package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.encargado.util.KeyValueString;

@FacesConverter("KeyValueStringConverter")
public class KeyValueStringConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		KeyValueString kv = new KeyValueString();
		String[] ss = s.split("@%@");

		kv.setKey(ss[0]);
		kv.setValue(ss[1]);

		return kv;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		KeyValueString kv = (KeyValueString) o;
		return kv.getKey() + "@%@" + kv.getValue();
	}

}