package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Localidad;
import cl.mtt.rnt.commons.model.sgprt.Provincia;
import cl.mtt.rnt.commons.model.sgprt.Region;

@FacesConverter("LocalidadConverter")
public class LocalidadConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		Localidad tsa = new Localidad();
		String[] ss = s.split("@%@");
		tsa.setCodigo(Integer.parseInt(ss[0]));
		tsa.setNombre(ss[1]);
		tsa.setComuna(new Comuna(ss[3], ss[2]));
		tsa.getComuna().setProvincia(new Provincia(ss[5], ss[4]));
		tsa.getComuna().getProvincia().setRegion(new Region(ss[7], ss[6], ss[8]));
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		Localidad tsa = (Localidad) o;
		return String.valueOf(tsa.getCodigo()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getComuna().getCodigo() + "@%@" + tsa.getComuna().getNombre() + "@%@"
				+ tsa.getComuna().getProvincia().getCodigo() + "@%@" + tsa.getComuna().getProvincia().getNombre() + "@%@" + tsa.getComuna().getProvincia().getRegion().getCodigo() + "@%@"
				+ tsa.getComuna().getProvincia().getRegion().getNombre()+ "@%@"+ tsa.getComuna().getProvincia().getRegion().getPrefijo();
	}

}