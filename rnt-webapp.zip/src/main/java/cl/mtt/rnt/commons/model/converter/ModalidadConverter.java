package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.Modalidad;

@FacesConverter("ModalidadConverter")
public class ModalidadConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		Modalidad tsa = new Modalidad();
		String[] ss = s.split("@%@");
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setNombre(ss[1]);
		tsa.setDescriptor(ss[2]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if("".equals(o))
			o=null;
		Modalidad tsa = (Modalidad) o;
		if (tsa != null)
			return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getDescriptor();
		return "";
	}

}