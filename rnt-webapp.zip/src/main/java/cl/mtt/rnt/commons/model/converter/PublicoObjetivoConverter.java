package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.PublicoObjetivo;

@FacesConverter("PublicoObjetivoConverter")
public class PublicoObjetivoConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
		if (s == null || "".equals(s) || s.indexOf("@%@") == -1)
			return null;
		PublicoObjetivo tsa = new PublicoObjetivo();
		String[] ss = s.split("@%@");
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setEtiqueta(ss[1]);
		tsa.setDescriptor(ss[2]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if (o == null || "".equals(o))
			return null;
		PublicoObjetivo tsa = (PublicoObjetivo) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getEtiqueta() + "@%@" + tsa.getDescriptor();
	}

}