package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.sgprt.Region;

@FacesConverter("RegionConverter")
public class RegionConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
		if(s==null || s.isEmpty())
			return null;
		Region tsa = new Region();
		String[] ss = s.split("@%@");
		if (ss.length<3)
			return null;
		tsa.setCodigo(ss[0]);
		tsa.setNombre(ss[1]);
		tsa.setPrefijo(ss[2]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if ("".equals(o))
			return null;
		Region tsa = (Region) o;
		if (tsa == null)
			return null;
		return String.valueOf(tsa.getCodigo()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getPrefijo();
	}

}