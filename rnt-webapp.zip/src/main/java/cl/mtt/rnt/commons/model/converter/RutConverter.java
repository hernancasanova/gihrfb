package cl.mtt.rnt.commons.model.converter;

import java.text.NumberFormat;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.util.Resources;

@FacesConverter("RutConverter")
public class RutConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
		try {
			if (s != null)
				s = s.trim();
			if (s == null || "".equals(s))
				return null;
			s = s.replace(".", "");
			if (!s.contains("-"))
				s = s.substring(0, s.length() - 1) + "-" + s.substring(s.length() - 1);
			String rutUpperCase = s.toUpperCase();
			if (!validarRut(rutUpperCase)) {
				FacesMessage msg = new FacesMessage(Resources.getString("jsf.validation.rut"), Resources.getString("jsf.validation.rut"));
				msg.setSeverity(FacesMessage.SEVERITY_ERROR);
				throw new ConverterException(msg);
			}

			return rutUpperCase;
		} catch (Exception e) {
			FacesMessage msg = new FacesMessage(Resources.getString("jsf.validation.rut"), Resources.getString("jsf.validation.rut"));
			msg.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ConverterException(msg);
		}
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		String rut = (String) o;
		return convertRut(rut);
	}

	public static boolean validarRut(String rut) {

		boolean validacion = false;
		try {
			rut = rut.replace(".", "");
			rut = rut.replace("-", "");
			int rutAux = Integer.parseInt(rut.substring(0, rut.length() - 1));

			char dv = rut.charAt(rut.length() - 1);

			int m = 0, s = 1;
			for (; rutAux != 0; rutAux /= 10) {
				s = (s + rutAux % 10 * (9 - m++ % 6)) % 11;
			}
			if (dv == (char) (s != 0 ? s + 47 : 75)) {
				validacion = true;
			}

		} catch (java.lang.NumberFormatException e) {
			return false;
		} catch (Exception e) {

		}
		return validacion;
	}

	public static String convertRut(String rut) {

		String result = new String();
		if ((rut.contains("-"))) {
			String[] aux = rut.split("-");
			Integer rutint = Integer.parseInt(aux[0]);
			aux[0] = NumberFormat.getIntegerInstance().format(rutint);
			result = aux[0] + '-' + aux[1];

			return result;
		}

		return rut;

	}

}