package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.SituacionContractual;

@FacesConverter("SituacionContractualConverter")
public class SituacionContractualConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
		if (s == null || "".equals(s))
			return null;
		try {
			SituacionContractual tsa = new SituacionContractual();
			String[] ss = s.split("@%@");
			tsa.setId(Long.valueOf(ss[0]));
			tsa.setNombre(ss[1]);
			return tsa;
		} catch (Exception e) {
			return null;
		}
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if (o == null || "".equals(o.toString()))
			return null;
		SituacionContractual tsa = (SituacionContractual) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre();
	}

}