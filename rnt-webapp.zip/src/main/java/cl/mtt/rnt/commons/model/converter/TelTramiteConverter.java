/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.mtt.rnt.commons.model.converter;

import javax.el.ELContext;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import org.apache.log4j.Logger;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Tramite;
import cl.mtt.rnt.commons.service.TramiteManager;

/**
 *
 * @author jhenriquez
 */
@FacesConverter("TelTramiteConverter")
public class TelTramiteConverter implements Converter{
    private TramiteManager tramiteManager;
    
    public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		try {
			return getTramiteManager(facesContext).getTramiteById(Long.valueOf(s));
		} catch (NumberFormatException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}
    
    public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if (o == null || "".equals(o))
			return null;
		return String.valueOf(((Tramite) o).getId());
	}

    public TramiteManager getTramiteManager(FacesContext facesContext) {
        if (tramiteManager == null) {
                ELContext elContext = facesContext.getELContext();
                tramiteManager = (TramiteManager) elContext.getELResolver().getValue(elContext, null, "tramiteManager");
        }
        
        return tramiteManager;
    }
}