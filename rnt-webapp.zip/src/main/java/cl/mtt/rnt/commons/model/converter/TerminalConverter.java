package cl.mtt.rnt.commons.model.converter;

import javax.el.ELContext;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Terminal;
import cl.mtt.rnt.commons.service.TerminalManager;

@FacesConverter("TerminalConverter")
public class TerminalConverter implements Converter {

	private TerminalManager terminalManager;

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
		try {
			if(s!=null || !"".equals(s))
				return getTerminalManager(facesContext).getTerminalById(Long.valueOf(s));
		} catch (NumberFormatException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if (o == null || "".equals(o.toString()))
			return null;
		return String.valueOf(((Terminal) o).getId());
	}

	private TerminalManager getTerminalManager(FacesContext facesContext) {
		if (terminalManager == null) {
			ELContext elContext = facesContext.getELContext();
			terminalManager = (TerminalManager) elContext.getELResolver().getValue(elContext, null, "terminalManager");
		}
		return terminalManager;
	}

}