package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.util.ElResolver;

@FacesConverter("TipoCancelacionConverter")
public class TipoCancelacionConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		TipoCancelacion tsa = new TipoCancelacion();
		String[] ss = s.split("@%@");
		CurrentSessionBean currSesBean = (CurrentSessionBean) ElResolver.getManagedObject("currentSessionBean");
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setNombre(ss[1]);
		tsa.setAplica(ss[2]);
		tsa = currSesBean.getTipoCancelacion(tsa.getId(), tsa.getAplica());
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		TipoCancelacion tsa = (TipoCancelacion) o;
		if (tsa.getId() == null)
			return null;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getAplica() + "@%@" + tsa.getDescripcion() + "@%@" + tsa.getTipoCancelacion();
	}

}