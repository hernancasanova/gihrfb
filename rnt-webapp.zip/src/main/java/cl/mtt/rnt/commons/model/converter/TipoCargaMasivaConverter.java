package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.TipoCargaMasiva;

@FacesConverter("TipoCargaMasivaConverter")
public class TipoCargaMasivaConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
	    if ((value==null)||("".equals(value)))
            return null;
		TipoCargaMasiva tsa = new TipoCargaMasiva();
		String[] ss = value.split("@%@");
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setNombre(ss[1]);
		tsa.setDescriptor(ss[2]);
		return tsa;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
	    if ((value==null) ||("".equals(value)))
            return "";
		if(value instanceof TipoCargaMasiva){
			TipoCargaMasiva tsa = (TipoCargaMasiva) value;
			if (tsa != null)
				return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getDescriptor();
		}
		return null;
	}

}
