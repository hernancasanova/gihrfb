package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.TipoDocumento;

@FacesConverter("TipoDocumentoConverter")
public class TipoDocumentoConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
		if("".equals(s) || s==null)
			return null;
		TipoDocumento tsa = new TipoDocumento();
		String[] ss = s.split("@%@");
		tsa.setId(Long.parseLong(ss[0]));
		tsa.setNombre(ss[1]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if("".equals(o) || o==null)
			return null;
		TipoDocumento tsa = (TipoDocumento) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre();
	}

}