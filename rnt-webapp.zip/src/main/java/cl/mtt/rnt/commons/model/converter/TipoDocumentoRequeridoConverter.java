package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.TipoDocumentoGrupo;
import cl.mtt.rnt.commons.model.core.TipoDocumentoRequerido;

@FacesConverter("TipoDocumentoRequeridoConverter")
public class TipoDocumentoRequeridoConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		TipoDocumentoRequerido tsa = new TipoDocumentoRequerido();
		String[] ss = s.split("@%@");
		tsa.setId(Long.parseLong(ss[0]));
		tsa.setNombre(ss[1]);
		tsa.setDePortacion(Boolean.parseBoolean(ss[2]));
		if (ss.length == 5) {
			tsa.setGrupo(new TipoDocumentoGrupo());
			tsa.getGrupo().setId(Long.parseLong(ss[3]));
			tsa.getGrupo().setNombre(ss[4]);
		}
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		TipoDocumentoRequerido tsa = (TipoDocumentoRequerido) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + tsa.isDePortacion()
				+ ((tsa.getGrupo() == null) ? "" : ("@%@" + tsa.getGrupo().getId() + "@%@" + tsa.getGrupo().getNombre()));
	}

}