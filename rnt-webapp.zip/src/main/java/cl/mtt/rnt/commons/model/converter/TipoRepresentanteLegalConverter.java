package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.TipoRepresentanteLegal;

@FacesConverter("TipoRepresentanteLegalConverter")
public class TipoRepresentanteLegalConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		TipoRepresentanteLegal tsa = new TipoRepresentanteLegal();
		String[] ss = s.split("@%@");
		tsa.setId(Long.parseLong(ss[0]));
		tsa.setDescriptor(ss[1]);
		tsa.setNombre(ss[2]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		TipoRepresentanteLegal tsa = (TipoRepresentanteLegal) o;
	
			return String.valueOf(tsa.getId()) + "@%@" + tsa.getDescriptor() + "@%@" + tsa.getNombre();

	}
}
