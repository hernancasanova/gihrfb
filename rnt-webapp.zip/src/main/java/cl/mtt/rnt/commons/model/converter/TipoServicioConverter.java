package cl.mtt.rnt.commons.model.converter;

import javax.el.ELContext;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.service.TipoServicioManager;

@FacesConverter("TipoServicioConverter")
public class TipoServicioConverter implements Converter {

	private TipoServicioManager tipoServicioManager;

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		try {
			return getTipoServicioManager(facesContext).getTipoServicioById(Long.valueOf(s));
		} catch (NumberFormatException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return null;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if (o == null || "".equals(o))
			return null;
		return String.valueOf(((TipoServicio) o).getId());
	}

	private TipoServicioManager getTipoServicioManager(FacesContext facesContext) {
		if (tipoServicioManager == null) {
			ELContext elContext = facesContext.getELContext();
			tipoServicioManager = (TipoServicioManager) elContext.getELResolver().getValue(elContext, null, "tipoServicioManager");
		}
		return tipoServicioManager;
	}
}