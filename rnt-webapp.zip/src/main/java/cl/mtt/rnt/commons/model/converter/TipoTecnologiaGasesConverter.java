package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.TipoTecnologiaGases;

@FacesConverter("TipoTecnologiaGasesConverter")
public class TipoTecnologiaGasesConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		TipoTecnologiaGases tsa = new TipoTecnologiaGases();
		String[] ss = s.split("@%@");
		tsa.setId(Long.valueOf(ss[0]));
		tsa.setNombre(ss[1]);
		tsa.setDescriptor(ss[2]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		TipoTecnologiaGases tsa = (TipoTecnologiaGases) o;
		if (tsa != null)
			return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + tsa.getDescriptor();
		return "";
	}

}