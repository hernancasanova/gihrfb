package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.sgprt.TipoVehiculo;

@FacesConverter("TipoVehiculoConverter")
public class TipoVehiculoConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s))){
            return null;
	    }
		TipoVehiculo tsa = new TipoVehiculo();
		String[] ss = s.split("@%@");
		tsa.setId(Integer.parseInt(ss[0]));
		tsa.setDescripcion(ss[1]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null)||("".equals(o))){
            return null;		
	    }
	    TipoVehiculo tsa = (TipoVehiculo) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getDescripcion();
	}

}