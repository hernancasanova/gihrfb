package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.TipoServicioArea;
import cl.mtt.rnt.commons.model.core.TipoVehiculoServicio;

@FacesConverter("TipoVehiculoServicioConverter")
public class TipoVehiculoServicioConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		TipoVehiculoServicio tsa = new TipoVehiculoServicio();
		String[] ss = s.split("@%@");
		tsa.setId(Long.parseLong(ss[0]));
		tsa.setDescriptor(ss[1]);
		tsa.setNombre(ss[2]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if("".equals(o))
			o=null;
		TipoVehiculoServicio tsa = (TipoVehiculoServicio) o;
		if (tsa != null)
			return String.valueOf(tsa.getId()) + "@%@" + tsa.getDescriptor() + "@%@" + tsa.getNombre();
		return "";
	}

}