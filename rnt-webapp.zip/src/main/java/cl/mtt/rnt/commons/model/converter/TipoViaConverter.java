package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.TipoVia;

@FacesConverter("TipoViaConverter")
public class TipoViaConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		for (TipoVia tv :TipoVia.getAll()) {
			if (tv.getTipoLabel().equalsIgnoreCase(s)) {
				return tv;
			}
		}
		return TipoVia.TIPO_VIA_CALLE;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		
			TipoVia a = (TipoVia) o;
			return a.getTipoLabel();
		
		
	}

}