package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.TipoZona;

@FacesConverter("TipoZonaConverter")
public class TipoZonaConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		TipoZona tza = new TipoZona();
		String[] ss = s.split("@%@");
		tza.setId(Long.parseLong(ss[0]));
		tza.setNombre(ss[1]);

		return tza;
	}

	@SuppressWarnings("unused")
	@Override
	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if(o==null || "".equals(o)){
			return "";
		}
		TipoZona tsa = (TipoZona) o;
		if (tsa != null)
			return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre();
		return "";
	}

}
