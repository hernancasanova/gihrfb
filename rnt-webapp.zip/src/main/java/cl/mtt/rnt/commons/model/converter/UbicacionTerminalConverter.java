package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.UbicacionTerminal;

@FacesConverter("ubicacionTerminalConverter")
public class UbicacionTerminalConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s == null)||("".equals(s)))
            return null;
		UbicacionTerminal ut = new UbicacionTerminal();
		String[] ss = s.split("@%@");
		ut.setId(Long.parseLong(ss[0]));
		ut.setNombre(ss[1]);
		ut.setSigla(ss[2]);
		return ut;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		if ((o == null)||("".equals(o)))
			return null;
		UbicacionTerminal ut = (UbicacionTerminal) o;
		return String.valueOf(ut.getId()) + "@%@" + ut.getNombre()+ "@%@" +ut.getSigla();
	}

}