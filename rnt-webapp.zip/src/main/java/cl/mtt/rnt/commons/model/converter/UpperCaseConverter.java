package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter("UpperCaseConverter")
public class UpperCaseConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		return value != null ? value.toUpperCase() : null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
	    if ((value==null) ||("".equals(value)))
            return "";
		return value.toString();
	}

}
