package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.userrol.User;

@FacesConverter("UsuarioConverter")
public class UsuarioConverter implements Converter{
	
	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {

	    if ((s==null)||("".equals(s)))
            return null;
		User u = new User();
		String[] ss = s.split("@%@");
		u.setId(Long.parseLong(ss[0]));
		u.setNombreUsuario(ss[1]);
		u.setNombreCompleto(ss[2]);
		return u;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		User u = (User) o;
		return String.valueOf(u.getId()) + "@%@" + u.getNombreUsuario() + "@%@" + u.getNombreCompleto();

	}

}
