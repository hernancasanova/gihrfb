package cl.mtt.rnt.commons.model.converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.util.Resources;

@FacesConverter("valorTarifaConverter")
public class ValorTarifaConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		try {
			if (value != null && !value.isEmpty()) {
				if (value.contains(".") || value.contains("-")) {
					FacesMessage msg = new FacesMessage(Resources.getString("validation.message.tarifaFormat.error"), Resources.getString("validation.message.tarifaFormat.error"));
					msg.setSeverity(FacesMessage.SEVERITY_ERROR);
					throw new ConverterException(msg);
				}
				if (value.length()>7)
					value=value.substring(0,7);
				Float f = Float.parseFloat(value);
				return f;
			}
			return null;
		} catch (Exception e) {
			FacesMessage msg = new FacesMessage(Resources.getString("validation.message.tarifaFormat.error"), Resources.getString("validation.message.tarifaFormat.error"));
			msg.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ConverterException(msg);
		}
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
	    if ((value==null) ||("".equals(value)))
            return "";
		String s = String.valueOf(new Long((long) Math.floor((Float) value)));
		if (s.indexOf(".")!=-1)
			return s.substring(0,s.indexOf("."));
		return s;
	}

}
