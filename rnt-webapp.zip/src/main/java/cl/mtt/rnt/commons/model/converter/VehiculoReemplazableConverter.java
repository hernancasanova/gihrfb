package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.encargado.bean.controller.util.VehiculoReemplazable;

@FacesConverter("vehiculoReemplazableConverter")
public class VehiculoReemplazableConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		VehiculoReemplazable tza = new VehiculoReemplazable();
		String[] ss = s.split("@%@");
		tza.setIdentServicio(Long.parseLong(ss[0]));
		tza.setIdServicio(Long.parseLong(ss[1]));
		tza.setIdVehiculoServicio(Long.parseLong(ss[2]));
		tza.setPpu(ss[3]);
	
		return tza;
	}

	@Override
	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
		VehiculoReemplazable tsa = (VehiculoReemplazable) o;
		if (tsa != null)
			return String.valueOf(tsa.getIdentServicio()) + "@%@" + String.valueOf(tsa.getIdServicio()) + "@%@" + String.valueOf(tsa.getIdVehiculoServicio())  + "@%@" + String.valueOf(tsa.getPpu());
		return "";
	}

	}