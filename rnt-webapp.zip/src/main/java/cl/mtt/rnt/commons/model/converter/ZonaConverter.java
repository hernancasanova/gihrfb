package cl.mtt.rnt.commons.model.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.model.sgprt.Region;

@FacesConverter("ZonaConverter")
public class ZonaConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent component, String s) {
	    if ((s==null)||("".equals(s)))
            return null;
		Zona tsa = new Zona();
		String[] ss = s.split("@%@");
		tsa.setId(Long.parseLong(ss[0]));
		tsa.setNombre(ss[1]);
		if(!"-".equals(ss[2])){
			tsa.setRegionResponsable(new Region(ss[2], ss[3],ss[4]));
		}
		tsa.setIdRegion(ss[3]);
		return tsa;
	}

	public String getAsString(FacesContext facesContext, UIComponent component, Object o) {
	    if ((o==null) ||("".equals(o)))
            return "";
		Zona tsa = (Zona) o;
		return String.valueOf(tsa.getId()) + "@%@" + tsa.getNombre() + "@%@" + ((tsa.getRegionResponsable()==null)?"-":tsa.getRegionResponsable().getNombre()) + "@%@" + tsa.getIdRegion()+ "@%@" + tsa.getRegionResponsable().getPrefijo();
	}

}