package cl.mtt.rnt.commons.model.core;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_ADQUISICION")
@Audited
public class Adquisicion extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5493060150107877948L;
	private Date fechaAdquisicion;
	private String numeroRepertorio;
	private Date fechaRepertorio;
	private String repertorio;
	private String oficinaRegistrocivil;
	private String ppu;
	private Boolean actual;

	private List<Propietario> propietarios;

	private boolean coincideRegistroCivil;
	private DocumentoBiblioteca documentoTransferencia;
		
	@Column(name = "FECHA_ADQUISICION", nullable = true)
	public Date getFechaAdquisicion() {
		return fechaAdquisicion;
	}

	public void setFechaAdquisicion(Date fechaAdquisicion) {
		this.fechaAdquisicion = fechaAdquisicion;
	}

	@Column(name = "NUMERO_REPERTORIO", nullable = true)
	public String getNumeroRepertorio() {
		return numeroRepertorio;
	}

	public void setNumeroRepertorio(String numeroRepertorio) {
		this.numeroRepertorio = numeroRepertorio;
	}

	@Column(name = "FECHA_REPERTORIO", nullable = true)
	public Date getFechaRepertorio() {
		return fechaRepertorio;
	}

	public void setFechaRepertorio(Date fechaRepertorio) {
		this.fechaRepertorio = fechaRepertorio;
	}

	@Column(name = "REPERTORIO", nullable = true)
	public String getRepertorio() {
		return repertorio;
	}

	public void setRepertorio(String repertorio) {
		this.repertorio = repertorio;
	}

	@Column(name = "OFICINA_REGISTRO_CIVIL", nullable = true)
	public String getOficinaRegistrocivil() {
		return oficinaRegistrocivil;
	}

	public void setOficinaRegistrocivil(String oficinaRegistrocivil) {
		this.oficinaRegistrocivil = oficinaRegistrocivil;
	}

	/**
	 * @return el valor de propietarios
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = Propietario.class, mappedBy = "adquisicion", cascade = { CascadeType.ALL })
	@BatchSize (size = 20)
	public List<Propietario> getPropietarios() {
		return propietarios;
	}

	/**
	 * @param setea
	 *            el parametro propietarios al campo propietarios
	 */
	public void setPropietarios(List<Propietario> propietarios) {
		this.propietarios = propietarios;
	}

	/**
	 * @return el valor de actual
	 */
	@Column(name = "PROPIETARIO_ACTUAL", nullable = true)
	public Boolean getActual() {
		return actual;
	}

	/**
	 * @param setea
	 *            el parametro actual al campo actual
	 */
	public void setActual(Boolean actual) {
		this.actual = actual;
	}

	/**
	 * @return el valor de ppu
	 */
	@Column(name = "PPU", nullable = true)
	public String getPpu() {
		return ppu;
	}

	/**
	 * @param setea
	 *            el parametro ppu al campo ppu
	 */
	public void setPpu(String ppu) {
		this.ppu = ppu;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cl.mtt.rnt.commons.model.core.GenericModelObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {

		boolean res = super.equals(obj);
		if (res)
			return true;

		if (this.getFechaAdquisicion() == null)
			return false;

		return this.getFechaAdquisicion().equals(((Adquisicion) obj).getFechaAdquisicion()) && this.tieneMismosPropietarios((Adquisicion) obj);
	}

	@Transient
	public boolean tieneMismosPropietarios(Adquisicion adq) {
		if (this.getPropietarios().size() != adq.getPropietarios().size())
			return false;
		for (Propietario propietarioActual : getPropietarios()) {
			boolean ret = false;
			for (Propietario propietarioDestino : adq.getPropietarios()) {
				if (propietarioActual.getPersona().getRut().equals(propietarioDestino.getPersona().getRut()))
					ret = true;
			}
			if (!ret)
				return false;
		}
		return true;
	}

	/**
	 * @return el valor de coincideRegistroCivil
	 */
	@Transient
	public boolean isCoincideRegistroCivil() {
		return coincideRegistroCivil;
	}

	/**
	 * @param setea
	 *            el parametro coincideRegistroCivil al campo
	 *            coincideRegistroCivil
	 */
	public void setCoincideRegistroCivil(boolean coincideRegistroCivil) {
		this.coincideRegistroCivil = coincideRegistroCivil;
	}

	
	/**
	 * @return el valor de documentoInscripcion
	 */
	@ManyToOne(targetEntity = DocumentoBiblioteca.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_DOCUMENTO_BIBLIOTECA_TRANSFERENCIA")
	public DocumentoBiblioteca getDocumentoTransferencia() {
		return documentoTransferencia;
	}

	/**
	 * @param setea el parametro documentoInscripcion al campo documentoInscripcion
	 */
	public void setDocumentoTransferencia(DocumentoBiblioteca documentoTransferencia) {
		this.documentoTransferencia = documentoTransferencia;
	}

}
