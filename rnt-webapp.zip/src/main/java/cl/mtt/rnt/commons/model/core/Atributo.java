package cl.mtt.rnt.commons.model.core;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.userrol.User;

@Entity
@Table(name = "RNT_ATRIBUTO")
@Audited
public class Atributo extends GenericModelObject {

	private static final long serialVersionUID = -7168603511950815077L;

	private String tipo;
	private String etiqueta;
	private String aplicaA;
	private String componente;
	private String descriptor;
	private Integer ordenParcial;
	private boolean seleccionado;
	private boolean obligatorio;
	
	// Mejoras 201409 Nro: 28
	private boolean principal;
	// Mejoras 201409 Nro: 28

	// private List<TipoServicio> tiposServicios;
	private List<TipoServicioAtributo> tipoServicioAtributos;
	private List<FuenteDato> fuenteDeDatos;

	public static final String APLICA_A_SERVICIO = "servicio";
	public static final String APLICA_A_VEHICULO = "vehiculo";

	public static final String COMPONENTE_INPUT_TEXT = "inputText";
	public static final String COMPONENTE_CHECK_BOX = "checkBox";
	public static final String COMPONENTE_LISTA = "lista";
	public static final String COMPONENTE_CALENDAR = "calendar";

	public static final String entero = "Entero";
	public static final String texto = "Texto";
	public static final String real = "Real";
	public static final String booleano = "Verdadero-Falso";
	public static final String lista = "Lista";
	public static final String fecha = "Fecha";

	/**
	 * @return el valor de tipo
	 */
	@Column(name = "TIPO", nullable = false)
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param setea
	 *            el parametro tipo al campo tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * @return el valor de etiqueta
	 */
	@Column(name = "ETIQUETA", nullable = false)
	public String getEtiqueta() {
		return etiqueta;
	}

	/**
	 * @param setea
	 *            el parametro etiqueta al campo etiqueta
	 */
	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	/**
	 * @return el valor de aplicaA
	 */

	@Column(name = "APLICA_A", nullable = false)
	public String getAplicaA() {
		return aplicaA;
	}

	/**
	 * @param setea
	 *            el parametro aplicaA al campo aplicaA
	 */
	public void setAplicaA(String aplicaA) {
		this.aplicaA = aplicaA;
	}

	/**
	 * @return el valor de tiposServicios
	 */

	// @ManyToMany(targetEntity= TipoServicio.class,fetch=FetchType.LAZY)
	// @JoinTable(name="RNT_TIPO_SERVICIO_ATRIBUTO",
	// joinColumns=@JoinColumn(name="ID_ATRIBUTO"),inverseJoinColumns=@JoinColumn(name="ID_TIPO_SERVICIO"))
	// @Audited (targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	// public List<TipoServicio> getTiposServicios() {
	// return tiposServicios;
	// }
	// /**
	// * @param setea el parametro tiposServicios al campo tiposServicios
	// */
	// public void setTiposServicios(List<TipoServicio> tiposServicios) {
	// this.tiposServicios = tiposServicios;
	// }
	//
	/**
	 * @return el valor de componente
	 */
	@Column(name = "COMPONENTE", nullable = false)
	public String getComponente() {
		return componente;
	}

	/**
	 * @param setea
	 *            el parametro componente al campo componente
	 */
	public void setComponente(String componente) {
		this.componente = componente;
	}

	/**
	 * @return el valor de fuenteDeDatos
	 */
	@OneToMany(targetEntity = FuenteDato.class, mappedBy = "atributo", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@BatchSize (size = 3000)
	public List<FuenteDato> getFuenteDeDatos() {
		return fuenteDeDatos;
	}

	/**
	 * @param setea
	 *            el parametro fuenteDeDatos al campo fuenteDeDatos
	 */
	public void setFuenteDeDatos(List<FuenteDato> fuenteDeDatos) {
		this.fuenteDeDatos = fuenteDeDatos;
	}

	/**
	 * @return el valor de tipoServicioAtributos
	 */
	@OneToMany(targetEntity = TipoServicioAtributo.class, mappedBy = "atributo", fetch = FetchType.LAZY)
	@NotAudited
	public List<TipoServicioAtributo> getTipoServicioAtributos() {
		return tipoServicioAtributos;
	}

	/**
	 * @param setea
	 *            el parametro tipoServicioAtributos al campo
	 *            tipoServicioAtributos
	 */
	public void setTipoServicioAtributos(List<TipoServicioAtributo> tipoServicioAtributos) {
		this.tipoServicioAtributos = tipoServicioAtributos;
	}

	@Transient
	public String getNombre() {
		return etiqueta;
	}

	/**
	 * @return el valor de seleccionado
	 */
	@Transient
	public boolean isSeleccionado() {
		return seleccionado;
	}

	/**
	 * @param setea
	 *            el parametro seleccionado al campo seleccionado
	 */
	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	/**
	 * @return el valor de obligatorio
	 */
	@Transient
	public boolean isObligatorio() {
		return obligatorio;
	}

	/**
	 * @param setea
	 *            el parametro obligatorio al campo obligatorio
	 */
	public void setObligatorio(boolean obligatorio) {
		this.obligatorio = obligatorio;
	}
	
	// Mejoras 201409 Nro: 28
	@Transient
	public boolean isPrincipal() {
		return principal;
	}

	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}
	
	// Mejoras 201409 Nro: 28

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cl.mtt.rnt.commons.model.core.GenericModelObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		try {
			Atributo otro = (Atributo) obj;
			return otro.getId().equals(this.getId());
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * @return el valor de descriptor
	 */
	@Column(name = "DESCRIPTOR", nullable = true)
	public String getDescriptor() {
		return descriptor;
	}

	/**
	 * @param setea
	 *            el parametro descriptor al campo descriptor
	 */
	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	/**
	 * @return el valor de ordenParcial
	 */
	@Column(name = "ORDEN_PARCIAL", nullable = true)
	public Integer getOrdenParcial() {
		return ordenParcial;
	}

	/**
	 * @param setea
	 *            el parametro ordenParcial al campo ordenParcial
	 */
	public void setOrdenParcial(Integer ordenParcial) {
		this.ordenParcial = ordenParcial;
	}

	public Atributo clone(){
		Atributo a=new Atributo();
		
		a.setId(new Long(this.getId()));
		a.setCreation(this.getCreation());
		a.setModified(this.getModified());
		a.setUserCreation(this.getUserCreation());
		a.setUserModified(this.getUserModified());
	
		a.setTipo(new String(this.getTipo()));
		a.setEtiqueta(new String(this.getEtiqueta()));
		a.setAplicaA(new String(this.getAplicaA()));
		a.setComponente((this.getComponente()!=null)?new String(this.getComponente()):null);
		a.setDescriptor((this.getDescriptor()!=null)?new String(this.getDescriptor()):null);
		a.setOrdenParcial((this.getOrdenParcial()!=null)?new Integer(this.getOrdenParcial()):null);
		a.setFuenteDeDatos(this.getFuenteDeDatos());
		
		return a;

	}

}
