package cl.mtt.rnt.commons.model.core;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "RNT_ATRIBUTO_CARGA_MASIVA")
public class AtributoCargaMasiva extends GenericModelObject {
	
	private static final long serialVersionUID = 1893268091532074493L;
	private String clave;
	private String valor;
	private CargaMasiva cargaMasiva;
	/**
	 * @return el valor de clave
	 */
	public String getClave() {
		return clave;
	}
	/**
	 * @param setea el parametro clave al campo clave
	 */
	public void setClave(String clave) {
		this.clave = clave;
	}
	/**
	 * @return el valor de valor
	 */
	public String getValor() {
		return valor;
	}
	/**
	 * @param setea el parametro valor al campo valor
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}
	
	/**
	 * @return el valor de cargaMasiva
	 */
	@ManyToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CARGA_MASIVA")
	public CargaMasiva getCargaMasiva() {
		return cargaMasiva;
	}
	/**
	 * @param setea el parametro cargaMasiva al campo cargaMasiva
	 */
	public void setCargaMasiva(CargaMasiva cargaMasiva) {
		this.cargaMasiva = cargaMasiva;
	}
	
	
}
