package cl.mtt.rnt.commons.model.core;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import cl.mtt.rnt.commons.util.Constants;

@Entity
@Table(name = "RNT_ATRIBUTO_INSTANCIA")
public class AtributoInstancia extends GenericModelObject {

	SimpleDateFormat sdf = new SimpleDateFormat();
	private static final long serialVersionUID = 1L;

	private Atributo atributo;
	private String valor;

	private Servicio servicio;
	private Vehiculo vehiculo;
	private Long idVehiculo;
	private boolean obligatorio = false;
	// Mejoras 201409 Nro: 28
	private boolean principal = false;
	// Mejoras 201409 Nro: 28

	/**
	 * @return el valor de atributo
	 */
	@ManyToOne(targetEntity = Atributo.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_ATRIBUTO")
	public Atributo getAtributo() {
		return atributo;
	}

	/**
	 * @param setea
	 *            el parametro atributo al campo atributo
	 */
	public void setAtributo(Atributo atributo) {
		this.atributo = atributo;
	}

	/**
	 * @return el valor de valor
	 */
	@Column(name = "VALOR", nullable = true)
	public String getValor() {
		return valor;
	}

	/**
	 * @param setea
	 *            el parametro valor al campo valor
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

	/**
	 * @return el valor de servicio
	 */
	@ManyToOne(targetEntity = Servicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SERVICIO", nullable = true)
	public Servicio getServicio() {
		return servicio;
	}

	/**
	 * @param setea
	 *            el parametro servicio al campo servicio
	 */
	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}

	/**
	 * @return el valor de vehiculo
	 */
	@ManyToOne(targetEntity = Vehiculo.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_VEHICULO", nullable = true)
	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	/**
	 * @param setea
	 *            el parametro vehiculo al campo vehiculo
	 */
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	/**
	 * @return el valor de obligatorio
	 */
	@Transient
	public boolean isObligatorio() {
		return obligatorio;
	}

	/**
	 * @param setea
	 *            el parametro obligatorio al campo obligatorio
	 */
	public void setObligatorio(boolean obligatorio) {
		this.obligatorio = obligatorio;
	}
	
	// Mejoras 201409 Nro: 28
    @Transient
	public boolean isPrincipal() {
		return principal;
	}

	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}
	// Mejoras 201409 Nro: 28

	/**
	 * @return el valor de valorDate
	 */
	@Transient
	public Date getValorDate() {
		try {
			return Constants.dateFormat.parse(this.valor);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @param setea
	 *            el parametro valorDate al campo valorDate
	 */
	public void setValorDate(Date valorDate) {
		if (valorDate != null) {
			this.valor = Constants.dateFormat.format(valorDate);
		} else
			this.valor = null;
	}

	/**
	 * @return el valor de valorDate
	 */
	@Transient
	public Boolean getValorBoolean() {
		if (valor != null) {
			return "true".equals(valor);
		}
		return null;
	}

	/**
	 * @param setea
	 *            el parametro valorDate al campo valorDate
	 */
	public void setValorBoolean(Boolean valorBool) {
		if (valorBool != null) {
			if (valorBool.booleanValue()) {
				this.valor = "true";
			} else {
				this.valor = "false";
			}
		} else {
			this.valor = null;
		}
	}

	/**
	 * @return el valor de idVehiculo
	 */
	@Column(name = "ID_VEHICULO", updatable=false, insertable=false)
	public Long getIdVehiculo() {
		return idVehiculo;
	}

	/**
	 * @param setea el parametro idVehiculo al campo idVehiculo
	 */
	public void setIdVehiculo(Long idVehiculo) {
		this.idVehiculo = idVehiculo;
	}

}
