package cl.mtt.rnt.commons.model.core;

public class AuthenticationToken {
	
	private String username;
	private String sessionId;
	private String ticket;
	/**
	 * @return el valor de username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param setea el parametro username al campo username
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return el valor de sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}
	/**
	 * @param setea el parametro sessionId al campo sessionId
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	/**
	 * @return el valor de ticket
	 */
	public String getTicket() {
		return ticket;
	}
	/**
	 * @param setea el parametro ticket al campo ticket
	 */
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}
	
	

}
