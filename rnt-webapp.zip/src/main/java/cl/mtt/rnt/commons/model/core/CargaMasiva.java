package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.sgprt.Region;

@Entity
@Table(name = "RNT_CARGA_MASIVA")
@Audited
public class CargaMasiva extends GenericModelObject{

	private static final long serialVersionUID = 5052749870289536225L;
	
	private boolean compartido;
	private String nombre;
	private Region region;
	private String codigoRegion;
	private int estadoUltEjecucion;
	private Date fechaUltEjecucion;
	private TipoCargaMasiva tipoCargaMasiva;
	
	private CategoriaTransporte categoria;
	private TipoTransporte tipoTransporte;
	private MedioTransporte medio;
	
	private JobCargaMasiva job;
	private List<AtributoCargaMasiva> atributos;
	
	private DocumentoBiblioteca documentoAsociado;

	/**
	 * @return el valor de nombre
	 */
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param setea el parametro nombre al campo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return el valor de compartido
	 */
	@Column(name = "COMPARTIDO", nullable = false)
	public boolean isCompartido() {
		return compartido;
	}

	/**
	 * @param setea el parametro compartido al campo compartido
	 */
	public void setCompartido(boolean compartido) {
		this.compartido = compartido;
	}

	/**
	 * @return el valor de region
	 */
	@Transient
	public Region getRegion() {
		return region;
	}

	/**
	 * @param setea el parametro region al campo region
	 */
	public void setRegion(Region region) {
		this.region = region;
	}

	/**
	 * @return el valor de estadoUltEjecucion
	 */
	@Column(name = "ESTADO_ULT_EJECUCION")
	public int getEstadoUltEjecucion() {
		return estadoUltEjecucion;
	}

	/**
	 * @param setea el parametro estadoUltEjecucion al campo estadoUltEjecucion
	 */
	public void setEstadoUltEjecucion(int estadoUltEjecucion) {
		this.estadoUltEjecucion = estadoUltEjecucion;
	}

	/**
	 * @return el valor de fechaUltEjecucion
	 */
	@Column(name = "FECHA_ULT_EJECUCION")
	public Date getFechaUltEjecucion() {
		return fechaUltEjecucion;
	}

	/**
	 * @param setea el parametro fechaUltEjecucion al campo fechaUltEjecucion
	 */
	public void setFechaUltEjecucion(Date fechaUltEjecucion) {
		this.fechaUltEjecucion = fechaUltEjecucion;
	}

	/**
	 * @return el valor de tipoCargaMasiva
	 */
	@ManyToOne(targetEntity = TipoCargaMasiva.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_CARGA_MASIVA",nullable=true)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoCargaMasiva getTipoCargaMasiva() {
		return tipoCargaMasiva;
	}

	/**
	 * @param setea el parametro tipoCargaMasiva al campo tipoCargaMasiva
	 */
	public void setTipoCargaMasiva(TipoCargaMasiva tipoCargaMasiva) {
		this.tipoCargaMasiva = tipoCargaMasiva;
	}

	/**
	 * @return el valor de job
	 */
	@ManyToOne(targetEntity = JobCargaMasiva.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_JOB_CARGA_MASIVA",nullable=true)
	@Cascade({CascadeType.DELETE})
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public JobCargaMasiva getJob() {
		return job;
	}

	/**
	 * @param setea el parametro job al campo job
	 */	
	public void setJob(JobCargaMasiva job) {
		this.job = job;
	}

	/**
	 * @return el valor de codigoRegion
	 */
	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	/**
	 * @param setea el parametro codigoRegion al campo codigoRegion
	 */
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	
	@ManyToOne(targetEntity = CategoriaTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CATEGORIA",nullable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public CategoriaTransporte getCategoria() {
		return categoria;
	}

	public void setCategoria(CategoriaTransporte categoria) {
		this.categoria = categoria;
	}

	@ManyToOne(targetEntity = TipoTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_TRANSPORTE",nullable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoTransporte getTipoTransporte() {
		return tipoTransporte;
	}

	public void setTipoTransporte(TipoTransporte tipoTransporte) {
		this.tipoTransporte = tipoTransporte;
	}

	@ManyToOne(targetEntity = MedioTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_MEDIO_TRANSPORTE",nullable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public MedioTransporte getMedio() {
		return medio;
	}

	public void setMedio(MedioTransporte medio) {
		this.medio = medio;
	}

	/**
	 * @return el valor de atributos
	 */
	@OneToMany(targetEntity=AtributoCargaMasiva.class,mappedBy="cargaMasiva",fetch = FetchType.EAGER)
	@Cascade({CascadeType.ALL})
	@NotAudited
	public List<AtributoCargaMasiva> getAtributos() {
		if(atributos==null) this.atributos= new ArrayList<AtributoCargaMasiva>();
		return atributos;
	}

	/**
	 * @param setea el parametro atributos al campo atributos
	 */
	public void setAtributos(List<AtributoCargaMasiva> atributos) {
		this.atributos = atributos;
	}

	/**
	 * @return el valor de documentoAsociado
	 */
	@ManyToOne(targetEntity = DocumentoBiblioteca.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_DOCUMENTO_BIBLIOTECA_ASOCIADO")
	public DocumentoBiblioteca getDocumentoAsociado() {
		return documentoAsociado;
	}

	/**
	 * @param setea el parametro documentoAsociado al campo documentoAsociado
	 */
	public void setDocumentoAsociado(DocumentoBiblioteca documentoAsociado) {
		this.documentoAsociado = documentoAsociado;
	}
	
	
	
}
