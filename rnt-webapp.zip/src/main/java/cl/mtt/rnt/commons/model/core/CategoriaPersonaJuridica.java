package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_CATEGORIA_PERSONA")
@Audited
public class CategoriaPersonaJuridica extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5187319111766751833L;

	private String nombre;

	/**
	 * @return el valor de nombre
	 */
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param setea
	 *            el parametro nombre al campo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
