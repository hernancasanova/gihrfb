package cl.mtt.rnt.commons.model.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

/**
 * Mantiene la informacion de Categoria de transporte
 * 
 * @author josebision
 * 
 */

@Entity
@Table(name = "RNT_CATEGORIA_TRANSPORTE")
@Audited
public class CategoriaTransporte extends GenericModelObject implements Serializable {

	private static final long serialVersionUID = -6591162279037377787L;

	private String nombre;
	private String nombreImagen;
	private String descriptor;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "NOMBRE_IMAGEN", nullable = false)
	public String getNombreImagen() {
		return nombreImagen;
	}

	public void setNombreImagen(String nombreImagen) {
		this.nombreImagen = nombreImagen;
	}

	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cl.mtt.rnt.commons.model.core.GenericModelObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		try {
			CategoriaTransporte cat = (CategoriaTransporte) obj;
			return cat.getDescriptor().equals(this.getDescriptor());
		} catch (Exception e) {
			return false;
		}
	}

}