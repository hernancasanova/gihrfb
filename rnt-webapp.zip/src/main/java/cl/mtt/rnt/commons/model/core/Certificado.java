package cl.mtt.rnt.commons.model.core;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;

import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.commons.util.CampoDecorator;
import cl.mtt.rnt.commons.util.Constants;

@Entity
@Table(name = "RNT_CERTIFICADO")
public class Certificado extends GenericNotAuditCancellableModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4973873732625664749L;
	public static final String ESTADO_FIRMA_FIRMADO = "firmado";
	public static final String ESTADO_FIRMA_WS_FIRMADO = "Firmado";
	public static final String ESTADO_FIRMA_FIRMADO_MANUAL = "firmado manual";
	public static final String ESTADO_FIRMA_WS_FIRMADO_MANUAL = "Firmado Manual";
	public static final String ESTADO_SIN_FIRMAR = "sin firmar";
	public static final String ESTADO_SIN_FIRMAR_WS = "Espera de Firma";
	public static final String ESTADO_FIRMA_RECHAZADO = "rechazado";
	public static final String ESTADO_ENVIADO_A_FIRMAR = "enviado a firmar";
	public static final String ESTADO_CERTIFICADO_MIGRADO = "certificado migrado";
	public static final String ESTADO_CANCELADO = "cancelado";
	public static final String ESTADO_FIRMA_MANUAL = "firma manual";
	public static final String ESTADO_FIRMA_AUTOMATICA = "firma automatica";
	private TipoCertificado tipoCertificado;
	private VehiculoServicio vehiculo;
	private Recorrido recorrido;
	private String estadoFirma;
	private Date fechaDesde;
	private Date fechaHasta;
	private Integer identificadorWS;
	private String linkCertificado;
	private String codigoRegion;
	private Long nroFolio;
	private Date fechaFolio;
	
	private boolean selected;
	
	//para performance
	private Long idVehiculoServicio;
	private Long idRecorrido; 

	private Map<String, CampoDecorator> modifiers = new HashMap<String, CampoDecorator>();
//	private List<CertificadoDato> certificadoDatos;
	
	private XmlCertificado xml;
	private String checksum;

	@ManyToOne(targetEntity = VehiculoServicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_VEHICULO_SERVICIO")
	public VehiculoServicio getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(VehiculoServicio vehiculo) {
		this.vehiculo = vehiculo;
	}

	/**
	 * @return el valor de tipoCertificado
	 */
	@ManyToOne(targetEntity = TipoCertificado.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_CERTIFICADO")
	public TipoCertificado getTipoCertificado() {
		return tipoCertificado;
	}

	/**
	 * @param setea
	 *            el parametro tipoCertificado al campo tipoCertificado
	 */
	public void setTipoCertificado(TipoCertificado tipoCertificado) {
		this.tipoCertificado = tipoCertificado;
	}

	/**
	 * @return el valor de estadoFirma
	 */
	@Column(name = "ESTADO_FIRMA", nullable = true)
	public String getEstadoFirma() {
		return estadoFirma;
	}

	/**
	 * @param setea
	 *            el parametro estadoFirma al campo estadoFirma
	 */
	public void setEstadoFirma(String estadoFirma) {
		this.estadoFirma = estadoFirma;
	}

	/**
	 * @return el valor de fechaDesde
	 */
	@Column(name = "FECHA_DESDE", nullable = true)
	public Date getFechaDesde() {
		return fechaDesde;
	}

	/**
	 * @param setea
	 *            el parametro fechaDesde al campo fechaDesde
	 */
	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	/**
	 * @return el valor de fechaHasta
	 */
	@Column(name = "FECHA_HASTA", nullable = true)
	public Date getFechaHasta() {
		return fechaHasta;
	}

	/**
	 * @param setea
	 *            el parametro fechaHasta al campo fechaHasta
	 */
	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	/**
	 * @return el valor de trazado
	 */
	@ManyToOne(targetEntity = Recorrido.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_RECORRIDO")
	/**
	 * @return el valor de recorrido
	 */
	public Recorrido getRecorrido() {
		return recorrido;
	}

	/**
	 * @param setea
	 *            el parametro recorrido al campo recorrido
	 */
	public void setRecorrido(Recorrido recorrido) {
		this.recorrido = recorrido;
	}

	@Transient
	public String getRelacionadoCon() {
		if (this.getVehiculo() != null) {
			String ret = "(" + this.getVehiculo().getServicio().getIdentServicio() + ") " + this.getVehiculo().getVehiculo().getPpu();
			if (this.getRecorrido() != null)
				ret += " - "+ this.getRecorrido().getNombre();
			return ret;
		} else {
			if (this.getRecorrido() != null)
				return "(" + this.getRecorrido().getServicio().getIdentServicio() + ") " + this.getRecorrido().getNombre();
			return "";
		}
	}

	@Transient
	public String getFechaEstadoDesc() {
		if (getEstado().intValue() <= 1) {
			if (fechaDesde != null) {
				return Constants.dateFormat.format(fechaDesde);
			}
		} else {
			if (fechaHasta != null) {
				return Constants.dateFormat.format(fechaHasta);
			}
		}
		return "";
	}

	/**
	 * @return el valor de identificadorWS
	 */
	@Column(name = "IDENT_FIRMADOR", nullable = true)
	public Integer getIdentificadorWS() {
		return identificadorWS;
	}

	/**
	 * @param setea
	 *            el parametro identificadorWS al campo identificadorWS
	 */
	public void setIdentificadorWS(Integer identificadorWS) {
		this.identificadorWS = identificadorWS;
	}

	@Transient
	public Object getObjetoAsociado() {
		if (this.getTipoCertificado().getClaseTipoCertificado().getObjeto().equals(TipoCertificado.OBJETO_VEHICULO))
			return this.getVehiculo();
		else if (this.getTipoCertificado().getClaseTipoCertificado().getObjeto().equals(TipoCertificado.OBJETO_RECORRIDO)) {
			return this.getRecorrido();
		}

		return null;
	}

	@Transient
	public String getNombreObjetoAsociado() {
		if (this.getTipoCertificado().getClaseTipoCertificado().getObjeto().equals(TipoCertificado.OBJETO_VEHICULO))
			return TipoCertificado.OBJETO_VEHICULO;
		else if (this.getTipoCertificado().getClaseTipoCertificado().getObjeto().equals(TipoCertificado.OBJETO_RECORRIDO)) {
			return TipoCertificado.OBJETO_RECORRIDO;
		}

		return "";
	}

	/**
	 * @return el valor de modifiers
	 */
	@Transient
	public Map<String, CampoDecorator> getModifiers() {
		return modifiers;
	}

	/**
	 * @param setea
	 *            el parametro modifiers al campo modifiers
	 */
	public void setModifiers(Map<String, CampoDecorator> modifiers) {
		this.modifiers = modifiers;
	}

	@Transient
	public boolean isFirmado() {
		return Certificado.ESTADO_FIRMA_FIRMADO.equals(this.estadoFirma);
	}

	@Transient
	public boolean isSinFirmar() {
		return Certificado.ESTADO_SIN_FIRMAR.equals(this.estadoFirma);
	}
	
	@Transient
	public boolean isEnviadoAFirmar() {
		return Certificado.ESTADO_ENVIADO_A_FIRMAR.equals(this.estadoFirma);
	}

	@Transient
	public boolean isRechazado() {
		return Certificado.ESTADO_FIRMA_RECHAZADO.equals(this.estadoFirma);
	}
	
	@Transient
	public boolean isCancelado() {
		return Certificado.ESTADO_CANCELADO.equals(this.estadoFirma);
	}
	
	@Transient
	public boolean isMigrado() {
		return Certificado.ESTADO_CERTIFICADO_MIGRADO.equals(this.estadoFirma);
	}

	// Mejoras 201409 Nro: 33
	@Transient
	public boolean isVencido() {
		Date today = new Date();
		return today.after(this.fechaHasta);
	}
	// Mejoras 201409 Nro: 33
	
	@Column(name = "LINK_DOCUMENTO", nullable = true)
	public String getLinkCertificado() {
		return linkCertificado;
	}

	public void setLinkCertificado(String linkCertificado) {
		this.linkCertificado = linkCertificado;
	}

//	@OneToMany(targetEntity = CertificadoDato.class, mappedBy = "certificado", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//	public List<CertificadoDato> getCertificadoDatos() {
//		return certificadoDatos;
//	}
//
//	public void setCertificadoDatos(List<CertificadoDato> certificadoDatos) {
//		this.certificadoDatos = certificadoDatos;
//		for (CertificadoDato certificadoDato : certificadoDatos) {
//			certificadoDato.setCertificado(this);
//		}
//	}

	/**
	 * @return el valor de selected
	 */
	@Transient
	public boolean isSelected() {
		return selected;
	}

	/**
	 * @param setea el parametro selected al campo selected
	 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	/**
	 * @return el valor de xml
	 */	
	@OneToOne(targetEntity=XmlCertificado.class,mappedBy="certificado",fetch=FetchType.LAZY)
	public XmlCertificado getXml() {
		return xml;
	}

	/**
	 * @param setea el parametro xml al campo xml
	 */
	public void setXml(XmlCertificado xml) {
		this.xml = xml;
	}
	
	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}
	
	@Column(name = "NRO_FOLIO", nullable = true)
	public Long getNroFolio() {
		return nroFolio;
	}

	public void setNroFolio(Long nroFolio) {
		this.nroFolio = nroFolio;
	}
	
	@Column(name = "FECHA_FOLIO", nullable = true)
	public Date getFechaFolio() {
		return fechaFolio;
	}

	public void setFechaFolio(Date fechaFolio) {
		this.fechaFolio = fechaFolio;
	}

	@Column(name = "CHECKSUM_MD5", nullable = true)
	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

    /**
     * @return el valor de idVehiculoServicio
     */
	@Column(name = "ID_VEHICULO_SERVICIO", updatable=false, insertable=false)
	public Long getIdVehiculoServicio() {
        return idVehiculoServicio;
    }

    /**
     * @param setea el parametro idVehiculoServicio al campo idVehiculoServicio
     */
	public void setIdVehiculoServicio(Long idVehiculoServicio) {
        this.idVehiculoServicio = idVehiculoServicio;
    }

    /**
     * @return el valor de idRecorrido
     */
    @Column(name = "ID_RECORRIDO", updatable=false, insertable=false)
    public Long getIdRecorrido() {
        return idRecorrido;
    }

    /**
     * @param setea el parametro idRecorrido al campo idRecorrido
     */
    public void setIdRecorrido(Long idRecorrido) {
        this.idRecorrido = idRecorrido;
    }
	
  


}
