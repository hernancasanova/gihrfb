package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_CERTIFICADO_CAMPO")
public class CertificadoCampo extends GenericModelObject implements Comparable<CertificadoCampo> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1700750500131313502L;

	private CertificadoCampoDefinition campoDefinition;
	private CertificadoSeccion seccion;

	private String etiqueta;
	private String valor;

	@ManyToOne(targetEntity = CertificadoCampoDefinition.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CERTIFICADO_CAMPO_DEF")
	public CertificadoCampoDefinition getCampoDefinition() {
		return campoDefinition;
	}

	public void setCampoDefinition(CertificadoCampoDefinition campoDefinition) {
		this.campoDefinition = campoDefinition;
	}

	@ManyToOne(targetEntity = CertificadoSeccion.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_SECCION")
	public CertificadoSeccion getSeccion() {
		return seccion;
	}

	public void setSeccion(CertificadoSeccion seccion) {
		this.seccion = seccion;
	}

	/**
	 * @return el valor de etiqueta
	 */
	@Column(name = "ETIQUETA", nullable = true)
	public String getEtiqueta() {
		return etiqueta;
	}

	/**
	 * @param setea
	 *            el parametro etiqueta al campo etiqueta
	 */
	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	/**
	 * @return el valor de valor
	 */
	@Column(name = "VALOR_CAMPO", nullable = true)
	public String getValor() {
		return valor;
	}

	/**
	 * @param setea
	 *            el parametro valor al campo valor
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}


	@Override
	public int compareTo(CertificadoCampo o) {
		String t1 = this.getCampoDefinition().getDescriptor();
		String t2 = o.getCampoDefinition().getDescriptor();
		if (t1 == null && t2 == null){
			return 0;
		}else if (t1 == null){
			return -1;
		} else if (t2 == null) {
			return 1;
		} else {
			return t1.toLowerCase().compareTo(t2.toLowerCase());
		}
	}
}
