package cl.mtt.rnt.commons.model.core;

import java.util.Enumeration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.swing.tree.TreeNode;

@Entity
@Table(name = "RNT_CERTIFICADO_CAMPO_DEF")
public class CertificadoCampoDefinition extends NodoCertificado {

	private static final long serialVersionUID = -467252804139805466L;

	public static final int TIPO_CAMPO_PROPERTY = 1;
	public static final int TIPO_CAMPO_ATRIBUTO_SERVICIO = 2;
	public static final int TIPO_CAMPO_ATRIBUTO_VEHICULO = 3;
	public static final int TIPO_CAMPO_VALOR_FIJO = 4;
	public static final int TIPO_CAMPO_VALOR_VARIABLE = 5;

	private CertificadoSeccionDefinition seccionDefinition;
	private Integer tipoCampo;
	private String valor;

	@ManyToOne(targetEntity = CertificadoSeccionDefinition.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_SECCION_DEF")
	public CertificadoSeccionDefinition getSeccionDefinition() {
		return seccionDefinition;
	}

	public void setSeccionDefinition(CertificadoSeccionDefinition seccionDefinition) {
		this.seccionDefinition = seccionDefinition;
	}

	@Override
	@Transient
	public TreeNode getChildAt(int childIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transient
	public int getChildCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	@Transient
	public TreeNode getParent() {
		return getSeccionDefinition();
	}

	@Override
	@Transient
	public int getIndex(TreeNode node) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	@Transient
	public boolean getAllowsChildren() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	@Transient
	public boolean isLeaf() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	@Transient
	public Enumeration children() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return el valor de tipoCampo
	 */
	@Column(name = "TIPO_CAMPO", nullable = true)
	public Integer getTipoCampo() {
		return tipoCampo;
	}

	/**
	 * @param setea
	 *            el parametro tipoCampo al campo tipoCampo
	 */
	public void setTipoCampo(Integer tipoCampo) {
		this.tipoCampo = tipoCampo;
	}

	/**
	 * @return el valor de valor
	 */
	@Transient
	public String getValor() {
		return valor;
	}

	/**
	 * @param setea
	 *            el parametro valor al campo valor
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}


}
