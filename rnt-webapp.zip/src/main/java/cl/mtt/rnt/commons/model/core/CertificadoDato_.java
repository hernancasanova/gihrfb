package cl.mtt.rnt.commons.model.core;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

//@Entity
//@Table(name = "RNT_CERTIFICADO_DATO")
public class CertificadoDato_ extends GenericModelObject {

//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = 650443154375037713L;
//	private CertificadoCampo certificadoCampo;
//	private Certificado certificado;
//	private Long idObject;
//	private String valor;
//	private String checksum;
//
//	public CertificadoDato_() {
//		super();
//	}
//
//	public CertificadoDato_(CertificadoCampo certificadoCampo, Certificado certificado, Long idObject, String valor) {
//		super();
//		this.certificadoCampo = certificadoCampo;
//		this.certificado = certificado;
//		this.idObject = idObject;
//		
//		if(valor!=null){
//			try {
//				MessageDigest md = MessageDigest.getInstance("MD5");
//		        md.update(valor.getBytes());
//				byte byteData[] = md.digest();
//		        //convert the byte to hex format method 1
//		        StringBuffer sb = new StringBuffer();
//		        for (int i = 0; i < byteData.length; i++) {
//		         sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
//		        }
//		        checksum=sb.toString();
//			} catch (NoSuchAlgorithmException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		if (valor.length()>200){
//			valor=valor.substring(0,200);
//		} 
//		this.valor = valor;
//	}
//
//	@ManyToOne(targetEntity = CertificadoCampo.class, fetch = FetchType.LAZY)
//	@JoinColumn(name = "ID_CERTIFICADO_CAMPO")
//	public CertificadoCampo getCertificadoCampo() {
//		return certificadoCampo;
//	}
//
//	public void setCertificadoCampo(CertificadoCampo certificadoCampo) {
//		this.certificadoCampo = certificadoCampo;
//	}
//
//	@ManyToOne(targetEntity = Certificado.class, fetch = FetchType.LAZY)
//	@JoinColumn(name = "ID_CERTIFICADO")
//	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
//	public Certificado getCertificado() {
//		return certificado;
//	}
//
//	public void setCertificado(Certificado certificado) {
//		this.certificado = certificado;
//	}
//
//	@Column(name = "ID_OBJECT", nullable = true)
//	public Long getIdObject() {
//		return idObject;
//	}
//
//	public void setIdObject(Long idObject) {
//		this.idObject = idObject;
//	}
//
//	@Column(name = "VALOR", nullable = true)
//	public String getValor() {
//		return valor;
//	}
//
//	public void setValor(String valor) {
//		this.valor = valor;
//	}
//
//	@Column(name = "CHECKSUM_MD5", nullable = true)
//	public String getChecksum() {
//		return checksum;
//	}
//
//	public void setChecksum(String checksum) {
//		this.checksum = checksum;
//	}

}
