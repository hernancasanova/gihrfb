package cl.mtt.rnt.commons.model.core;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_CERTIFICADO_SECCION")
public class CertificadoSeccion extends GenericModelObject implements Comparable<CertificadoSeccion> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2424084582642611086L;

	private CertificadoSeccionDefinition seccionDefinition;

	private CertificadoSeccion seccionSuperior;

	private List<CertificadoSeccion> secciones;
	private List<CertificadoCampo> campos;

	private String etiqueta;

	@OneToMany(fetch = FetchType.EAGER, targetEntity = CertificadoSeccion.class, mappedBy = "seccionSuperior")
	public List<CertificadoSeccion> getSecciones() {
		Collections.sort(secciones);
		return secciones;
	}

	public void setSecciones(List<CertificadoSeccion> secciones) {
		this.secciones = secciones;
	}

	@OneToMany(fetch = FetchType.EAGER, targetEntity = CertificadoCampo.class, mappedBy = "seccion")
	public List<CertificadoCampo> getCampos() {
		Collections.sort(campos);
		return campos;
	}

	public void setCampos(List<CertificadoCampo> campos) {
		this.campos = campos;
	}

	@ManyToOne(targetEntity = CertificadoSeccionDefinition.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CERTIFICADO_SECCION_DEF")
	public CertificadoSeccionDefinition getSeccionDefinition() {
		return seccionDefinition;
	}

	public void setSeccionDefinition(CertificadoSeccionDefinition seccionDefinition) {
		this.seccionDefinition = seccionDefinition;
	}

	@ManyToOne(targetEntity = CertificadoSeccion.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_SECCION_SUPERIOR")
	public CertificadoSeccion getSeccionSuperior() {
		return seccionSuperior;
	}

	public void setSeccionSuperior(CertificadoSeccion seccionSuperior) {
		this.seccionSuperior = seccionSuperior;
	}

	/**
	 * @return el valor de etiqueta
	 */
	@Column(name = "ETIQUETA", nullable = true)
	public String getEtiqueta() {
		return etiqueta;
	}

	/**
	 * @param setea
	 *            el parametro etiqueta al campo etiqueta
	 */
	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}


	@Override
	public int compareTo(CertificadoSeccion o) {
		String t1 = this.getSeccionDefinition().getDescriptor();
		String t2 = o.getSeccionDefinition().getDescriptor();
		if (t1 == null && t2 == null){
			return 0;
		}else if (t1 == null){
			return -1;
		} else if (t2 == null) {
			return 1;
		} else {
			return t1.toLowerCase().compareTo(t2.toLowerCase());
		}
	}
}
