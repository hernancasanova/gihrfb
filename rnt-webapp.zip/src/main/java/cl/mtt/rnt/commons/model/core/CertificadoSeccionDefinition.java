package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.swing.tree.TreeNode;

import com.google.common.collect.Iterators;

@Entity
@Table(name = "RNT_CERTIFICADO_SECCION_DEF")
public class CertificadoSeccionDefinition extends NodoCertificado{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6515469293854074818L;

	private CertificadoSeccionDefinition seccionSuperior;
	private Boolean multiple = false;

	private List<CertificadoSeccionDefinition> secciones;
	private List<CertificadoCampoDefinition> campos;

	private String aplica;

	@OneToMany(fetch = FetchType.EAGER, targetEntity = CertificadoSeccionDefinition.class, mappedBy = "seccionSuperior")
	public List<CertificadoSeccionDefinition> getSecciones() {
		Collections.sort(secciones);
		return secciones;
	}

	public void setSecciones(List<CertificadoSeccionDefinition> secciones) {
		this.secciones = secciones;
	}

	@OneToMany(fetch = FetchType.EAGER, targetEntity = CertificadoCampoDefinition.class, mappedBy = "seccionDefinition")
	public List<CertificadoCampoDefinition> getCampos() {
		Collections.sort(campos);
		return campos;
	}

	public void setCampos(List<CertificadoCampoDefinition> campos) {
		this.campos = campos;
	}

	@ManyToOne(targetEntity = CertificadoSeccionDefinition.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_SECCION_SUPERIOR_DEF")
	public CertificadoSeccionDefinition getSeccionSuperior() {
		return seccionSuperior;
	}

	public void setSeccionSuperior(CertificadoSeccionDefinition seccionSuperior) {
		this.seccionSuperior = seccionSuperior;
	}

	@Column(name = "MULTIPLE", nullable = false)
	public Boolean isMultiple() {
		return multiple;
	}

	public void setMultiple(Boolean multiple) {
		this.multiple = multiple;
	}

	@Column(name = "APLICA", nullable = true)
	public String getAplica() {
		return aplica;
	}

	public void setAplica(String aplica) {
		this.aplica = aplica;
	}

	@Override
	@Transient
	public TreeNode getChildAt(int childIndex) {
		if (childIndex < secciones.size())
			return secciones.get(childIndex);
		else
			return campos.get(childIndex - secciones.size());
	}

	@Override
	@Transient
	public int getChildCount() {
		return secciones.size() + campos.size();
	}

	@Override
	@Transient
	public TreeNode getParent() {
		return getSeccionSuperior();
	}

	@Override
	@Transient
	public int getIndex(TreeNode node) {
		int ind = secciones.indexOf(node);
		if (ind >= 0)
			return ind;
		ind = campos.indexOf(node);
		if (ind >= 0)
			return ind + secciones.size();
		return -1;
	}

	@Override
	@Transient
	public boolean getAllowsChildren() {
		return true;
	}

	@Override
	@Transient
	public boolean isLeaf() {
		return false;
	}

	@SuppressWarnings("rawtypes")
	@Override
	@Transient
	public Enumeration children() {
		List<Object> ret = new ArrayList<Object>();
		ret.addAll(getSecciones());
		ret.addAll(getCampos());
		return Iterators.asEnumeration(ret.iterator());
	}


}
