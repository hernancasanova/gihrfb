package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import cl.mtt.rnt.commons.model.sgprt.Region;

@Entity
@Table(name = "RNT_CERTIFICADO_VALORES_VARIABLES")
public class CertificadoValorVariable extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private String descriptor;
	private String valorVariable;
	private String codigoRegion;
	private Region region;

	/**
	 * @return el valor de descriptor
	 */
	@Column(name = "DESCRIPTOR", nullable = true)
	public String getDescriptor() {
		return descriptor;
	}

	/**
	 * @param setea
	 *            el parametro descriptor al campo descriptor
	 */
	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	/**
	 * @return el valor de valorVariable
	 */
	@Column(name = "VALOR_VARIABLE", nullable = true)
	public String getValorVariable() {
		return valorVariable;
	}

	/**
	 * @param setea
	 *            el parametro valorVariable al campo valorVariable
	 */
	public void setValorVariable(String valorVariable) {
		this.valorVariable = valorVariable;
	}

	/**
	 * @return el valor de codigoRegion
	 */
	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	/**
	 * @param setea
	 *            el parametro codigoRegion al campo codigoRegion
	 */
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	/**
	 * @return el valor de region
	 */
	@Transient
	public Region getRegion() {
		return region;
	}

	/**
	 * @param setea
	 *            el parametro region al campo region
	 */
	public void setRegion(Region region) {
		this.region = region;
	}

}
