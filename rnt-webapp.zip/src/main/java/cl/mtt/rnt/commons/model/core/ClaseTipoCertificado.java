package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "RNT_CLASE_TIPO_CERTIFICADO")
public class ClaseTipoCertificado extends GenericModelObject {

	private static final long serialVersionUID = 7855940414797720276L;

	private String nombre;
	private String movimiento;
	private String objeto;

	public static final String MOVIMIENTO_ADD = "inscripcion";
	public static final String MOVIMIENTO_CHANGE = "actualizacion";
	public static final String MOVIMIENTO_CANCEL = "cancelacion";

	public static final String OBJETO_RECORRIDO = "recorrido";
	public static final String OBJETO_VEHICULO = "vehiculo";

	private CertificadoSeccionDefinition seccionRaiz;
	private Long seccionRaizId;

	/**
	 * @return el valor de nombre
	 */
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param setea
	 *            el parametro nombre al campo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return el valor de movimiento
	 */
	@Column(name = "MOVIMIENTO")
	public String getMovimiento() {
		return movimiento;
	}

	/**
	 * @param setea
	 *            el parametro movimiento al campo movimiento
	 */
	public void setMovimiento(String movimiento) {
		this.movimiento = movimiento;
	}

	/**
	 * @return el valor de objeto
	 */
	@Column(name = "OBJETO")
	public String getObjeto() {
		return objeto;
	}

	/**
	 * @param setea
	 *            el parametro objeto al campo objeto
	 */
	public void setObjeto(String objeto) {
		this.objeto = objeto;
	}

	@ManyToOne(targetEntity = CertificadoSeccionDefinition.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SECCION_RAIZ_DEF")
	public CertificadoSeccionDefinition getSeccionRaiz() {
		return seccionRaiz;
	}

	public void setSeccionRaiz(CertificadoSeccionDefinition seccionRaiz) {
		this.seccionRaiz = seccionRaiz;
	}

	@Transient
	public String getMovimientoAdd() {
		return MOVIMIENTO_ADD;
	}

	@Transient
	public String getMovimientoChange() {
		return MOVIMIENTO_CHANGE;
	}

	@Transient
	public String getMovimientoCancel() {
		return MOVIMIENTO_CANCEL;
	}

	@Transient
	public String getObjetoRecorrido() {
		return OBJETO_RECORRIDO;
	}

	@Transient
	public String getObjetoVehiculo() {
		return OBJETO_VEHICULO;
	}

	/**
	 * @return el valor de seccionRaizId
	 */
    @Column(name = "ID_SECCION_RAIZ_DEF", updatable=false, insertable=false)
	public Long getSeccionRaizId() {
		return seccionRaizId;
	}

	/**
	 * @param setea el parametro seccionRaizId al campo seccionRaizId
	 */
	public void setSeccionRaizId(Long seccionRaizId) {
		this.seccionRaizId = seccionRaizId;
	}
}
