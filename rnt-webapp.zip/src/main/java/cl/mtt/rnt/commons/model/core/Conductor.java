package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.util.ElResolver;

@Entity
@Table(name = "RNT_CONDUCTOR")
@Audited
public class Conductor extends GenericModelObject {

	public static final String TIPO_CONDUCTOR = "CONDUCTOR";
	public static final String TIPO_AUXILIAR = "AUXILIAR";

	private static final long serialVersionUID = -1524198341388744259L;
	private String domicilio;
	private String codigoComuna;
	private String codigoLocalidad;
	private String telefono;
	private String fax;
	private String email;
	private Boolean activo;
	private Persona persona;
	private String tipoConductor;
	// Datos de Licencia de conducir
	private ClaseLicenciaConducir claseLicenciaConducir;
	private String codigoComunaOtorgante;
	private String certificadoAntecedentes;
	private Date vigenciaDesdeLicencia;
	private Date vigenciaHastaLicencia;

	private String nombreRegion;
	private String nombreComuna;
	private String nombreComunaOtorgante;
	private Comuna comunaOtorgante;
	private String nombreRegionOtorgante;

	@Column(name = "CODIGO_LOCALIDAD", nullable = true)
	public String getCodigoLocalidad() {
		return codigoLocalidad;
	}

	public void setCodigoLocalidad(String codigoLocalidad) {
		this.codigoLocalidad = codigoLocalidad;
	}

	@Column(name = "activo", nullable = false)
	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	@ManyToOne(targetEntity = Persona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PERSONA")
	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Column(name = "DOMICILIO", nullable = true)
	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "TELEFONO", nullable = true)
	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Column(name = "FAX", nullable = true)
	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "EMAIL", nullable = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "TIPO_CONDUCTOR", nullable = false)
	public String getTipoConductor() {
		return tipoConductor;
	}

	public void setTipoConductor(String tipoConductor) {
		this.tipoConductor = tipoConductor;
	}

	@ManyToOne(targetEntity = ClaseLicenciaConducir.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CLASE_LICENCIA", nullable = true)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public ClaseLicenciaConducir getClaseLicenciaConducir() {
		return claseLicenciaConducir;
	}

	public void setClaseLicenciaConducir(ClaseLicenciaConducir claseLicenciaConducir) {
		this.claseLicenciaConducir = claseLicenciaConducir;
	}

	@Column(name = "CODIGO_COMUNA_OTORGANTE", nullable = true)
	public String getCodigoComunaOtorgante() {
		return codigoComunaOtorgante;
	}

	public void setCodigoComunaOtorgante(String codigoComunaOtorgante) {
		this.codigoComunaOtorgante = codigoComunaOtorgante;
	}

	@Column(name = "VIGENCIA_DESDE_LICENCIA", nullable = true)
	public Date getVigenciaDesdeLicencia() {
		return vigenciaDesdeLicencia;
	}

	public void setVigenciaDesdeLicencia(Date vigenciaDesdeLicencia) {
		this.vigenciaDesdeLicencia = vigenciaDesdeLicencia;
	}

	@Column(name = "VIGENCIA_HASTA_LICENCIA", nullable = true)
	public Date getVigenciaHastaLicencia() {
		return vigenciaHastaLicencia;
	}

	public void setVigenciaHastaLicencia(Date vigenciaHastaLicencia) {
		this.vigenciaHastaLicencia = vigenciaHastaLicencia;
	}

	@Column(name = "CERTIFICADO_ANTECEDENTES", nullable = true)
	public String getCertificadoAntecedentes() {
		return certificadoAntecedentes;
	}

	public void setCertificadoAntecedentes(String certificadoAntecedentes) {
		this.certificadoAntecedentes = certificadoAntecedentes;
	}

	@Transient
	public String getNombreRegion() {
		if (this.codigoComuna != null) {
			Comuna comuna = getComunaDb(this.codigoComuna);
			if (comuna != null) {
				nombreRegion = comuna.getProvincia().getRegion().getNombre();
			}
		}

		return nombreRegion;
	}

	public void setNombreRegion(String nombreRegion) {
		this.nombreRegion = nombreRegion;
	}

	@Transient
	public String getNombreComuna() {
		if (this.codigoComuna != null) {
			Comuna comuna = getComunaDb(this.codigoComuna);
			if (comuna != null) {
				nombreComuna = comuna.getNombre();
			}
		}

		return nombreComuna;
	}

	public void setNombreComuna(String nombreComuna) {
		this.nombreComuna = nombreComuna;
	}

	/**
	 * @return el valor de nombreComunaOtorgante
	 */
	@Transient
	public String getNombreComunaOtorgante() {
		if (this.codigoComunaOtorgante != null) {
			Comuna comuna = getComunaDb(this.codigoComunaOtorgante);
			if (comuna != null) {
				nombreComunaOtorgante = comuna.getNombre();
			}
		}

		return nombreComunaOtorgante;
	}

	public void resetComunaOtorgante() {
		comunaOtorgante = null;
		nombreComunaOtorgante = null;
	}

	@Transient
	public Comuna getComunaOtorgante() {
		if (comunaOtorgante == null) {
			if (this.codigoComunaOtorgante != null) {
				comunaOtorgante = getComunaDb(this.codigoComunaOtorgante);
			}
		}
		return comunaOtorgante;
	}

	/**
	 * @param setea
	 *            el parametro nombreComunaOtorgante al campo
	 *            nombreComunaOtorgante
	 */
	public void setNombreComunaOtorgante(String nombreComunaOtorgante) {
		this.nombreComunaOtorgante = nombreComunaOtorgante;
	}

	@Transient
	private Comuna getComunaDb(String id) {
		CurrentSessionBean curr = (CurrentSessionBean) ElResolver.getManagedObject("currentSessionBean");
		if (curr != null)
			try {
				return curr.getUbicacionGeograficaManager().getComunaById(id);
			} catch (GeneralDataAccessException e) {
				return null;
			}
		return null;
	}

	@Transient
	public String getNombreRegionOtorgante() {

		if (this.codigoComunaOtorgante != null) {
			Comuna comuna = getComunaDb(this.codigoComunaOtorgante);
			if (comuna != null) {
				nombreRegionOtorgante = comuna.getProvincia().getRegion().getNombre();
			}

		}
		return nombreRegionOtorgante;
	}

}
