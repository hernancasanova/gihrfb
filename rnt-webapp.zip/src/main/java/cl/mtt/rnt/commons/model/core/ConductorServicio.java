package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

@Entity
@Table(name = "RNT_CONDUCTOR_SERVICIO")
@Audited
public class ConductorServicio extends GenericAuditCancellableModelObject implements Anonymizable {

	public final static String ORIGEN_CONDUCTOR_SERVICIO = "servicio";
	public final static String ORIGEN_CONDUCTOR_VEHICULO = "vehiculo";

	private Servicio servicio;
	private Conductor conductor;
	private List<ConductorVehiculo> conductoresVehiculo;
	private String origenDelConductor;
	private List<AutorizacionMovimiento> autorizacionesMovimiento;
	private Long idServicio;
	private List<Poliza> polizas;

	
	@ManyToOne(targetEntity = Servicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SERVICIO")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	// TODO eliminar cuando el servicio sea audited
	public Servicio getServicio() {
		return servicio;
	}

	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}

	@ManyToOne(targetEntity = Conductor.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CONDUCTOR")
	public Conductor getConductor() {
		return conductor;
	}

	public void setConductor(Conductor conductor) {
		this.conductor = conductor;
	}

	@OneToMany(targetEntity = ConductorVehiculo.class, mappedBy = "conductorServicio", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	public List<ConductorVehiculo> getConductoresVehiculo() {
		return conductoresVehiculo;
	}

	public void setConductoresVehiculo(List<ConductorVehiculo> conductoresVehiculo) {
		this.conductoresVehiculo = conductoresVehiculo;
	}

	@Column(name = "ORIGEN_CONDUCTOR", nullable = true)
	public String getOrigenDelConductor() {
		return origenDelConductor;
	}

	public void setOrigenDelConductor(String origenDelConductor) {
		this.origenDelConductor = origenDelConductor;
	}

	public ConductorServicio geForClonadoServicio(Servicio serv, String origenConductor) {
		ConductorServicio cs = new ConductorServicio();
		cs.setConductor(this.getConductor());
		cs.setDbAction(GenericModelObject.ACTION_SAVE);
		cs.setEstado(GenericCancellableModelObject.ESTADO_VIGENTE);
		cs.setFechaCambioEstado(new Date());
		cs.setOrigenDelConductor(origenConductor);
		cs.setServicio(serv);
		return cs;
	}

	@Override
	public ConductorServicio clone() {
		ConductorServicio cs = new ConductorServicio();
		cs.setCodigoRegionDestino(this.getCodigoRegionDestino());
		cs.setConductor(this.getConductor());
		if (this.getConductoresVehiculo() != null) {
			cs.setConductoresVehiculo(new ArrayList<ConductorVehiculo>());
		}
		cs.setCreation(this.getCreation());
		cs.setDbAction(this.getDbAction());
		cs.setEstado(this.getEstado());
		cs.setFechaCambioEstado(this.getFechaCambioEstado());
		cs.setFechaResolucionCancelacion(this.getFechaResolucionCancelacion());
		cs.setId(this.getId());
		cs.setLinkResolucionCancelacion(this.getLinkResolucionCancelacion());
		cs.setModified(this.getModified());
		cs.setNumeroResolucion(this.getNumeroResolucion());
		cs.setObservacionCancelacion(this.getObservacionCancelacion());
		cs.setOrigenDelConductor(this.getOrigenDelConductor());
		// cs.setServicio(this.getServicio());
		cs.setTipoCancelacion(this.getTipoCancelacion());
		cs.setTipoServicioSaliente(this.getTipoServicioSaliente());
		cs.setUserCreation(this.getUserCreation());
		cs.setUserModified(this.getUserModified());
		cs.setPolizas(this.getPolizas());
		return cs;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(ACTION_SAVE);

		if (this.getConductoresVehiculo() != null) {
			for (ConductorVehiculo cv : this.getConductoresVehiculo()) {
				cv.anonimize();
			}
		}

	}

	/**
	 * @return el valor de autorizacionMovimiento
	 */
	@Transient
	public List<AutorizacionMovimiento> getAutorizacionesMovimiento() {
		return autorizacionesMovimiento;
	}

	/**
	 * @param setea el parametro autorizacionMovimiento al campo autorizacionMovimiento
	 */
	public void setAutorizacionesMovimiento(List<AutorizacionMovimiento> autorizacionesMovimiento) {
		this.autorizacionesMovimiento = autorizacionesMovimiento;
	}

    /**
     * @return el valor de idServicio
     */
	@Column(name = "ID_SERVICIO", updatable=false, insertable=false)
    protected Long getIdServicio() {
        return idServicio;
    }

    /**
     * @param setea el parametro idServicio al campo idServicio
     */
    protected void setIdServicio(Long idServicio) {
        this.idServicio = idServicio;
    }

	/**
	 * @return el valor de polizas
	 */
	@OneToMany(targetEntity = Poliza.class, mappedBy = "conductorServicio", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	public List<Poliza> getPolizas() {
		return polizas;
	}

	/**
	 * @param setea el parametro polizas al campo polizas
	 */
	public void setPolizas(List<Poliza> polizas) {
		this.polizas = polizas;
	}

	@Transient
	public boolean isContieneVehiculos() {
		return getConductoresVehiculo()!=null && !getConductoresVehiculo().isEmpty();
	}

}
