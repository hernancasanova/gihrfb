package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

@Entity
@Table(name = "RNT_CONDUCTOR_VEHICULO")
@Audited
public class ConductorVehiculo extends GenericAuditCancellableModelObject implements Anonymizable {

	private VehiculoServicio vehiculoServicio;
	private ConductorServicio conductorServicio;
	private List<AutorizacionMovimiento> autorizacionesMovimiento;
    private Long idVehiculoServicio;
	
	@ManyToOne(targetEntity = VehiculoServicio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_VEHICULO_SERVICIO")
	public VehiculoServicio getVehiculoServicio() {
		return vehiculoServicio;
	}

	public void setVehiculoServicio(VehiculoServicio vehiculoServicio) {
		this.vehiculoServicio = vehiculoServicio;
	}

	@ManyToOne(targetEntity = ConductorServicio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CONDUCTOR_SERVICIO")
	public ConductorServicio getConductorServicio() {
		return conductorServicio;
	}

	public void setConductorServicio(ConductorServicio conductorServicio) {
		this.conductorServicio = conductorServicio;
	}
	

	@Column(name = "ID_VEHICULO_SERVICIO", updatable=false, insertable=false)
    public Long getIdVehiculoServicio() {
        return idVehiculoServicio;
    }

    public void setIdVehiculoServicio(Long idVehiculoServicio) {
        this.idVehiculoServicio = idVehiculoServicio;
    }

	
	@Override
	public ConductorVehiculo clone() {
		ConductorVehiculo cv = new ConductorVehiculo();
		cv.setCodigoRegionDestino(this.getCodigoRegionDestino());
		cv.setConductorServicio(this.getConductorServicio());
		
		cv.setCreation(this.getCreation());
		cv.setDbAction(this.getDbAction());
		cv.setEstado(this.getEstado());
		cv.setFechaCambioEstado(this.getFechaCambioEstado());
		cv.setFechaResolucionCancelacion(this.getFechaResolucionCancelacion());
		cv.setId(this.getId());
		cv.setLinkResolucionCancelacion(this.getLinkResolucionCancelacion());
		cv.setModified(this.getModified());
		cv.setNumeroResolucion(this.getNumeroResolucion());
		cv.setObservacionCancelacion(this.getObservacionCancelacion());
		cv.setTipoCancelacion(this.getTipoCancelacion());
		cv.setTipoServicioSaliente(this.getTipoServicioSaliente());
		cv.setUserCreation(this.getUserCreation());
		cv.setUserModified(this.getUserModified());
		cv.setVehiculoServicio(this.getVehiculoServicio());
		cv.setIdVehiculoServicio(this.getIdVehiculoServicio());

		return cv;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(ACTION_SAVE);
	}

	@Override
	public boolean equals(Object obj) {
		if (super.equals(obj))
			return true;
		ConductorVehiculo cv = (ConductorVehiculo) obj;
		return this.getVehiculoServicio().getVehiculo().getPpu().equals(cv.getVehiculoServicio().getVehiculo().getPpu())
				&& this.getConductorServicio().getConductor().getPersona().getRut().equals(cv.getConductorServicio().getConductor().getPersona().getRut())
				&& this.getConductorServicio().getConductor().getTipoConductor().equals(cv.getConductorServicio().getConductor().getTipoConductor());
	}

	/**
	 * @return el valor de autorizacionMovimiento
	 */
	@Transient
	public List<AutorizacionMovimiento> getAutorizacionesMovimiento() {
		return autorizacionesMovimiento;
	}

	/**
	 * @param setea el parametro autorizacionMovimiento al campo autorizacionMovimiento
	 */
	public void setAutorizacionesMovimiento(List<AutorizacionMovimiento> autorizacionesMovimiento) {
		this.autorizacionesMovimiento = autorizacionesMovimiento;
	}

	public void copyDataFrom(ConductorVehiculo conductorVehiculo) {
		this.setCodigoRegionDestino(conductorVehiculo.getCodigoRegionDestino());
		this.setConductorServicio(conductorVehiculo.getConductorServicio());
		
		this.setCreation(conductorVehiculo.getCreation());
		this.setDbAction(conductorVehiculo.getDbAction());
		this.setEstado(conductorVehiculo.getEstado());
		this.setFechaCambioEstado(conductorVehiculo.getFechaCambioEstado());
		this.setFechaResolucionCancelacion(conductorVehiculo.getFechaResolucionCancelacion());
		this.setId(conductorVehiculo.getId());
		this.setLinkResolucionCancelacion(conductorVehiculo.getLinkResolucionCancelacion());
		this.setModified(conductorVehiculo.getModified());
		this.setNumeroResolucion(conductorVehiculo.getNumeroResolucion());
		this.setObservacionCancelacion(conductorVehiculo.getObservacionCancelacion());
		this.setTipoCancelacion(conductorVehiculo.getTipoCancelacion());
		this.setTipoServicioSaliente(conductorVehiculo.getTipoServicioSaliente());
		this.setUserCreation(conductorVehiculo.getUserCreation());
		this.setUserModified(conductorVehiculo.getUserModified());
		this.setVehiculoServicio(conductorVehiculo.getVehiculoServicio());
		this.setIdVehiculoServicio(conductorVehiculo.getIdVehiculoServicio());
		
	}

}
