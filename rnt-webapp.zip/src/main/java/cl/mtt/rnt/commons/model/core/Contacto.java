package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.encargado.dto.ServicioDTO;

@Entity
@Table(name = "RNT_CONTACTO")
@Audited
public class Contacto extends GenericModelObject implements Anonymizable {

	private static final long serialVersionUID = 192596827084165593L;
	private String domicilio;
	private String codigoComuna;
	private String codigoRegion;
	private String telefono;
	private String fax;
	private String email;
	private Persona persona;
	private String cargo;
	private String nombreRegion;
	private String nombreComuna;

	private List<Servicio> servicios;

	List<ServicioDTO> serviciosDTO;

	@Column(name = "DOMICILIO", nullable = true)
	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	@Column(name = "TELEFONO", nullable = true)
	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Column(name = "FAX", nullable = true)
	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "EMAIL", nullable = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@ManyToOne(targetEntity = Persona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PERSONA")
	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Column(name = "CARGO", nullable = true)
	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	/**
	 * @return el valor de servicios
	 */
	@ManyToMany(targetEntity = Servicio.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_SERVICIO_CONTACTO", joinColumns = @JoinColumn(name = "ID_CONTACTO"), inverseJoinColumns = @JoinColumn(name = "ID_SERVICIO"))
	public List<Servicio> getServicios() {
		return servicios;
	}

	/**
	 * @param setea
	 *            el parametro servicios al campo servicios
	 */
	public void setServicios(List<Servicio> servicios) {
		this.servicios = servicios;
	}

	/**
	 * @return el valor de serviciosDTO
	 */
	@Transient
	public List<ServicioDTO> getServiciosDTO() {
		return serviciosDTO;
	}

	/**
	 * @param setea
	 *            el parametro serviciosDTO al campo serviciosDTO
	 */
	// public void setServiciosDTO(List<ServicioDTO> serviciosDTO) {
	// this.serviciosDTO = serviciosDTO;
	// }

	@Transient
	public String getServiciosDesc() {
		String texto = "";
		// if ((serviciosDTO!= null) && (serviciosDTO.size()>1)) {
		// for (ServicioDTO serv : serviciosDTO) {
		// texto = "" + serv.getId()+ "(" + serv.getTipoTransporte() + " " +
		// serv.getMedioTransporte() + "... ";
		// }
		// }
		// if ((serviciosDTO!= null) && (serviciosDTO.size()==1)) {
		// for (ServicioDTO serv : serviciosDTO) {
		// texto = serv.getDescripcion();
		// }
		// }

		// if ((servicios!= null) && (servicios.size()>1)) {
		// for (Servicio serv : servicios) {
		// texto = "" + serv.getId()+ "(" +
		// serv.getTipoServicio().getTipoTransporte() + " " +
		// serv.getTipoServicio().getMedioTransporte() + "... ";
		// }
		// }
		// if ((servicios!= null) && (servicios.size()==1)) {
		// for (Servicio serv : servicios) {
		// texto = serv.getDescripcion();
		// }
		// }

		return texto;
	}

	/**
	 * @return el valor de nombreRegion
	 */
	@Transient
	public String getNombreRegion() {
		return nombreRegion;
	}

	/**
	 * @param setea
	 *            el parametro nombreRegion al campo nombreRegion
	 */
	public void setNombreRegion(String nombreRegion) {
		this.nombreRegion = nombreRegion;
	}

	/**
	 * @return el valor de nombreComuna
	 */
	@Transient
	public String getNombreComuna() {
		return nombreComuna;
	}

	/**
	 * @param setea
	 *            el parametro nombreComuna al campo nombreComuna
	 */
	public void setNombreComuna(String nombreComuna) {
		this.nombreComuna = nombreComuna;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@Transient
	public Contacto getForClone() {
		Contacto m = new Contacto();
		m.cargo = this.cargo;
		m.codigoComuna = this.codigoComuna;
		m.codigoRegion = this.codigoRegion;
		m.domicilio = this.domicilio;
		m.email = this.email;
		m.fax = this.fax;
		m.nombreComuna = this.nombreComuna;
		m.nombreRegion = this.nombreRegion;
		m.persona = this.persona;
		m.telefono = this.telefono;
		m.setServicios(new ArrayList<Servicio>());
		m.setDbAction(ACTION_SAVE);
		return m;
	}
}
