package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.ws.model.WsUtil;
import cl.mtt.rnt.commons.ws.model.revisiontecnica.REVISION.VEHICULO.REVISIONTECNICA;

@Entity
@Table(name = "RNT_REVISION_TECNICA_DATOS")
@Audited
public class DatosRevisionTecnica extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3082790661844865413L;

	private String codigoprt;
	private String codresultado;
	private String comunaprt;
	private String direccionprt;
	private Date fecharevision;
	private Date fechavencimiento;
	private String idcrt;
	private String mensajeresultado;
	private String numerocertificado;
	private String regionprt;

	@Transient
	public static DatosRevisionTecnica createNewFromRevision(REVISIONTECNICA revisiontecnica) {

		DatosRevisionTecnica drt = new DatosRevisionTecnica();

		drt.codigoprt = revisiontecnica.getCODIGOPRT();
		drt.codresultado = revisiontecnica.getCODRESULTADO();
		drt.comunaprt = revisiontecnica.getCOMUNAPRT();
		drt.direccionprt = revisiontecnica.getDIRECCIONPRT();
		drt.fecharevision = WsUtil.getFechaFromWS(revisiontecnica.getFECHAREVISION());
		drt.fechavencimiento = WsUtil.getFechaFromWS(revisiontecnica.getFECHAVENCIMIENTO());
		drt.idcrt = revisiontecnica.getIDCRT();
		drt.mensajeresultado = revisiontecnica.getMENSAJERESULTADO();
		drt.numerocertificado = revisiontecnica.getNUMEROCERTIFICADO();
		drt.regionprt = revisiontecnica.getREGIONPRT();
		return drt;
	}

	/**
	 * @return el valor de codigoprt
	 */
	@Column(name = "CODIGO_PRT", nullable = true)
	public String getCodigoprt() {
		return codigoprt;
	}

	/**
	 * @param setea
	 *            el parametro codigoprt al campo codigoprt
	 */
	public void setCodigoprt(String codigoprt) {
		this.codigoprt = codigoprt;
	}

	/**
	 * @return el valor de codresultado
	 */
	@Column(name = "CODIGO_RESULTADO", nullable = true)
	public String getCodresultado() {
		return codresultado;
	}

	/**
	 * @param setea
	 *            el parametro codresultado al campo codresultado
	 */
	public void setCodresultado(String codresultado) {
		this.codresultado = codresultado;
	}

	/**
	 * @return el valor de comunaprt
	 */
	@Column(name = "COMUNA_PRT", nullable = true)
	public String getComunaprt() {
		return comunaprt;
	}

	/**
	 * @param setea
	 *            el parametro comunaprt al campo comunaprt
	 */
	public void setComunaprt(String comunaprt) {
		this.comunaprt = comunaprt;
	}

	/**
	 * @return el valor de direccionprt
	 */
	@Column(name = "DIRECCION_PRT", nullable = true)
	public String getDireccionprt() {
		return direccionprt;
	}

	/**
	 * @param setea
	 *            el parametro direccionprt al campo direccionprt
	 */
	public void setDireccionprt(String direccionprt) {
		this.direccionprt = direccionprt;
	}

	/**
	 * @return el valor de fecharevision
	 */
	@Column(name = "FECHA_REVISION", nullable = true)
	public Date getFecharevision() {
		return fecharevision;
	}

	/**
	 * @param setea
	 *            el parametro fecharevision al campo fecharevision
	 */
	public void setFecharevision(Date fecharevision) {
		this.fecharevision = fecharevision;
	}

	/**
	 * @return el valor de fechavencimiento
	 */
	@Column(name = "FECHA_VENCIMIENTO", nullable = true)
	public Date getFechavencimiento() {
		return fechavencimiento;
	}

	/**
	 * @param setea
	 *            el parametro fechavencimiento al campo fechavencimiento
	 */
	public void setFechavencimiento(Date fechavencimiento) {
		this.fechavencimiento = fechavencimiento;
	}

	/**
	 * @return el valor de idcrt
	 */
	@Column(name = "IDCRT", nullable = true)
	public String getIdcrt() {
		return idcrt;
	}

	/**
	 * @param setea
	 *            el parametro idcrt al campo idcrt
	 */
	public void setIdcrt(String idcrt) {
		this.idcrt = idcrt;
	}

	/**
	 * @return el valor de mensajeresultado
	 */
	@Column(name = "MENSAJE_RESULTADO", nullable = true, length = 1000)
	public String getMensajeresultado() {
		return mensajeresultado;
	}

	/**
	 * @param setea
	 *            el parametro mensajeresultado al campo mensajeresultado
	 */
	public void setMensajeresultado(String mensajeresultado) {
		this.mensajeresultado = mensajeresultado;
	}

	/**
	 * @return el valor de numerocertificado
	 */
	@Column(name = "NUMERO_CERTIFICADO", nullable = true)
	public String getNumerocertificado() {
		return numerocertificado;
	}

	/**
	 * @param setea
	 *            el parametro numerocertificado al campo numerocertificado
	 */
	public void setNumerocertificado(String numerocertificado) {
		this.numerocertificado = numerocertificado;
	}

	/**
	 * @return el valor de regionprt
	 */
	@Column(name = "REGION_PRT", nullable = true)
	public String getRegionprt() {
		return regionprt;
	}

	/**
	 * @param setea
	 *            el parametro regionprt al campo regionprt
	 */
	public void setRegionprt(String regionprt) {
		this.regionprt = regionprt;
	}

}
