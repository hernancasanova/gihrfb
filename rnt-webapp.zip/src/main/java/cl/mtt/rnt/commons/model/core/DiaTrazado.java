package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.model.core.recorrido.Trazado;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.encargado.bean.util.DatoDiario;

@Entity
@Table(name = "RNT_TRAZADO_DIA")
@Audited
public class DiaTrazado extends GenericModelObject implements DatoDiario, Anonymizable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7373386099240851179L;

	private String dia;
	private Trazado trazado;
	private String horaDesde;
	private String horaHasta;
	private Integer intervaloSalida;
	private Float frecuencia;
	private boolean seleccionado;

	/**
	 * @return el valor de dia
	 */
	@Column(name = "DIA", nullable = true)
	public String getDia() {
		return dia;
	}

	/**
	 * @param setea
	 *            el parametro dia al campo dia
	 */
	public void setDia(String dia) {
		this.dia = dia;
	}

	/**
	 * @return el valor de trazado
	 */
	@ManyToOne(targetEntity = Trazado.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TRAZADO")
	public Trazado getTrazado() {
		return trazado;
	}

	/**
	 * @param setea
	 *            el parametro trazado al campo trazado
	 */
	public void setTrazado(Trazado trazado) {
		this.trazado = trazado;
	}

	/**
	 * @return el valor de horaDesde
	 */
	@Column(name = "HORA_DESDE", nullable = true)
	public String getHoraDesde() {
		return horaDesde;
	}

	/**
	 * @param setea
	 *            el parametro horaDesde al campo horaDesde
	 */
	public void setHoraDesde(String horaDesde) {
		this.horaDesde = horaDesde;
	}

	/**
	 * @return el valor de horaHasta
	 */
	@Column(name = "HORA_HASTA", nullable = true)
	public String getHoraHasta() {
		return horaHasta;
	}

	/**
	 * @param setea
	 *            el parametro horaHasta al campo horaHasta
	 */
	public void setHoraHasta(String horaHasta) {
		this.horaHasta = horaHasta;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Object clone() throws CloneNotSupportedException {
		DiaTrazado dt = new DiaTrazado();
		dt.setId(this.getId());
		dt.setDia(this.getDia());
		dt.setHoraDesde(this.getHoraDesde());
		dt.setHoraHasta(this.getHoraHasta());
		dt.setTrazado(this.getTrazado());
		dt.setFrecuencia(this.getFrecuencia());
		dt.setIntervaloSalida(this.getIntervaloSalida());
		dt.setSeleccionado(this.isSeleccionado());
		return dt;
	}

	@Transient
	public String getDiaDesc() {
		if (dia != null)
			return Resources.getString("common.dia." + dia);
		else
			return "";
	}

	public static List<DiaTrazado> getSemanaClean(Trazado trazado) {
		List<DiaTrazado> lista = new ArrayList<DiaTrazado>();
		DiaTrazado dt = new DiaTrazado();
		dt.setDia(DiaTrazado.LUNES);
		dt.setTrazado(trazado);
		dt.setDbAction(ACTION_SAVE);
		lista.add(dt);
		dt = new DiaTrazado();
		dt.setDia(DiaTrazado.MARTES);
		dt.setTrazado(trazado);
		dt.setDbAction(ACTION_SAVE);
		lista.add(dt);
		dt = new DiaTrazado();
		dt.setDia(DiaTrazado.MIERCOLES);
		dt.setTrazado(trazado);
		dt.setDbAction(ACTION_SAVE);
		lista.add(dt);
		dt = new DiaTrazado();
		dt.setDia(DiaTrazado.JUEVES);
		dt.setTrazado(trazado);
		dt.setDbAction(ACTION_SAVE);
		lista.add(dt);
		dt = new DiaTrazado();
		dt.setDia(DiaTrazado.VIERNES);
		dt.setTrazado(trazado);
		dt.setDbAction(ACTION_SAVE);
		lista.add(dt);
		dt = new DiaTrazado();
		dt.setDia(DiaTrazado.SABADO);
		dt.setTrazado(trazado);
		dt.setDbAction(ACTION_SAVE);
		lista.add(dt);
		dt = new DiaTrazado();
		dt.setDia(DiaTrazado.DOMINGO);
		dt.setTrazado(trazado);
		dt.setDbAction(ACTION_SAVE);
		lista.add(dt);
		dt = new DiaTrazado();
		dt.setDia(DiaTrazado.FERIADOS);
		dt.setTrazado(trazado);
		dt.setDbAction(ACTION_SAVE);
		lista.add(dt);
		return lista;
	}

	/**
	 * @return el valor de seleccionado
	 */
	@Column(name = "ACTIVO", nullable = true)
	public boolean isSeleccionado() {
		return seleccionado;
	}

	/**
	 * @param setea
	 *            el parametro seleccionado al campo seleccionado
	 */
	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	@Transient
	public String getDiaYHorario() {
		String diahora = this.dia;
		if (this.getHoraDesde() != null) {
			diahora += " " + this.getHoraDesde();
		}
		if (this.getHoraHasta() != null) {
			diahora += " a " + this.getHoraHasta();
		}
		return diahora;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	/**
	 * @return el valor de intervaloSalida
	 */
	@Column(name = "INTERVALO_SALIDA", nullable = true)
	public Integer getIntervaloSalida() {
		return intervaloSalida;
	}

	/**
	 * @param setea
	 *            el parametro intervaloSalida al campo intervaloSalida
	 */
	public void setIntervaloSalida(Integer intervaloSalida) {
		this.intervaloSalida = intervaloSalida;
	}
	
	@Column(name = "FRECUENCIA", nullable = true, columnDefinition = "double")
	public Float getFrecuencia() {
		return frecuencia;
	}

	public void setFrecuencia(Float frecuencia) {
		this.frecuencia = frecuencia;
	}

	
}
