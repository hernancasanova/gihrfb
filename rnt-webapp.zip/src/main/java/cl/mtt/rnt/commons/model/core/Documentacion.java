package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_DOCUMENTACION_TRAMITE")
public class Documentacion  extends GenericModelObject implements Comparable<Documentacion> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1984861323233534894L;
	
	private String nombre;

	@Column(name = "NOMBRE")
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	@Override
	public int compareTo(Documentacion o) {
		 return this.getNombre().compareToIgnoreCase(o.getNombre()); 
	} 

}
