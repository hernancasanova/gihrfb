package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity
@Table(name = "RNT_DOCUMENTO_BIBLIOTECA")
@Audited
public class DocumentoBiblioteca extends GenericModelObject{

	/**
     * 
     */
    private static final long serialVersionUID = 6958574925015675711L;
    private String linkDocumento;
	private TipoDocumento tipoDocumento;
	private String materia;
	private String codigoRegion;
	private String nombre;
	private String numero;
	private Date fecha;
	private String observacion;
	
	@Column(name = "LINK_DOCUMENTO", nullable = true)
	public String getLinkDocumento() {
		return linkDocumento;
	}
	public void setLinkDocumento(String linkDocumento) {
		this.linkDocumento = linkDocumento;
	}
	
	@ManyToOne(targetEntity = TipoDocumento.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_DOCUMENTO")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(TipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	@Column(name = "MATERIA", nullable = false)
	public String getMateria() {
		return materia;
	}
	public void setMateria(String materia) {
		this.materia = materia;
	}

	@Column(name = "CODIGO_REGION", nullable = false)
	public String getCodigoRegion() {
		return codigoRegion;
	}
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "NUMERO")
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}

	@Column(name = "FECHA", nullable = false)
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	/**
	 * @return el valor de observacion
	 */
	@Column(name = "OBSERVACION", nullable = true)
	public String getObservacion() {
		return observacion;
	}
	/**
	 * @param setea el parametro observacion al campo observacion
	 */
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
	
	
	
}
