package cl.mtt.rnt.commons.model.core;

import java.io.Serializable;

/**
 * 
 * @author jeyler
 * 
 */
public class Estado implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4362900088957266470L;

	private Boolean estado;
	private String nombreEstado;

	public Estado(Boolean estado, String nombreEstado) {
		super();
		this.estado = estado;
		this.nombreEstado = nombreEstado;
	}

	/**
	 * @return el valor de estado
	 */
	public Boolean getEstado() {
		return estado;
	}

	/**
	 * @param setea
	 *            el parametro estado al campo estado
	 */
	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	/**
	 * @return el valor de nombreEstado
	 */
	public String getNombreEstado() {
		return nombreEstado;
	}

	/**
	 * @param setea
	 *            el parametro nombreEstado al campo nombreEstado
	 */
	public void setNombreEstado(String nombreEstado) {
		this.nombreEstado = nombreEstado;
	}

}
