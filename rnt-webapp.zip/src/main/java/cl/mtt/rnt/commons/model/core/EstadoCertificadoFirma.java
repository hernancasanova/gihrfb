package cl.mtt.rnt.commons.model.core;



public class EstadoCertificadoFirma {

	public static final String ERROR_CONSULTA = "error";
	boolean firmado = false;
	String estado;
	String linkDocumento;
	String observacionRechazo;
	String folio;
	String fechaFirma;

	public String getObservacionRechazo() {
		return observacionRechazo;
	}

	public void setObservacionRechazo(String observacionRechazo) {
		this.observacionRechazo = observacionRechazo;
	}

	public boolean isFirmado() {
		return firmado;
	}

	public void setFirmado(boolean firmado) {
		this.firmado = firmado;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	

    /**
     * @return el valor de linkDocumento
     */
    public String getLinkDocumento() {
        return linkDocumento;
    }

    /**
     * @param setea el parametro linkDocumento al campo linkDocumento
     */
    public void setLinkDocumento(String linkDocumento) {
        this.linkDocumento = linkDocumento;
    }

    /**
     * @return el valor de folio
     */
    public String getFolio() {
        return folio;
    }

    /**
     * @param setea el parametro folio al campo folio
     */
    public void setFolio(String folio) {
        this.folio = folio;
    }

    /**
     * @return el valor de fechaFirma
     */
    public String getFechaFirma() {
        return fechaFirma;
    }

    /**
     * @param setea el parametro fechaFirma al campo fechaFirma
     */
    public void setFechaFirma(String fechaFirma) {
        this.fechaFirma = fechaFirma;
    }

}
