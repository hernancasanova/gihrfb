package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.model.core.recorrido.Trazado;

@Entity
@Table(name = "RNT_TRAZADO_FRECUENCIA")
@Audited
public class FrecuenciaTrazado extends GenericModelObject implements Anonymizable {

	private String nombre;
	private Trazado trazado;
	private String horaDesde;
	private String horaHasta;
	private List<FrecuenciaTrazadoItem> frecuenciaTrazadoItems;

	@Column(name = "NOMBRE", nullable = true)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return el valor de trazado
	 */
	@ManyToOne(targetEntity = Trazado.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TRAZADO")
	public Trazado getTrazado() {
		return trazado;
	}

	/**
	 * @param setea
	 *            el parametro trazado al campo trazado
	 */
	public void setTrazado(Trazado trazado) {
		this.trazado = trazado;
	}

	/**
	 * @return el valor de horaDesde
	 */
	@Column(name = "HORA_DESDE", nullable = true)
	public String getHoraDesde() {
		return horaDesde;
	}

	/**
	 * @param setea
	 *            el parametro horaDesde al campo horaDesde
	 */
	public void setHoraDesde(String horaDesde) {
		this.horaDesde = horaDesde;
	}

	/**
	 * @return el valor de horaHasta
	 */
	@Column(name = "HORA_HASTA", nullable = true)
	public String getHoraHasta() {
		return horaHasta;
	}

	/**
	 * @param setea
	 *            el parametro horaHasta al campo horaHasta
	 */
	public void setHoraHasta(String horaHasta) {
		this.horaHasta = horaHasta;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = FrecuenciaTrazadoItem.class, mappedBy = "frecuenciaTrazado", cascade = CascadeType.ALL)
	public List<FrecuenciaTrazadoItem> getFrecuenciaTrazadoItems() {
		return frecuenciaTrazadoItems;
	}

	public void setFrecuenciaTrazadoItems(List<FrecuenciaTrazadoItem> frecuenciaTrazadoItems) {
		this.frecuenciaTrazadoItems = frecuenciaTrazadoItems;
	}

	@Override
	public FrecuenciaTrazado clone() throws CloneNotSupportedException {
		FrecuenciaTrazado fr = new FrecuenciaTrazado();
		if (this.getNombre() != null)
			fr.setNombre(new String(this.getNombre()));
		if (this.getId() != null)
			fr.setId(new Long(this.getId()));
		fr.setTrazado(this.getTrazado());
		if (this.getHoraDesde() != null)
			fr.setHoraDesde(new String(this.getHoraDesde()));
		if (this.getHoraHasta() != null)
			fr.setHoraHasta(new String(this.getHoraHasta()));

		if (this.getFrecuenciaTrazadoItems() != null) {
			fr.setFrecuenciaTrazadoItems(new ArrayList<FrecuenciaTrazadoItem>());
			for (FrecuenciaTrazadoItem fti : this.getFrecuenciaTrazadoItems()) {
				FrecuenciaTrazadoItem fticlon = fti.clone();
				fticlon.setFrecuenciaTrazado(fr);
				fr.getFrecuenciaTrazadoItems().add(fticlon);
			}
		}
		return fr;

	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@Transient
	public void createNewItems() {
		this.setFrecuenciaTrazadoItems(new ArrayList<FrecuenciaTrazadoItem>());
		this.getFrecuenciaTrazadoItems().add(new FrecuenciaTrazadoItem(DiaTrazado.LUNES, this));
		this.getFrecuenciaTrazadoItems().add(new FrecuenciaTrazadoItem(DiaTrazado.MARTES, this));
		this.getFrecuenciaTrazadoItems().add(new FrecuenciaTrazadoItem(DiaTrazado.MIERCOLES, this));
		this.getFrecuenciaTrazadoItems().add(new FrecuenciaTrazadoItem(DiaTrazado.JUEVES, this));
		this.getFrecuenciaTrazadoItems().add(new FrecuenciaTrazadoItem(DiaTrazado.VIERNES, this));
		this.getFrecuenciaTrazadoItems().add(new FrecuenciaTrazadoItem(DiaTrazado.SABADO, this));
		this.getFrecuenciaTrazadoItems().add(new FrecuenciaTrazadoItem(DiaTrazado.DOMINGO, this));
		this.getFrecuenciaTrazadoItems().add(new FrecuenciaTrazadoItem(DiaTrazado.FERIADOS, this));

	}

}
