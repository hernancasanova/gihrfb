package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.encargado.bean.util.DatoDiario;

@Entity
@Table(name = "RNT_TRAZADO_FRECUENCIA_ITEM")
@Audited
public class FrecuenciaTrazadoItem extends GenericModelObject implements DatoDiario, Anonymizable {

	private String dia;
	private FrecuenciaTrazado frecuenciaTrazado;
	private Float frecuencia;
	private Integer intervaloSalida;

	public FrecuenciaTrazadoItem() {
		super();
	}

	public FrecuenciaTrazadoItem(String dia, FrecuenciaTrazado frecuenciaTrazado) {
		super();
		this.dia = dia;
		this.frecuenciaTrazado = frecuenciaTrazado;
	}

	@Column(name = "DIA", nullable = true)
	public String getDia() {
		return dia;
	}

	public void setDia(String dia) {
		this.dia = dia;
	}

	@ManyToOne(targetEntity = FrecuenciaTrazado.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TRAZADO_FRECUENCIA")
	public FrecuenciaTrazado getFrecuenciaTrazado() {
		return frecuenciaTrazado;
	}

	public void setFrecuenciaTrazado(FrecuenciaTrazado frecuenciaTrazado) {
		this.frecuenciaTrazado = frecuenciaTrazado;
	}

	@Column(name = "FRECUENCIA", nullable = true, columnDefinition = "double")
	public Float getFrecuencia() {
		return frecuencia;
	}

	public void setFrecuencia(Float frecuencia) {
		this.frecuencia = frecuencia;
	}

	@Column(name = "INTERVALO_SALIDA", nullable = true)
	public Integer getIntervaloSalida() {
		return intervaloSalida;
	}

	public void setIntervaloSalida(Integer intervaloSalida) {
		this.intervaloSalida = intervaloSalida;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@Override
	public FrecuenciaTrazadoItem clone() throws CloneNotSupportedException {
		FrecuenciaTrazadoItem fr = new FrecuenciaTrazadoItem();
		if (this.getId() != null)
			fr.setId(new Long(this.getId()));
		if (this.getDia() != null)
			fr.setDia(new String(this.getDia()));
		fr.setFrecuenciaTrazado(this.getFrecuenciaTrazado());
		if (this.getFrecuencia() != null)
			fr.setFrecuencia(new Float(this.getFrecuencia()));
		if (this.getIntervaloSalida() != null)
			fr.setIntervaloSalida(new Integer(this.getIntervaloSalida()));

		return fr;

	}

}
