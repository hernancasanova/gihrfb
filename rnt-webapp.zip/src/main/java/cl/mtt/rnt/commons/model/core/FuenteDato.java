package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity
@Table(name = "RNT_FUENTE_DE_DATO")
public class FuenteDato extends GenericModelObject {

	private static final long serialVersionUID = -5420122080736710636L;

	private String valor;
	private Atributo atributo;

	/**
	 * @return el valor de valor
	 */
	@Column(name = "VALOR", nullable = false)
	public String getValor() {
		return valor;
	}

	/**
	 * @param setea
	 *            el parametro valor al campo valor
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

	/**
	 * @return el valor de atributo
	 */
	@ManyToOne(targetEntity = Atributo.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATRIBUTO", nullable = false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public Atributo getAtributo() {
		return atributo;
	}

	/**
	 * @param setea
	 *            el parametro atributo al campo atributo
	 */
	public void setAtributo(Atributo atributo) {
		this.atributo = atributo;
	}

}
