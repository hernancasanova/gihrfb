package cl.mtt.rnt.commons.model.core;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.BatchSize;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@MappedSuperclass
public class GenericAuditCancellableModelObject extends GenericCancellableModelObject {

    /**
     * 
     */
    private static final long serialVersionUID = 4842042632220516894L;

    /**
     * @return el valor de tipocancelacion
     */
    @ManyToOne(targetEntity = TipoCancelacion.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPO_CANCELACION")
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @BatchSize (size = 50)
    public TipoCancelacion getTipoCancelacion() {
        return tipoCancelacion;
    }

    /**
     * @param setea
     *            el parametro tipocancelacion al campo tipocancelacion
     */
    public void setTipoCancelacion(TipoCancelacion tipoCancelacion) {
        this.tipoCancelacion = tipoCancelacion;
    }

}
