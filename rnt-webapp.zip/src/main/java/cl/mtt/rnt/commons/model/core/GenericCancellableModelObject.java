package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;

import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;

@MappedSuperclass
public class GenericCancellableModelObject extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7839246235145677272L;
	public static final int ESTADO_FLOTA_VIGENTE = 99;
	public static final int ESTADO_FLOTA_TODOS = 100;
	public static final int ESTADO_VIGENTE = 1;
	public static final int ESTADO_CANCELADO = 2;
	public static final int ESTADO_PENDIENTE_INGRESO = 0;
	public static final int ESTADO_CANCELADO_DEFINITIVO = 3;
	public static final int ESTADO_PENDIENTE_CANCELACION = 4;
//	public static final int ESTADO_PENDIENTE_ACTIVACION = 5;
	public static final int ESTADO_VENCIDO = 6;
	public static final int ESTADO_PENDIENTE_AUTORIZACION = 7;
	public static final String CANCELACION_TEMPORAL_KEY = Resources.getString("tipo.cancelacion.temporal.key");
	public static final String CANCELACION_DEFINITIVA_KEY = Resources.getString("tipo.cancelacion.definitiva.key");
	public static final String CANCELACION_TEMPORAL = Resources.getString("tipo.cancelacion.temporal");
	public static final String CANCELACION_DEFINITIVA = Resources.getString("tipo.cancelacion.definitiva");

	public static final String NOMBRE_ESTADO_FLOTA_VIGENTE = Resources.getString("servicio.vehiculo.datos.flotaVigente");
	public static final String NOMBRE_ESTADO_FLOTA_TODOS = Resources.getString("servicio.vehiculo.datos.todos");
	public static final String NOMBRE_ESTADO_VIGENTE = Resources.getString("servicio.vehiculo.datos.activo");
	public static final String NOMBRE_ESTADO_CANCELADO = Resources.getString("servicio.vehiculo.datos.cancelado");
	public static final String NOMBRE_ESTADO_PENDIENTE_INGRESO = Resources.getString("servicio.vehiculo.datos.pendiente");
	public static final String NOMBRE_ESTADO_CANCELADO_DEFINITIVO = Resources.getString("servicio.vehiculo.datos.cancelado.definitivo");
	public static final String NOMBRE_ESTADO_PENDIENTE_CANCELACION = Resources.getString("servicio.vehiculo.datos.pendiente.cancelacion");
	public static final String NOMBRE_ESTADO_PENDIENTE_ACTIVACION = Resources.getString("servicio.vehiculo.datos.pendiente.activacion");
	public static final String NOMBRE_ESTADO_PENDIENTE_AUTORIZACION = Resources.getString("servicio.vehiculo.datos.pendiente.autoriza");

	private Integer estado;
	private String observacionCancelacion;
	protected TipoCancelacion tipoCancelacion;
	private TipoServicio tipoServicioSaliente;
	private String codigoRegionDestino;
	private Date fechaResolucionCancelacion;
	private String linkResolucionCancelacion;
	private String numeroResolucion;
	private Date fechaCambioEstado;

	@Column(name = "ESTADO", nullable = true)
	public Integer getEstado() {
		return estado;
	}

	public void setEstado(Integer estado) {
		this.estado = estado;
	}

	

	/**
	 * @return el valor de observacion
	 */
	@Column(name = "OBSERVACION_CANCELACION", nullable = true, length = 2000)
	public String getObservacionCancelacion() {
		return observacionCancelacion;
	}

	/**
	 * @param setea
	 *            el parametro observacion al campo observacion
	 */
	public void setObservacionCancelacion(String observacionCancelacion) {
		this.observacionCancelacion = observacionCancelacion;
	}

	@Column(name = "RESOLUCION_CANCELACION_FECHA", nullable = true)
	public Date getFechaResolucionCancelacion() {
		return fechaResolucionCancelacion;
	}

	public void setFechaResolucionCancelacion(Date fechaResolucionCancelacion) {
		this.fechaResolucionCancelacion = fechaResolucionCancelacion;
	}

	@Column(name = "RESOLUCION_CANCELACION_LINK", nullable = true)
	public String getLinkResolucionCancelacion() {
		return linkResolucionCancelacion;
	}

	public void setLinkResolucionCancelacion(String linkResolucionCancelacion) {
		this.linkResolucionCancelacion = linkResolucionCancelacion;
	}

	/**
	 * @return el valor de tipoServicioSaliente
	 */
	@ManyToOne(targetEntity = TipoServicio.class, fetch = FetchType.EAGER)
	@BatchSize (size = 300)
	public TipoServicio getTipoServicioSaliente() {
		return tipoServicioSaliente;
	}

	/**
	 * @param setea
	 *            el parametro tipoServicioSaliente al campo
	 *            tipoServicioSaliente
	 */
	public void setTipoServicioSaliente(TipoServicio tipoServicioSaliente) {
		this.tipoServicioSaliente = tipoServicioSaliente;
	}

	/**
	 * @return el valor de codigoRegionDestino
	 */
	@Column(name = "REGION_DESTINO", nullable = true)
	public String getCodigoRegionDestino() {
		return codigoRegionDestino;
	}

	/**
	 * @param setea
	 *            el parametro codigoRegionDestino al campo codigoRegionDestino
	 */
	public void setCodigoRegionDestino(String codigoRegionDestino) {
		this.codigoRegionDestino = codigoRegionDestino;
	}

	/**
	 * @return el valor de numeroResolucion
	 */
	@Column(name = "NUMERO_RESOLUCION", nullable = true)
	public String getNumeroResolucion() {
		return numeroResolucion;
	}

	/**
	 * @param setea
	 *            el parametro numeroResolucion al campo numeroResolucion
	 */
	public void setNumeroResolucion(String numeroResolucion) {
		this.numeroResolucion = numeroResolucion;
	}

	/**
	 * @return el valor de fechaCancelacion
	 */
	@Column(name = "FECHA_ESTADO", nullable = true)
	public Date getFechaCambioEstado() {
		return fechaCambioEstado;
	}

	/**
	 * @param setea
	 *            el parametro fechaCancelacion al campo fechaCancelacion
	 */
	public void setFechaCambioEstado(Date fechaCambioEstado) {
		this.fechaCambioEstado = fechaCambioEstado;
	}

	@Transient
	public String getFechaEstadoDesc() {
		if (this.getFechaCambioEstado() != null) {
			return Constants.dateFormat.format(getFechaCambioEstado());
		}
		return "";
	}
	
	
	/**
	 * Borra todos los datos asociados a la cancelacion (no toca fecha estado ni estado)
	 */
	@Transient
	public void clearCancelacion() {
		observacionCancelacion = null;
		tipoCancelacion = null;
		tipoServicioSaliente = null;
		codigoRegionDestino = null;
		fechaResolucionCancelacion = null;
		linkResolucionCancelacion = null;
		numeroResolucion = null;
	}

}
