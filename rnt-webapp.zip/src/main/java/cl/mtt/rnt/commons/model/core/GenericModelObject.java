package cl.mtt.rnt.commons.model.core;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;

import cl.mtt.rnt.commons.model.userrol.User;

/**
 * Clase generica del modelo que contiene todos lo campos comunes a las clases
 * del modelo.
 * 
 */
@MappedSuperclass
public class GenericModelObject implements Serializable {

	public static final int ACTION_NOACTION = 0;
	public static final int ACTION_SAVE = 1;
	public static final int ACTION_UPDATE = 2;
	public static final int ACTION_DELETE = 3;

	private static final long serialVersionUID = 1L;

	private Long id;
	private Timestamp creation;
	private Timestamp modified;
	private User userCreation;
	private User userModified;

	private int dbAction = ACTION_NOACTION;

	@Id
	@Column(name = "ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "CREATION")
	public Timestamp getCreation() {
		return creation;
	}

	public void setCreation(Timestamp creation) {
		this.creation = creation;
	}

	@Column(name = "MODIFIED")
	public Timestamp getModified() {
		return modified;
	}

	public void setModified(Timestamp modified) {
		this.modified = modified;
	}

	@ManyToOne(targetEntity = User.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_USER_CREATION")
	@BatchSize (size = 50)
	public User getUserCreation() {
		return userCreation;
	}

	public void setUserCreation(User userCreation) {
		this.userCreation = userCreation;
	}

	@ManyToOne(targetEntity = User.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_USER_MODIFIED")
	@BatchSize (size = 50)
	public User getUserModified() {
		return userModified;
	}

	public void setUserModified(User userModified) {
		this.userModified = userModified;
	}

	@Override
	public int hashCode() {
		if (this.id == null)
			return super.hashCode();
		return this.id.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
	    
		if (obj == null)
			return false;
		if (!(obj instanceof GenericModelObject))
		    return false;
		if (obj == this)
			return true;
//		if (obj.getClass() != getClass())
//			return false;
		if (this.getId() == null)
			return false;
		return this.getId().equals(((GenericModelObject) obj).getId());
	}

	@Transient
	public int getDbAction() {
		return dbAction;
	}

	public void setDbAction(int dbAction) {
		this.dbAction = dbAction;
	}


}
