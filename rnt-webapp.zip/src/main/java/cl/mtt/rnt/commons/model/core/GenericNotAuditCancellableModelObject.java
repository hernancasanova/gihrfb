package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;

@MappedSuperclass
public class GenericNotAuditCancellableModelObject extends GenericCancellableModelObject {

    /**
     * 
     */
    private static final long serialVersionUID = 4842042632220516894L;

    /**
     * @return el valor de tipocancelacion
     */
    @ManyToOne(targetEntity = TipoCancelacion.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPO_CANCELACION")
    @BatchSize (size = 300)
    public TipoCancelacion getTipoCancelacion() {
        return tipoCancelacion;
    }

    /**
     * @param setea
     *            el parametro tipocancelacion al campo tipocancelacion
     */
    public void setTipoCancelacion(TipoCancelacion tipoCancelacion) {
        this.tipoCancelacion = tipoCancelacion;
    }

}
