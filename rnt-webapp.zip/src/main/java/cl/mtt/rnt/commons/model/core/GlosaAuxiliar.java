package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_GLOSA_AUXILIAR")
public class GlosaAuxiliar extends GenericModelObject {

	private static final long serialVersionUID = -8448278171505211983L;

	public static final String AUXILIAR = "Auxiliares";
	public static final String ADULTO_ACOMPANIANTE = "Adultos Acompañantes";

	private String glosa;
	private String glosaSingular;
	private String discriminador;

	@Column(name = "GLOSA", nullable = false)
	public String getGlosa() {
		return glosa;
	}

	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	@Column(name = "GLOSA_SINGULAR", nullable = false)
	public String getGlosaSingular() {
		return glosaSingular;
	}

	public void setGlosaSingular(String glosaSingular) {
		this.glosaSingular = glosaSingular;
	}

	@Column(name = "DISCRIMINADOR", nullable = false)
	public String getDiscriminador() {
		return discriminador;
	}

	public void setDiscriminador(String discriminador) {
		this.discriminador = discriminador;
	}

}
