package cl.mtt.rnt.commons.model.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.impl.ReemplazosMarcoGeografico;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

@Entity
@Table(name = "RNT_GLOSA_REGLAMENTACION")
@Audited
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class GlosaReglamentacion extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4729150221976223898L;
	
	public static final int TIPO_NUMERACCION_NINGUNA=0;
	public static final int TIPO_NUMERACCION_NUMEROS=1;
	public static final int TIPO_NUMERACCION_LETRA=2;
	public static final int TIPO_NUMERACCION_PUNTOS=3;
	public static final int TIPO_NUMERACCION_GUIONES=4;

	private Boolean habilitada;
	private String encabezado;
	private String pie;
	private List<ItemGlosaReglamentacion> items = new ArrayList<ItemGlosaReglamentacion>();
	private int tipoNumeracion = TIPO_NUMERACCION_NINGUNA;
	private String nuevoItem;
	
	private List<String> extraItems = new ArrayList<String>();

	private List<ItemGlosaReglamentacion> itemsAEliminar = new ArrayList<ItemGlosaReglamentacion>();

//	/**
//	 * @return el valor de glosaVehiculo
//	 */
//	@Column(name = "GLOSA_NIVEL_VEHICULO")
//	public String getGlosaVehiculo() {
//		return null;
////		return glosaVehiculo;
//	}
//
//	/**
//	 * @param setea el parametro glosaVehiculo al campo glosaVehiculo
//	 */
//	public void setGlosaVehiculo(String glosaVehiculo) {
////		this.glosaVehiculo = glosaVehiculo;
//	}
//
//	/**
//	 * @return el valor de glosaCertificado
//	 */
//	@Column(name = "GLOSA_NIVEL_CERT")
//	public String getGlosaCertificado() {
//		return null;
////		return glosaCertificado;
//	}
//
//	/**
//	 * @param setea el parametro glosaCertificado al campo glosaCertificado
//	 */
//	public void setGlosaCertificado(String glosaCertificado) {
////		this.glosaCertificado = glosaCertificado;
//	}
//
//	/**
//	 * @return el valor de glosaWeb
//	 */
//	@Column(name = "GLOSA_NIVEL_WEB")
//	public String getGlosaWeb() {
//		return null;
////		return glosaWeb;
//	}
//
//	/**
//	 * @param setea el parametro glosaWeb al campo glosaWeb
//	 */
//	public void setGlosaWeb(String glosaWeb) {
////		this.glosaWeb = glosaWeb;
//	}

	/**
	 * @return el valor de habilitada
	 */
	@Column(name = "HABILITADA")
	public Boolean getHabilitada() {
		return habilitada;
	}

	/**
	 * @param setea el parametro habilitada al campo habilitada
	 */
	public void setHabilitada(Boolean habilitada) {
		this.habilitada = habilitada;
	}

	/**
	 * @return el valor de encabezado
	 */
	@Column(name = "ENCABEZADO")
	public String getEncabezado() {
		return encabezado;
	}

	/**
	 * @param setea el parametro encabezado al campo encabezado
	 */
	public void setEncabezado(String encabezado) {
		this.encabezado = encabezado;
	}

	/**
	 * @return el valor de pie
	 */
	@Column(name = "PIE")
	public String getPie() {
		return pie;
	}

	/**
	 * @param setea el parametro pie al campo pie
	 */
	public void setPie(String pie) {
		this.pie = pie;
	}

	/**
	 * @return el valor de items
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = ItemGlosaReglamentacion.class, mappedBy = "glosaReglamentacion")
	public List<ItemGlosaReglamentacion> getItems() {
		sortItems();
		return items;
	}

	/**
	 * @param setea el parametro items al campo items
	 */
	public void setItems(List<ItemGlosaReglamentacion> items) {
		this.items = items;
		sortItems();

	}

	/**
	 * @return el valor de tipoNumeracion
	 */
	@Column(name = "TIPO_NUMERACION")
	public int getTipoNumeracion() {
		return tipoNumeracion;
	}

	/**
	 * @param setea el parametro tipoNumeracion al campo tipoNumeracion
	 */
	public void setTipoNumeracion(int tipoNumeracion) {
		this.tipoNumeracion = tipoNumeracion;
	}

	/**
	 * @return el valor de nuevoItem
	 */
	@Transient
	public String getNuevoItem() {
		return nuevoItem;
	}

	/**
	 * @param setea el parametro nuevoItem al campo nuevoItem
	 */
	public void setNuevoItem(String nuevoItem) {
		this.nuevoItem = nuevoItem;
	}

	@Transient
	public String getListaItemsAsText(){
		if(items==null || items.isEmpty()){
			return "";
		}
		String ret = getItemsHeaderAsHTML();
		for (ItemGlosaReglamentacion item: items) {
			ret+="<li>";
			if(getTipoNumeracion()==TIPO_NUMERACCION_GUIONES){
				ret+="- ";
			}
			ret+=item.getTexto()+"</li>";
		}
		for (String item: extraItems) {
			ret+="<li>";
			if(getTipoNumeracion()==TIPO_NUMERACCION_GUIONES){
				ret+="- ";
			}
			ret+=item+"</li>";
		}
		if(getTipoNumeracion()==TIPO_NUMERACCION_LETRA || getTipoNumeracion()==TIPO_NUMERACCION_NUMEROS){
			ret+="</ol>";
		}else{
			ret+="</ul>";
		}
		return ret;
	}

	/**
	 * @param ret
	 * @return
	 */
	@Transient
	private String getItemsHeaderAsHTML() {
		String ret = "";
		if(getTipoNumeracion()==TIPO_NUMERACCION_LETRA || getTipoNumeracion()==TIPO_NUMERACCION_NUMEROS){
			ret+="<ol style=\"padding-left: 2.5em;\" type=\""+((getTipoNumeracion()==TIPO_NUMERACCION_LETRA)?"a":"1")+"\">";
		}else{
			ret+="<ul style=\"padding-left: 2.5em;list-style-type:";
			if(getTipoNumeracion()==TIPO_NUMERACCION_NINGUNA){
				ret+="none\">";
			}else if(getTipoNumeracion()==TIPO_NUMERACCION_PUNTOS){
				ret+="disc\">";
			}else if(getTipoNumeracion()==TIPO_NUMERACCION_GUIONES){
				ret+="none\">";
			}
		}
		return ret;
	}

	@Transient
	public String getAsHtml(){
		String ret="<div>";
		if(getEncabezado()!=null){
			ret+="<div>"+getEncabezado()+"</div>";
		}
		ret+=getListaItemsAsText();
		if(getPie()!=null){
			ret+="<div>"+getPie()+"</div>";
		}
		return ret+"</div>";
	}
	
	@Transient
	public void addItem(String itemText) {
		ItemGlosaReglamentacion item=new ItemGlosaReglamentacion();
		item.setGlosaReglamentacion(this);
		item.setTexto(itemText);
		items.add(item);
		item.setPosicion(items.size());
	}
	
	@Transient
	public void addExtraItem(String itemText) {
		extraItems.add(itemText);
	}

	/**
	 * @return el valor de extraItems
	 */
	@Transient
	public List<String> getExtraItems() {
		if(extraItems==null){
			extraItems=new ArrayList<String>();
		}
		return extraItems;
	}

	/**
	 * @param setea el parametro extraItems al campo extraItems
	 */
	public void setExtraItems(List<String> extraItems) {
		this.extraItems = extraItems;
	}

	public void removeItem(int index){
		ItemGlosaReglamentacion item = items.get(index);
		if(item.getId()!=null){
			itemsAEliminar.add(item);
		}
		items.remove(index);
		int i=1;
		for(ItemGlosaReglamentacion it:items ){
			it.setPosicion(i++);
		}
	}
	
	private void sortItems(){
		Collections.sort(items, new Comparator<ItemGlosaReglamentacion>() {
			   public int compare(ItemGlosaReglamentacion obj1, ItemGlosaReglamentacion obj2) {
			      return obj1.getPosicion()-obj2.getPosicion();
			   }
			});
	}
	
	public void subirItem(int index){
		items.get(index).setPosicion(items.get(index).getPosicion()-1);
		items.get(index-1).setPosicion(items.get(index).getPosicion()+1);
		sortItems();
	}

	public void bajarItem(int index){
		items.get(index).setPosicion(items.get(index).getPosicion()+1);
		items.get(index+1).setPosicion(items.get(index).getPosicion()-1);
		sortItems();
	}


	/**
	 * @return el valor de itemsAEliminar
	 */
	@Transient
	public List<ItemGlosaReglamentacion> getItemsAEliminar() {
		if(itemsAEliminar==null){
			itemsAEliminar=new ArrayList<ItemGlosaReglamentacion>();
		}
		return itemsAEliminar;
	}

	/**
	 * @param setea el parametro itemsAEliminar al campo itemsAEliminar
	 */
	public void setItemsAEliminar(List<ItemGlosaReglamentacion> itemsAEliminar) {
		this.itemsAEliminar = itemsAEliminar;
	}
	
	@Transient
	public String getPreItem(int i){
		if(getTipoNumeracion()==TIPO_NUMERACCION_GUIONES){
			return "- ";
		}
		if(getTipoNumeracion()==TIPO_NUMERACCION_PUNTOS){
			return ""+(char)(8226)+" ";
		}
		if(getTipoNumeracion()==TIPO_NUMERACCION_NUMEROS){
			return i+" ";
		}
		if(getTipoNumeracion()==TIPO_NUMERACCION_LETRA){
			String letras="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			return letras.charAt(i-1)+" ";
		}
		return "";
	}
	
	@Transient
	public List<ItemGlosaReglamentacion> getAllItems() {
		List<ItemGlosaReglamentacion> ret=new ArrayList<ItemGlosaReglamentacion>();
		int i=1;
		if(items!=null){
			for (ItemGlosaReglamentacion item : items) {
				ItemGlosaReglamentacion it = new ItemGlosaReglamentacion();
				it.setTexto(getPreItem(i++) + item.getTexto());
				ret.add(it);
			}
		}
		if(extraItems != null){
			for (String item : extraItems) {
				ItemGlosaReglamentacion it = new ItemGlosaReglamentacion();
				it.setTexto(getPreItem(i++) + item);
				ret.add(it);
			}
		}
		return ret;
	}
	
}
