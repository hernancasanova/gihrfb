package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_GREMIO")
@Audited
public class Gremio extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3382858425878781737L;
	private String nombre;
	private String descriptor;
	private List<GremioRegion> gremiosRegiones;
	
	/**
	 * @return el valor de nombre
	 */
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param setea
	 *            el parametro nombre al campo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return el valor de descriptor
	 */
	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	/**
	 * @param setea
	 *            el parametro descriptor al campo descriptor
	 */
	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}
	
	
	@OneToMany(fetch = FetchType.EAGER, targetEntity = GremioRegion.class, mappedBy = "gremio", cascade = { CascadeType.ALL })
	public List<GremioRegion> getGremiosRegiones() {
		return gremiosRegiones;
	}

	public void setGremiosRegiones(List<GremioRegion> gremiosRegiones) {
		this.gremiosRegiones = gremiosRegiones;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cl.mtt.rnt.commons.model.core.GenericModelObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		try {
			Gremio otro = (Gremio) obj;
			return otro.getId().equals(this.getId());
		} catch (Exception e) {
			return false;
		}
	}

}
