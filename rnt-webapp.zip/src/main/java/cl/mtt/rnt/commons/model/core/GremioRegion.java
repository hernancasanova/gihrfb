// Mejoras 201409 Nro: 30
package cl.mtt.rnt.commons.model.core;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_GREMIO_REGION")
@Audited
public class GremioRegion extends GenericModelObject {

	private static final long serialVersionUID = 7017930662171593292L;
	 
	private String codRegion;
	private Gremio gremio;
	
	@Column(name = "COD_REGION", nullable = false)
	public String getCodRegion() {
		return codRegion;
	}
	
	
	public void setCodRegion(String codRegion) {
		this.codRegion = codRegion;
	}
	
	@ManyToOne(targetEntity = Gremio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_GREMIO")
	public Gremio getGremio() {
		return gremio;
	}
	
	
	public void setGremio(Gremio gremio) {
		this.gremio = gremio;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		GremioRegion gr = (GremioRegion) obj;
		try {
			return gr.getId().equals(this.getId());
		} catch (Exception e) {
			return false;
		}

	}

}
//Mejoras 201409 Nro: 30