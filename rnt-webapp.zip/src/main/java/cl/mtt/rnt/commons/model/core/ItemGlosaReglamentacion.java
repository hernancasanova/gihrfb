package cl.mtt.rnt.commons.model.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.impl.ReemplazosMarcoGeografico;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

@Entity
@Table(name = "RNT_ITEM_GLOSA_REGLAMENTACION")
@Audited
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class ItemGlosaReglamentacion extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4729150221976223898L;
	

	private String texto;
	private int posicion;
	private GlosaReglamentacion glosaReglamentacion;
	
	/**
	 * @return el valor de texto
	 */
	@Column(name = "TEXTO")
	public String getTexto() {
		return texto;
	}
	/**
	 * @param setea el parametro texto al campo texto
	 */
	public void setTexto(String texto) {
		this.texto = texto;
	}
	/**
	 * @return el valor de posicion
	 */
	@Column(name = "POSICION")
	public int getPosicion() {
		return posicion;
	}
	/**
	 * @param setea el parametro posicion al campo posicion
	 */
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	/**
	 * @return el valor de glosaReglamentacion
	 */
	@ManyToOne(targetEntity = GlosaReglamentacion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_GLOSA_REGLAMENTACION")
	public GlosaReglamentacion getGlosaReglamentacion() {
		return glosaReglamentacion;
	}
	/**
	 * @param setea el parametro glosaReglamentacion al campo glosaReglamentacion
	 */
	public void setGlosaReglamentacion(GlosaReglamentacion glosaReglamentacion) {
		this.glosaReglamentacion = glosaReglamentacion;
	}
	
	
}
