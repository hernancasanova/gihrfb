package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

@Entity
@Table(name = "RNT_ITEM_MATRIZ_TARIFARIA")
@Audited
public class ItemMatrizTarifaria extends GenericModelObject implements Anonymizable {

	private Sector sectorInicial;
	private Sector sectorFinal;
	private Float monto;
	private Float montoSecundario;
	private TramoTarifario tramoTarifario;

	public ItemMatrizTarifaria() {
		super();
	}

	public ItemMatrizTarifaria(Sector sectorInicial, Sector sectorFinal, TramoTarifario tramoTarifario) {
		super();
		this.sectorInicial = sectorInicial;
		this.sectorFinal = sectorFinal;
		this.tramoTarifario = tramoTarifario;
	}

	@ManyToOne(targetEntity = Sector.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_SECTOR_INICIAL")
	public Sector getSectorInicial() {
		return sectorInicial;
	}

	public void setSectorInicial(Sector sectorInicial) {
		this.sectorInicial = sectorInicial;
	}

	@ManyToOne(targetEntity = Sector.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_SECTOR_FINAL")
	public Sector getSectorFinal() {
		return sectorFinal;
	}

	public void setSectorFinal(Sector sectorFinal) {
		this.sectorFinal = sectorFinal;
	}

	@Column(name = "MONTO", nullable = true, columnDefinition = "double")
	public Float getMonto() {
		return monto;
	}

	public void setMonto(Float monto) {
		this.monto = monto;
	}

	@Column(name = "MONTO_SECUNDARIO", nullable = true, columnDefinition = "double")
	public Float getMontoSecundario() {
		return montoSecundario;
	}

	public void setMontoSecundario(Float montoSecundario) {
		this.montoSecundario = montoSecundario;
	}

	@ManyToOne(targetEntity = TramoTarifario.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TRAMO_TARIFARIO")
	public TramoTarifario getTramoTarifario() {
		return tramoTarifario;
	}

	public void setTramoTarifario(TramoTarifario tramoTarifario) {
		this.tramoTarifario = tramoTarifario;
	}

	@Override
	public ItemMatrizTarifaria clone() throws CloneNotSupportedException {
		ItemMatrizTarifaria tt = new ItemMatrizTarifaria();
		tt.setCreation(this.getCreation());
		tt.setDbAction(this.getDbAction());
		if (this.getId() != null)
			tt.setId(new Long(this.getId()));
		tt.setModified(this.getModified());
		tt.setUserCreation(this.getUserCreation());
		tt.setUserModified(this.getUserModified());
		tt.setSectorInicial(this.getSectorInicial());
		tt.setSectorFinal(this.getSectorFinal());
		if (this.getMonto() != null)
			tt.setMonto(new Float(this.getMonto()));
		if (this.getMontoSecundario() != null)
			tt.setMontoSecundario(new Float(this.getMontoSecundario()));

		return tt;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

}
