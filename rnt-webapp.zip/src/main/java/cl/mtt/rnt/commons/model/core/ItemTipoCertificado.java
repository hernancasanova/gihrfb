package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_ITEM_TIPO_CERTIFICADO")
public class ItemTipoCertificado extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7865358922126193256L;

	private String campo;
	private String etiqueta;
	private RegistroTipoCertificado registroTipoCertificado;

	/**
	 * @return el valor de campo
	 */
	@Column(name = "CAMPO", nullable = false)
	public String getCampo() {
		return campo;
	}

	/**
	 * @param setea
	 *            el parametro campo al campo campo
	 */
	public void setCampo(String campo) {
		this.campo = campo;
	}

	/**
	 * @return el valor de etiqueta
	 */
	@Column(name = "ETIQUETA", nullable = false)
	public String getEtiqueta() {
		return etiqueta;
	}

	/**
	 * @param setea
	 *            el parametro etiqueta al campo etiqueta
	 */
	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	/**
	 * @return el valor de registroTipoCertificado
	 */
	@ManyToOne(targetEntity = RegistroTipoCertificado.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_REGISTRO_TIPO_CERTIFICADO")
	public RegistroTipoCertificado getRegistroTipoCertificado() {
		return registroTipoCertificado;
	}

	/**
	 * @param setea
	 *            el parametro registroTipoCertificado al campo
	 *            registroTipoCertificado
	 */
	public void setRegistroTipoCertificado(RegistroTipoCertificado registroTipoCertificado) {
		this.registroTipoCertificado = registroTipoCertificado;
	}

}
