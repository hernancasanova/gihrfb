package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

@Entity
@Table(name = "RNT_ITEM_TRAMO_TARIFARIO")
@Audited
public class ItemTramoTarifario extends GenericModelObject implements Anonymizable, Comparable<ItemTramoTarifario> {

	private String horaInicial;
	private String horaFinal;
	private Float monto;
	private Float montoSecundario;
	private TramoTarifario tramoTarifario;

	public ItemTramoTarifario() {
		super();
	}

	@Column(name = "HORA_INICIAL", nullable = true)
	public String getHoraInicial() {
		return horaInicial;
	}

	public void setHoraInicial(String horaInicial) {
		this.horaInicial = horaInicial;
	}

	@Column(name = "HORA_FINAL", nullable = true)
	public String getHoraFinal() {
		return horaFinal;
	}

	public void setHoraFinal(String horaFinal) {
		this.horaFinal = horaFinal;
	}

	@Column(name = "MONTO", nullable = true, columnDefinition = "double")
	public Float getMonto() {
		return monto;
	}

	public void setMonto(Float monto) {
		this.monto = monto;
	}

	@Column(name = "MONTO_SECUNDARIO", nullable = true, columnDefinition = "double")
	public Float getMontoSecundario() {
		return montoSecundario;
	}

	public void setMontoSecundario(Float montoSecundario) {
		this.montoSecundario = montoSecundario;
	}

	@ManyToOne(targetEntity = TramoTarifario.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TRAMO_TARIFARIO")
	public TramoTarifario getTramoTarifario() {
		return tramoTarifario;
	}

	public void setTramoTarifario(TramoTarifario tramoTarifario) {
		this.tramoTarifario = tramoTarifario;
	}

	@Override
	public ItemTramoTarifario clone() throws CloneNotSupportedException {
		ItemTramoTarifario tt = new ItemTramoTarifario();
		tt.setCreation(this.getCreation());
		tt.setDbAction(this.getDbAction());
		if (this.getId() != null)
			tt.setId(new Long(this.getId()));
		tt.setModified(this.getModified());
		tt.setUserCreation(this.getUserCreation());
		tt.setUserModified(this.getUserModified());
		tt.setHoraInicial(this.getHoraInicial());
		tt.setHoraFinal(this.getHoraFinal());
		if (this.getMonto() != null)
			tt.setMonto(new Float(this.getMonto()));
		if (this.getMontoSecundario() != null)
			tt.setMontoSecundario(new Float(this.getMontoSecundario()));

		return tt;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@Override
	public int compareTo(ItemTramoTarifario o) {
		if (this.getHoraInicial() == null && o.getHoraInicial() == null)
			return 0;
		if (this.getHoraInicial() == null)
			return -1;
		if (o.getHoraInicial() == null)
			return 1;
		return this.getHoraInicial().compareTo(o.getHoraInicial());
	}

}
