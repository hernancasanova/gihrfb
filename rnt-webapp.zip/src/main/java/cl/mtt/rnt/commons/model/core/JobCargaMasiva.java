package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

@Entity
@Table(name = "RNT_JOB_CARGA_MASIVA")
public class JobCargaMasiva extends GenericModelObject {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4583201291058886877L;
	private Integer cantidadFilas;
	
	
	protected JsonArray jsonTable;
	
	/**
	 * @return el valor de job
	 */
	@Column(name = "JOB", nullable = false)
	 @Lob
	public String getJob() {
		if(jsonTable!=null){
			return new Gson().toJson(jsonTable);
		}
		else{
			return null;
		}
	}

	/**
	 * @param setea el parametro job al campo job
	 */
	public void setJob(String job) {
		JsonParser parser = new JsonParser();
		JsonArray jArray = parser.parse(job).getAsJsonArray();
		this.jsonTable = jArray;
	}

	@Column(name = "CANTIDAD_FILAS", nullable = false)
	public Integer getCantidadFilas() {
		return cantidadFilas;
	}

	public void setCantidadFilas(Integer cantidadFilas) {
		this.cantidadFilas = cantidadFilas;
	}

	/**
	 * @return el valor de jsonTable
	 */
	@Transient
	public JsonArray getJsonTable() {
		if(this.jsonTable==null) this.jsonTable = new JsonArray();
		return jsonTable;
	}

	/**
	 * @param setea el parametro jsonTable al campo jsonTable
	 */
	public void setJsonTable(JsonArray jsonTable) {
		this.jsonTable = jsonTable;
	}

	

	
	
	
}
