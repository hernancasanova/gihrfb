package cl.mtt.rnt.commons.model.core;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_LIMITACION_VEHICULO")
public class LimitacionVehiculo extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2401004535233251085L;

	private String titulo;
	private String documento;
	private String naturaleza;
	private String comuna;
	private String causa;
	private String aCausa;
	private Date fechaDoc;
	private String autorizante;
	private String acreedor;
	private String repertorio;
	private String numeroRepertorio;
	private Date fechaRepertorio;
	private List<Tenedor> tenedores;
	private Vehiculo vehiculo;

	/**
	 * @return el valor de titulo
	 */
	@Column(name = "TITULO", nullable = true)
	public String getTitulo() {
		return titulo;
	}

	/**
	 * @param setea
	 *            el parametro titulo al campo titulo
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	/**
	 * @return el valor de documento
	 */
	@Column(name = "DOCUMENTO", nullable = true)
	public String getDocumento() {
		return documento;
	}

	/**
	 * @param setea
	 *            el parametro documento al campo documento
	 */
	public void setDocumento(String documento) {
		this.documento = documento;
	}

	/**
	 * @return el valor de naturaleza
	 */
	@Column(name = "NATURALEZA", nullable = true)
	public String getNaturaleza() {
		return naturaleza;
	}

	/**
	 * @param setea
	 *            el parametro naturaleza al campo naturaleza
	 */
	public void setNaturaleza(String naturaleza) {
		this.naturaleza = naturaleza;
	}

	/**
	 * @return el valor de comuna
	 */
	@Column(name = "COMUNA", nullable = true)
	public String getComuna() {
		return comuna;
	}

	/**
	 * @param setea
	 *            el parametro comuna al campo comuna
	 */

	public void setComuna(String comuna) {
		this.comuna = comuna;
	}

	/**
	 * @return el valor de causa
	 */
	@Column(name = "CAUSA", nullable = true)
	public String getCausa() {
		return causa;
	}

	/**
	 * @param setea
	 *            el parametro causa al campo causa
	 */
	public void setCausa(String causa) {
		this.causa = causa;
	}

	/**
	 * @return el valor de aCausa
	 */
	@Column(name = "A_CAUSA", nullable = true)
	public String getaCausa() {
		return aCausa;
	}

	/**
	 * @param setea
	 *            el parametro aCausa al campo aCausa
	 */
	public void setaCausa(String aCausa) {
		this.aCausa = aCausa;
	}

	/**
	 * @return el valor de fehcaDoc
	 */
	@Column(name = "FECHA_DOCUMENTO", nullable = true)
	public Date getFechaDoc() {
		return fechaDoc;
	}

	/**
	 * @param setea
	 *            el parametro fehcaDoc al campo fehcaDoc
	 */
	public void setFechaDoc(Date fehcaDoc) {
		this.fechaDoc = fehcaDoc;
	}

	/**
	 * @return el valor de autorizante
	 */
	@Column(name = "AUTORIZANTE", nullable = true)
	public String getAutorizante() {
		return autorizante;
	}

	/**
	 * @param setea
	 *            el parametro autorizante al campo autorizante
	 */
	public void setAutorizante(String autorizante) {
		this.autorizante = autorizante;
	}

	/**
	 * @return el valor de acreedor
	 */
	@Column(name = "ACREEDOR", nullable = true)
	public String getAcreedor() {
		return acreedor;
	}

	/**
	 * @param setea
	 *            el parametro acreedor al campo acreedor
	 */
	public void setAcreedor(String acreedor) {
		this.acreedor = acreedor;
	}

	/**
	 * @return el valor de repertorio
	 */
	@Column(name = "REPERTORIO", nullable = true)
	public String getRepertorio() {
		return repertorio;
	}

	/**
	 * @param setea
	 *            el parametro repertorio al campo repertorio
	 */
	public void setRepertorio(String repertorio) {
		this.repertorio = repertorio;
	}

	/**
	 * @return el valor de numeroRepertorio
	 */
	@Column(name = "NUMERO_REPERTORIO", nullable = true)
	public String getNumeroRepertorio() {
		return numeroRepertorio;
	}

	/**
	 * @param setea
	 *            el parametro numeroRepertorio al campo numeroRepertorio
	 */
	public void setNumeroRepertorio(String numeroRepertorio) {
		this.numeroRepertorio = numeroRepertorio;
	}

	/**
	 * @return el valor de fechaRepertorio
	 */
	@Column(name = "FECHA_REPERTORIO", nullable = true)
	public Date getFechaRepertorio() {
		return fechaRepertorio;
	}

	/**
	 * @param setea
	 *            el parametro fechaRepertorio al campo fechaRepertorio
	 */
	public void setFechaRepertorio(Date fechaRepertorio) {
		this.fechaRepertorio = fechaRepertorio;
	}

	/**
	 * @return el valor de tenedores
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = Tenedor.class, mappedBy = "limitacion", cascade = { CascadeType.ALL })
	public List<Tenedor> getTenedores() {
		return tenedores;
	}

	/**
	 * @param setea
	 *            el parametro tenedores al campo tenedores
	 */
	public void setTenedores(List<Tenedor> tenedores) {
		this.tenedores = tenedores;
	}

	/**
	 * @return el valor de vehiculo
	 */
	@ManyToOne(targetEntity = Vehiculo.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_VEHICULO")
	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	/**
	 * @param setea
	 *            el parametro vehiculo al campo vehiculo
	 */
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

}
