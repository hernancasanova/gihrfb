package cl.mtt.rnt.commons.model.core;

public interface Localizable {

	public String getRegionIdentifier();

	public String getIdentifier();

	public String getLabel();

	public String getLabelLarge();

}
