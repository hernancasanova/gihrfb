package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_LOG_SERVICIO")
public class LogServicio {

	Long id;
	Servicio servicio;
	Long rev;
	String message;
	
	
	
	public LogServicio() {
		super();
	}
	
	
	public LogServicio(Servicio servicio, String message) {
		super();
		this.servicio = servicio;
		this.message = message;
	}


	@Id
	@Column(name = "ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@ManyToOne(targetEntity = Servicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SERVICIO")
	public Servicio getServicio() {
		return servicio;
	}
	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}
	@Column(name = "REV", nullable = false)
	public Long getRev() {
		return rev;
	}
	public void setRev(Long rev) {
		this.rev = rev;
	}
	@Column(name = "MESSAGE", nullable = false)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	
	
}
