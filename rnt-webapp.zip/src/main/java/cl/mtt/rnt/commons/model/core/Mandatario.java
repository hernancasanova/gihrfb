package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

@Entity
@Table(name = "RNT_MANDATARIO")
@Audited
public class Mandatario extends GenericModelObject implements Anonymizable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6555458049261284460L;
	private String domicilio;
	private String codigoRegion;
	private String codigoComuna;
	private String telefono;
	private String fax;
	private String email;
	private String nombreRegion;
	private String nombreComuna;
	private Boolean autorizadoTramites;
	private TipoRepresentante tipoRepresentante;
	private Date mandatoDesde;
	private Date mandatoHasta;

	private Persona persona;

	@Column(name = "DOMICILIO", nullable = true)
	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "TELEFONO", nullable = true)
	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Column(name = "FAX", nullable = true)
	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "EMAIL", nullable = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@ManyToOne(targetEntity = Persona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PERSONA")
	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Column(name = "AUTORIZADO_TRAMITES", nullable = true)
	public Boolean getAutorizadoTramites() {
		return autorizadoTramites;
	}

	public void setAutorizadoTramites(Boolean autorizadoTramites) {
		this.autorizadoTramites = autorizadoTramites;
	}

	/**
	 * @return el valor de nombreRegion
	 */
	@Transient
	public String getNombreRegion() {
		return nombreRegion;
	}

	/**
	 * @param setea
	 *            el parametro nombreRegion al campo nombreRegion
	 */
	public void setNombreRegion(String nombreRegion) {
		this.nombreRegion = nombreRegion;
	}

	/**
	 * @return el valor de nombreComuna
	 */
	@Transient
	public String getNombreComuna() {
		return nombreComuna;
	}

	/**
	 * @param setea
	 *            el parametro nombreComuna al campo nombreComuna
	 */
	public void setNombreComuna(String nombreComuna) {
		this.nombreComuna = nombreComuna;
	}

	@ManyToOne(targetEntity = TipoRepresentante.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_REPRESENTANTE")
	public TipoRepresentante getTipoRepresentante() {
		return tipoRepresentante;
	}

	public void setTipoRepresentante(TipoRepresentante tipoRepresentante) {
		this.tipoRepresentante = tipoRepresentante;
	}

	// Mejoras 201409 Nro: 41
	@Column(name = "MANDATO_DESDE", nullable = true)
	public Date getMandatoDesde() {
		return mandatoDesde;
	}

	public void setMandatoDesde(Date mandatoDesde) {
		this.mandatoDesde = mandatoDesde;
	}

	@Column(name = "MANDATO_HASTA", nullable = true)
	public Date getMandatoHasta() {
		return mandatoHasta;
	}
	// Mejoras 201409 Nro: 41
	/**
	 * @param setea
	 *            el parametro mandatoHasta al campo mandatoHasta
	 */
	public void setMandatoHasta(Date mandatoHasta) {
		this.mandatoHasta = mandatoHasta;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@Transient
	public Mandatario getForClone() {
		Mandatario m = new Mandatario();
		m.autorizadoTramites = this.autorizadoTramites;
		m.codigoComuna = this.codigoComuna;
		m.codigoRegion = this.codigoRegion;
		m.domicilio = this.domicilio;
		m.email = this.email;
		m.fax = this.fax;
		m.nombreComuna = this.nombreComuna;
		m.nombreRegion = this.nombreRegion;
		m.persona = this.persona;
		m.telefono = this.telefono;
		m.tipoRepresentante = this.tipoRepresentante;
		m.mandatoDesde = this.mandatoDesde;
		m.mandatoHasta = this.mandatoHasta;
		m.setDbAction(ACTION_SAVE);
		return m;
	}

}
