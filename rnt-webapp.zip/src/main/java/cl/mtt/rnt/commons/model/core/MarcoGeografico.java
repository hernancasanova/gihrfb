package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.faces.event.AjaxBehaviorEvent;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Localidad;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;

@Entity
@Table(name = "RNT_MARCO_GEOGRAFICO")
@Audited
public class MarcoGeografico extends GenericModelObject {

	private static final long serialVersionUID = 1L;
	private String aplicableA;
	private List<Localizable> localizables;
	private List<MarcoGeograficoLocalizable> marcosGeograficoslocalizables;
	private List<Localizable> localizablesExistentes = new ArrayList<Localizable>();
	@Transient
	private boolean locked;

	private MarcoGeograficoSource source;

	private TipoZona tipoZonaSelected;
	// Mejoras 201409 Nro: 5
	private Region regionZonaSelected;
	// Mejoras 201409 Nro: 5
	
	public MarcoGeografico() {
		super();
	}

	public MarcoGeografico(String aplicableA) {
		super();
		this.aplicableA = aplicableA;
		this.localizables = new ArrayList<Localizable>();
	}

	public MarcoGeografico(String aplicableA, MarcoGeograficoSource marcoGeograficoSource) {
		super();
		this.aplicableA = aplicableA;
		this.localizables = new ArrayList<Localizable>();
		this.source = marcoGeograficoSource;
	}

	@Column(name = "APLICABLE_A", nullable = false)
	public String getAplicableA() {
		return aplicableA;
	}

	public void setAplicableA(String aplicableA) {
		this.aplicableA = aplicableA;
	}

	@Transient
	public List<Localizable> getLocalizables() {
		return localizables;
	}

	public void setLocalizables(List<Localizable> localizables) {
		this.localizables = localizables;
		updateLocalizables();
	}

	private void updateLocalizables() {
		if (MarcoGeograficoSource.AMBITO_NACIONAL.equals(aplicableA)) {
			if (marcosGeograficoslocalizables != null && marcosGeograficoslocalizables.size() == 1 && "nac".equals(marcosGeograficoslocalizables.get(0).getIdLocalizable()))
				return;
			marcosGeograficoslocalizables = new ArrayList<MarcoGeograficoLocalizable>();
			marcosGeograficoslocalizables.add(new MarcoGeograficoLocalizable("nac", "nac", this));
			return;
		}
		if (localizables != null) {
			ArrayList<MarcoGeograficoLocalizable> mgls = new ArrayList<MarcoGeograficoLocalizable>();
			if (marcosGeograficoslocalizables == null)
				marcosGeograficoslocalizables = new ArrayList<MarcoGeograficoLocalizable>();
			for (Localizable localizable : localizables) {
				MarcoGeograficoLocalizable mglExistente = null;
				for (MarcoGeograficoLocalizable mgl : marcosGeograficoslocalizables) {
					if (mgl.getIdRegion().equals(localizable.getRegionIdentifier()) && mgl.getIdLocalizable().equals(localizable.getIdentifier())) {
						mglExistente = mgl;
					}
				}
				if (mglExistente == null) {
					mgls.add(new MarcoGeograficoLocalizable(localizable.getRegionIdentifier(), localizable.getIdentifier(), this));
				}
				else {
					mgls.add(mglExistente);
				}
			}
			setMarcosGeograficoslocalizables(mgls);
		}
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = MarcoGeograficoLocalizable.class, mappedBy = "marcoGeografico")
	public List<MarcoGeograficoLocalizable> getMarcosGeograficoslocalizables() {
		updateLocalizables();
		return marcosGeograficoslocalizables;
	}

	public void setMarcosGeograficoslocalizables(List<MarcoGeograficoLocalizable> marcosGeograficoslocalizables) {
		this.marcosGeograficoslocalizables = marcosGeograficoslocalizables;
	}

	@SuppressWarnings("static-access")
	@Transient
	public String getDescription() {
		String desc = "[" + source.getAmbitoName(getAplicableA()) + "]";
		for (Localizable l : localizables) {
			desc += " - " + l.getLabel();
		}
		return desc;
	}

	@SuppressWarnings("static-access")
	@Transient
	public String getAplicaAText() {
		return source.getAmbitoName(getAplicableA());
	}

	@Transient
	public String getListaLocalizablesText() {
		if (this.getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL)) {
			return MarcoGeograficoSource.getAmbitoName(MarcoGeograficoSource.AMBITO_NACIONAL);
		}
		if (localizables == null)
			return null;
		if (localizables.size() == 0)
			return "";
		String desc = "";
		if (localizables.size() <= 3) {
			for (Localizable l : localizables) {
				desc += l.getLabel() + ", ";
			}
			return desc.substring(0, desc.lastIndexOf(","));
		} else {
			for (int i = 0; i < 3; i++) {
				Localizable l = localizables.get(i);
				desc += l.getLabel() + ", ";
			}
			return desc.substring(0, desc.lastIndexOf(",")) + " ...";
		}

	}

	@Transient
	public List<String> getListaLocalizablesList() {
		if (this.getAplicableA().equals(MarcoGeograficoSource.AMBITO_NACIONAL)) {
			List<String> locatexts = new ArrayList<String>();
			locatexts.add(MarcoGeograficoSource.getAmbitoName(MarcoGeograficoSource.AMBITO_NACIONAL));
			return locatexts;
		}
		if (localizables == null)
			return null;
		List<String> locatexts = new ArrayList<String>();
		if (localizables.size() == 0)
			return locatexts;
		for (Localizable l : localizables) {
			locatexts.add(l.getLabel());
		}
		return locatexts;
	}

	@Transient
	public List<Region> getRegiones() {
		List<Region> items = new ArrayList<Region>();
		for (Localizable localizable : localizables) {
			try {
				items.add((Region) localizable);
			} catch (ClassCastException e) {
			}
		}
		return items;
	}

	public void setRegiones(List<Region> regiones) {
		localizables = new ArrayList<Localizable>(regiones);
	}

	@Transient
	public List<Localidad> getLocalidades() {
		List<Localidad> items = new ArrayList<Localidad>();
		for (Localizable localizable : localizables) {
			try {
				items.add((Localidad) localizable);
			} catch (ClassCastException e) {
			}
		}
		return items;
	}

	public void setLocalidades(List<Localidad> localidades) {
		localizables = new ArrayList<Localizable>(localidades);
	}

	@Transient
	public List<Comuna> getComunas() {
		List<Comuna> items = new ArrayList<Comuna>();
		for (Localizable localizable : localizables) {
			try {
				items.add((Comuna) localizable);
			} catch (ClassCastException e) {
			}
		}
		return items;
	}

	public void setComunas(List<Comuna> comunas) {
		localizables = new ArrayList<Localizable>(comunas);
	}

	@Transient
	public List<Zona> getZonas() {
		List<Zona> items = new ArrayList<Zona>();
		if (localizables != null) {
			for (Localizable localizable : localizables) {
				try {
					items.add((Zona) localizable);
				} catch (ClassCastException e) {
				}
			}
		}
		return items;
	}

	public void setZonas(List<Zona> zonas) {
		localizables = new ArrayList<Localizable>(zonas);
	}

	@Transient
	public MarcoGeograficoSource getSource() {
		return source;
	}

	public void setSource(MarcoGeograficoSource source) {
		this.source = source;
	}

	@Transient
	public List<Localizable> getLocalizablesExistentes() {
		return localizablesExistentes;
	}

	public void setLocalizablesExistentes(List<Localizable> localizablesExistentes) {
		this.localizablesExistentes = localizablesExistentes;
	}

	@Transient
	public void lockLocalizables(List<Localizable> localizablesBloqueados) {
		if (!locked) {
			localizablesExistentes = new ArrayList<Localizable>();
			for (Localizable localizable : localizables) {
				if (localizablesBloqueados.contains(localizable))
					localizablesExistentes.add(localizable);
			}
			for (Localizable localizable : localizablesExistentes) {
				localizables.remove(localizable);
			}
			locked = true;
		}
	}

	@Transient
	public void lockLocalizables() {
		if (!locked) {
			localizablesExistentes = localizables;
			localizables = new ArrayList<Localizable>();
			locked = true;
		}
	}

	@Transient
	public void unlockLocalizables() {
		if (locked) {
			localizables.addAll(localizablesExistentes);
			localizablesExistentes = new ArrayList<Localizable>();
			locked = false;
		}
	}

	@ManyToOne(targetEntity = TipoZona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_ZONA")
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoZona getTipoZonaSelected() {
		return tipoZonaSelected;
	}

	public void setTipoZonaSelected(TipoZona tipoZona) {
		this.tipoZonaSelected = tipoZona;
	}


	// Mejoras 201409 Nro: 5
	@Transient
	public Region getRegionZonaSelected() {
		return regionZonaSelected;
	}

	public void setRegionZonaSelected(Region regionZonaSelected) {
		this.regionZonaSelected = regionZonaSelected;
	}
	
	
	public void tipoZonaChanged(AjaxBehaviorEvent event){
		setZonas(new ArrayList<Zona>());	
	}
	
	// Mejoras 201409 Nro: 5
}
