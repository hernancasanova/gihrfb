package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_MARCO_GEOGRAFICO_LOCALIZABLE")
@Audited
public class MarcoGeograficoLocalizable extends GenericModelObject {

	private static final long serialVersionUID = 1L;
	private String idRegion;
	private String idLocalizable;
	private MarcoGeografico marcoGeografico;

	public MarcoGeograficoLocalizable() {
		super();
	}

	public MarcoGeograficoLocalizable(String idRegion, String idLocalizable, MarcoGeografico marcoGeografico) {
		super();
		this.idRegion = idRegion;
		this.idLocalizable = idLocalizable;
		this.marcoGeografico = marcoGeografico;
	}

	@Column(name = "ID_REGION", nullable = false)
	public String getIdRegion() {
		return idRegion;
	}

	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}

	@Column(name = "ID_LOCALIZABLE", nullable = false)
	public String getIdLocalizable() {
		return idLocalizable;
	}

	public void setIdLocalizable(String idLocalizable) {
		this.idLocalizable = idLocalizable;
	}

	@ManyToOne(targetEntity = MarcoGeografico.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_MARCO_GEOGRAFICO", nullable = false)
	public MarcoGeografico getMarcoGeografico() {
		return marcoGeografico;
	}

	public void setMarcoGeografico(MarcoGeografico marcoGeografico) {
		this.marcoGeografico = marcoGeografico;
	}

}
