package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.NombrableModelObject;

@Entity
@Table(name = "RNT_MEDIO_TRANSPORTE")
@Audited
public class MedioTransporte extends GenericModelObject implements NombrableModelObject {

	private static final long serialVersionUID = 1L;

	private String nombre;
	private String descriptor;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

}
