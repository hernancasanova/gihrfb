package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_MOTIVO_MOD_SERVICIO")
public class MotivoModServicio extends GenericModelObject {

	private static final long serialVersionUID = 2154084773319473938L;

	public String nombre;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
