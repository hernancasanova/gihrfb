package cl.mtt.rnt.commons.model.core;

public class Nacionalidad {

	private String id;
	private String nacionalidadDesc;

	public static final String NACIONALIDAD_C_ID = "C";
	public static final String NACIONALIDAD_E_ID = "E";

	public Nacionalidad(String id, String nacionalidadDesc) {
		super();
		this.id = id;
		this.nacionalidadDesc = nacionalidadDesc;
	}

	/**
	 * @return el valor de id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param setea
	 *            el parametro id al campo id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return el valor de nacionalidadDesc
	 */
	public String getNacionalidadDesc() {
		return nacionalidadDesc;
	}

	/**
	 * @param setea
	 *            el parametro nacionalidadDesc al campo nacionalidadDesc
	 */
	public void setNacionalidadDesc(String nacionalidadDesc) {
		this.nacionalidadDesc = nacionalidadDesc;
	}

}
