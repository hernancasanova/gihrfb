package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.swing.tree.TreeNode;

//import org.richfaces.model.TreeNode;

@MappedSuperclass
public abstract class NodoCertificado extends GenericModelObject implements TreeNode, Comparable<NodoCertificado>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5646723921426887010L;

	public static String nodo_tipo_seccion = "seccion";
	public static String nodo_tipo_campo = "campo";

	private String nombre;
	private String descripcion;
	private String property;
	private Boolean selected;
	private Boolean utilizaLabel;
	private Boolean mandatory;
	private String descriptor;

	private String etiqueta;

	private int deep;

	public NodoCertificado() {
		selected = Boolean.FALSE;
		utilizaLabel = Boolean.FALSE;
		mandatory = Boolean.FALSE;
	}

	@Column(name = "NOMBRE", nullable = true)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "PROPERTY", nullable = true)
	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	@Column(name = "DESCRIPCION", nullable = true)
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Column(name = "UTILIZA_LABEL", nullable = true)
	public Boolean getUtilizaLabel() {
		return utilizaLabel;
	}

	@Column(name = "UTILIZA_LABEL", nullable = true)
	public void setUtilizaLabel(Boolean utilizaLabel) {
		this.utilizaLabel = utilizaLabel;
	}

	@Transient
	public Boolean getSelected() {
		if (selected == null) {
			selected = Boolean.FALSE;
		}
		return selected;
	}

	public void setSelected(Boolean selected) {
		this.selected = selected;
	}

	@Transient
	public String getType() {
		// devolver instancia de que objeto es
		if (this instanceof CertificadoSeccionDefinition)
			return nodo_tipo_seccion;
		else if (this instanceof CertificadoCampoDefinition)
			return nodo_tipo_campo;
		return "";
	}

	@Column(name = "MANDATORY", nullable = false)
	public Boolean getMandatory() {
		return mandatory;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	/**
	 * @return el valor de descriptor
	 */
	@Column(name = "DESCRIPTOR", nullable = true)
	public String getDescriptor() {
		return descriptor;
	}

	/**
	 * @param setea
	 *            el parametro descriptor al campo descriptor
	 */
	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	/**
	 * @return el valor de etiqueta
	 */
	@Transient
	public String getEtiqueta() {
		if (etiqueta == null) {
			etiqueta = this.getDescripcion();
		}
		return etiqueta;
	}

	/**
	 * @param setea
	 *            el parametro etiqueta al campo etiqueta
	 */
	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	public void setDeep(int level) {
		this.deep = level;

	}

	/**
	 * @return el valor de deep
	 */
	@Transient
	public int getDeep() {
		return deep;
	}

	/**
	 * Para un nodo el campo es
	 */
	@Transient
	public Integer getTipoCampo() {
		return 0;
	}
	
	@Override
	public int compareTo(NodoCertificado o) {
		String t1 = this.getDescriptor();
		String t2 = o.getDescriptor();
		if (t1 == null && t2 == null){
			return 0;
		}else if (t1 == null){
			return -1;
		} else if (t2 == null) {
			return 1;
		} else {
			return t1.toLowerCase().compareTo(t2.toLowerCase());
		}
	}
}
