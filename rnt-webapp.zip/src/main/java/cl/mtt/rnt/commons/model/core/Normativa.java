package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.autorizacion.Autorizacion;

@Entity
@Table(name = "RNT_NORMATIVA")
@Audited
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class Normativa extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3001115424726342079L;

	private String label;
	private String descriptor;
	private String tipoNormativa;
	private String validacion;
	private List<NormativaRegistro> registros;
	private Reglamentacion reglamentacion;
	private boolean requiereMarcoGeografico;
	private boolean requiereTipoServicio;
	private Boolean permiteAutorizacion;
	private Autorizacion autorizacion;
	
	
	public static String descriptorTiposVehiculosPermitidos = "normas_tipos_vehiculo_permitido";
	public static String descriptorVehiculosPrestandoOtrosServicios = "tipos_vehiculo_permitidos_otros_servicios";
	public static String reemplazosRestriccionTipoCancelacionRemplazado= "reemplazosRestriccionTipoCancelacionRemplazado";

	@Column(name = "RNT_LABEL", nullable = false)
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	@Column(name = "TIPONORMATIVA", nullable = false)
	public String getTipoNormativa() {
		return tipoNormativa;
	}

	public void setTipoNormativa(String tipoNormativa) {
		this.tipoNormativa = tipoNormativa;
	}

	@Column(name = "VALIDACION", nullable = false)
	public String getValidacion() {
		return validacion;
	}

	public void setValidacion(String validacion) {
		this.validacion = validacion;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = NormativaRegistro.class, mappedBy = "normativa", cascade = { CascadeType.ALL }, orphanRemoval = true)
	@BatchSize (size = 100)
	public List<NormativaRegistro> getRegistros() {
		return registros;
	}

	public void setRegistros(List<NormativaRegistro> registros) {		
		this.registros = registros;		
	}

	@ManyToOne(targetEntity = Reglamentacion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_REGLAMENTACION")
	public Reglamentacion getReglamentacion() {
		return reglamentacion;
	}

	public void setReglamentacion(Reglamentacion reglamentacion) {
		this.reglamentacion = reglamentacion;
	}

	@Column(name = "REQUIERE_MARCO_GEOGRAFICO", nullable = false)
	public boolean isRequiereMarcoGeografico() {
		return requiereMarcoGeografico;
	}

	public void setRequiereMarcoGeografico(boolean requiereMarcoGeografico) {
		this.requiereMarcoGeografico = requiereMarcoGeografico;
	}

	@Column(name = "REQUIERE_TIPO_SERVICIO", nullable = false)
	public boolean isRequiereTipoServicio() {
		return requiereTipoServicio;
	}

	public void setRequiereTipoServicio(boolean requiereTipoServicio) {
		this.requiereTipoServicio = requiereTipoServicio;
	}
	
	// Mejoras 201409 Nro: 75
	@Column(name = "PERMITE_AUTORIZACION")
	public Boolean getPermiteAutorizacion() {
		if(permiteAutorizacion == null)
			permiteAutorizacion = false;
		return permiteAutorizacion;
	}

	public void setPermiteAutorizacion(Boolean permiteAutorizacion) {
		this.permiteAutorizacion = permiteAutorizacion;
	}
	
	@OneToOne(fetch = FetchType.LAZY, targetEntity = Autorizacion.class, mappedBy = "normativa", cascade = { CascadeType.ALL }, orphanRemoval = true)
	public Autorizacion getAutorizacion() {
		return this.autorizacion;
	}

	public void setAutorizacion(Autorizacion autorizacion) {
		this.autorizacion = autorizacion;
	}
	
	// Mejoras 201409 Nro: 75
	
	

}
