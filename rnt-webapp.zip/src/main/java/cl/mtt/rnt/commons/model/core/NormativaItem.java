package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_NORMATIVA_ITEM")
@Audited
public class NormativaItem extends GenericModelObject {

	private String key;
	private List<String> values;
	private NormativaRegistro registro;
	private String textualValue;
	private List<String> textualValues;

	public NormativaItem() {
		super();
	}

	public NormativaItem(String key, List<String> values, NormativaRegistro registro) {
		super();
		this.key = key;
		this.values = values;
		this.registro = registro;
	}

	public NormativaItem(String key, String value) {
		super();
		this.key = key;
		this.values = new ArrayList<String>();
		if (value != null) {
			this.values.add(value);
			this.textualValue = new String(value);
		}
	}

	public NormativaItem(String key, String value, String textualValue) {
		super();
		this.key = key;
		this.values = new ArrayList<String>();
		this.values.add(value);
		this.textualValue = textualValue;
	}

	public NormativaItem(String key, List<String> values, String textualValue) {
		super();
		this.key = key;
		this.values = values;
		this.textualValue = textualValue;
	}

	public NormativaItem(String key, List<String> values) {
		super();
		this.key = key;
		this.values = values;
		this.textualValue = "";
		if (values != null) {
			for (int i = 0; i < values.size(); i++) {
				this.textualValue += ((i == 0) ? "" : ", ") + values.get(i);
			}
		}
	}

	@Column(name = "RNT_KEY", nullable = false)
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	@ManyToOne(targetEntity = NormativaRegistro.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_NORMATIVA_REGISTRO")
	public NormativaRegistro getRegistro() {
		return registro;
	}

	public void setRegistro(NormativaRegistro registro) {
		this.registro = registro;
	}

	@ElementCollection
	@CollectionTable(name = "RNT_NORMATIVA_ITEM_DATA", joinColumns = @JoinColumn(name = "ID_NORMATIVA_ITEM"))
	@Column(name = "VALUE")
	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	@Transient
	public String getValue() {
		if (this.values != null && this.values.size() > 0)
			return this.values.get(0);
		return null;
	}

	public void setValue(String value) {
		try {
			if (this.values == null)
				this.values = new ArrayList<String>();
			if (this.values.size() > 0)
				this.values.set(0, value);
			else
				this.values.add(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Transient
	public String getTextualValue() {
		return textualValue;
	}

	public void setTextualValue(String textualValue) {
		this.textualValue = textualValue;
	}

	@Transient
	public List<String> getTextualValues() {
		return textualValues;
	}

	public void setTextualValues(List<String> textualValues) {
		this.textualValues = textualValues;
	}

	
}
