package cl.mtt.rnt.commons.model.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_NORMATIVA_REGISTRO")
@Audited
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class NormativaRegistro extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5748804695778774982L;

	private Normativa normativa;
	private List<NormativaItem> items;
	private String descriptor;

	@Column(name = "DESCRIPTOR", nullable = true)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	@ManyToOne(targetEntity = Normativa.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_NORMATIVA")
	public Normativa getNormativa() {
		return normativa;
	}

	public void setNormativa(Normativa normativa) {
		this.normativa = normativa;
	}

	@OneToMany(fetch = FetchType.EAGER, targetEntity = NormativaItem.class, mappedBy = "registro", cascade = { CascadeType.ALL })//, orphanRemoval = true)
	@BatchSize (size = 100)
	public List<NormativaItem> getItems() {
		return items;
	}

	public void setItems(List<NormativaItem> items) {
		if(this.items==null){
			this.items = items;
		}else{
			this.items.clear();
			this.items.addAll(items);
		}
		
	}

	@Transient
	public void addNormativaItem(NormativaItem normativaItem) {
		this.items.add(normativaItem);
		normativaItem.setRegistro(this);
	}

	@Transient
	public Map<String, NormativaItem> getItemsAsMap() {
		Map<String, NormativaItem> ret = new HashMap<String, NormativaItem>();
		for (NormativaItem item : items) {
			ret.put(item.getKey(), item);
		}
		return ret;
	}

}
