package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import com.google.gson.annotations.Expose;

import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.util.Constants;

@Entity
@Table(name = "RNT_OFICINA_VENTA_PASAJE")
@Audited
public class OficinaVentaPasaje extends PointOfInterest {

	private static final long serialVersionUID = -5572500982780420184L;
	
	private String nombre;
	private String descripcion;
	private String tipoUbicacion;
	@Expose
	private String domicilio;
	private String telefono;
	private String fax;
	private String email;
	private String codigoRegion;
	private String codigoComuna;
	private Paradero paradero;
	private boolean esWeb;
	private String urlWeb;
	private boolean selected;
	private boolean agregada;
	private String nombreCortado;
	private String descripcionCortada;
	
	@Transient
	@Expose
	private Region region;
	
	@Transient
	@Expose
	private Comuna comuna;

	
	public OficinaVentaPasaje() {
		super();
		markerName="OFICINA_VENTAS";
	}
	
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	@Column(name = "DESCRIPCION", nullable = true)
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	@Column(name = "TIPO_UBICACION", nullable = false)
	public String getTipoUbicacion() {
		return tipoUbicacion;
	}
	public void setTipoUbicacion(String tipoUbicacion) {
		this.tipoUbicacion = tipoUbicacion;
	}
	
	@Column(name = "DIRECCION", nullable = true)
	public String getDomicilio() {
		return domicilio;
	}
	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}
	
	@Column(name = "TELEFONO", nullable = true)
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
	@Column(name = "FAX", nullable = true)
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	
	@Column(name = "EMAIL", nullable = true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}
	
	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}
	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}
	
	@ManyToOne(targetEntity = Paradero.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PARADERO", nullable = true)
	public Paradero getParadero() {
		return paradero;
	}
	public void setParadero(Paradero paradero) {
		this.paradero = paradero;
	}
	
	@Column(name = "ES_WEB", nullable = true)
	public boolean isEsWeb() {
		return esWeb;
	}
	public void setEsWeb(boolean esWeb) {
		this.esWeb = esWeb;
	}
	
	@Column(name = "URL_WEB", nullable = true)
	public String getUrlWeb() {
		return urlWeb;
	}
	public void setUrlWeb(String urlWeb) {
		this.urlWeb = urlWeb;
	}
	
	@Transient
	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}
	
	@Transient
	public Comuna getComuna() {
		return comuna;
	}

	public void setComuna(Comuna comuna) {
		this.comuna = comuna;
	}
	
	@Transient
	public boolean isSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	
	@Transient
	public boolean isAgregada() {
		return agregada;
	}
	public void setAgregada(boolean agregada) {
		this.agregada = agregada;
	}
	
	@Transient
	public String getUbicacion() {
		String ubicacion="";
		try{
			if(this.tipoUbicacion!=null){
				if(tipoUbicacion.contains(Constants.TIPO_UBICACION_DIRECCION)){
					ubicacion= this.region.getNombre()+"-"+this.comuna.getNombre()+"-"+this.getDomicilio();
				}else if(tipoUbicacion.contains(Constants.TIPO_UBICACION_DENTRO_DE_PARADERO)){
					ubicacion="Paradero "+this.getParadero().getNombre();
				}else if(tipoUbicacion.contains(Constants.TIPO_UBICACION_DENTRO_DE_TERMINAL)){
					ubicacion="Terminal "+this.getParadero().getNombre();
				}else if(tipoUbicacion.contains(Constants.TIPO_UBICACION_SOLO_WEB)){
					
				}
			}
			return ubicacion;
		}
		catch(Exception ex){
			return "";
		}
		
	}
	@Transient
	public String getNombreCortado() {
		nombreCortado = nombre;
		if(this.nombreCortado != null && this.nombreCortado.length() > 100){
				nombreCortado = nombreCortado.substring(0, 90)+"...";
		}
		return nombreCortado;
	}
	public void setNombreCortado(String nombreCortado) {
		this.nombreCortado = nombreCortado;
	}
	@Transient
	public String getDescripcionCortada() {
		descripcionCortada = descripcion;
		if(this.descripcionCortada != null && this.descripcionCortada.length() > 100){
			descripcionCortada = descripcionCortada.substring(0, 90)+"...";
		}
		return descripcionCortada;
	}
	public void setDescripcionCortada(String descripcionCortada) {
		this.descripcionCortada = descripcionCortada;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		OficinaVentaPasaje of = (OficinaVentaPasaje) obj;
		try {
			return of.getId().equals(this.getId());
		} catch (Exception e) {
			return false;
		}

	}
	
	@Transient
	public String getNombreRegion() {
	    if (this.getRegion()!=null) {
	        return this.getRegion().getNombre();
	    }
	    return "";
	}
	
	@Transient
    public String getNombreComuna() {
        if (this.getComuna()!=null) {
            return this.getComuna().getNombre();
        }
        return "";
    }
	


}
