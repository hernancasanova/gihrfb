package cl.mtt.rnt.commons.model.core;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;


@Entity
@Table(name = "RNT_SERVICIO_OFICINA_VENTA_PASAJE")
@Audited
public class OficinaVentaPasajeServicio extends GenericModelObject {

	private static final long serialVersionUID = 2551087448935639603L;
	
	private OficinaVentaPasaje oficina;
	private Servicio servicio;
	
	
	@ManyToOne(targetEntity = OficinaVentaPasaje.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_OFICINA", nullable = false)
	public OficinaVentaPasaje getOficina() {
		return oficina;
	}
	public void setOficina(OficinaVentaPasaje oficina) {
		this.oficina = oficina;
	}
	
	@ManyToOne(targetEntity = Servicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SERVICIO", nullable = false)
	public Servicio getServicio() {
		return servicio;
	}
	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}
	
	@Override
	public boolean equals(Object obj) {
		OficinaVentaPasajeServicio os = (OficinaVentaPasajeServicio) obj;
		try {
			if (os.getId()==null && this.getId()==null)
				return this.getOficina().equals(os.getOficina()) && this.getServicio().equals(os.getServicio());
			return os.getId().equals(this.getId());
		} catch (Exception e) {
			return false;
		}

	}
	
	
	
	
	

}
