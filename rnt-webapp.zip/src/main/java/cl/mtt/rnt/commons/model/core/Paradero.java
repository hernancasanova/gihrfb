package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.model.sgprt.Region;

import com.google.gson.annotations.Expose;

@Entity
@Table(name = "RNT_PARADERO")
@Inheritance(strategy = InheritanceType.JOINED)
@Audited
public class Paradero extends PointOfInterest implements Anonymizable {

	public static final String TIPO_PARADERO = "PARADERO";
	public static final String TIPO_TERMINAL = "TERMINAL";
	public static final String TIPO_UBICACION = "UBICACION";

	private static final long serialVersionUID = -5402224636931775050L;
	@Expose
	private String tipoParadero;
	@Expose
	private String nombre;
	@Expose
	private String codigoComuna;
	@Expose
	private Comuna comuna;
	private String descriptor;
	@Expose
	private String domicilio;
	@Expose
	private String numeroDomicilio;
	@Expose
	private Region region;
	private String idRegion;
	private Long idComunaOld;
	private UbicacionTerminal ubicacionTerminal;
	private Long idUbicacionTerminal;

	private Boolean esDireccion;
	
	@Column(name = "TIPO", nullable = false)
	public String getTipoParadero() {
		return tipoParadero;
	}

	public void setTipoParadero(String tipoParadero) {
		this.tipoParadero = tipoParadero;
		setMarkerName(tipoParadero);
	}

	@Column(name = "NOMBRE", nullable = true)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "DESCRIPTOR", nullable = true)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	@Column(name = "DOMICILIO", nullable = true)
	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	@Column(name = "NUMERO_DIRECCION", nullable = true)
	public String getNumeroDomicilio() {
		return numeroDomicilio;
	}

	public void setNumeroDomicilio(String numeroDomicilio) {
		this.numeroDomicilio = numeroDomicilio;
	}

	@Transient
	public Comuna getComuna() {
		return comuna;
	}

	public void setComuna(Comuna comuna) {
		this.comuna = comuna;
	}

	/**
	 * @return el valor de region
	 */
	@Transient
	public Region getRegion() {
		return region;
	}

	/**
	 * @param setea
	 *            el parametro region al campo region
	 */
	public void setRegion(Region region) {
		this.region = region;
	}

	/**
	 * @return el valor de idComunaOld
	 */
	@Column(name = "ID_COMUNA_OLD", nullable = true)
	public Long getIdComunaOld() {
		return idComunaOld;
	}

	/**
	 * @param setea
	 *            el parametro idComunaOld al campo idComunaOld
	 */
	public void setIdComunaOld(Long idComunaOld) {
		this.idComunaOld = idComunaOld;
	}

	@Transient
	public String getIdRegion() {
		return idRegion;
	}

	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@ManyToOne(targetEntity = UbicacionTerminal.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_UBICACION_TERMINAL", nullable = true)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public UbicacionTerminal getUbicacionTerminal() {
		return ubicacionTerminal;
	}

	public void setUbicacionTerminal(UbicacionTerminal ubicacionTerminal) {
		this.ubicacionTerminal = ubicacionTerminal;
	}

	/**
	 * @return el valor de idUbicacionTerminal
	 */
    @Column(name = "ID_UBICACION_TERMINAL", updatable=false, insertable=false)
	public Long getIdUbicacionTerminal() {
		return idUbicacionTerminal;
	}

	/**
	 * @param setea el parametro idUbicacionTerminal al campo idUbicacionTerminal
	 */
	public void setIdUbicacionTerminal(Long idUbicacionTerminal) {
		this.idUbicacionTerminal = idUbicacionTerminal;
	}

	@Transient
	public String getUbicacionParadero() {
		if (ubicacionTerminal == null)
			return "";
		return ubicacionTerminal.getNombre();

	}

	@Override
	public boolean equals(Object obj) {
		if (super.equals(obj))
			return true;
		Paradero p=(Paradero) obj;
		if(this.getId()==null)
			return this.getTipoParadero().equals(p.getTipoParadero()) 
				&&	this.getNombre().equals(p.getNombre())
				&&	this.getCodigoComuna().equals(p.getCodigoComuna())
				&& this.getDomicilio().equals(p.getDomicilio());
		return false;
	}
	
	/**
	 * Retorna calle y numero, en caso de ser null retorna ""
	 * @return
	 */
	@Transient
	public String getDomicilioCompleto() {
	    if (this.domicilio != null) {
	        if (this.numeroDomicilio != null) {
	            return this.domicilio + " " + this.numeroDomicilio;
	        }
	        return this.domicilio;
	    }
	    return "";
	}

	/**
	 * @return el valor de esDireccion
	 */
	@Column(name = "ES_DIRECCION", nullable = true)
	public Boolean getEsDireccion() {
		return esDireccion;
	}

	/**
	 * @param setea el parametro esDireccion al campo esDireccion
	 */
	public void setEsDireccion(Boolean esDireccion) {
		if(esDireccion == null){
			esDireccion = false;
		}
		this.esDireccion = esDireccion;
	}

}
