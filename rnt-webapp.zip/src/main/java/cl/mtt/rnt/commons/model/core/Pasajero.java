package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_PASAJERO")
@Audited
public class Pasajero extends GenericModelObject {
	
	private static final long serialVersionUID = -6060305973458760406L;
	
	private Persona persona;
	private Servicio servicio;
	private VehiculoServicio vehiculoServicio;
	private Integer estado;
	private Date fechaEstado;
	
	
	/**
	 * @return el valor de persona
	 */
	@ManyToOne(targetEntity = Persona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PERSONA")
	public Persona getPersona() {
		return persona;
	}
	/**
	 * @param setea el parametro persona al campo persona
	 */
	public void setPersona(Persona persona) {
		this.persona = persona;
	}
	/**
	 * @return el valor de servicio
	 */
	@ManyToOne(targetEntity = Servicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SERVICIO")
	public Servicio getServicio() {
		return servicio;
	}
	/**
	 * @param setea el parametro servicio al campo servicio
	 */
	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}
	/**
	 * @return el valor de vehiculoServicio
	 */
	@ManyToOne(targetEntity = VehiculoServicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_VEHICULO_SERVICIO")
	public VehiculoServicio getVehiculoServicio() {
		return vehiculoServicio;
	}
	/**
	 * @param setea el parametro vehiculoServicio al campo vehiculoServicio
	 */
	public void setVehiculoServicio(VehiculoServicio vehiculoServicio) {
		this.vehiculoServicio = vehiculoServicio;
	}
	/**
	 * @return el valor de estado
	 */
	@Column(name = "ESTADO")
	public Integer getEstado() {
		return estado;
	}
	/**
	 * @param setea el parametro estado al campo estado
	 */
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	/**
	 * @return el valor de fechaEstado
	 */
	@Column(name = "FECHA_ESTADO")
	public Date getFechaEstado() {
		return fechaEstado;
	}
	/**
	 * @param setea el parametro fechaEstado al campo fechaEstado
	 */
	public void setFechaEstado(Date fechaEstado) {
		this.fechaEstado = fechaEstado;
	}
	
	

}
