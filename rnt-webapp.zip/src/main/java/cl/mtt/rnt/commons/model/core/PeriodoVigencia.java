package cl.mtt.rnt.commons.model.core;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.impl.TiposVehiculoPermitidosOtrosServicios;
import cl.mtt.rnt.admin.reglamentacion.util.ItemPeriodoNormativa;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.util.Utils;

@Entity
@Table(name = "RNT_PERIODO_VIGENCIA")
@Audited
public class PeriodoVigencia extends GenericModelObject {
	
	private static final long serialVersionUID = 565027666812263750L;
	
	private String nombrePeriodo;
	private String tipoVigencia;
	private Date fechaDesde;
	private Date fechaHasta;
//	private Servicio servicio;
	private VehiculoServicio vehiculoServicio;
	
	
	/**
	 * @return el valor de nombrePeriodo
	 */
	@Column(name = "NOMBRE_PERIODO")
	public String getNombrePeriodo() {
		return nombrePeriodo;
	}
	/**
	 * @param setea el parametro nombrePeriodo al campo nombrePeriodo
	 */
	public void setNombrePeriodo(String nombrePeriodo) {
		this.nombrePeriodo = nombrePeriodo;
	}
	/**
	 * @return el valor de fechaDesde
	 */
	@Column(name = "FECHA_DESDE")
	public Date getFechaDesde() {
		return fechaDesde;
	}
	/**
	 * @param setea el parametro fechaDesde al campo fechaDesde
	 */
	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}
	/**
	 * @return el valor de fechaHasta
	 */
	@Column(name = "FECHA_HASTA")
	public Date getFechaHasta() {
		return fechaHasta;
	}
	/**
	 * @param setea el parametro fechaHasta al campo fechaHasta
	 */
	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}
	/**
	 * @return el valor de servicio
	 */
	@ManyToOne(targetEntity = VehiculoServicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_VEHICULO_SERVICIO")
	/**
	 * @return el valor de vehiculoServicio
	 */
	public VehiculoServicio getVehiculoServicio() {
		return vehiculoServicio;
	}
	/**
	 * @param setea el parametro vehiculoServicio al campo vehiculoServicio
	 */
	public void setVehiculoServicio(VehiculoServicio vehiculoServicio) {
		this.vehiculoServicio = vehiculoServicio;
	}
	
	/**
	 * @return el valor de tipoVigencia
	 */
	@Column(name = "TIPO_VIGENCIA")
	public String getTipoVigencia() {
		return tipoVigencia;
	}
	/**
	 * @param setea el parametro tipoVigencia al campo tipoVigencia
	 */
	public void setTipoVigencia(String tipoVigencia) {
		this.tipoVigencia = tipoVigencia;
	}
	
	/**
	 * 
	 * @return
	 */
	@Transient
	public String getDiasCorridos() {
		if(fechaHasta==null || fechaDesde==null){
			return "";
		}
		final long MILLSECS_PER_DAY = 24 * 60 * 60 * 1000; //Milisegundos al día 
		
		long diferencia = ( fechaHasta.getTime() - fechaDesde.getTime() )/MILLSECS_PER_DAY; 
		return String.valueOf(diferencia+1); 
		
//	    try {
//            TiposVehiculoPermitidosOtrosServicios tvpoto = (TiposVehiculoPermitidosOtrosServicios) NormativaAccess.getInstance().getNormativaAplicada(this.servicio.getReglamentacion(), Normativa.descriptorVehiculosPrestandoOtrosServicios);
//            return tvpoto.getCantidadDeDiasCorridos().toString();
//	    }
//        catch (EventEvalException e) {
//            return "";
//        }
	}
	
	@Override
	public PeriodoVigencia clone() {
		PeriodoVigencia pv = new PeriodoVigencia();
		pv.setCreation(this.getCreation());
		pv.setDbAction(this.getDbAction());
		if(this.getFechaDesde()!=null){
			pv.setFechaDesde(new Date(this.getFechaDesde().getTime()));
		}
		if(this.getFechaHasta()!=null){
			pv.setFechaHasta(new Date(this.getFechaHasta().getTime()));
		}
		pv.setId(this.getId());
		pv.setModified(this.getModified());
		pv.setNombrePeriodo(this.getNombrePeriodo());
		pv.setTipoVigencia(this.getTipoVigencia());
		pv.setUserCreation(this.getUserCreation());
		pv.setUserCreation(this.getUserCreation());
		pv.setUserModified(this.getUserModified());
		pv.setVehiculoServicio(this.getVehiculoServicio());return pv;
	}
	
}
