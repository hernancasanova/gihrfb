package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.util.NacionalidadManager;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.SexoManager;

@Entity
@Table(name = "RNT_PERSONA")
@Audited
public class Persona extends GenericModelObject {

	/**
	 * 
	 */

	public static final Integer TIPO_PERSONA_JURIDICA = 2;
	public static final Integer TIPO_PERSONA_NATURAL = 1;
	private static final String TIPO_PERSONA_NATURAL_DESC = "persona.tipo.natural";
	private static final String TIPO_PERSONA_JURIDICA_DESC = "persona.tipo.juridica";

	public static final String WEBSERVICE_SOURCE = "WS";
	public static final String DATABASE_SOURCE = "DB";
	public static final String MANUAL_SOURCE = "MA";

	private static final long serialVersionUID = -4609920604802179526L;

	private String nombre;
	private String rut;
	private Integer tipoPersona; // Jurídica o natural
	private String nombreFantasia;
	private String nombreComercial;
	private CategoriaPersonaJuridica categoriaPersonaJuridica;// (Sólo si es
																// persona
																// Jurídica)
	private String domicilio;
	private String codigoRegion;
	private String nombreRegion;
	private String codigoComuna;
	private String nombreComuna;
	private String telefono;
	private String fax;
	private String email;
	private String sexo;
	private String codigoLocalidad;
	private Date fechaNacimiento;
	private List<Inhabilidad> inhabilidades;
	private static List<TipoPersona> tipoOpts;
	private Long idOld;
	private String nacionalidad;
	private String source;

	// utilizada para determinar si es una nueva persona que debe ser guardada
	// en la DB
	private boolean requieredSave;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "rut", nullable = false)
	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	@Column(name = "TIPO_PERSONA", nullable = true)
	public Integer getTipoPersona() {
		return tipoPersona;
	}

	public void setTipoPersona(Integer tipoPersona) {
		this.tipoPersona = tipoPersona;
	}

	@Column(name = "NOMBRE_FANTASIA", nullable = true)
	public String getNombreFantasia() {
		return nombreFantasia;
	}

	public void setNombreFantasia(String nombreFantasia) {
		this.nombreFantasia = nombreFantasia;
	}

	@Column(name = "NOMBRE_COMERCIAL", nullable = true)
	public String getNombreComercial() {
		return nombreComercial;
	}

	public void setNombreComercial(String nombreComercial) {
		this.nombreComercial = nombreComercial;
	}

	@ManyToOne(targetEntity = CategoriaPersonaJuridica.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CATEGORIA_PERSONA")
	public CategoriaPersonaJuridica getCategoriaPersonaJuridica() {
		return categoriaPersonaJuridica;
	}

	public void setCategoriaPersonaJuridica(CategoriaPersonaJuridica categoriaPersonaJuridica) {
		this.categoriaPersonaJuridica = categoriaPersonaJuridica;
	}

	@Column(name = "DOMICILIO", nullable = true)
	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "TELEFONO", nullable = true)
	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Column(name = "FAX", nullable = true)
	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "EMAIL", nullable = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "SEXO", nullable = true, length = 1)
	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	@Column(name = "CODIGO_LOCALIDAD", nullable = true)
	public String getCodigoLocalidad() {
		return codigoLocalidad;
	}

	public void setCodigoLocalidad(String codigoLocalidad) {
		this.codigoLocalidad = codigoLocalidad;
	}

	@Transient
	public String getTipoPersonaDesc() {
		if (tipoPersona != null) {
			if (tipoPersona.equals(TIPO_PERSONA_NATURAL)) {
				return Resources.getString(TIPO_PERSONA_NATURAL_DESC);
			} else {
				return Resources.getString(TIPO_PERSONA_JURIDICA_DESC);
			}
		}
		return null;
	}

	@Transient
	public boolean isPersonaJuridica() {
		return TIPO_PERSONA_JURIDICA.equals(tipoPersona);
	}

	/**
	 * @return el valor de tipoOpts
	 */
	@Transient
	public List<TipoPersona> getTipoOpts() {
		if (tipoOpts == null) {
			tipoOpts = new ArrayList<TipoPersona>();
			tipoOpts.add(new TipoPersona(TIPO_PERSONA_NATURAL, Resources.getString(TIPO_PERSONA_NATURAL_DESC)));
			tipoOpts.add(new TipoPersona(TIPO_PERSONA_JURIDICA, Resources.getString(TIPO_PERSONA_JURIDICA_DESC)));
		}
		return tipoOpts;
	}

	@Transient
	public List<TipoPersona> getTipoNatOpt() {
		if (tipoOpts == null) {
			tipoOpts = new ArrayList<TipoPersona>();
			tipoOpts.add(new TipoPersona(TIPO_PERSONA_NATURAL, Resources.getString(TIPO_PERSONA_NATURAL_DESC)));
		}
		return tipoOpts;
	}

	/**
	 * @return el valor de codigoRegion
	 */
	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	/**
	 * @param setea
	 *            el parametro codigoRegion al campo codigoRegion
	 */
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	@Transient
	public List<Sexo> getSexoOpts() {
		return SexoManager.getSexos();
	}

	@Transient
	public String getSexoDesc() {
		if (this.sexo != null) {
			return SexoManager.getSexoDesc(this.sexo);
		}
		return null;
	}

	/**
	 * @return el valor de nombreRegion
	 */
	@Transient
	public String getNombreRegion() {
		return nombreRegion;
	}

	/**
	 * @param setea
	 *            el parametro nombreRegion al campo nombreRegion
	 */
	public void setNombreRegion(String nombreRegion) {
		this.nombreRegion = nombreRegion;
	}

	/**
	 * @return el valor de nombreComuna
	 */
	@Transient
	public String getNombreComuna() {
		return nombreComuna;
	}

	/**
	 * @param setea
	 *            el parametro nombreComuna al campo nombreComuna
	 */
	public void setNombreComuna(String nombreComuna) {
		this.nombreComuna = nombreComuna;
	}

	/**
	 * @return el valor de fechaNacimiento
	 */
	@Column(name = "FECHA_NACIMIENTO", nullable = true)
	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	/**
	 * @param setea
	 *            el parametro fechaNacimiento al campo fechaNacimiento
	 */
	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	@ManyToMany(targetEntity = Inhabilidad.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_PERSONA_INHABILIDAD", joinColumns = @JoinColumn(name = "ID_PERSONA"), inverseJoinColumns = @JoinColumn(name = "ID_INHABILIDAD"))
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public List<Inhabilidad> getInhabilidades() {
		return inhabilidades;
	}

	public void setInhabilidades(List<Inhabilidad> inhabilidades) {
		this.inhabilidades = inhabilidades;
	}

	@Transient
	public Integer getEdad() {
		if (this.getFechaNacimiento() == null)
			return null;
		int age = 0;
		int factor = 0;
		Calendar cal1 = new GregorianCalendar();
		Calendar cal2 = new GregorianCalendar();
		cal1.setTime(this.getFechaNacimiento());
		cal2.setTime(new Date());
		if (cal2.get(Calendar.DAY_OF_YEAR) < cal1.get(Calendar.DAY_OF_YEAR)) {
			factor = -1;
		}
		age = cal2.get(Calendar.YEAR) - cal1.get(Calendar.YEAR) + factor;
		return age;
	}

	/**
	 * @return el valor de personaNuevaEnServicio
	 */
	@Transient
	public boolean isPersonaNuevaEnServicio() {
		return this.getId() == null;
	}

	@Override
	public boolean equals(Object obj) {
		if (this.getId() != null && ((GenericModelObject) obj).getId() != null)
			return super.equals(obj);

		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;
		if (this.getRut() == null)
			return false;
		return this.getRut().equals(((Persona) obj).getRut());
	}

	@Override
	public Persona clone() throws CloneNotSupportedException {
		Persona p = new Persona();
		p.setCategoriaPersonaJuridica(this.getCategoriaPersonaJuridica());
		if (this.getCodigoComuna() != null)
			p.setCodigoComuna(new String(this.getCodigoComuna()));
		if (this.getCodigoLocalidad() != null)
			p.setCodigoLocalidad(new String(this.getCodigoLocalidad()));
		if (this.getCodigoRegion() != null)
			p.setCodigoRegion(new String(this.getCodigoRegion()));
		p.setCreation(this.getCreation());
		p.setDbAction(this.getDbAction());
		if (this.getDomicilio() != null)
			p.setDomicilio(new String(this.getDomicilio()));
		if (this.getEmail() != null)
			p.setEmail(new String(this.getEmail()));
		if (this.getFax() != null)
			p.setFax(new String(this.getFax()));
		p.setFechaNacimiento(this.getFechaNacimiento());
		if (this.getId() != null)
			p.setId(new Long(this.getId()));
		p.setId(this.getId());
		p.setModified(this.getModified());
		p.setNombre(new String(this.getNombre()));
		if (this.getNombreComercial() != null)
			p.setNombreComercial(new String(this.getNombreComercial()));
		if (this.getNombreComuna() != null)
			p.setNombreComuna(new String(this.getNombreComuna()));
		if (this.getNombreFantasia() != null)
			p.setNombreFantasia(new String(this.getNombreFantasia()));
		if (this.getNombreRegion() != null)
			p.setNombreRegion(new String(this.getNombreRegion()));
		if (this.getRut() != null)
			p.setRut(new String(this.getRut()));
		if (this.getSexo() != null)
			p.setSexo(new String(this.getSexo()));
		if (this.getTelefono() != null)
			p.setTelefono(new String(this.getTelefono()));
		if (this.getTipoPersona() != null)
			p.setTipoPersona(new Integer(this.getTipoPersona()));
		p.setUserCreation(this.getUserCreation());
		p.setUserModified(this.getUserModified());
		p.setNacionalidad(this.nacionalidad);
		return p;
	}

//	@Transient
//	public void updateTipoPersona() {
		// String rut = getRut().toUpperCase();
		// rut = rut.replace("K", "0");
		// if(Long.parseLong(rut.replaceAll("-", ""))<700000000l){
		// setTipoPersona(TIPO_PERSONA_NATURAL);
		// }else{
		// setTipoPersona(TIPO_PERSONA_JURIDICA);
		// }

		// se setea por defecto juridica y se elimina la logica anterior porque
		// no es correcta
//		setTipoPersona(TIPO_PERSONA_JURIDICA);
//	}

	/**
	 * @return el valor de idOld
	 */
	@Column(name = "ID_OLD", nullable = true)
	public Long getIdOld() {
		return idOld;
	}

	/**
	 * @param setea
	 *            el parametro idOld al campo idOld
	 */
	public void setIdOld(Long idOld) {
		this.idOld = idOld;
	}

	/**
	 * @return el valor de nacionalidad
	 */
	@Column(name = "NACIONALIDAD", nullable = true, length = 1, columnDefinition = "char")
	public String getNacionalidad() {
		return nacionalidad;
	}

	/**
	 * @param setea
	 *            el parametro nacionalidad al campo nacionalidad
	 */
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	/**
	 * @return el valor de source
	 */
	@Column(name = "SOURCE", nullable = true, length = 2)
	public String getSource() {
		return source;
	}

	/**
	 * @param setea
	 *            el parametro source al campo source
	 */
	public void setSource(String source) {
		this.source = source;
	}

	@Transient
	public List<Nacionalidad> getNacionalidadesOpts() {
		return NacionalidadManager.getNacionalidades();
	}

	@Transient
	public String getNacionalidadDesc() {
		if (this.nacionalidad != null) {
			return NacionalidadManager.getNacionalidadDesc(this.nacionalidad);
		}
		return null;
	}

	@Transient
	public boolean isRequieredSave() {
		return requieredSave;
	}

	/**
	 * @param setea
	 *            el parametro requieredSave al campo requieredSave
	 */
	public void setRequieredSave(boolean requieredSave) {
		this.requieredSave = requieredSave;
	}
}
