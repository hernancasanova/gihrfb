package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;

@MappedSuperclass
public class PointOfInterest extends GenericModelObject {

	private static final long serialVersionUID = 6223888099413513238L;
	@Expose
	protected String geographicPosition;
	@Expose
	protected String markerName;

	@Column(name = "GEOGRAPHIC_POSITION")
	public String getGeographicPosition() {
		return geographicPosition;
	}

	public void setGeographicPosition(String geographicPosition) {
		this.geographicPosition = geographicPosition;
	}

	@Transient
	public String getAsJSon() {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
		return gson.toJson(this);
	}

	@Transient
	public String getMarkerName(){
		return markerName;
	}

	public void setMarkerName(String markerName) {
		this.markerName = markerName;
	}
	
}
