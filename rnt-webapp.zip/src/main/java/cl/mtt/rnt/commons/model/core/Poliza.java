package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.util.Utils;

@Entity
@Table(name = "RNT_POLIZA")
@Audited
public class Poliza extends GenericModelObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String numero;
	private Date fechaDesde;
	private Date fechaHasta;
	private String entidadAseguradora;
	private ConductorServicio conductorServicio;  
	
	/**
	 * @return el valor de numero
	 */
	@Column(name = "NUMERO")
	public String getNumero() {
		return numero;
	}
	/**
	 * @param setea el parametro numero al campo numero
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}
	/**
	 * @return el valor de fechaDesde
	 */
	@Column(name = "FECHA_DESDE")
	public Date getFechaDesde() {
		return fechaDesde;
	}
	/**
	 * @param setea el parametro fechaDesde al campo fechaDesde
	 */
	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}
	/**
	 * @return el valor de fechaHasta
	 */
	@Column(name = "FECHA_HASTA")
	public Date getFechaHasta() {
		return fechaHasta;
	}
	/**
	 * @param setea el parametro fechaHasta al campo fechaHasta
	 */
	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}
	/**
	 * @return el valor de entidadAseguradora
	 */
	@Column(name = "ENTIDAD_ASEGURADORA")
	public String getEntidadAseguradora() {
		return entidadAseguradora;
	}
	/**
	 * @param setea el parametro entidadAseguradora al campo entidadAseguradora
	 */
	public void setEntidadAseguradora(String entidadAseguradora) {
		this.entidadAseguradora = entidadAseguradora;
	}
	
	@Transient
	public boolean isVencida(){
		return (new Date()).after(fechaHasta);
	}
	/**
	 * @return el valor de conductorServicio
	 */
	@ManyToOne(targetEntity = ConductorServicio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CONDUCTOR_SERVICIO")
	public ConductorServicio getConductorServicio() {
		return conductorServicio;
	}
	/**
	 * @param setea el parametro conductorServicio al campo conductorServicio
	 */
	public void setConductorServicio(ConductorServicio conductorServicio) {
		this.conductorServicio = conductorServicio;
	}
	
	@Transient
	public String getEstado(){
		if(fechaHasta.before(new Date())){
			return "Vencido";
		}
		return "Vigente";
	}

}
