package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import cl.mtt.rnt.commons.model.sgprt.Region;

@Entity
@Table(name = "RNT_PPU_ANULADA")
public class PpuAnulada extends GenericModelObject implements Comparable<PpuAnulada> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3210439259224108019L;
	
	private Date fechaIngresoRnt;
	private Date fechaIngresoServicio;
	private Date fechaCancelacion;
	private Long idServicio;
	private Long identServicio;
	private String codregion;
	private Integer estado;
	private String observacion;
	private String ppu;
	
	private boolean visible=true;
	private Region region;
	

	@Column(name ="PPU")
	public String getPpu() {
		return ppu;
	}

	public void setPpu(String ppu) {
		this.ppu = ppu;
	}

	@Column(name ="FECHA_INGRESO_RNT")
	public Date getFechaIngresoRnt() {
		return fechaIngresoRnt;
	}
	
	public void setFechaIngresoRnt(Date fechaIngresoRnt) {
		this.fechaIngresoRnt = fechaIngresoRnt;
	}
	
	@Column(name ="FECHA_INGRESO_SERVICIO")
	public Date getFechaIngresoServicio() {
		return fechaIngresoServicio;
	}
	
	public void setFechaIngresoServicio(Date fechaIngresoServicio) {
		this.fechaIngresoServicio = fechaIngresoServicio;
	}
	
	@Column(name ="FECHA_CANCELACION")
	public Date getFechaCancelacion() {
		return fechaCancelacion;
	}
	
	public void setFechaCancelacion(Date fechaCancelacion) {
		this.fechaCancelacion = fechaCancelacion;
	}
	
	@Column(name ="ID_SERVICIO")
	public Long getIdServicio() {
		return idServicio;
	}
	
	public void setIdServicio(Long idServicio) {
		this.idServicio = idServicio;
	}
	
	@Column(name ="COD_REGION")
	public String getCodregion() {
		return codregion;
	}
	
	public void setCodregion(String codregion) {
		this.codregion = codregion;
	}
	
	@Column(name ="ESTADO_SERVICIO")
	public Integer getEstado() {
		return estado;
	}
	
	public void setEstado(Integer estado) {
		this.estado = estado;
	}

	@Column(name ="IDENT_SERVICIO")
	public Long getIdentServicio() {
		return identServicio;
	}

	public void setIdentServicio(Long identServicio) {
		this.identServicio = identServicio;
	}
	
	@Column(name ="OBSERVACION")
	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	@Transient
	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		if(region == null)
			region = new Region();
		this.region = region;
	}
	
	@Transient
	public String getObservacionTransient() {
		if(this.observacion != null){
			if(observacion.length() > 10){
				return observacion.substring(0, 9)+"...";
			}
		}
		return observacion;
	}

	@Transient
	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	@Override
	public int compareTo(PpuAnulada o) {
		 return o.getCreation().compareTo(this.getCreation()); 
	} 
	

}
