package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.util.validator.PPUValidator;

@Entity
@Table(name = "RNT_PROPIETARIO")
@Audited
public class Propietario extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5493060150107877948L;
	private Persona persona;
	private Adquisicion adquisicion;
	String ppu;
	@Transient
	String digitoVerificador;

	private String descripcionTipoVehiculo;
	private String descripcionMeroTenedor;
	private String nombreComuna;

	private boolean esNuevaPersona;

	@ManyToOne(targetEntity = Persona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PERSONA")
	@BatchSize (size = 20)
	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	/**
	 * @return el valor de adquisicion
	 */
	@ManyToOne(targetEntity = Adquisicion.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_ADQUISICION")
	public Adquisicion getAdquisicion() {
		return adquisicion;
	}

	/**
	 * @param setea
	 *            el parametro adquisicion al campo adquisicion
	 */
	public void setAdquisicion(Adquisicion adquisicion) {
		this.adquisicion = adquisicion;
	}

	/**
	 * @return el valor de ppu
	 */
	@Column(name = "PPU", nullable = false)
	public String getPpu() {
		return ppu;
	}

	/**
	 * @param setea
	 *            el parametro ppu al campo ppu
	 */
	public void setPpu(String ppu) {
		this.ppu = ppu;
	}

	@Transient
	/**
	 * @return el valor de descripcionTipoVehiculo
	 */
	public String getDescripcionTipoVehiculo() {
		return descripcionTipoVehiculo;
	}

	/**
	 * @param setea
	 *            el parametro descripcionTipoVehiculo al campo
	 *            descripcionTipoVehiculo
	 */
	public void setDescripcionTipoVehiculo(String descripcionTipoVehiculo) {
		this.descripcionTipoVehiculo = descripcionTipoVehiculo;
	}

	/**
	 * @return el valor de descripcionMeroTenedor
	 */

	@Transient
	public String getDescripcionMeroTenedor() {
		return descripcionMeroTenedor;
	}

	/**
	 * @param setea
	 *            el parametro descripcionMeroTenedor al campo
	 *            descripcionMeroTenedor
	 */
	public void setDescripcionMeroTenedor(String descripcionMeroTenedor) {
		this.descripcionMeroTenedor = descripcionMeroTenedor;
	}

	@Transient
	public String getDescripcionCortaMeroTenedor() {
		if (this.descripcionMeroTenedor != null && this.descripcionMeroTenedor.length() > 30)
			return this.descripcionMeroTenedor.substring(0, 30) + "...";
		return this.descripcionMeroTenedor;
	}

	@Column(name = "NOMBRE_COMUNA", nullable = true)
	public String getNombreComuna() {
		return nombreComuna;
	}

	public void setNombreComuna(String nombreComuna) {
		this.nombreComuna = nombreComuna;
	}

	@Transient
	/**
	 * @return el valor de esNuevaPersona
	 */
	public boolean isEsNuevaPersona() {
		return esNuevaPersona;
	}

	/**
	 * @param setea
	 *            el parametro esNuevaPersona al campo esNuevaPersona
	 */
	public void setEsNuevaPersona(boolean esNuevaPersona) {
		this.esNuevaPersona = esNuevaPersona;
	}
	@Transient
	public String getPpuCompleta(){
		if(digitoVerificador==null || "".equals(digitoVerificador))
			digitoVerificador = PPUValidator.getDigitoVerificador(ppu);
		return ppu+"-"+digitoVerificador;
	}
}
