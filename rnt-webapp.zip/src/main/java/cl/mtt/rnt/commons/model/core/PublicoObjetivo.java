package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_PUBLICO_OBJETIVO")
public class PublicoObjetivo extends GenericModelObject {

	private String etiqueta;
	private String descriptor;

	@Column(name = "ETIQUETA", nullable = false)
	public String getEtiqueta() {
		return etiqueta;
	}

	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

}
