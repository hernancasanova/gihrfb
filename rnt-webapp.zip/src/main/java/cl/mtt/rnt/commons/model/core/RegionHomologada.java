package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_REGION_HOMOLOGADA")
public class RegionHomologada extends GenericModelObject {

	private String codigo;
	private String nomberGoogleMaps;

	@Column(name = "CODIGO", nullable = false)
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@Column(name = "NOMBRE_GOOGLE_MAPS", nullable = false)
	public String getNomberGoogleMaps() {
		return nomberGoogleMaps;
	}

	public void setNomberGoogleMaps(String nomberGoogleMaps) {
		this.nomberGoogleMaps = nomberGoogleMaps;
	}

}
