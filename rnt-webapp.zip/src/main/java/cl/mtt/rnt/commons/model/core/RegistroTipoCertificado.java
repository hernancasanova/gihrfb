package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_REGISTRO_TIPO_CERTIFICADO")
public class RegistroTipoCertificado extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1704718276348391045L;

	private String tipoDocumento;
	private String materia;
	private String docxsd;
	private String docxml;
	private String movimiento;
	private String objeto;
	private TipoCertificado tipoCertificado;

	private List<ItemTipoCertificado> items;

	/**
	 * @return el valor de tipoDocumento
	 */
	@Column(name = "TIPO_DOCUMENTO")
	public String getTipoDocumento() {
		return tipoDocumento;
	}

	/**
	 * @param setea
	 *            el parametro tipoDocumento al campo tipoDocumento
	 */
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	/**
	 * @return el valor de materia
	 */
	@Column(name = "MATERIA")
	public String getMateria() {
		return materia;
	}

	/**
	 * @param setea
	 *            el parametro materia al campo materia
	 */
	public void setMateria(String materia) {
		this.materia = materia;
	}

	/**
	 * @return el valor de docxsd
	 */
	@Column(name = "DOC_XSD")
	public String getDocxsd() {
		return docxsd;
	}

	/**
	 * @param setea
	 *            el parametro docxsd al campo docxsd
	 */
	public void setDocxsd(String docxsd) {
		this.docxsd = docxsd;
	}

	/**
	 * @return el valor de docxml
	 */
	@Column(name = "DOC_XML")
	public String getDocxml() {
		return docxml;
	}

	/**
	 * @param setea
	 *            el parametro docxml al campo docxml
	 */
	public void setDocxml(String docxml) {
		this.docxml = docxml;
	}

	/**
	 * @return el valor de movimiento
	 */
	@Column(name = "MOVIMIENTO")
	public String getMovimiento() {
		return movimiento;
	}

	/**
	 * @param setea
	 *            el parametro movimiento al campo movimiento
	 */
	public void setMovimiento(String movimiento) {
		this.movimiento = movimiento;
	}

	/**
	 * @return el valor de objeto
	 */
	@Column(name = "OBJETO")
	public String getObjeto() {
		return objeto;
	}

	/**
	 * @param setea
	 *            el parametro objeto al campo objeto
	 */
	public void setObjeto(String objeto) {
		this.objeto = objeto;
	}

	/**
	 * @return el valor de tipoCertificado
	 */
	@ManyToOne(targetEntity = TipoCertificado.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_CERTIFICADO")
	public TipoCertificado getTipoCertificado() {
		return tipoCertificado;
	}

	/**
	 * @param setea
	 *            el parametro tipoCertificado al campo tipoCertificado
	 */
	public void setTipoCertificado(TipoCertificado tipoCertificado) {
		this.tipoCertificado = tipoCertificado;
	}

	/**
	 * @return el valor de items
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = ItemTipoCertificado.class, mappedBy = "registroTipoCertificado")
	public List<ItemTipoCertificado> getItems() {
		return items;
	}

	/**
	 * @param setea
	 *            el parametro items al campo items
	 */
	public void setItems(List<ItemTipoCertificado> items) {
		this.items = items;
	}

}
