package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.impl.ReemplazosMarcoGeografico;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;

@Entity
@Table(name = "RNT_REGLAMENTACION")
@Audited
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class Reglamentacion extends GenericModelObject implements Comparable<Reglamentacion> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4729150221976223898L;
	public static final String DESTINO_ALL = "all";
	public static final String DESTINO_SERVICIO = "destserv";
	public static final String DESTINO_VEHICULO = "destvehiculo";
	public static final String APLICACION_TODOS_VEHICULOS = "aplicaAVehiculo.todos";
	public static final String APLICACION_ALGUNOS_VEHICULOS = "aplicaAVehiculo.algunos";
	
	private TipoReglamentacion tipoReglamentacion;
	private String nombre;

//	private String linkDocumento;
//	private TipoDocumento tipoDocumento;
//	private String materia;
//	private String nombreDocumento;
	private DocumentoBiblioteca documentoBiblioteca;

	// private String aplicaA;
	private MarcoGeografico marcoGeografico;
	// private Boolean zonaPrecedeComuna;
	// private List<Integer> regiones;
	// private List<Integer> comunas;
	// private List<Zona> zonas;
	private List<TipoServicio> tiposServicio;
	private Date vigenciaDesde;
	private Date vigenciaHasta;
	private String aplicaVehiculos;
	private String estado;
	private Boolean especificadaSobreExistente;
	// private String dependeTipoReglamentacion;
	// private String dependeNombreReglamentacion;
	private Reglamentacion reglamentacionDeQueDepende;
	private List<Reglamentacion> reglamentacionesSubordinadas;
	private List<Normativa> normativas;

	private String motivoCambio;
	private Boolean visibleEncargado;
	private Boolean seleccionableServicio;
	private Boolean seleccionableVehiculo;
	
	private Long idReglamentacionSuperior;
	
	private String descripcion;

	private boolean normativasInicializadas=false;

	private GlosaReglamentacion glosaVehiculo;
	private GlosaReglamentacion glosaCertificado;
	boolean verFechaOtorgamiento;
	boolean verFechaPostulacion;
	
	public Reglamentacion() {
		super();
		glosaVehiculo = new GlosaReglamentacion();
		glosaCertificado = new GlosaReglamentacion();
		reglamentacionesSubordinadas = new ArrayList<Reglamentacion>();
	}

	@ManyToOne(targetEntity = TipoReglamentacion.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_REGLAMENTACION")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoReglamentacion getTipoReglamentacion() {
		return tipoReglamentacion;
	}

	public void setTipoReglamentacion(TipoReglamentacion tipoReglamentacion) {
		this.tipoReglamentacion = tipoReglamentacion;
	}

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

//	@Column(name = "LINK_DOCUMENTO", nullable = true)
//	public String getLinkDocumento() {
//		return linkDocumento;
//	}
//
//	public void setLinkDocumento(String linkDocumento) {
//		this.linkDocumento = linkDocumento;
//	}
//
//	@ManyToOne(targetEntity = TipoDocumento.class, fetch = FetchType.EAGER)
//	@JoinColumn(name = "ID_TIPO_DOCUMENTO")
//	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
//	public TipoDocumento getTipoDocumento() {
//		return tipoDocumento;
//	}
//
//	public void setTipoDocumento(TipoDocumento tipoDocumento) {
//		this.tipoDocumento = tipoDocumento;
//	}

//	@Column(name = "MATERIA", nullable = true)
//	public String getMateria() {
//		return materia;
//	}
//
//	public void setMateria(String materia) {
//		this.materia = materia;
//	}
//
//	@Column(name = "NOMBRE_DOCUMENTO", nullable = true)
//	public String getNombreDocumento() {
//		return nombreDocumento;
//	}
//
//	public void setNombreDocumento(String nombreDocumento) {
//		this.nombreDocumento = nombreDocumento;
//	}

	// @Column(name="APLICA_A", nullable=true)
	// public String getAplicaA() {
	// return aplicaA;
	// }
	// public void setAplicaA(String aplicaA) {
	// this.aplicaA = aplicaA;
	// }

	// @Column(name="ZONA_PRECEDE_COMUNA", nullable=true)
	// public Boolean getZonaPrecedeComuna() {
	// return zonaPrecedeComuna;
	// }
	// public void setZonaPrecedeComuna(Boolean zonaPrecedeComuna) {
	// this.zonaPrecedeComuna = zonaPrecedeComuna;
	// }

	// @ElementCollection
	// @CollectionTable(name="RNT_REGION_REGLAMENTACION",
	// joinColumns=@JoinColumn(name="ID_REGLAMENTACION"))
	// @Column(name="CODIGO_REGION")
	// public List<Integer> getRegiones() {
	// return regiones;
	// }
	// public void setRegiones(List<Integer> regiones) {
	// this.regiones = regiones;
	// }
	//
	// @ElementCollection
	// @CollectionTable(name="RNT_COMUNA_REGLAMENTACION",
	// joinColumns=@JoinColumn(name="ID_REGLAMENTACION"))
	// @Column(name="CODIGO_COMUNA")
	// public List<Integer> getComunas() {
	// return comunas;
	// }
	// public void setComunas(List<Integer> comunas) {
	// this.comunas = comunas;
	// }
	//
	// @ManyToOne(targetEntity=Trazado.class,fetch=FetchType.LAZY)
	// @JoinColumn(name="ID_ZONA")
	// public List<Zona> getZonas() {
	// return zonas;
	// }
	// public void setZonas(List<Zona> zonas) {
	// this.zonas = zonas;
	// }

	@ManyToMany(targetEntity = TipoServicio.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_REGLAMENTACION_TIPO_SERVICIO", joinColumns = @JoinColumn(name = "REGLAMENTACION_ID"), inverseJoinColumns = @JoinColumn(name = "TIPO_SERVICIO_ID"))
	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	@Column(name = "VIGENCIA_DESDE", nullable = true)
	public Date getVigenciaDesde() {
		return vigenciaDesde;
	}

	public void setVigenciaDesde(Date vigenciaDesde) {
		this.vigenciaDesde = vigenciaDesde;
	}

	@Column(name = "VIGENCIA_HASTA", nullable = true)
	public Date getVigenciaHasta() {
		return vigenciaHasta;
	}

	public void setVigenciaHasta(Date vigenciaHasta) {
		this.vigenciaHasta = vigenciaHasta;
	}

	@Column(name = "APLICA_VEHICULOS", nullable = true)
	public String getAplicaVehiculos() {
		return aplicaVehiculos;
	}

	public void setAplicaVehiculos(String aplicaVehiculos) {
		this.aplicaVehiculos = aplicaVehiculos;
	}

	@Column(name = "ESTADO", nullable = true)
	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Column(name = "ESPECIFICADO_SOBRE_EXISTENTE", nullable = true)
	public Boolean getEspecificadaSobreExistente() {
		return especificadaSobreExistente;
	}

	public void setEspecificadaSobreExistente(Boolean especificadaSobreExistente) {
		this.especificadaSobreExistente = especificadaSobreExistente;
	}

	// @Column(name="DEPENDE_TIPO_REGLAMENTE", nullable=true)
	// public String getDependeTipoReglamentacion() {
	// return dependeTipoReglamentacion;
	// }
	// public void setDependeTipoReglamentacion(String
	// dependeTipoReglamentacion) {
	// this.dependeTipoReglamentacion = dependeTipoReglamentacion;
	// }
	//
	// @Column(name="DEPENDE_NOMBRE_REGLAMENTE", nullable=true)
	// public String getDependeNombreReglamentacion() {
	// return dependeNombreReglamentacion;
	// }
	// public void setDependeNombreReglamentacion(String
	// dependeNombreReglamentacion) {
	// this.dependeNombreReglamentacion = dependeNombreReglamentacion;
	// }

	@ManyToOne(targetEntity = Reglamentacion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_REGLAMENTACION_DE_QUE_DEPENDE")
	public Reglamentacion getReglamentacionDeQueDepende() {
		return reglamentacionDeQueDepende;
	}

	public void setReglamentacionDeQueDepende(Reglamentacion reglamentacionDeQueDepende) {
		this.reglamentacionDeQueDepende = reglamentacionDeQueDepende;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Normativa.class, mappedBy = "reglamentacion")
	public List<Normativa> getNormativas() {
		return normativas;
	}

	public void setNormativas(List<Normativa> normativas) {
		this.normativas = normativas;
	}

	@ManyToOne(targetEntity = MarcoGeografico.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_MARCO_GEOGRAFICO", unique = true)
	public MarcoGeografico getMarcoGeografico() {
		return marcoGeografico;
	}

	public void setMarcoGeografico(MarcoGeografico marcoGeografico) {
		this.marcoGeografico = marcoGeografico;
	}

	@Column(name = "MOTIVO_CAMBIO", nullable = true, length = 1000)
	public String getMotivoCambio() {
		return motivoCambio;
	}

	public void setMotivoCambio(String motivoCambio) {
		this.motivoCambio = motivoCambio;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Reglamentacion.class, mappedBy = "reglamentacionDeQueDepende")
	public List<Reglamentacion> getReglamentacionesSubordinadas() {
		return reglamentacionesSubordinadas;
	}

	public void setReglamentacionesSubordinadas(List<Reglamentacion> reglamentacionesSubordinadas) {
		this.reglamentacionesSubordinadas = reglamentacionesSubordinadas;
	}

	/**
	 * @return el valor de visibleEncargado
	 */
	@Column(name = "VISIBLE_ENCARGADO", nullable = true)
	public Boolean getVisibleEncargado() {
		return visibleEncargado;
	}

	/**
	 * @param setea
	 *            el parametro visibleEncargado al campo visibleEncargado
	 */
	public void setVisibleEncargado(Boolean visibleEncargado) {
		this.visibleEncargado = visibleEncargado;
	}

	/**
	 * @return el valor de seleccionableServicio
	 */
	@Column(name = "SELECCIONABLE_SERVICIO", nullable = true)
	public Boolean getSeleccionableServicio() {
		return seleccionableServicio;
	}

	/**
	 * @param setea el parametro seleccionableServicio al campo seleccionableServicio
	 */
	public void setSeleccionableServicio(Boolean seleccionableServicio) {
		this.seleccionableServicio = seleccionableServicio;
	}

	/**
	 * @return el valor de seleccionableVehiculo
	 */
	@Column(name = "SELECCIONABLE_VEHICULO", nullable = true)
	public Boolean getSeleccionableVehiculo() {
		return seleccionableVehiculo;
	}

	/**
	 * @param setea el parametro seleccionableVehiculo al campo seleccionableVehiculo
	 */
	public void setSeleccionableVehiculo(Boolean seleccionableVehiculo) {
		this.seleccionableVehiculo = seleccionableVehiculo;
	}
	
	@Column(name = "DESCRIPCION")
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public int compareTo(Reglamentacion o) {
		int c = 0;
		if (this.getDocumentoBiblioteca()!=null && o.getDocumentoBiblioteca()!=null && this.getDocumentoBiblioteca().getTipoDocumento()!=null && o.getDocumentoBiblioteca().getTipoDocumento()!=null){
			c = this.getDocumentoBiblioteca().getTipoDocumento().getNombre().compareTo(o.getDocumentoBiblioteca().getTipoDocumento().getNombre());
		}
		if( c==0 ){
			return this.getNombre().compareTo(o.getNombre());
		}
		return c;
	}

	@Transient
	public boolean isVigente() {
		boolean vigente = true;
		if (vigenciaHasta != null) {
			if (ValidacionHelper.esFechaMayor(new Date(),vigenciaHasta)) {
				vigente = false;
			}
		}
		if (ValidacionHelper.esFechaMayor(vigenciaDesde,new Date())) {
			vigente = false;
		}
		return vigente;
		
	}
	
	@ManyToOne(targetEntity = DocumentoBiblioteca.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_DOCUMENTO_BIBLIOTECA")
	public DocumentoBiblioteca getDocumentoBiblioteca() {
		return documentoBiblioteca;
	}

	public void setDocumentoBiblioteca(DocumentoBiblioteca documentoBiblioteca) {
		this.documentoBiblioteca = documentoBiblioteca;
	}

	/**
	 * @return el valor de normativasInicializadas
	 */
	@Transient
	public boolean isNormativasInicializadas() {
		return normativasInicializadas;
	}

	/**
	 * @param setea el parametro normativasInicializadas al campo normativasInicializadas
	 */
	public void setNormativasInicializadas(boolean normativasInicializadas) {
		this.normativasInicializadas = normativasInicializadas;
	}

    /**
     * @return el valor de idReglamentacionSuperior
     */
	@Column(name = "ID_REGLAMENTACION_DE_QUE_DEPENDE", updatable=false, insertable=false)
    public Long getIdReglamentacionSuperior() {
        return idReglamentacionSuperior;
    }

    /**
     * @param setea el parametro idReglamentacionSuperior al campo idReglamentacionSuperior
     */
    public void setIdReglamentacionSuperior(Long idReglamentacionSuperior) {
        this.idReglamentacionSuperior = idReglamentacionSuperior;
    }

    @Transient
    public List<Region> getRegionesAplicablesReemplazo(VehiculoServicio vs) {
        List<Region> regiones = new ArrayList<Region>();
        try {
            ReemplazosMarcoGeografico nt = (ReemplazosMarcoGeografico) NormativaAccess.getInstance().getNormativaAplicada(this, "reemplazos_marco_geografico");
            if (nt == null) {
                return null;
            }
            else {
                if (nt.isNinguna()) {
                    regiones.add(vs.getServicio().getRegion());
                }
                else {
                    return null;
                }
            }
            return regiones;
        } catch (EventEvalException e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(), e);
        }
        return null;
    }

	/**
	 * @return el valor de glosaReglamentacion
	 */
	@ManyToOne(targetEntity = GlosaReglamentacion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_GLOSA_VEHICULO")
	public GlosaReglamentacion getGlosaVehiculo() {
		return glosaVehiculo;
	}

	/**
	 * @param setea el parametro glosaReglamentacion al campo glosaReglamentacion
	 */
	public void setGlosaVehiculo(GlosaReglamentacion glosaVehiculo) {
		this.glosaVehiculo= glosaVehiculo;
	}

	/**
	 * @return el valor de glosaReglamentacion
	 */
	@ManyToOne(targetEntity = GlosaReglamentacion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_GLOSA_CERTIFICADO")
	public GlosaReglamentacion getGlosaCertificado() {
		return glosaCertificado;
	}

	/**
	 * @param setea el parametro glosaReglamentacion al campo glosaReglamentacion
	 */
	public void setGlosaCertificado(GlosaReglamentacion glosaCertificado) {
		this.glosaCertificado= glosaCertificado;
	}

	@Transient
	public void clearGlosasNormativa() {
		verFechaOtorgamiento=false;
		verFechaPostulacion=false;
		
		if(getGlosaVehiculo()!=null){
			getGlosaVehiculo().getExtraItems().clear();
		}
		if(getGlosaCertificado()!=null){
			getGlosaCertificado().getExtraItems().clear();
		}
	}

	@Transient
	public boolean isVerFechaOtorgamiento(){
		return verFechaOtorgamiento;
	}
	@Transient
	public boolean isVerFechaPostulacion(){
		return verFechaPostulacion;
	}

	/**
	 * @param setea el parametro verFechaOtorgamiento al campo verFechaOtorgamiento
	 */
	public void setVerFechaOtorgamiento(boolean verFechaOtorgamiento) {
		this.verFechaOtorgamiento = verFechaOtorgamiento;
	}

	/**
	 * @param setea el parametro verFechaPostulacion al campo verFechaPostulacion
	 */
	public void setVerFechaPostulacion(boolean verFechaPostulacion) {
		this.verFechaPostulacion = verFechaPostulacion;
	}


	
//	@Transient
//	public String getGlosaVehiculoAsHtml(){
//		for (Normativa normativa : normativas) {
//			if(normativa)
//		}
//	}
}
