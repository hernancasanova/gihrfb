package cl.mtt.rnt.commons.model.core;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.encargado.dto.ServicioDTO;

@Entity
@Table(name = "RNT_REPRESENTATE_LEGAL")
@Audited
public class RepresentanteLegal extends GenericModelObject implements Anonymizable {

	private static final long serialVersionUID = 192596827084165593L;
	private String domicilio;
	private String codigoRegion;
	private String codigoComuna;
	private String telefono;
	private String fax;
	private String email;
	private Boolean autorizadoTramites;
	private String nombreComuna;
	private String nombreRegion;
	private TipoRepresentanteLegal tipoRepresentanteLegal;
	// Mejoras 201409 Nro: 44
	private Boolean requeridoFormaActuan;
	// Mejoras 201409 Nro: 44
	
	private Persona persona;
	private List<Mandatario> mandatarios;

	List<ServicioDTO> serviciosDTO;

	@Column(name = "DOMICILIO", nullable = true)
	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "TELEFONO", nullable = true)
	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Column(name = "FAX", nullable = true)
	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "EMAIL", nullable = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "AUTORIZADO_TRAMITES", nullable = true)
	public Boolean getAutorizadoTramites() {
		return autorizadoTramites;
	}

	public void setAutorizadoTramites(Boolean autorizadoTramites) {
		this.autorizadoTramites = autorizadoTramites;
	}

	@ManyToOne(targetEntity = Persona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PERSONA")
	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	// @ManyToOne(targetEntity=Mandatario.class,fetch=FetchType.EAGER)
	// @JoinColumn(name="ID_MANDATARIO")
	// public Mandatario getMandatario() {
	// return mandatario;
	// }
	// public void setMandatario(Mandatario mandatario) {
	// this.mandatario = mandatario;
	// }

	@ManyToOne(targetEntity = TipoRepresentanteLegal.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_REPRESENTANTE_LEGAL")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoRepresentanteLegal getTipoRepresentanteLegal() {
		return tipoRepresentanteLegal;
	}

	public void setTipoRepresentanteLegal(TipoRepresentanteLegal tipoRepresentanteLegal) {
		this.tipoRepresentanteLegal = tipoRepresentanteLegal;
	}

	@ManyToMany(targetEntity = Mandatario.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_REPRESENTANTE_LEGAL_MANDATARIO", joinColumns = @JoinColumn(name = "ID_REPRESENTANTE_LEGAL"), inverseJoinColumns = @JoinColumn(name = "ID_MANDATARIO"))
	public List<Mandatario> getMandatarios() {
		return mandatarios;
	}

	public void setMandatarios(List<Mandatario> mandatarios) {
		this.mandatarios = mandatarios;
	}

	@Transient
	public String getMandatarioText() {
		String ret = "";
		if (this.getMandatarios() != null && !this.getMandatarios().isEmpty()) {
			for (Mandatario mandatario : getMandatarios()) {
				if (mandatario != null && mandatario.getPersona() != null)
					ret += "(" + mandatario.getPersona().getRut() + ") " + mandatario.getPersona().getNombre() + "   ";
			}
		}
		return ret;
	}

	@Transient
	public List<ServicioDTO> getServiciosDTO() {
		return serviciosDTO;
	}

	/**
	 * @param setea
	 *            el parametro serviciosDTO al campo serviciosDTO
	 */
	public void setServiciosDTO(List<ServicioDTO> serviciosDTO) {
		this.serviciosDTO = serviciosDTO;
	}

	@Transient
	public String getServiciosDesc() {
		String texto = "";
		if ((serviciosDTO != null) && (serviciosDTO.size() > 1)) {
			for (ServicioDTO serv : serviciosDTO) {
				texto = "" + serv.getId() + "(" + serv.getTipoTransporte() + " " + serv.getMedioTransporte() + "... ";
			}
		}
		if ((serviciosDTO != null) && (serviciosDTO.size() == 1)) {
			for (ServicioDTO serv : serviciosDTO) {
				texto = serv.getDescripcion();
			}
		}

		return texto;
	}

	/**
	 * @return el valor de nombreComuna
	 */
	@Transient
	public String getNombreComuna() {
		return nombreComuna;
	}

	/**
	 * @param setea
	 *            el parametro nombreComuna al campo nombreComuna
	 */
	public void setNombreComuna(String nombreComuna) {
		this.nombreComuna = nombreComuna;
	}

	/**
	 * @return el valor de nombreRegion
	 */
	@Transient
	public String getNombreRegion() {
		return nombreRegion;
	}

	/**
	 * @param setea
	 *            el parametro nombreRegion al campo nombreRegion
	 */
	public void setNombreRegion(String nombreRegion) {
		this.nombreRegion = nombreRegion;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
		for (Mandatario item : mandatarios) {
			item.anonimize();
		}

	}
	
	// Mejoras 201409 Nro: 44
	@Column(name = "REQUERIDO_FORMA_ACTUAN", nullable = true)
	public Boolean getRequeridoFormaActuan() {
		if(requeridoFormaActuan==null)
			requeridoFormaActuan=false;
		return requeridoFormaActuan;
	}

	public void setRequeridoFormaActuan(Boolean requeridoFormaActuan) {
		this.requeridoFormaActuan = requeridoFormaActuan;
	}
	// Mejoras 201409 Nro: 44

	@Transient
	public RepresentanteLegal getForClone(boolean trasMandatarios) {
		RepresentanteLegal rl = new RepresentanteLegal();
		rl.setAutorizadoTramites(this.autorizadoTramites);
		rl.setCodigoComuna(this.codigoComuna);
		rl.setCodigoRegion(this.codigoRegion);
		rl.setCreation(new Timestamp(new Date().getTime()));
		rl.setDbAction(GenericModelObject.ACTION_SAVE);
		rl.setDomicilio(this.domicilio);
		rl.setEmail(this.email);
		rl.setFax(this.email);
		rl.setModified(new Timestamp(new Date().getTime()));
		rl.setNombreComuna(this.nombreComuna);
		rl.setNombreRegion(this.nombreRegion);
		rl.setPersona(this.persona);
		rl.setTelefono(this.telefono);
		rl.setTipoRepresentanteLegal(this.tipoRepresentanteLegal);
		rl.setMandatarios(new ArrayList<Mandatario>());
		if (trasMandatarios && (this.mandatarios != null)) {
			for (Mandatario m : mandatarios) {
				Mandatario mclon = m.getForClone();
				rl.getMandatarios().add(mclon);
			}
		}
		// Mejoras 201409 Nro: 44
		rl.setRequeridoFormaActuan(new Boolean(requeridoFormaActuan));
		// Mejoras 201409 Nro: 44
		return rl;
	}

}
