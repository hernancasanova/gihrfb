package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.encargado.dto.ServicioDTO;

@Entity
@Table(name = "RNT_RESPONSABLE_SERVICIO")
@Audited
public class ResponsableServicio extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3058454841360637623L;

	public static final String FORMA_ACTUAN_CONJUNTO_KEY = "servicio.responsable.formactuan.conjunta";
	public static final String FORMA_ACTUAN_INDIVIDUAL_KEY = "servicio.responsable.formactuan.individual";
	public static final String FORMA_ACTUAN_ALGUNO_KEY = "servicio.responsable.formactuan.alguno";

	/**
	 * 
	 */
	private String formaActuanRepresentantes;
	private String comentarioFormaActuan;
	private Gremio gremio;
	private String domicilio;
	private String codigoRegion;
	private String nombreRegion;
	private String codigoComuna;
	private String nombreComuna;
	private String telefono;
	private String fax;
	private String email;
	private Persona persona;
	private List<ServicioDTO> serviciosDTO;
	private List<String> formaActuanOpts;

	public ResponsableServicio() {
		super();
		this.formaActuanOpts = new ArrayList<String>();
		formaActuanOpts.add(Resources.getString(FORMA_ACTUAN_CONJUNTO_KEY));
		formaActuanOpts.add(Resources.getString(FORMA_ACTUAN_INDIVIDUAL_KEY));
		formaActuanOpts.add(Resources.getString(FORMA_ACTUAN_ALGUNO_KEY));
	}

	@Column(name = "DOMICILIO", nullable = true)
	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "TELEFONO", nullable = true)
	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Column(name = "FAX", nullable = true)
	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "EMAIL", nullable = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return el valor de persona
	 */
	@ManyToOne(targetEntity = Persona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PERSONA")
	public Persona getPersona() {
		return persona;
	}

	/**
	 * @param setea
	 *            el parametro persona al campo persona
	 */
	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	/**
	 * @return el valor de formaActuanRepresentantes
	 */
	@Column(name = "FORMA_ACTUAN", nullable = true)
	public String getFormaActuanRepresentantes() {
		return formaActuanRepresentantes;
	}

	/**
	 * @param setea
	 *            el parametro formaActuanRepresentantes al campo
	 *            formaActuanRepresentantes
	 */
	public void setFormaActuanRepresentantes(String formaActuanRepresentantes) {
		this.formaActuanRepresentantes = formaActuanRepresentantes;
	}

	/**
	 * @return el valor de comentarioFormaActuan
	 */
	@Column(name = "COMENTARIO_FORMA_ACTUAN", nullable = true)
	public String getComentarioFormaActuan() {
		return comentarioFormaActuan;
	}

	/**
	 * @param setea el parametro comentarioFormaActuan al campo comentarioFormaActuan
	 */
	public void setComentarioFormaActuan(String comentarioFormaActuan) {
		this.comentarioFormaActuan = comentarioFormaActuan;
	}

	/**
	 * @return el valor de gremio
	 */
	@ManyToOne(targetEntity = Gremio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_GREMIO")
	public Gremio getGremio() {
		return gremio;
	}

	/**
	 * @param setea
	 *            el parametro gremio al campo gremio
	 */
	public void setGremio(Gremio gremio) {
		this.gremio = gremio;
	}

	/**
	 * @return el valor de serviciosDTO
	 */
	@Transient
	public List<ServicioDTO> getServiciosDTO() {
		return serviciosDTO;
	}

	/**
	 * @param setea
	 *            el parametro serviciosDTO al campo serviciosDTO
	 */
	public void setServiciosDTO(List<ServicioDTO> serviciosDTO) {
		this.serviciosDTO = serviciosDTO;
	}

	@Transient
	public String getServiciosDesc() {
		String texto = "";
		if ((serviciosDTO != null) && (serviciosDTO.size() > 1)) {
			for (ServicioDTO serv : serviciosDTO) {
				texto = "" + serv.getIdentServicio() + "(" + serv.getTipoTransporte() + " " + serv.getMedioTransporte() + "... ";
			}
		}
		if ((serviciosDTO != null) && (serviciosDTO.size() == 1)) {
			for (ServicioDTO serv : serviciosDTO) {
				texto = serv.getDescripcion();
				if (texto.length() > 40) {
					texto = texto.substring(0, 40) + "...";
				}
			}
		}

		return texto;
	}

	/**
	 * @return el valor de formaActuanOpts
	 */
	@Transient
	public List<String> getFormaActuanOpts() {
		return formaActuanOpts;
	}

	/**
	 * @param setea
	 *            el parametro formaActuanOpts al campo formaActuanOpts
	 */
	public void setFormaActuanOpts(List<String> formaActuanOpts) {
		this.formaActuanOpts = formaActuanOpts;
	}

	/**
	 * @return el valor de codigoRegion
	 */
	@Column(name = "CODIGO_REGION", nullable = true)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	/**
	 * @param setea
	 *            el parametro codigoRegion al campo codigoRegion
	 */
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	@Override
	public ResponsableServicio clone() throws CloneNotSupportedException {
		ResponsableServicio cloned = new ResponsableServicio();
		if (this.codigoComuna != null)
			cloned.setCodigoComuna(new String(this.codigoComuna));
		if (this.codigoRegion != null)
			cloned.setCodigoRegion(new String(this.codigoRegion));
		if (this.domicilio != null)
			cloned.setDomicilio(new String(this.domicilio));
		if (this.email != null)
			cloned.setEmail(new String(this.email));
		if (this.fax != null)
			cloned.setFax(new String(this.fax));
		if (this.formaActuanRepresentantes != null)
			cloned.setFormaActuanRepresentantes(new String(this.formaActuanRepresentantes));
		if (this.comentarioFormaActuan != null)
			cloned.setComentarioFormaActuan(new String(this.comentarioFormaActuan));
		if (this.gremio != null && this.gremio.getId() != null)
			cloned.setGremio(this.getGremio());
		cloned.setPersona(this.getPersona());
		if (this.telefono != null)
			cloned.setTelefono(new String(this.telefono));
		return cloned;
	}

	/**
	 * @return el valor de nombreRegion
	 */
	@Transient
	public String getNombreRegion() {
		return nombreRegion;
	}

	/**
	 * @param setea
	 *            el parametro nombreRegion al campo nombreRegion
	 */
	public void setNombreRegion(String nombreRegion) {
		this.nombreRegion = nombreRegion;
	}

	/**
	 * @return el valor de nombreComuna
	 */
	@Transient
	public String getNombreComuna() {
		return nombreComuna;
	}

	/**
	 * @param setea
	 *            el parametro nombreComuna al campo nombreComuna
	 */
	public void setNombreComuna(String nombreComuna) {
		this.nombreComuna = nombreComuna;
	}

	@Transient
	public boolean isFormaActuanAlgunosDeEllos() {
		return Resources.getString(FORMA_ACTUAN_ALGUNO_KEY).equals(formaActuanRepresentantes);
	}


}
