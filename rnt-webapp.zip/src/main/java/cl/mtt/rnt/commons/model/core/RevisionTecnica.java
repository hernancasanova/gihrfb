package cl.mtt.rnt.commons.model.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.ws.model.WsUtil;
import cl.mtt.rnt.commons.ws.model.revisiontecnica.REVISION;

@Entity
@Table(name = "RNT_REVISION_TECNICA")
@Audited
public class RevisionTecnica extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4199551381093628231L;
	private Long codigoconsulta;
	private Date fechaconsulta;
	private Short anofabricacion;
	private String codigomarca;
	private String codigotipocombustible;
	private String codigotiposello;
	private String codigotiposervicio;
	private String codigotipovehiculo;
	private String marca;
	private String modelo;
	private String numerochasis;
	private String numeromotor;
	private String ppu;
	private String ppudv;
	private String tipocombustible;
	private String tiposello;
	private String tiposervicio;
	private String tipovehiculo;
	private DatosRevisionTecnica revisionTecnica;
	private DatosRevisionGases revisionGases;
	private boolean empty;

	@Transient
	public static RevisionTecnica getNewFromWS(REVISION rev) {
		RevisionTecnica rt = new RevisionTecnica();
		rt.codigoconsulta = rev.getCODIGOCONSULTA();
		rt.fechaconsulta = WsUtil.getFechaFromWS(rev.getFECHACONSULTA());
		rt.anofabricacion = rev.getVEHICULO().getANOFABRICACION();
		rt.codigomarca = rev.getVEHICULO().getCODIGOMARCA();
		rt.codigotipocombustible = rev.getVEHICULO().getCODIGOTIPOCOMBUSTIBLE();
		rt.codigotiposello = rev.getVEHICULO().getCODIGOTIPOSELLO();
		rt.codigotiposervicio = rev.getVEHICULO().getCODIGOTIPOSERVICIO();
		rt.codigotipovehiculo = rev.getVEHICULO().getCODIGOTIPOVEHICULO();
		rt.marca = rev.getVEHICULO().getMARCA();
		rt.modelo = rev.getVEHICULO().getMODELO();
		rt.numerochasis = rev.getVEHICULO().getNUMEROCHASIS();
		rt.numeromotor = rev.getVEHICULO().getNUMEROMOTOR();
		rt.ppu = rev.getVEHICULO().getPPU();
		rt.ppudv = rev.getVEHICULO().getPPUDV();
		rt.tipocombustible = rev.getVEHICULO().getTIPOCOMBUSTIBLE();
		rt.tiposello = rev.getVEHICULO().getTIPOSELLO();
		rt.tiposervicio = rev.getVEHICULO().getTIPOSERVICIO();
		rt.tipovehiculo = rev.getVEHICULO().getTIPOVEHICULO();

		if (rev.getVEHICULO().getREVISIONGASES() != null)
			rt.revisionGases = DatosRevisionGases.createNewFromRevision(rev.getVEHICULO().getREVISIONGASES());
		if (rev.getVEHICULO().getREVISIONTECNICA() != null)
			rt.revisionTecnica = DatosRevisionTecnica.createNewFromRevision(rev.getVEHICULO().getREVISIONTECNICA());
		
		return rt;

	}

	/**
	 * @return el valor de codigoconsulta
	 */
	@Column(name = "CODIGO_CONSULTA", nullable = true)
	public Long getCodigoconsulta() {
		return codigoconsulta;
	}

	/**
	 * @param setea
	 *            el parametro codigoconsulta al campo codigoconsulta
	 */
	public void setCodigoconsulta(Long codigoconsulta) {
		this.codigoconsulta = codigoconsulta;
	}

	/**
	 * @return el valor de fechaconsulta
	 */
	@Column(name = "FECHA_CONSULTA", nullable = true)
	public Date getFechaconsulta() {
		return fechaconsulta;
	}

	/**
	 * @param setea
	 *            el parametro fechaconsulta al campo fechaconsulta
	 */

	public void setFechaconsulta(Date fechaconsulta) {
		this.fechaconsulta = fechaconsulta;
	}

	/**
	 * @return el valor de anofabricacion
	 */
	@Column(name = "ANIO_FABRICACION", nullable = true)
	public Short getAnofabricacion() {
		return anofabricacion;
	}

	/**
	 * @param setea
	 *            el parametro anofabricacion al campo anofabricacion
	 */
	public void setAnofabricacion(Short anofabricacion) {
		this.anofabricacion = anofabricacion;
	}

	/**
	 * @return el valor de codigomarca
	 */
	@Column(name = "CODIGO_MARCA", nullable = true)
	public String getCodigomarca() {
		return codigomarca;
	}

	/**
	 * @param setea
	 *            el parametro codigomarca al campo codigomarca
	 */
	public void setCodigomarca(String codigomarca) {
		this.codigomarca = codigomarca;
	}

	/**
	 * @return el valor de codigotipocombustible
	 */
	@Column(name = "CODIGO_COMBUSTIBLE", nullable = true)
	public String getCodigotipocombustible() {
		return codigotipocombustible;
	}

	/**
	 * @param setea
	 *            el parametro codigotipocombustible al campo
	 *            codigotipocombustible
	 */
	public void setCodigotipocombustible(String codigotipocombustible) {
		this.codigotipocombustible = codigotipocombustible;
	}

	/**
	 * @return el valor de codigotiposello
	 */
	@Column(name = "CODIGO_TIPO_SELLO", nullable = true)
	public String getCodigotiposello() {
		return codigotiposello;
	}

	/**
	 * @param setea
	 *            el parametro codigotiposello al campo codigotiposello
	 */
	public void setCodigotiposello(String codigotiposello) {
		this.codigotiposello = codigotiposello;
	}

	/**
	 * @return el valor de codigotiposervicio
	 */
	@Column(name = "CODIGO_TIPO_SERVICIO", nullable = true)
	public String getCodigotiposervicio() {
		return codigotiposervicio;
	}

	/**
	 * @param setea
	 *            el parametro codigotiposervicio al campo codigotiposervicio
	 */
	public void setCodigotiposervicio(String codigotiposervicio) {
		this.codigotiposervicio = codigotiposervicio;
	}

	/**
	 * @return el valor de codigotipovehiculo
	 */
	@Column(name = "CODIGO_TIPO_VEHICULO", nullable = true)
	public String getCodigotipovehiculo() {
		return codigotipovehiculo;
	}

	/**
	 * @param setea
	 *            el parametro codigotipovehiculo al campo codigotipovehiculo
	 */
	public void setCodigotipovehiculo(String codigotipovehiculo) {
		this.codigotipovehiculo = codigotipovehiculo;
	}

	/**
	 * @return el valor de marca
	 */
	@Column(name = "MARCA", nullable = true)
	public String getMarca() {
		return marca;
	}

	/**
	 * @param setea
	 *            el parametro marca al campo marca
	 */
	public void setMarca(String marca) {
		this.marca = marca;
	}

	/**
	 * @return el valor de modelo
	 */
	@Column(name = "MODELO", nullable = true)
	public String getModelo() {
		return modelo;
	}

	/**
	 * @param setea
	 *            el parametro modelo al campo modelo
	 */
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	/**
	 * @return el valor de numerochasis
	 */
	@Column(name = "NUMERO_CHASIS", nullable = true)
	public String getNumerochasis() {
		return numerochasis;
	}

	/**
	 * @param setea
	 *            el parametro numerochasis al campo numerochasis
	 */
	public void setNumerochasis(String numerochasis) {
		this.numerochasis = numerochasis;
	}

	/**
	 * @return el valor de numeromotor
	 */
	@Column(name = "NUMERO_MOTOR", nullable = true)
	public String getNumeromotor() {
		return numeromotor;
	}

	/**
	 * @param setea
	 *            el parametro numeromotor al campo numeromotor
	 */
	public void setNumeromotor(String numeromotor) {
		this.numeromotor = numeromotor;
	}

	/**
	 * @return el valor de ppu
	 */
	@Column(name = "PPU", nullable = true)
	public String getPpu() {
		return ppu;
	}

	/**
	 * @param setea
	 *            el parametro ppu al campo ppu
	 */
	public void setPpu(String ppu) {
		this.ppu = ppu;
	}

	/**
	 * @return el valor de ppudv
	 */
	@Column(name = "PPU_DV", nullable = true)
	public String getPpudv() {
		return ppudv;
	}

	/**
	 * @param setea
	 *            el parametro ppudv al campo ppudv
	 */
	public void setPpudv(String ppudv) {
		this.ppudv = ppudv;
	}

	/**
	 * @return el valor de tipocombustible
	 */
	@Column(name = "TIPO_COMBUSTIBLE", nullable = true)
	public String getTipocombustible() {
		return tipocombustible;
	}

	/**
	 * @param setea
	 *            el parametro tipocombustible al campo tipocombustible
	 */
	public void setTipocombustible(String tipocombustible) {
		this.tipocombustible = tipocombustible;
	}

	/**
	 * @return el valor de tiposello
	 */
	@Column(name = "TIPO_SELLO", nullable = true)
	public String getTiposello() {
		return tiposello;
	}

	/**
	 * @param setea
	 *            el parametro tiposello al campo tiposello
	 */
	public void setTiposello(String tiposello) {
		this.tiposello = tiposello;
	}

	/**
	 * @return el valor de tiposervicio
	 */
	@Column(name = "TIPO_SERVICIO", nullable = true)
	public String getTiposervicio() {
		return tiposervicio;
	}

	/**
	 * @param setea
	 *            el parametro tiposervicio al campo tiposervicio
	 */
	public void setTiposervicio(String tiposervicio) {
		this.tiposervicio = tiposervicio;
	}

	/**
	 * @return el valor de tipovehiculo
	 */
	@Column(name = "TIPO_VEHICULO", nullable = true)
	public String getTipovehiculo() {
		return tipovehiculo;
	}

	/**
	 * @param setea
	 *            el parametro tipovehiculo al campo tipovehiculo
	 */
	public void setTipovehiculo(String tipovehiculo) {
		this.tipovehiculo = tipovehiculo;
	}

	/**
	 * @return el valor de revisionTecnica
	 */
	@ManyToOne(targetEntity = DatosRevisionTecnica.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_DATOS_REVISION_TECNICA")
	public DatosRevisionTecnica getRevisionTecnica() {
		return revisionTecnica;
	}

	/**
	 * @param setea
	 *            el parametro revisionTecnica al campo revisionTecnica
	 */
	public void setRevisionTecnica(DatosRevisionTecnica revisionTecnica) {
		this.revisionTecnica = revisionTecnica;
	}

	/**
	 * @return el valor de revisionGases
	 */
	@ManyToOne(targetEntity = DatosRevisionGases.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_DATOS_REVISION_GASES")
	public DatosRevisionGases getRevisionGases() {
		return revisionGases;
	}

	/**
	 * @param setea
	 *            el parametro revisionGases al campo revisionGases
	 */
	public void setRevisionGases(DatosRevisionGases revisionGases) {
		this.revisionGases = revisionGases;
	}

	/**
	 * @return el valor de empty
	 */
	@Transient
	public boolean isEmpty() {
		return empty;
	}

	/**
	 * @param setea el parametro empty al campo empty
	 */
	public void setEmpty(boolean empty) {
		this.empty = empty;
	}

}
