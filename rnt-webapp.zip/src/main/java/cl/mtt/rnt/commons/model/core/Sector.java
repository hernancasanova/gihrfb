package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;

@Entity
@Table(name = "RNT_SECTOR")
@Audited
public class Sector extends GenericModelObject implements Anonymizable {

	private String nombre;
	private Recorrido recorrido;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(targetEntity = Recorrido.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_RECORRIDO")
	public Recorrido getRecorrido() {
		return recorrido;
	}

	public void setRecorrido(Recorrido recorrido) {
		this.recorrido = recorrido;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@Transient
	@Override
	public Sector clone() throws CloneNotSupportedException {
		Sector sec = new Sector();
		sec.setCreation(this.getCreation());
		sec.setDbAction(this.getDbAction());
		if (this.getId() != null)
			sec.setId(new Long(this.getId()));
		sec.setModified(this.getModified());
		if (this.getNombre() != null)
			sec.setNombre(new String(this.getNombre()));
		sec.setRecorrido(this.getRecorrido());
		sec.setUserCreation(this.getUserCreation());
		sec.setUserModified(this.getUserModified());

		return sec;
	}
}
