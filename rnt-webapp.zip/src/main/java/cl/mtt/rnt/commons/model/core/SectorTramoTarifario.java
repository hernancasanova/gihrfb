package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

@Entity
@Table(name = "RNT_SECTOR_TRAMO_TARIFARIO")
@Audited
public class SectorTramoTarifario extends GenericModelObject implements Comparable<SectorTramoTarifario>, Anonymizable {

	public static final int EXTREMO_INICIO = 0;
	public static final int EXTREMO_FIN = 1;

	private Sector sector;
	private Tarifa tarifa;
	private int extremo;
	private int orden;

	@ManyToOne(targetEntity = Sector.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_SECTOR")
	public Sector getSector() {
		return sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	@ManyToOne(targetEntity = Tarifa.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TARIFA")
	public Tarifa getTarifa() {
		return tarifa;
	}

	public void setTarifa(Tarifa tarifa) {
		this.tarifa = tarifa;
	}

	@Column(name = "EXTREMO", nullable = false)
	public int getExtremo() {
		return extremo;
	}

	public void setExtremo(int extremo) {
		this.extremo = extremo;
	}

	@Column(name = "ORDEN", nullable = false)
	public int getOrden() {
		return orden;
	}

	public void setOrden(int orden) {
		this.orden = orden;
	}

	@Override
	public int compareTo(SectorTramoTarifario o) {
		return this.orden - o.orden;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@Override
	public SectorTramoTarifario clone() throws CloneNotSupportedException {
		SectorTramoTarifario stt = new SectorTramoTarifario();

		stt.setCreation(this.getCreation());
		stt.setDbAction(this.getDbAction());
		stt.setExtremo(this.getExtremo());
		if (this.getId() != null)
			;
		stt.setId(this.getId());
		stt.setModified(this.getModified());
		stt.setOrden(this.getOrden());
		stt.setSector(this.getSector());
		stt.setTarifa(this.getTarifa());
		stt.setUserCreation(this.getUserCreation());
		stt.setUserModified(this.getUserModified());

		return stt;
	}

}
