package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;
import cl.mtt.rnt.encargado.dto.RecorridoDTO;
import cl.mtt.rnt.encargado.dto.VehiculoServicioDTO;

@Entity
@Table(name = "RNT_SERVICIO")
@Audited
public class Servicio extends GenericAuditCancellableModelObject {

	/**
	 * 
	 */
	public static final String LISTA_CONTACTO = "listaContacto";
	public static final String LISTA_REPRESENTANTE = "listaRepresentante";
	public static final String LISTA_MANDATRIO = "listaMandatario";
	public static final String LISTA_PERIODOS_VIGENCIA = "listaPeriodoVigencia";

	private static final long serialVersionUID = -3841553105426978158L;
	private TipoServicio tipoServicio;
	private Reglamentacion reglamentacion;
	private Long identServicio;
	private Date vigenciaDesde;
	private Date vigenciaHasta;
	private Integer mesesVigencia;
	private Boolean activo;
	private String codigoRegion;
	private MotivoModServicio motivoModServicio;
	private String observaciones;

	private List<Recorrido> recorridos;
	private List<VehiculoServicio> vehiculos;
	private List<ConductorServicio> conductoresServicio;
	private Tarifa tarifa;

	private ResponsableServicio responsable;
	private Long idResponsable;
	private List<RepresentanteLegal> representantesLegales;
	private List<Contacto> contactos;

	private List<Mandatario> mandatarios;

	private HashMap<String, Object> tmpConductoresVehiculo;
	private HashMap<Long, Object> tmpConductoresServicio;

	private HashMap<String, Object> tmpPeriodosVigencia;

	private List<AtributoInstancia> atributosInstancia;
	private Long idOld;

	private TipoContrato tipoContrato;
	private TipoSubsidio tipoSubsidio;

	private Zona zonaServicio;
	private List<Zona> zonasSubsidio;

	private Integer cantidadRepresentantesActuan;

	@Transient
	private Region region;

	private LinkedList<VehiculoServicioDTO> vehiculosSkeleton;
	private LinkedList<RecorridoDTO> recorridosSkeleton;
	
	private Long revisionNumber = null;

	@SuppressWarnings("rawtypes")
    @Transient
	private Map<String, List> listasEliminar = new HashMap<String, List>();
	
	private Long idReglamentacion;
	
	private Long idTipoServicio;
	
	private List<Pasajero> pasajeros;
	
//	private List<PeriodoVigencia> periodosVigencia;
	
	private List<LogServicio> logServicio;
	
	private Boolean especificadosFormaActuan;
	private List<OficinaVentaPasajeServicio> oficinasVentaPasajeServicio;
	
	private DocumentoBiblioteca documentoCancelacion;

	private DocumentoBiblioteca documentoInscripcion;
	
	private List<AtributoInstancia>  atributosInstanciasServicioPrincipal;
	private List<AtributoInstancia>  atributosInstanciasServicioSecundario;
	private boolean atributosCargados=false;

	private boolean recienGuardado = false;
	private int incluirCertificadosMigrados = 0;
	private boolean generarCertificados = true;
	
	@OneToMany(fetch = FetchType.LAZY, targetEntity = Recorrido.class, mappedBy = "servicio")
	public List<Recorrido> getRecorridos() {
		return recorridos;
	}

	public void setRecorridos(List<Recorrido> recorridos) {
		this.recorridos = recorridos;
	}

	// @ManyToMany(targetEntity= Persona.class,fetch=FetchType.LAZY)
	// @JoinTable(name="RNT_SERVICIO_CONDUCTOR",
	// joinColumns=@JoinColumn(name="ID_SERVICIO"),inverseJoinColumns=@JoinColumn(name="ID_CONDUCTOR"))
	@OneToMany(fetch = FetchType.LAZY, targetEntity = ConductorServicio.class, mappedBy = "servicio")
	public List<ConductorServicio> getConductoresServicio() {
		return conductoresServicio;
	}

	public void setConductoresServicio(List<ConductorServicio> conductoresServicio) {
		this.conductoresServicio = conductoresServicio;
	}

	// @OneToMany(targetEntity= Auxiliar.class,fetch=FetchType.LAZY)
	// @JoinTable(name="RNT_SERVICIO_AUXILIAR",
	// joinColumns=@JoinColumn(name="ID_SERVICIO"),inverseJoinColumns=@JoinColumn(name="ID_AUXILIAR"))
	// public List<Auxiliar> getAuxiliares() {
	// return auxiliares;
	// }
	// public void setAuxiliares(List<Auxiliar> auxiliares) {
	// this.auxiliares = auxiliares;
	// }

	@ManyToOne(targetEntity = TipoServicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TIPO_SERVICIO")
	public TipoServicio getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(TipoServicio tiposServicio) {
		this.tipoServicio = tiposServicio;
	}

	@ManyToOne(targetEntity = Reglamentacion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_REGLAMENTACION")
	public Reglamentacion getReglamentacion() {
		return reglamentacion;
	}

	public void setReglamentacion(Reglamentacion reglamentacion) {
		this.reglamentacion = reglamentacion;
	}
	

	/**
	 * @return el valor de idReglamentacion
	 */
	@Column(name = "ID_REGLAMENTACION", updatable=false, insertable=false)
	public Long getIdReglamentacion() {
		return idReglamentacion;
	}

	/**
	 * @param setea el parametro idReglamentacion al campo idReglamentacion
	 */
	public void setIdReglamentacion(Long idReglamentacion) {
		this.idReglamentacion = idReglamentacion;
	}
	
	/**
	 * @return el valor de idReglamentacion
	 */
	@Column(name = "ID_RESPONSABLE_SERVICIO", updatable=false, insertable=false)
	public Long getIdResponsable() {
		return idResponsable;
	}
	
	/**
	 * @param setea el parametro idResponsable al campo idResponsable
	 */
	public void setIdResponsable(Long idResponsable) {
		this.idResponsable = idResponsable;
	}

	@Column(name = "VIGENCIA_DESDE", nullable = false)
	public Date getVigenciaDesde() {
		return vigenciaDesde;
	}

	public void setVigenciaDesde(Date vigenciaDesde) {
		this.vigenciaDesde = vigenciaDesde;
	}

	@Column(name = "VIGENCIA_HASTA", nullable = false)
	public Date getVigenciaHasta() {
		return vigenciaHasta;
	}

	public void setVigenciaHasta(Date vigenciaHasta) {
		this.vigenciaHasta = vigenciaHasta;
	}

	@ManyToOne(targetEntity = ResponsableServicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_RESPONSABLE_SERVICIO")
	public ResponsableServicio getResponsable() {
		return responsable;
	}

	public void setResponsable(ResponsableServicio responsable) {
		this.responsable = responsable;
	}

	@ManyToMany(targetEntity = RepresentanteLegal.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_SERVICIO_REPRESENTANTE", joinColumns = @JoinColumn(name = "ID_SERVICIO"), inverseJoinColumns = @JoinColumn(name = "ID_REPRESENTANTE_SERVICIO"))
	public List<RepresentanteLegal> getRepresentantesLegales() {
		return representantesLegales;
	}

	public void setRepresentantesLegales(List<RepresentanteLegal> representantesLegales) {
		this.representantesLegales = representantesLegales;
	}

	@ManyToMany(targetEntity = Contacto.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_SERVICIO_CONTACTO", joinColumns = @JoinColumn(name = "ID_SERVICIO"), inverseJoinColumns = @JoinColumn(name = "ID_CONTACTO"))
	public List<Contacto> getContactos() {
		return contactos;
	}

	public void setContactos(List<Contacto> contactos) {
		this.contactos = contactos;
	}

	/**
	 * @return el valor de identServicio
	 */
	@Column(name = "IDENT_SERVICIO", nullable = false)
	public Long getIdentServicio() {
		return identServicio;
	}

	/**
	 * @param setea
	 *            el parametro identServicio al campo identServicio
	 */
	public void setIdentServicio(Long identServicio) {
		this.identServicio = identServicio;
	}

	@Column(name = "activo", nullable = false)
	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	@Column(name = "CODIGO_REGION", nullable = false)
	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	@ManyToOne(targetEntity = MotivoModServicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_MOTIVO_MOD_SERVICIO")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public MotivoModServicio getMotivoModServicio() {
		return motivoModServicio;
	}

	public void setMotivoModServicio(MotivoModServicio motivoModServicio) {
		this.motivoModServicio = motivoModServicio;
	}

	@Column(name = "OBSERVACION", nullable = true, length = 1000)
	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	@ManyToOne(targetEntity = Tarifa.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "ID_TARIFA", unique = true)
	public Tarifa getTarifa() {
		return tarifa;
	}

	public void setTarifa(Tarifa tarifa) {
		this.tarifa = tarifa;
	}

	// @Transient
	// public String getEstado(){
	// if(this.activo)
	// return Constants.ESTADO_ACTIVO;
	// return Constants.ESTADO_INACTIVO;
	// }

	@Transient
	public Region getRegion() {
		return region;
	}

	@Transient
	public void setRegion(Region region) {
		this.region = region;
	}

	/**
	 * @return el valor de vehiculos
	 */
	@OneToMany(targetEntity = VehiculoServicio.class, mappedBy = "servicio")
	public List<VehiculoServicio> getVehiculos() {
		return vehiculos;
	}

	/**
	 * @param setea
	 *            el parametro vehiculos al campo vehiculos
	 */
	public void setVehiculos(List<VehiculoServicio> vehiculos) {
		this.vehiculos = vehiculos;
	}

	@ManyToMany(targetEntity = Mandatario.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "RNT_SERVICIO_MANDATARIO", joinColumns = @JoinColumn(name = "ID_SERVICIO"), inverseJoinColumns = @JoinColumn(name = "ID_MANDATARIO"))
	public List<Mandatario> getMandatarios() {
		return mandatarios;
	}

	public void setMandatarios(List<Mandatario> mandatarios) {
		this.mandatarios = mandatarios;
	}

	// @ManyToOne(targetEntity=Mandatario.class,fetch=FetchType.LAZY)
	// @JoinColumn(name="ID_MANDATARIO")
	// public Mandatario getMandatario() {
	// return mandatario;
	// }
	// public void setMandatario(Mandatario mandatario) {
	// this.mandatario = mandatario;
	// }

	@Transient
	public String getDescripcion() {
		return "" + this.getIdentServicio() + "(" + this.getTipoServicio().getTipoTransporte() + " " + this.getTipoServicio().getMedioTransporte() + " "
				+ this.getTipoServicio().getCategoriaTransporte() + " " + this.getTipoServicio().getTipoServicioArea() + " " + this.getTipoServicio().getModalidad() + ")";
	}

	/**
	 * @return el valor de tmpConductoresVehiculo
	 */
	@Transient
	public HashMap<String, Object> getTmpConductoresVehiculo() {
		return tmpConductoresVehiculo;
	}

	/**
	 * @param setea
	 *            el parametro tmpConductoresVehiculo al campo
	 *            tmpConductoresVehiculo
	 */
	public void setTmpConductoresVehiculo(HashMap<String, Object> tmpConductoresVehiculo) {
		this.tmpConductoresVehiculo = tmpConductoresVehiculo;
	}

	/**
	 * @return el valor de tmpConductoresServicio
	 */
	@Transient
	public HashMap<Long, Object> getTmpConductoresServicio() {
		return tmpConductoresServicio;
	}

	/**
	 * @param setea
	 *            el parametro tmpConductoresServicio al campo
	 *            tmpConductoresServicio
	 */
	public void setTmpConductoresServicio(HashMap<Long, Object> tmpConductoresServicio) {
		this.tmpConductoresServicio = tmpConductoresServicio;
	}

	/**
	 * @return el valor de atributosInstancia
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = AtributoInstancia.class, mappedBy = "servicio")
	@NotAudited
	public List<AtributoInstancia> getAtributosInstancia() {
		return atributosInstancia;
	}

	/**
	 * @param setea
	 *            el parametro atributosInstancia al campo atributosInstancia
	 */
	public void setAtributosInstancia(List<AtributoInstancia> atributosInstancia) {
		this.atributosInstancia = atributosInstancia;
	}

	/**
	 * @return el valor de idOld
	 */
	@Column(name = "ID_OLD", nullable = true)
	public Long getIdOld() {
		return idOld;
	}

	/**
	 * @param setea
	 *            el parametro idOld al campo idOld
	 */
	public void setIdOld(Long idOld) {
		this.idOld = idOld;
	}

	/**
	 * @return el valor de tipoContrato
	 */
	@ManyToOne(targetEntity = TipoContrato.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_CONTRATO", nullable = true)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoContrato getTipoContrato() {
		return tipoContrato;
	}

	/**
	 * @param setea
	 *            el parametro tipoContrato al campo tipoContrato
	 */
	public void setTipoContrato(TipoContrato tipoContrato) {
		this.tipoContrato = tipoContrato;
	}

	/**
	 * @return el valor de zonaServicio
	 */
	@ManyToOne(targetEntity = Zona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_ZONA", nullable = true)
	public Zona getZonaServicio() {
		return zonaServicio;
	}

	/**
	 * @param setea
	 *            el parametro zonaServicio al campo zonaServicio
	 */
	public void setZonaServicio(Zona zonaServicio) {
		this.zonaServicio = zonaServicio;
	}

	/**
	 * @return el valor de cantidadRepresentantesActuan
	 */
	// @Column(name="CANTIDAD_REPRESENTANTES_ACTUAN", columnDefinition =
	// "smallint")
	@Column(name = "CANTIDAD_REPRESENTANTES_ACTUAN", columnDefinition = "smallint")
	public Integer getCantidadRepresentantesActuan() {
		return cantidadRepresentantesActuan;
	}

	/**
	 * @param setea
	 *            el parametro cantidadRepresentantesActuan al campo
	 *            cantidadRepresentantesActuan
	 */
	public void setCantidadRepresentantesActuan(Integer cantidadRepresentantesActuan) {
		this.cantidadRepresentantesActuan = cantidadRepresentantesActuan;
	}

	@Transient
	public boolean isEnCancelacion() {
		return getEstado().equals(GenericCancellableModelObject.ESTADO_CANCELADO) || getEstado().equals(GenericCancellableModelObject.ESTADO_CANCELADO_DEFINITIVO)
				|| getEstado().equals(GenericCancellableModelObject.ESTADO_PENDIENTE_CANCELACION);
	}

	/**
	 * @return el valor de cantidadVehiculos
	 */

	/**
	 * @return el valor de vehiculosSkeleton
	 */
	@Transient
	public LinkedList<VehiculoServicioDTO> getVehiculosSkeleton() {
		if(vehiculosSkeleton == null){
			vehiculosSkeleton = new LinkedList<VehiculoServicioDTO>();
		} 
		return vehiculosSkeleton;
	}

	/**
	 * @param setea
	 *            el parametro vehiculosSkeleton al campo vehiculosSkeleton
	 */
	public void setVehiculosSkeleton(LinkedList<VehiculoServicioDTO> vehiculosSkeleton) {
		this.vehiculosSkeleton = vehiculosSkeleton;
	}

	/**
	 * @return el valor de recorridosSkeleton
	 */
	@Transient
	public LinkedList<RecorridoDTO> getRecorridosSkeleton() {
		if(recorridosSkeleton == null){
			recorridosSkeleton = new LinkedList<RecorridoDTO>();
		}
		return recorridosSkeleton;
	}

	/**
	 * @param setea
	 *            el parametro recorridosSkeleton al campo recorridosSkeleton
	 */
	public void setRecorridosSkeleton(LinkedList<RecorridoDTO> recorridosSkeleton) {
		this.recorridosSkeleton = recorridosSkeleton;
	}

	@OneToOne(targetEntity = TipoSubsidio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_SUBSIDIO", nullable = true)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoSubsidio getTipoSubsidio() {
		return tipoSubsidio;
	}

	public void setTipoSubsidio(TipoSubsidio tipoSubsidio) {
		this.tipoSubsidio = tipoSubsidio;
	}

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_SERVICIO_ZONA_SUBSIDIO", joinColumns = @JoinColumn(name = "ID_SERVICIO"), inverseJoinColumns = @JoinColumn(name = "ID_ZONA"))
	public List<Zona> getZonasSubsidio() {
		return zonasSubsidio;
	}

	public void setZonasSubsidio(List<Zona> zonasSubsidio) {
		this.zonasSubsidio = zonasSubsidio;
	}

	public int getModificadorCupoVehiculos(Long idReglamentacion, String codigoRegionZona) {
		int cant = 0;
		for (VehiculoServicioDTO vsDTO : getVehiculosSkeleton()) {
			if (vsDTO.getVs() != null && vsDTO.getVs().getDbAction() == GenericModelObject.ACTION_SAVE) {
				VehiculoServicio vs = vsDTO.getVs();
				if (vs.getReglamentacion().getId().equals(idReglamentacion) && vs.getReemplaza() == null) {
					if (vs.getReglamentacion().getMarcoGeografico().getAplicableA().equals(MarcoGeograficoSource.AMBITO_ZONAL)) {
						if (vs.getZonaVehiculo().getId().equals(Long.valueOf(codigoRegionZona))) {
							cant++;
						}
					} else {
						if (vs.getServicio().getCodigoRegion().equals(codigoRegionZona)) {
							cant++;
						}
					}
				}
			}
		}
		return cant;
	}

	/**
	 * @return el valor de listasEliminar
	 */
	@SuppressWarnings("rawtypes")
    @Transient
	public Map<String, List> getListasEliminar() {
		return listasEliminar;
	}

	/**
	 * @param setea
	 *            el parametro listasEliminar al campo listasEliminar
	 */
	@SuppressWarnings("rawtypes")
    public void setListasEliminar(Map<String, List> listasEliminar) {
		this.listasEliminar = listasEliminar;
	}

	/**
	 * @return el valor de revisionNumber
	 */
	@Transient
	public Long getRevisionNumber() {
		return revisionNumber;
	}

	/**
	 * @param setea el parametro revisionNumber al campo revisionNumber
	 */
	public void setRevisionNumber(Long revisionNumber) {
		this.revisionNumber = revisionNumber;
	}

	/**
	 * @return el valor de pasajeros
	 */
	@OneToMany(targetEntity = Pasajero.class, fetch = FetchType.LAZY, mappedBy = "servicio")
	public List<Pasajero> getPasajeros() {
		return pasajeros;
	}

	/**
	 * @param setea el parametro pasajeros al campo pasajeros
	 */
	public void setPasajeros(List<Pasajero> pasajeros) {
		this.pasajeros = pasajeros;
	}

//	/**
//	 * @return el valor de periodosVigencia
//	 */
//	@OneToMany(targetEntity = PeriodoVigencia.class, fetch = FetchType.LAZY, mappedBy = "servicio")
//	public List<PeriodoVigencia> getPeriodosVigencia() {
//		return periodosVigencia;
//	}
//
//	/**
//	 * @param setea el parametro periodosVigencia al campo periodosVigencia
//	 */
//	public void setPeriodosVigencia(List<PeriodoVigencia> periodosVigencia) {
//		this.periodosVigencia = periodosVigencia;
//	}
	
	@Transient
	public boolean isHistorico() {
		return this.revisionNumber!=null;
	}
	
@Transient
	public List<LogServicio> getLogServicio() {
		if (logServicio==null)
			logServicio=new ArrayList<LogServicio>();
		return logServicio;
	}

	public void setLogServicio(List<LogServicio> logServicio) {
		this.logServicio = logServicio;
	}
	
	@Transient
	public void addLog(String message){
		if(!this.getLogServicio().contains(message))
			this.getLogServicio().add(new LogServicio(this,message));
	}

	
	// Mejora 201409 Nro: 24
	/**
	 * @return el valor de mesesVigencia
	 */
	@Transient
	public Integer getMesesVigencia() {
		if ((this.vigenciaDesde!=null)&&(this.vigenciaHasta!=null)&&(mesesVigencia==null)) {
			this.mesesVigencia = ValidacionHelper.mesesEntreFechas(vigenciaDesde,vigenciaHasta);
		}
		return mesesVigencia;
	}

	/**
	 * @param setea el parametro mesesVigencia al campo mesesVigencia
	 */
	public void setMesesVigencia(Integer mesesVigencia) {
		this.mesesVigencia = mesesVigencia;
	}
	// Mejora 201409 Nro: 24

	
	// Mejoras 201409 Nro: 44
	@Column(name = "ESPECIFICADOS_FORMA_ACTUAN", nullable = true)
	public Boolean getEspecificadosFormaActuan() {
		if (especificadosFormaActuan==null)
			especificadosFormaActuan=false;
		return especificadosFormaActuan;
	}

	public void setEspecificadosFormaActuan(Boolean especificadosFormaActuan) {
		this.especificadosFormaActuan = especificadosFormaActuan;
	}
	// Mejoras 201409 Nro: 44
	
	// Mejoras 201409 Nro: 9

	@OneToMany(targetEntity = OficinaVentaPasajeServicio.class, fetch = FetchType.LAZY, mappedBy = "servicio")
	public List<OficinaVentaPasajeServicio> getOficinasVentaPasajeServicio() {
		return oficinasVentaPasajeServicio;
	}

	public void setOficinasVentaPasajeServicio(
			List<OficinaVentaPasajeServicio> oficinasVentaPasajeServicio) {
		this.oficinasVentaPasajeServicio = oficinasVentaPasajeServicio;
	}

	/**
	 * @return el valor de documentoCancelacion
	 */
	@ManyToOne(targetEntity = DocumentoBiblioteca.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_DOCUMENTO_BIBLIOTECA_CANCELACION")
	public DocumentoBiblioteca getDocumentoCancelacion() {
		return documentoCancelacion;
	}

	/**
	 * @param setea el parametro documentoCancelacion al campo documentoCancelacion
	 */
	public void setDocumentoCancelacion(DocumentoBiblioteca documentoCancelacion) {
		this.documentoCancelacion = documentoCancelacion;
	}

	/**
	 * @return el valor de documentoInscripcion
	 */
	@ManyToOne(targetEntity = DocumentoBiblioteca.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_DOCUMENTO_BIBLIOTECA_INSCRIPCION")
	public DocumentoBiblioteca getDocumentoInscripcion() {
		return documentoInscripcion;
	}

	/**
	 * @param setea el parametro documentoInscripcion al campo documentoInscripcion
	 */
	public void setDocumentoInscripcion(DocumentoBiblioteca documentoInscripcion) {
		this.documentoInscripcion = documentoInscripcion;
	}

    /**
     * @return el valor de idTipoServicio
     */
	/**
     * @return el valor de idReglamentacion
     */
    @Column(name = "ID_TIPO_SERVICIO", updatable=false, insertable=false)
    public Long getIdTipoServicio() {
        return idTipoServicio;
    }

    /**
     * @param setea el parametro idTipoServicio al campo idTipoServicio
     */
    public void setIdTipoServicio(Long idTipoServicio) {
        this.idTipoServicio = idTipoServicio;
    }

	/**
	 * @return el valor de atributosCargados
	 */
    @Transient
	public boolean isAtributosCargados() {
		return atributosCargados;
	}

	/**
	 * @param setea el parametro atributosCargados al campo atributosCargados
	 */
	public void setAtributosCargados(boolean atributosCargados) {
		this.atributosCargados = atributosCargados;
	}

	
    @Transient
	public List<AtributoInstancia> getAtributosInstanciasServicioPrincipal() {
		if(atributosInstanciasServicioPrincipal == null)
			atributosInstanciasServicioPrincipal= new ArrayList<AtributoInstancia>();
		return atributosInstanciasServicioPrincipal;
	}

	public void setAtributosInstanciasServicioPrincipal(
			List<AtributoInstancia> atributosInstanciasServicioPrincipal) {
		this.atributosInstanciasServicioPrincipal = atributosInstanciasServicioPrincipal;
	}

    @Transient
	public List<AtributoInstancia> getAtributosInstanciasServicioSecundario() {
		if(atributosInstanciasServicioSecundario == null)
			atributosInstanciasServicioSecundario= new ArrayList<AtributoInstancia>();
		return atributosInstanciasServicioSecundario;
	}

	public void setAtributosInstanciasServicioSecundario(
			List<AtributoInstancia> atributosInstanciasServicioSecundario) {
		this.atributosInstanciasServicioSecundario = atributosInstanciasServicioSecundario;
	}

	/**
	 * @return el valor de recienGuardado
	 */
    @Transient
	public boolean isRecienGuardado() {
		return recienGuardado;
	}

	/**
	 * @param setea el parametro recienGuardado al campo recienGuardado
	 */
	public void setRecienGuardado(boolean recienGuardado) {
		this.recienGuardado = recienGuardado;
	}

	/**
	 * @return el valor de incluirCertificadosMigrados
	 */
	@Transient
	public Integer getIncluirCertificadosMigrados() {
		return incluirCertificadosMigrados;
	}

	/**
	 * @param setea el parametro incluirCertificadosMigrados al campo incluirCertificadosMigrados
	 */
	public void setIncluirCertificadosMigrados(Integer incluirCertificadosMigrados) {
		if(incluirCertificadosMigrados==null){
			incluirCertificadosMigrados=0;
		}
		this.incluirCertificadosMigrados = incluirCertificadosMigrados;
	}

	@Transient
	public boolean isVigente(){
		return ValidacionHelper.esFechaMayorIgual(this.getVigenciaHasta(), new Date());
	} 

	@Transient
	public boolean isVencidoNoCancelado(){
		return this.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE) && !isVigente() ;
	}

	/**
	 * @return el valor de generarCertificados
	 */
	@Transient
	public boolean isGenerarCertificados() {
		return generarCertificados;
	}

	/**
	 * @param setea el parametro generarCertificados al campo generarCertificados
	 */
	public void setGenerarCertificados(boolean generarCertificados) {
		this.generarCertificados = generarCertificados;
	}

	/**
	 * @return el valor de tmpPeriodosVigencia
	 */
	@Transient
	public HashMap<String, Object> getTmpPeriodosVigencia() {
		if(tmpPeriodosVigencia==null){
			tmpPeriodosVigencia=new HashMap<String, Object>();
		}
		return tmpPeriodosVigencia;
	}

	/**
	 * @param setea el parametro tmpPeriodosVigencia al campo tmpPeriodosVigencia
	 */
	public void setTmpPeriodosVigencia(HashMap<String, Object> tmpPeriodosVigencia) {
		this.tmpPeriodosVigencia = tmpPeriodosVigencia;
	}

	
	
}
