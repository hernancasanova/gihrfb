package cl.mtt.rnt.commons.model.core;

public class Sexo {

	private String id;
	private String sexoDesc;

	public static final String SEXO_MASC_ID = "M";
	public static final String SEXO_FEM_ID = "F";

	public Sexo(String id, String sexoDesc) {
		super();
		this.id = id;
		this.sexoDesc = sexoDesc;
	}

	/**
	 * @return el valor de id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param setea
	 *            el parametro id al campo id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return el valor de sexoDesc
	 */
	public String getSexoDesc() {
		return sexoDesc;
	}

	/**
	 * @param setea
	 *            el parametro sexoDesc al campo sexoDesc
	 */
	public void setSexoDesc(String sexoDesc) {
		this.sexoDesc = sexoDesc;
	}

}
