package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;

import cl.mtt.rnt.encargado.util.KeyValueString;

@Entity
@Table(name = "RNT_SUBINSCRIPCION_VEHICULO")
public class SubInscripcionVehiculo extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1396393556577465162L;

	private String nombre;
	private String detalles;
	private Vehiculo vehiculo;

	/**
	 * @return el valor de nombre
	 */
	@Column(name = "NOMBRE", nullable = true)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param setea
	 *            el parametro nombre al campo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return el valor de detalles
	 */
	@Column(name = "DETALLES", nullable = true, length = 1000)
	public String getDetalles() {
		return detalles;
	}

	/**
	 * @param setea
	 *            el parametro detalles al campo detalles
	 */
	public void setDetalles(String detalles) {
		this.detalles = detalles;
	}

	/**
	 * @return el valor de vehiculo
	 */
	@ManyToOne(targetEntity = Vehiculo.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_VEHICULO")
	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	/**
	 * @param setea
	 *            el parametro vehiculo al campo vehiculo
	 */
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	@Transient
	public List<KeyValueString> getDetallesList() {
		List<KeyValueString> lista = new ArrayList<KeyValueString>();
		if (this.getDetalles() != null) {
			try {
				String det = this.getDetalles();
				String[] splited = det.split("\\]\\[");
				for (int i = 0; i < splited.length; i++) {
					String detalle = splited[i];
					detalle = detalle.replace("[", "").replace("]", "");
					String[] kv = detalle.split("\\:");
					KeyValueString detKv = new KeyValueString();
					detKv.setKey(kv[0].trim());
					detKv.setValue(kv[1].trim());
					lista.add(detKv);
				}
			} catch (Exception e) {
				Logger.getLogger(this.getClass()).error("NO SE PUEDE PARSEAR DETALLES SUBINSCRIPCION:" + this.getDetalles(), e);
			}
		}
		return lista;
	}

}
