package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

@Entity
@Table(name = "RNT_TARIFA")
@Audited
public class Tarifa extends GenericModelObject implements Anonymizable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3931262205018145016L;
	public static final String TIPO_SIN_REGISTRO = "SIN_REGISTRO";
	public static final String TIPO_FIJA_VARIABLE = "FIJA_VARIABLE";
	public static final String TIPO_MATRIZ = "MATRIZ";

	private String tipoTarifa;
	@Transient
	private String tipoTarifaAnterior;
	private Float montoFijo;
	private Float montoMinimo;
	private Float montoMaximo;
	private List<TramoTarifario> tramosTarifarios;
	private List<SectorTramoTarifario> sectoresTramoTarifario;
	private List<SectorTramoTarifario> sectoresTramoTarifarioAnteriores;

	@Column(name = "TIPO_TARIFA", nullable = false)
	public String getTipoTarifa() {
		return tipoTarifa;
	}

	public void setTipoTarifa(String tipoTarifa) {
		if (this.tipoTarifa != null)
			tipoTarifaAnterior = new String(this.tipoTarifa);
		this.tipoTarifa = tipoTarifa;
	}

	public void recoverTipoTarifa() {
		tipoTarifa = new String(tipoTarifaAnterior);
	}

	@Column(name = "MONTO_FIJO", nullable = true, columnDefinition = "double")
	public Float getMontoFijo() {
		return montoFijo;
	}

	public void setMontoFijo(Float montoFijo) {
		this.montoFijo = montoFijo;
	}

	@Column(name = "MONTO_MINIMO", nullable = true, columnDefinition = "double")
	public Float getMontoMinimo() {
		return montoMinimo;
	}

	public void setMontoMinimo(Float montoMinimo) {
		this.montoMinimo = montoMinimo;
	}

	@Column(name = "MONTO_MAXIMO", nullable = true, columnDefinition = "double")
	public Float getMontoMaximo() {
		return montoMaximo;
	}

	public void setMontoMaximo(Float montoMaximo) {
		this.montoMaximo = montoMaximo;
	}

	@OneToMany(fetch = FetchType.EAGER, targetEntity = TramoTarifario.class, mappedBy = "tarifa")
	public List<TramoTarifario> getTramosTarifarios() {
		return tramosTarifarios;
	}

	public void setTramosTarifarios(List<TramoTarifario> tramosTarifarios) {
		this.tramosTarifarios = tramosTarifarios;
	}

	@Override
	public Tarifa clone() throws CloneNotSupportedException {
		Tarifa t = new Tarifa();
		t.setCreation(this.getCreation());
		t.setDbAction(this.getDbAction());
		if (this.getId() != null)
			t.setId(new Long(this.getId()));
		t.setModified(this.getModified());
		if (this.getMontoFijo() != null)
			t.setMontoFijo(new Float(this.getMontoFijo()));
		if (this.getMontoMaximo() != null)
			t.setMontoMaximo(new Float(this.getMontoMaximo()));
		if (this.getMontoMinimo() != null)
			t.setMontoMinimo(new Float(this.getMontoMinimo()));
		t.setTipoTarifa(new String(this.getTipoTarifa()));
		if (this.getTramosTarifarios() != null) {
			t.setTramosTarifarios(new ArrayList<TramoTarifario>());
			for (TramoTarifario tramoTarifario : this.getTramosTarifarios()) {
				TramoTarifario tt = tramoTarifario.clone();
				tt.setTarifa(t);
				t.getTramosTarifarios().add(tt);
			}
		} else
			t.setTramosTarifarios(null);
		t.setUserCreation(this.getUserCreation());
		t.setUserModified(this.getUserModified());

		t.setSectoresTramoTarifarioAnteriores(new ArrayList<SectorTramoTarifario>());
		try {
			for (SectorTramoTarifario sectorTramoTarifario : this.getSectoresTramoTarifario()) {
				t.getSectoresTramoTarifario().add(sectorTramoTarifario.clone());
			}
			t.getSectoresTramoTarifarioAnteriores().addAll(this.getSectoresTramoTarifarioAnteriores());
		} catch (Exception e) {
		}

		return t;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);

		for (TramoTarifario item : tramosTarifarios) {
			item.anonimize();
		}
		if(sectoresTramoTarifario!=null){
			for (SectorTramoTarifario item : sectoresTramoTarifario) {
				item.anonimize();
			}
		}
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = SectorTramoTarifario.class, mappedBy = "tarifa", cascade = { CascadeType.ALL })
	public List<SectorTramoTarifario> getSectoresTramoTarifario() {
		if(this.sectoresTramoTarifario==null) 
			this.sectoresTramoTarifario = new ArrayList<SectorTramoTarifario>();
		return sectoresTramoTarifario;
	}

	public void setSectoresTramoTarifario(List<SectorTramoTarifario> sectoresTramoTarifario) {
//		if(this.sectoresTramoTarifario==null && sectoresTramoTarifario!=null)
//			this.sectoresTramoTarifario = sectoresTramoTarifario;		
//		else if(this.sectoresTramoTarifario==null && sectoresTramoTarifario==null)
//			this.sectoresTramoTarifario = new ArrayList<SectorTramoTarifario>();
//		else if(this.sectoresTramoTarifario!=null && sectoresTramoTarifario!=null){
//			if (Hibernate.isInitialized(this.sectoresTramoTarifario) && !sectoresTramoTarifario.isEmpty()) {				
//				if(!this.sectoresTramoTarifario.equals(sectoresTramoTarifario)){
//					this.sectoresTramoTarifario.clear();
//					this.sectoresTramoTarifario.addAll(sectoresTramoTarifario);
//				}
//			} else if (sectoresTramoTarifario.isEmpty()){
//				this.sectoresTramoTarifario.clear();
//			} else {
//				this.sectoresTramoTarifario = sectoresTramoTarifario;
//			}
//		} else if(this.sectoresTramoTarifario!=null && sectoresTramoTarifario==null)
//			if (Hibernate.isInitialized(this.sectoresTramoTarifario)) {
//				this.sectoresTramoTarifario.clear();
//			}

		this.sectoresTramoTarifario = sectoresTramoTarifario;

	}

	@Transient
	public List<SectorTramoTarifario> getSectoresTramoTarifarioAnteriores() {
		return sectoresTramoTarifarioAnteriores;
	}

	public void setSectoresTramoTarifarioAnteriores(List<SectorTramoTarifario> sectoresTramoTarifarioAnteriores) {
		this.sectoresTramoTarifarioAnteriores = sectoresTramoTarifarioAnteriores;
	}

}
