/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.mtt.rnt.commons.model.core;

import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.envers.Audited;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.util.Resources;
import java.util.ArrayList;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import org.hibernate.envers.RelationTargetAuditMode;

/**
 *
 * @author jhenriquez
 */
@Entity
@Table(name = "TEL_AUTORIZACION", schema = "TEL")
@Audited
public class TelAutorizacion extends GenericModelObject implements Anonymizable{

    private static final long serialVersionUID = 447321220951054603L;
    
     public static final Integer TIPO_AUTORIZACION_REPRESENTANTE = 1;
    public static final Integer TIPO_AUTORIZACION_MANDATARIO = 2;
    private static final String TIPO_AUTORIZACION_REPRESENTANTE_DESC = "tel.autorizacion.representante";
    private static final String TIPO_AUTORIZACION_MANDATARIO_DESC = "tel.autorizacion.mandatario";
    
    private TelPersona telPersona;
    private List<Tramite> tramites;
    
    private Boolean autorizado;
    private Date fechaVigenciaDesde;
    private Date fechaVigenciaHasta;
    private String codigoRegion;
    private String nombreRegion;
    
    private String categoriasConfAut;
    private String tiposDeServicioConfAut;
    private String tramitesConfAut;
    
    private Long idCategoria;
    private String nombreCategoria;

    private Long idTipoServicio;
    private String nombreTipoServicio;  
    
//    private Integer tipoAutorizacion; // Representante o Mandatario
//    private static List<TipoAutorizacion> tipoAutorizacions;
//    
//    private String rutRepresentante;

    @ManyToOne(targetEntity = TelPersona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PERSONA")
    public TelPersona getTelPersona() {
        return telPersona;
    }

    public void setTelPersona(TelPersona telPersona) {
        this.telPersona = telPersona;
    }

    @Column(name = "AUTORIZADO", nullable = false)
    public Boolean getAutorizado() {
        return autorizado;
    }

    public void setAutorizado(Boolean autorizado) {
        this.autorizado = autorizado;
    }

    @Column(name = "FECHA_VIGENCIA_DESDE", nullable = false)
    public Date getFechaVigenciaDesde() {
        return fechaVigenciaDesde;
    }

    
    public void setFechaVigenciaDesde(Date fechaVigenciaDesde) {
        this.fechaVigenciaDesde = fechaVigenciaDesde;
    }

    @Column(name = "FECHA_VIGENCIA_HASTA", nullable = false)
    public Date getFechaVigenciaHasta() {
        return fechaVigenciaHasta;
    }

    public void setFechaVigenciaHasta(Date fechaVigenciaHasta) {
        this.fechaVigenciaHasta = fechaVigenciaHasta;
    }
    
    @Column(name = "CODIGO_REGION", nullable = false)
    public String getCodigoRegion() {
        return codigoRegion;
    }

    public void setCodigoRegion(String codigoRegion) {
        this.codigoRegion = codigoRegion;
    }
    
     @Column(name = "ID_TIPO_SERVICIO", nullable = false)
    public Long getIdTipoServicio() {
        return idTipoServicio;
    }

    public void setIdTipoServicio(Long idTipoServicio) {
        this.idTipoServicio = idTipoServicio;
    }

    @Column(name = "ID_CATEGORIA", nullable = false)
    public Long getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Long idCategoria) {
        this.idCategoria = idCategoria;
    }
    
//     @Column(name = "TIPO_AUTORIZACION", nullable = false)
//    public Integer getTipoAutorizacion() {
//        return tipoAutorizacion;
//    }
//
//    public void setTipoAutorizacion(Integer tipoAutorizacion) {
//        this.tipoAutorizacion = tipoAutorizacion;
//    }
//
//    @Column(name = "RUT_REPRESENTANTE", nullable = true)
//    public String getRutRepresentante() {
//        return rutRepresentante;
//    }
//
//    public void setRutRepresentante(String rutRepresentante) {
//        this.rutRepresentante = rutRepresentante;
//    }
    
    @Transient
    public String getNombreRegion() {
        return nombreRegion;
    }

    public void setNombreRegion(String nombreRegion) {
        this.nombreRegion = nombreRegion;
    }
    
    @Transient
    public String getNombreTipoServicio() {
        return nombreTipoServicio;
    }

    public void setNombreTipoServicio(String nombreTipoServicio) {
        this.nombreTipoServicio = nombreTipoServicio;
    }

    @Transient
    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }
    
     @ManyToMany(targetEntity = Tramite.class, fetch = FetchType.LAZY)
    @JoinTable(name = "TEL_AUTORIZACION_TRAMITE", schema = "TEL", joinColumns = @JoinColumn(name = "ID_AUTORIZACION", referencedColumnName = "ID"), inverseJoinColumns = @JoinColumn(name = "ID_TRAMITE", referencedColumnName = "ID"))
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
     public List<Tramite> getTramites() {
        return tramites;
    }

    public void setTramites(List<Tramite> tramites) {
        this.tramites = tramites;
    }
 
    @Transient
    public String getCategoriasConfAut() {
        return categoriasConfAut;
    }

    public void setCategoriasConfAut(String categoriasConfAut) {
        this.categoriasConfAut = categoriasConfAut;
    }
    
    @Transient
     public String getTiposDeServicioConfAut() {
        return tiposDeServicioConfAut;
    }

    public void setTiposDeServicioConfAut(String tiposDeServicioConfAut) {
        this.tiposDeServicioConfAut = tiposDeServicioConfAut;
    }
 
    @Transient
    public String getTramitesConfAut() {
        return tramitesConfAut;
    }

    public void setTramitesConfAut(String tramitesConfAut) {
        this.tramitesConfAut = tramitesConfAut;
    }
    
    @Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}
    
//    @Transient
//    public List<TipoAutorizacion> getTipoAutorizacions() {
//        if (tipoAutorizacions == null) {
//                tipoAutorizacions = new ArrayList<TipoAutorizacion>();
//                tipoAutorizacions.add(new TipoAutorizacion(TIPO_AUTORIZACION_REPRESENTANTE, Resources.getString(TIPO_AUTORIZACION_REPRESENTANTE_DESC)));
//                tipoAutorizacions.add(new TipoAutorizacion(TIPO_AUTORIZACION_MANDATARIO, Resources.getString(TIPO_AUTORIZACION_MANDATARIO_DESC)));
//        }
//        return tipoAutorizacions;
//    }
    
//    @Transient
//    public String getTipoAutorizacionDesc() {
//        if (tipoAutorizacion != null) {
//            if (tipoAutorizacion.equals(TIPO_AUTORIZACION_REPRESENTANTE)) {
//                return Resources.getString(TIPO_AUTORIZACION_REPRESENTANTE_DESC);
//            } else {
//                return Resources.getString(TIPO_AUTORIZACION_MANDATARIO_DESC);
//            }
//        }
//        return null;
//    }
    
//    @Transient
//    public boolean isTipoAutorizacionMandatario() {
//        return TIPO_AUTORIZACION_MANDATARIO.equals(tipoAutorizacion);
//    }
//    
    
}
