/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.util.SexoManager;
import cl.mtt.rnt.commons.util.Resources;
/**
 *
 * @author jhenriquez
 */
@Entity
@Table(name = "TEL_PERSONA", schema = "TEL")
@Audited
public class TelPersona extends GenericModelObject{

    private static final long serialVersionUID = 8981072324019220473L;
    
    public static final Integer TIPO_PERSONA_JURIDICA = 2;
    public static final Integer TIPO_PERSONA_NATURAL = 1;
    private static final String TIPO_PERSONA_NATURAL_DESC = "persona.tipo.natural";
    private static final String TIPO_PERSONA_JURIDICA_DESC = "persona.tipo.juridica";
    
    public static final String WEBSERVICE_SOURCE = "WS";
    public static final String DATABASE_SOURCE = "DB";
    public static final String MANUAL_SOURCE = "MA";
        
    private String rut;
    private String nombre;
    private Integer tipoPersonaId; // Jurídica o natural
    private String sexo;
    
    private List<Inhabilidad> inhabilidades;
    private static List<TipoPersona> tipoOpts;
    private String source;
    
    // utilizada para determinar si es una nueva persona que debe ser guardada
    // en la DB
    private boolean requieredSave;
    
    @Column(name = "RUT", nullable = false)
    public String getRut() {
            return rut;
    }
    public void setRut(String rut) {
            this.rut = rut;
    }
    
    @Column(name = "NOMBRE", nullable = false)
    public String getNombre() {
            return nombre;
    }

    public void setNombre(String nombre) {
            this.nombre = nombre;
    }
    
    @Column(name = "TIPO_PERSONA_ID", nullable = true)
    public Integer getTipoPersonaId() {
            return tipoPersonaId;
    }

    public void setTipoPersonaId(Integer tipoPersonaId) {
            this.tipoPersonaId = tipoPersonaId;
    }
    
    @Column(name = "SEXO", nullable = true, length = 1)
    public String getSexo() {
            return sexo;
    }

    public void setSexo(String sexo) {
            this.sexo = sexo;
    }
    
    @Transient
    public String getTipoPersonaDesc() {
        if (tipoPersonaId != null) {
            if (tipoPersonaId.equals(TIPO_PERSONA_NATURAL)) {
                return Resources.getString(TIPO_PERSONA_NATURAL_DESC);
            } else {
                return Resources.getString(TIPO_PERSONA_JURIDICA_DESC);
            }
        }
        return null;
    }
    
    @Transient
    public boolean isPersonaJuridica() {
        return TIPO_PERSONA_JURIDICA.equals(tipoPersonaId);
    }
    
    /**
    * @return el valor de tipoOpts
    */
    @Transient
    public List<TipoPersona> getTipoOpts() {
            if (tipoOpts == null) {
                    tipoOpts = new ArrayList<TipoPersona>();
                    tipoOpts.add(new TipoPersona(TIPO_PERSONA_NATURAL, Resources.getString(TIPO_PERSONA_NATURAL_DESC)));
                    tipoOpts.add(new TipoPersona(TIPO_PERSONA_JURIDICA, Resources.getString(TIPO_PERSONA_JURIDICA_DESC)));
            }
            return tipoOpts;
    }
    
    @Transient
    public List<TipoPersona> getTipoNatOpt() {
            if (tipoOpts == null) {
                    tipoOpts = new ArrayList<TipoPersona>();
                    tipoOpts.add(new TipoPersona(TIPO_PERSONA_NATURAL, Resources.getString(TIPO_PERSONA_NATURAL_DESC)));
            }
            return tipoOpts;
    }
    
    @Transient
    public List<Sexo> getSexoOpts() {
            return SexoManager.getSexos();
    }

    @Transient
    public String getSexoDesc() {
            if (this.sexo != null) {
                    return SexoManager.getSexoDesc(this.sexo);
            }
            return null;
    }
    
    @ManyToMany(targetEntity = Inhabilidad.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_PERSONA_INHABILIDAD", joinColumns = @JoinColumn(name = "ID_PERSONA"), inverseJoinColumns = @JoinColumn(name = "ID_INHABILIDAD"))
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public List<Inhabilidad> getInhabilidades() {
		return inhabilidades;
	}

	public void setInhabilidades(List<Inhabilidad> inhabilidades) {
		this.inhabilidades = inhabilidades;
	}
        
        @Override
	public boolean equals(Object obj) {
		if (this.getId() != null && ((GenericModelObject) obj).getId() != null)
			return super.equals(obj);

		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;
		if (this.getRut() == null)
			return false;
		return this.getRut().equals(((TelPersona) obj).getRut());
	}
        
        @Override
	public TelPersona clone() throws CloneNotSupportedException {
		TelPersona p = new TelPersona();
		
		p.setCreation(this.getCreation());
		p.setDbAction(this.getDbAction());
		
		if (this.getId() != null)
			p.setId(new Long(this.getId()));
		p.setId(this.getId());
		p.setModified(this.getModified());
		p.setNombre(new String(this.getNombre()));
		if (this.getRut() != null)
			p.setRut(new String(this.getRut()));
		if (this.getSexo() != null)
			p.setSexo(new String(this.getSexo()));
		if (this.getTipoPersonaId() != null)
			p.setTipoPersonaId(new Integer(this.getTipoPersonaId()));
		
		return p;
	}
        
        /**
	 * @return el valor de source
	 */
	@Column(name = "SOURCE", nullable = true, length = 2)
	public String getSource() {
		return source;
	}
        
        /**
	 * @param setea
	 *            el parametro source al campo source
	 */
	public void setSource(String source) {
		this.source = source;
	}
        
        @Transient
	public boolean isRequieredSave() {
		return requieredSave;
	}

	/**
	 * @param setea
	 *            el parametro requieredSave al campo requieredSave
	 */
	public void setRequieredSave(boolean requieredSave) {
		this.requieredSave = requieredSave;
	}
}
