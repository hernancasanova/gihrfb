/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.mtt.rnt.commons.model.core;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.envers.Audited;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author jhenriquez
 */
@Entity
@Table(name = "TEL_RESPONSABLE", schema = "TEL")
@Audited
public class TelResponsable extends GenericModelObject {

    private static final long serialVersionUID = 434308742119577434L;
    
    public static final String LISTA_TEL_AUTORIZACION = "listaTelAutorizacion";
    
    private TelPersona telPersona;
    private List<TelAutorizacion> telAutorizacion;
    private boolean recienGuardado = false;
    
    @SuppressWarnings("rawtypes")
    @Transient
    private Map<String, List> listasEliminar = new HashMap<String, List>();

    /**
    * @return el valor de persona
    */
   @ManyToOne(targetEntity = TelPersona.class, fetch = FetchType.EAGER)
   @JoinColumn(name = "ID_PERSONA")
   public TelPersona getTelPersona() {
           return telPersona;
   }
   
   @ManyToMany(targetEntity = TelAutorizacion.class, fetch = FetchType.LAZY)
    @JoinTable(name = "TEL_RESPONSABLE_AUTORIZACION", schema = "TEL", joinColumns = @JoinColumn(name = "ID_RESPONSABLE", referencedColumnName = "ID"), inverseJoinColumns = @JoinColumn(name = "ID_AUTORIZACION", referencedColumnName = "ID"))
    public List<TelAutorizacion> getTelAutorizacion() {
            return telAutorizacion;
    }

    public void setTelAutorizacion(List<TelAutorizacion> telAutorizacion) {
    this.telAutorizacion = telAutorizacion;
    }
    
    @Transient
	public String getTelAutorizacionText() {
            String ret = "";
            if (this.getTelAutorizacion()!= null && !this.getTelAutorizacion().isEmpty()) {
                    for (TelAutorizacion telAut : getTelAutorizacion()) {
                            if (telAut != null && telAut.getTelPersona() != null)
                                    ret += "(" + telAut.getTelPersona().getRut() + ") " + telAut.getTelPersona().getNombre() + "   ";
                    }
            }
            return ret;
	}
   
   /**
    * @param setea
    *            el parametro persona al campo persona
    */
   public void setTelPersona(TelPersona telPersona) {
           this.telPersona = telPersona;
   }
   
   /*
    * (non-Javadoc)
    * 
    * @see java.lang.Object#clone()
    */
   @Override
   public TelResponsable clone() throws CloneNotSupportedException {
           TelResponsable cloned = new TelResponsable();

           cloned.setTelPersona(this.getTelPersona());

           return cloned;
   }
   
   	/**
	 * @return el valor de recienGuardado
	 */
    @Transient
	public boolean isRecienGuardado() {
		return recienGuardado;
	}

	/**
	 * @param setea el parametro recienGuardado al campo recienGuardado
	 */
	public void setRecienGuardado(boolean recienGuardado) {
		this.recienGuardado = recienGuardado;
	}

    /**
     * @return el valor de listasEliminar
     */
    @SuppressWarnings("rawtypes")
    @Transient
    public Map<String, List> getListasEliminar() {
        return listasEliminar;
    }

    public void setListasEliminar(Map<String, List> listasEliminar) {
        this.listasEliminar = listasEliminar;
    }
}
