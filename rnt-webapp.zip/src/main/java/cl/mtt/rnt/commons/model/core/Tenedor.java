package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_TENEDOR")
public class Tenedor extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2486615368753884081L;

	private String rut;
	private String nombre;
	private LimitacionVehiculo limitacion;

	/**
	 * @return el valor de rut
	 */
	@Column(name = "RUT", nullable = true)
	public String getRut() {
		return rut;
	}

	/**
	 * @param setea
	 *            el parametro rut al campo rut
	 */
	public void setRut(String rut) {
		this.rut = rut;
	}

	/**
	 * @return el valor de nombre
	 */
	@Column(name = "NOMBRE", nullable = true)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param setea
	 *            el parametro nombre al campo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return el valor de limitacion
	 */
	@ManyToOne(targetEntity = LimitacionVehiculo.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_LIMITACION_VEHICULO")
	public LimitacionVehiculo getLimitacion() {
		return limitacion;
	}

	/**
	 * @param setea
	 *            el parametro limitacion al campo limitacion
	 */
	public void setLimitacion(LimitacionVehiculo limitacion) {
		this.limitacion = limitacion;
	}
}
