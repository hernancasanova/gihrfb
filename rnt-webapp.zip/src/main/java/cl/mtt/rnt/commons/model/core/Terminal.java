package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;

@Entity
@Table(name = "RNT_TERMINAL")
@PrimaryKeyJoinColumn(name = "ID")
@Audited
public class Terminal extends Paradero {

	private static final long serialVersionUID = -7721994597764934671L;

	// private String categoria;
	private TipoTerminal tipoTerminal;// Tipo Terminal (Lista desplegable)
	private Long metrosCuadradosTotales;
	private String telefono;
	// private UbicacionTerminal ubicacionTerminal;
	private CategoriaTerminal categoriaTerminal;
	private Integer flotaDisenio;
	
	// Mejoras 201409 Nro: 96
	private Integer numeroEstacionamientos;
	private Integer numeroAndenes;
	private List<TipoServicioArea> tiposServicioArea;
	// Mejoras 201409 Nro: 96
	
	
	@ManyToOne(targetEntity = TipoTerminal.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_TERMINAL", nullable = true)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoTerminal getTipoTerminal() {
		return tipoTerminal;
	}

	public void setTipoTerminal(TipoTerminal tipoTerminal) {
		this.tipoTerminal = tipoTerminal;
	}

	// @Column(name="CATEGORIA", nullable=false)
	// public String getCategoria() {
	// return categoria;
	// }
	// public void setCategoria(String categoria) {
	// this.categoria = categoria;
	// }

	@Column(name = "METROS_CUADRADOS_TOTALES")
	public Long getMetrosCuadradosTotales() {
		return metrosCuadradosTotales;
	}

	public void setMetrosCuadradosTotales(Long metrosCuadradosTotales) {
		this.metrosCuadradosTotales = metrosCuadradosTotales;
	}

	@Transient
	public boolean equals(Object obj) {
		if (obj instanceof Terminal)
			return ((Terminal) obj).getId().equals(getId());
		return false;
	}

	// @ManyToOne(targetEntity=UbicacionTerminal.class,fetch=FetchType.EAGER)
	// @JoinColumn(name="ID_UBICACION_TERMINAL", nullable=true)
	// @AuditJoinTable
	// @Audited (targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	// public UbicacionTerminal getUbicacionTerminal() {
	// return ubicacionTerminal;
	// }
	// public void setUbicacionTerminal(UbicacionTerminal ubicacionTerminal) {
	// this.ubicacionTerminal = ubicacionTerminal;
	// }

	@ManyToOne(targetEntity = CategoriaTerminal.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CATEGORIA_TERMINAL", nullable = true)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public CategoriaTerminal getCategoriaTerminal() {
		return categoriaTerminal;
	}

	public void setCategoriaTerminal(CategoriaTerminal categoriaTerminal) {
		this.categoriaTerminal = categoriaTerminal;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Column(name = "FLOTA_DISENIO")
	public Integer getFlotaDisenio() {
		return flotaDisenio;
	}

	public void setFlotaDisenio(Integer flotaDisenio) {
		this.flotaDisenio = flotaDisenio;
	}
	
	// Mejoras 201409 Nro: 96
	@Column(name = "NUMERO_ESTACIONAMIENTOS")
	public Integer getNumeroEstacionamientos() {
		return numeroEstacionamientos;
	}

	public void setNumeroEstacionamientos(Integer numeroEstacionamientos) {
		this.numeroEstacionamientos = numeroEstacionamientos;
	}

	@Column(name = "NUMERO_ANDENES")
	public Integer getNumeroAndenes() {
		return numeroAndenes;
	}

	public void setNumeroAndenes(Integer numeroAndenes) {
		this.numeroAndenes = numeroAndenes;
	}

	@ManyToMany(targetEntity = TipoServicioArea.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_TERMINAL_TIPO_SERVICIO_AREA", joinColumns = @JoinColumn(name = "ID_TERMINAL"), inverseJoinColumns = @JoinColumn(name = "ID_TIPO_SERVICIO_AREA"))
	public List<TipoServicioArea> getTiposServicioArea() {
		return tiposServicioArea;
	}

	public void setTiposServicioArea(List<TipoServicioArea> tiposServicioArea) {
		this.tiposServicioArea = tiposServicioArea;
	}
	// Mejoras 201409 Nro: 96

	
	
}
