/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.mtt.rnt.commons.model.core;

/**
 *
 * @author jhenriquez
 */
public class TipoAutorizacion {
    
      private Integer tipoAutorizacionId;
    private String descripcion;

    public TipoAutorizacion(Integer tipoAutorizacion, String descripcion) {
        this.tipoAutorizacionId = tipoAutorizacion;
        this.descripcion = descripcion;
    }

    public Integer getTipoAutorizacionId() {
        return tipoAutorizacionId;
    }

    public void setTipoAutorizacionId(Integer tipoAutorizacion) {
        this.tipoAutorizacionId = tipoAutorizacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
