package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "RNT_TIPO_CANCELACION")
@Audited
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class TipoCancelacion extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	public static final String APLICA_VEHICULOS = "vehiculo";
	public static final String APLICA_SERVICIO = "servicio";
	public static final String APLICA_PERSONA = "persona";
	public static final String APLICA_RECORRIDO = "recorrido";

	public static final String TIPO_TEMPORAL = "temporal";
	public static final String TIPO_DEFINITIVA = "definitiva";

	private String nombre;
	private String aplica;
	private String descripcion;
	private String tipoCancelacion;
	private boolean permiteReemplazo;
	private boolean requiereRegionDestino;
	private boolean permiteReingresoAlMismoTipo;
	private boolean requiereFechaResolucion;
	private boolean requiereNumeroResolucion;
	private boolean requiereLinkDocumento;
	private List<TipoServicio> tiposServicio;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return el valor de aplica
	 */
	@Column(name = "APLICA_A", nullable = false)
	public String getAplica() {
		return aplica;
	}

	/**
	 * @param setea
	 *            el parametro aplica al campo aplica
	 */
	public void setAplica(String aplica) {
		this.aplica = aplica;
	}

	/**
	 * @return el valor de descripcion
	 */
	@Column(name = "DESCRIPCION", nullable = true)
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param setea
	 *            el parametro descripcion al campo descripcion
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * @return el valor de tipoCancelacion
	 */
	@Column(name = "TIPO", nullable = true)
	public String getTipoCancelacion() {
		return tipoCancelacion;
	}

	/**
	 * @param setea
	 *            el parametro tipoCancelacion al campo tipoCancelacion
	 */
	public void setTipoCancelacion(String tipoCancelacion) {
		this.tipoCancelacion = tipoCancelacion;
	}

	/**
	 * @return el valor de permiteReemplazo
	 */
	@Column(name = "PERMITE_REEMPLAZO", nullable = true)
	public boolean isPermiteReemplazo() {
		return permiteReemplazo;
	}

	/**
	 * @param setea
	 *            el parametro permiteReemplazo al campo permiteReemplazo
	 */
	public void setPermiteReemplazo(boolean permiteReemplazo) {
		this.permiteReemplazo = permiteReemplazo;
	}

	/**
	 * @return el valor de requiereRegionDestino
	 */
	@Column(name = "REQUIERE_REGION_DESTINO", nullable = true)
	public boolean isRequiereRegionDestino() {
		return requiereRegionDestino;
	}

	/**
	 * @param setea
	 *            el parametro requiereRegionDestino al campo
	 *            requiereRegionDestino
	 */
	public void setRequiereRegionDestino(boolean requiereRegionDestino) {
		this.requiereRegionDestino = requiereRegionDestino;
	}

	/**
	 * @return el valor de permiteReingresoAlMismoTipo
	 */
	@Column(name = "PERMITE_REINGRESO_TIPO_SERVICIO", nullable = true)
	public boolean isPermiteReingresoAlMismoTipo() {
		return permiteReingresoAlMismoTipo;
	}

	/**
	 * @param setea
	 *            el parametro permiteReingresoAlMismoTipo al campo
	 *            permiteReingresoAlMismoTipo
	 */
	public void setPermiteReingresoAlMismoTipo(boolean permiteReingresoAlMismoTipo) {
		this.permiteReingresoAlMismoTipo = permiteReingresoAlMismoTipo;
	}

	/**
	 * @return el valor de requiereFechaResolucion
	 */
	@Column(name = "REQUIERE_FECHA_RESOLUCION", nullable = true)
	public boolean isRequiereFechaResolucion() {
		return requiereFechaResolucion;
	}

	/**
	 * @param setea
	 *            el parametro requiereFechaResolucion al campo
	 *            requiereFechaResolucion
	 */
	public void setRequiereFechaResolucion(boolean requiereFechaResolucion) {
		this.requiereFechaResolucion = requiereFechaResolucion;
	}

	/**
	 * @return el valor de requiereNumeroResolucion
	 */
	@Column(name = "REQUIERE_NUMERO_RESOLUCION", nullable = true)
	public boolean isRequiereNumeroResolucion() {
		return requiereNumeroResolucion;
	}

	/**
	 * @param setea
	 *            el parametro requiereNumeroResolucion al campo
	 *            requiereNumeroResolucion
	 */
	public void setRequiereNumeroResolucion(boolean requiereNumeroResolucion) {
		this.requiereNumeroResolucion = requiereNumeroResolucion;
	}

	/**
	 * @return el valor de requiereLinkDocumento
	 */
	@Column(name = "REQUIERE_LINK_DOCUMENTO", nullable = true)
	public boolean isRequiereLinkDocumento() {
		return requiereLinkDocumento;
	}

	/**
	 * @param setea
	 *            el parametro requiereLinkDocumento al campo
	 *            requiereLinkDocumento
	 */
	public void setRequiereLinkDocumento(boolean requiereLinkDocumento) {
		this.requiereLinkDocumento = requiereLinkDocumento;
	}

	/**
	 * @return el valor de tiposServicio
	 */
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_TIPO_CANCELACION_TIPO_SERVICIO", joinColumns = { @JoinColumn(name = "ID_TIPO_CANCELACION") }, inverseJoinColumns = { @JoinColumn(name = "ID_TIPO_SERVICIO") })
	@BatchSize (size = 50)
	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	/**
	 * @param setea
	 *            el parametro tiposServicio al campo tiposServicio
	 */
	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cl.mtt.rnt.commons.model.core.GenericModelObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		TipoCancelacion otro = (TipoCancelacion) obj;
		try {
			return otro.getId().equals(this.getId());
		} catch (Exception e) {
			return false;
		}

	}

}
