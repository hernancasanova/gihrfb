package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import cl.mtt.rnt.commons.model.core.interfaces.NombrableModelObject;
@Entity
@Table(name = "RNT_TIPO_CARGA_MASIVA")
public class TipoCargaMasiva extends GenericModelObject implements NombrableModelObject {
	
	private static final long serialVersionUID = 1L;

	public static final String CAMBIO_VIGENCIA_SERVICIOS = "cambioVigenciaServicios";
	public static final String CANCELACION_MASIVA_SERVICIOS ="cancelacionMasivaServicios";
	public static final String CANCELACION_MASIVA_VEHICULOS="cancelacionMasivaVehiculos";	
	public static final String REAJUSTES_TARIFARIOS_VF="reajustesTarifariosVF";
	public static final String REAJUSTES_TARIFARIOS_MATRIZ="reajustesTarifariosMatriz";
	public static final String REAJUSTES_TARIFARIOS_MATRIZ_RECORRIDO="reajustesTarifariosMatrizRecorrido";
	public static final String CLONACION_MASIVA_SERVICIOS="clonacionMasivaServicios";
//	public static final String CARGA_MASIVA_ATRIBUTOS = "cargaMasivaAtributos";
	public static final String CARGA_MASIVA_ATRIBUTOS_SERVICIO = "cargaMasivaAtributosServicio";
	public static final String CARGA_MASIVA_ATRIBUTOS_VEHICULO = "cargaMasivaAtributosVehiculo";
	public static final String CARGA_MASIVA_RECORRIDOS="cargaMasivaRecorridos";
	public static final String CARGA_MASIVA_TRAZADOS="cargaMasivaTrazados";
	public static final String CARGA_MASIVA_CALLES="cargaMasivaCalles";
	
	private String nombre;
	private String descriptor;
	
	@Override
	public String getNombre() {
		return nombre;
	}

	/**
	 * @return el valor de descriptor
	 */
	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	/**
	 * @param setea el parametro descriptor al campo descriptor
	 */
	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	/**
	 * @param setea el parametro nombre al campo nombre
	 */
	@Column(name = "NOMBRE", nullable = false)
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
