package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity
@Table(name = "RNT_TIPO_CERTIFICADO")
public class TipoCertificado extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	public static final String MOVIMIENTO_ADD = "inscripcion";
	public static final String MOVIMIENTO_CHANGE = "actualizacion";
	public static final String MOVIMIENTO_CANCEL = "cancelacion";

	public static final String OBJETO_RECORRIDO = "recorrido";
	public static final String OBJETO_VEHICULO = "vehiculo";

	private String nombre;
	private String descriptor;
	private String sistema;
	private String materia;
	private String tipoDoc;
	private Boolean obligatorio;
	private List<TipoCertificadoReglamentado> tiposCertificadosReglamentados;
	private ClaseTipoCertificado claseTipoCertificado;

	private CertificadoSeccion seccion;

	private Boolean recorridoObligatorio;
	private Boolean conductorObligatorio;
	private Boolean auxiliarObligatorio;
	private Boolean vigenciaObligatorio;
	private Boolean pasajeroObligatorio;
	
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	
	/**
	 * @return el valor de claseCertificado
	 */
	@ManyToOne(targetEntity = ClaseTipoCertificado.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CLASE_TIPO_CERTIFICADO", nullable = false)
	public ClaseTipoCertificado getClaseTipoCertificado() {
		return claseTipoCertificado;
	}

	/**
	 * @param setea
	 *            el parametro claseCertificado al campo claseCertificado
	 */
	public void setClaseTipoCertificado(ClaseTipoCertificado claseCertificado) {
		this.claseTipoCertificado = claseCertificado;
	}

	@Transient
	public String getTipoServicioDesc() { 
		//FIXME
		/*
		if (this.getTiposServicio() != null) {
			if (!this.getTiposServicio().isEmpty()) {
				if (this.getTiposServicio().size() == 1) {
					return this.getTiposServicio().get(0).getName();
				} else {
					return this.getTiposServicio().get(0).getName() + "...";
				}

			}
		}*/
		return "";
	}

	@Column(name = "SISTEMA", nullable = true, length = 10)
	public String getSistema() {
		return sistema;
	}

	public void setSistema(String sistema) {
		this.sistema = sistema;
	}

	@Column(name = "MATERIA", nullable = true, length = 100)
	public String getMateria() {
		return materia;
	}

	public void setMateria(String materia) {
		this.materia = materia;
	}

	@Column(name = "TIPO_DOC", nullable = true, length = 50)
	public String getTipoDoc() {
		return tipoDoc;
	}

	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}

	/**
	 * @return el valor de claseCertificado
	 */
	@ManyToOne(targetEntity = CertificadoSeccion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SECCION", nullable = true)
	public CertificadoSeccion getSeccion() {
		return seccion;
	}

	public void setSeccion(CertificadoSeccion seccion) {
		this.seccion = seccion;
	}

		

	@Transient
	public boolean isCertificadoConRecorrido() {
		for (CertificadoSeccion seccion : this.seccion.getSecciones()) {
			if (seccion.getSeccionDefinition().getNombre().toLowerCase().contains("recorrido"))
				return true;
		}

		return false;
	}

	/**
	 * @return el valor de tiposCertificadosReglamentados
	 */
	@OneToMany(targetEntity = TipoCertificadoReglamentado.class, fetch = FetchType.LAZY, mappedBy = "tipoCertificado")
	public List<TipoCertificadoReglamentado> getTiposCertificadosReglamentados() {
		return tiposCertificadosReglamentados;
	}

	/**
	 * @param setea el parametro tiposCertificadosReglamentados al campo tiposCertificadosReglamentados
	 */
	public void setTiposCertificadosReglamentados(List<TipoCertificadoReglamentado> tiposCertificadosReglamentados) {
		this.tiposCertificadosReglamentados = tiposCertificadosReglamentados;
	}

	@Column(name = "OBLIGATORIO", nullable = true)
	public Boolean getObligatorio() {
		return obligatorio;
	}

	public void setObligatorio(Boolean obligatorio) {
		this.obligatorio = obligatorio;
	}

	@Column(name = "RECORRIDO_OBLIGATORIO", nullable = true)
	public Boolean getRecorridoObligatorio() {
		return recorridoObligatorio;
	}

	public void setRecorridoObligatorio(Boolean recorridoObligatorio) {
		this.recorridoObligatorio = recorridoObligatorio;
	}

	@Column(name = "CONDUCTOR_OBLIGATORIO", nullable = true)
	public Boolean getConductorObligatorio() {
		return conductorObligatorio;
	}

	public void setConductorObligatorio(Boolean conductorObligatorio) {
		this.conductorObligatorio = conductorObligatorio;
	}

	@Column(name = "AUXILIAR_OBLIGATORIO", nullable = true)
	public Boolean getAuxiliarObligatorio() {
		return auxiliarObligatorio;
	}

	public void setAuxiliarObligatorio(Boolean auxiliarObligatorio) {
		this.auxiliarObligatorio = auxiliarObligatorio;
	}

	@Column(name = "VIGENCIA_OBLIGATORIO", nullable = true)
	public Boolean getVigenciaObligatorio() {
		return vigenciaObligatorio;
	}

	public void setVigenciaObligatorio(Boolean vigenciaObligatorio) {
		this.vigenciaObligatorio = vigenciaObligatorio;
	}

	@Column(name = "PASAJERO_OBLIGATORIO", nullable = true)
	public Boolean getPasajeroObligatorio() {
		return pasajeroObligatorio;
	}

	public void setPasajeroObligatorio(Boolean pasajeroObligatorio) {
		this.pasajeroObligatorio = pasajeroObligatorio;
	}

	
}
