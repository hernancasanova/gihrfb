package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity
@Table(name = "RNT_TIPO_CERTIFICADO_REGLAMENTADO")
public class TipoCertificadoReglamentado extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private TipoCertificado tipoCertificado;
	private Reglamentacion reglamentacion;
	private Boolean aplicaHijas;
	private List<TipoServicio> tiposServicio;
	private Boolean aplicaTodasReglamentaciones;
	private int dbActionAnterior;
	
	
	/**
	 * @return el valor de tiposServicio
	 */
	@ManyToMany(targetEntity = TipoServicio.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_TIPO_CERTIFICADO_REG_TIPO_SERVICIO", joinColumns = @JoinColumn(name = "ID_TIPO_CERTIFICADO_REG"), inverseJoinColumns = @JoinColumn(name = "ID_TIPO_SERVICIO"))
	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	/**
	 * @param setea
	 *            el parametro tiposServicio al campo tiposServicio
	 */
	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

		
	@ManyToOne(targetEntity = Reglamentacion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_REGLAMENTACION")
	public Reglamentacion getReglamentacion() {
		return reglamentacion;
	}

	public void setReglamentacion(Reglamentacion reglamentacion) {
		this.reglamentacion = reglamentacion;
	}

	/**
	 * @return el valor de tipoCertificado
	 */
	@ManyToOne(targetEntity = TipoCertificado.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TIPO_CERTIFICADO", nullable = true)
	public TipoCertificado getTipoCertificado() {
		return tipoCertificado;
	}

	/**
	 * @param setea el parametro tipoCertificado al campo tipoCertificado
	 */
	public void setTipoCertificado(TipoCertificado tipoCertificado) {
		this.tipoCertificado = tipoCertificado;
	}

	/**
	 * @return el valor de aplicaHijas
	 */
	@Column(name = "APLICA_HIJAS", nullable = true)
	public Boolean getAplicaHijas() {
		return aplicaHijas;
	}

	/**
	 * @param setea el parametro aplicaHijas al campo aplicaHijas
	 */
	public void setAplicaHijas(Boolean aplicaHijas) {
		this.aplicaHijas = aplicaHijas;
	}

	/**
	 * @return el valor de aplicaTodasReglamentaciones
	 */
	@Transient
	public Boolean getAplicaTodasReglamentaciones() {
		return aplicaTodasReglamentaciones;
	}

	/**
	 * @param setea el parametro aplicaTodasReglamentaciones al campo aplicaTodasReglamentaciones
	 */
	public void setAplicaTodasReglamentaciones(Boolean aplicaTodasReglamentaciones) {
		this.aplicaTodasReglamentaciones = aplicaTodasReglamentaciones;
	}

	/**
	 * @return el valor de dbActionAnterior
	 */
	@Transient
	public int getDbActionAnterior() {
		return dbActionAnterior;
	}

	/**
	 * @param setea el parametro dbActionAnterior al campo dbActionAnterior
	 */
	public void setDbActionAnterior(int dbActionAnterior) {
		this.dbActionAnterior = dbActionAnterior;
	}

}
