package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "RNT_TIPO_CONTRATO")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class TipoContrato extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private String nombre;
	private String descriptor;
	private String tipoCertificacion;

	/**
	 * @return el valor de nombre
	 */
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param setea
	 *            el parametro nombre al campo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return el valor de descriptor
	 */
	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	/**
	 * @param setea
	 *            el parametro descriptor al campo descriptor
	 */
	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	/**
	 * @return el valor de tipoCertificacion
	 */
	@Column(name = "TIPO_CERTIFICACION", nullable = true)
	public String getTipoCertificacion() {
		return tipoCertificacion;
	}

	/**
	 * @param setea
	 *            el parametro tipoCertificacion al campo tipoCertificacion
	 */
	public void setTipoCertificacion(String tipoCertificacion) {
		this.tipoCertificacion = tipoCertificacion;
	}

}
