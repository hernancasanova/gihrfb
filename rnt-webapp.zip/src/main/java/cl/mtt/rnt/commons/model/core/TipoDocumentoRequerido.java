package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "RNT_TIPO_DOCUMENTO_REQUERIDO")
public class TipoDocumentoRequerido extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private String nombre;
	private TipoDocumentoGrupo grupo;
	private boolean dePortacion;
	private boolean selected;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@ManyToOne(targetEntity = TipoDocumentoGrupo.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_DOCUMENTO_GRUPO", nullable = true)
	public TipoDocumentoGrupo getGrupo() {
		return grupo;
	}

	public void setGrupo(TipoDocumentoGrupo grupo) {
		this.grupo = grupo;
	}

	@Transient
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	@Column(name = "DE_PORTACION", nullable = false)
	public boolean isDePortacion() {
		return dePortacion;
	}

	public void setDePortacion(boolean dePortacion) {
		this.dePortacion = dePortacion;
	}

}
