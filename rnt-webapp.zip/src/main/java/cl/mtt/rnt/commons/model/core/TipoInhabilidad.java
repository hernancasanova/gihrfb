package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_TIPO_INHABILIDAD")
public class TipoInhabilidad extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private String nombre;
	private String linkDescripcion;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "LINK_DESCRIPCION")
	public String getLinkDescripcion() {
		return linkDescripcion;
	}

	public void setLinkDescripcion(String linkDescripcion) {
		this.linkDescripcion = linkDescripcion;
	}

}
