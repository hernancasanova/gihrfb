package cl.mtt.rnt.commons.model.core;

/**
 * 
 * @author jeyler
 * 
 */
public class TipoPersona {
	private Integer tipoId;
	private String descripcion;

	/**
	 * @param tipoId
	 * @param descripcion
	 */
	public TipoPersona(Integer tipoId, String descripcion) {
		super();
		this.tipoId = tipoId;
		this.descripcion = descripcion;
	}

	/**
	 * @return el valor de tipoId
	 */
	public Integer getTipoId() {
		return tipoId;
	}

	/**
	 * @param setea
	 *            el parametro tipoId al campo tipoId
	 */
	public void setTipoId(Integer tipoId) {
		this.tipoId = tipoId;
	}

	/**
	 * @return el valor de descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param setea
	 *            el parametro descripcion al campo descripcion
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
