package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_TIPO_REGLAMENTACION")
public class TipoReglamentacion extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	public final static String ALCANCE_PARTICULAR = "Particular";
	public final static String ALCANCE_GENERAL = "General";

	private String nombre;
	private String alcance;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "ALCANCE", nullable = false)
	public String getAlcance() {
		return alcance;
	}

	public void setAlcance(String alcance) {
		this.alcance = alcance;
	}

}
