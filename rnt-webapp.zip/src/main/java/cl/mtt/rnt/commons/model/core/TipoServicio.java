package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;

@Entity
@Table(name = "RNT_TIPO_SERVICIO")
@Audited
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class TipoServicio extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private TipoTransporte tipoTransporte;
	private MedioTransporte medioTransporte;
	private CategoriaTransporte categoriaTransporte;
	private TipoServicioArea tipoServicioArea;
	private Modalidad modalidad;
	private TipoVehiculoServicio tipoVehiculoServicio;
	private String documentoAsociado;
	private Boolean permiteRecorrido;
	private List<Reglamentacion> reglamentaciones;
	// private List<Atributo> atributos;
	private List<TipoServicioAtributo> tipoServicioAtributos;
	private Long idOld;
	private String glosa;
	private Boolean glosaPorServicio;
	private Boolean glosaEnCertificado;
	private Boolean glosaAlVehiculo;
	private Boolean conductoresPorServicio;
	private Boolean conductoresPorAmbos;
	private Boolean auxiliaresPorServicio;
	private Boolean pasajerosPorServicio;

	private GlosaAuxiliar glosaAuxiliar;

	private List<TipoCancelacion> tiposCancelacion;
	private Boolean habilitarConductor;
	private Boolean habilitarAuxiliar;
	private Boolean habilitarPasajero;
	private Boolean permiteIngresoPeriodoVig;
	
	private Boolean permiteOficinaVenta;

	@ManyToOne(targetEntity = TipoTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_TRANSPORTE", nullable = false)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoTransporte getTipoTransporte() {
		return tipoTransporte;
	}

	public void setTipoTransporte(TipoTransporte tipoTransporte) {
		this.tipoTransporte = tipoTransporte;
	}

	@ManyToOne(targetEntity = MedioTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_MEDIO_TRANSPORTE", nullable = false)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public MedioTransporte getMedioTransporte() {
		return medioTransporte;
	}

	public void setMedioTransporte(MedioTransporte medioTransporte) {
		this.medioTransporte = medioTransporte;
	}

	@ManyToOne(targetEntity = CategoriaTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CATEGORIA_TRANSPORTE", nullable = false)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public CategoriaTransporte getCategoriaTransporte() {
		return categoriaTransporte;
	}

	public void setCategoriaTransporte(CategoriaTransporte categoriaTransporte) {
		this.categoriaTransporte = categoriaTransporte;
	}

	@ManyToOne(targetEntity = TipoServicioArea.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_SERVICIO_AREA", nullable = false)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoServicioArea getTipoServicioArea() {
		return tipoServicioArea;
	}

	public void setTipoServicioArea(TipoServicioArea tipoServicioArea) {
		this.tipoServicioArea = tipoServicioArea;
	}

	@ManyToOne(targetEntity = Modalidad.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_MODALIDAD", nullable = false)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public Modalidad getModalidad() {
		return modalidad;
	}

	public void setModalidad(Modalidad modalidad) {
		this.modalidad = modalidad;
	}

	@Column(name = "DOCUMENTO_ASOCIADO", nullable = false)
	public String getDocumentoAsociado() {
		return documentoAsociado;
	}

	public void setDocumentoAsociado(String documentoAsociado) {
		this.documentoAsociado = documentoAsociado;
	}

	@Column(name = "PERMITE_RECORRIDO")
	public Boolean getPermiteRecorrido() {
		if(permiteRecorrido==null)
			permiteRecorrido=false;
		return permiteRecorrido;
	}

	public void setPermiteRecorrido(Boolean permiteRecorrido) {
		this.permiteRecorrido = permiteRecorrido;
	}

	@Transient
	public String getName() {
		try {
			// Se valida si es null porqe es un dato que se incorporó nuevo y
			// aún no se actualizaron los tipos de servicios
			String tipoVehiculo = this.getTipoVehiculoServicio() != null ? this.getTipoVehiculoServicio().getNombre() : "";
			return "(" + this.getTipoTransporte().getNombre() + " " + this.getMedioTransporte().getNombre() + " " + this.getCategoriaTransporte().getNombre() + " "
					+ this.getTipoServicioArea().getNombre() + " " + tipoVehiculo + " " + this.getModalidad().getNombre() + ")";
		} catch (Exception e) {
			return "";
		}

	}
	
	@Transient
	public String getCategoriaName() {
		try {
			// Se valida si es null porqe es un dato que se incorporó nuevo y
			// aún no se actualizaron los tipos de servicios
			String tipoVehiculo = this.getTipoVehiculoServicio() != null ? this.getTipoVehiculoServicio().getNombre() : "";
			return "(" + this.getTipoTransporte().getNombre() + " " + this.getMedioTransporte().getNombre() + " " + this.getCategoriaTransporte().getNombre() + ")";
		} catch (Exception e) {
			return "";
		}

	}
	
	@Transient
	public String getShortName() {
		try {
			// Se valida si es null porqe es un dato que se incorporó nuevo y
			// aún no se actualizaron los tipos de servicios
			String tipoVehiculo = this.getTipoVehiculoServicio() != null ? this.getTipoVehiculoServicio().getNombre() : "";
			return this.getTipoServicioArea().getNombre() + " " + tipoVehiculo + " " + this.getModalidad().getNombre() ;
		} catch (Exception e) {
			return "";
		}

	}

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToMany(targetEntity = Reglamentacion.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_REGLAMENTACION_TIPO_SERVICIO", joinColumns = @JoinColumn(name = "TIPO_SERVICIO_ID"), inverseJoinColumns = @JoinColumn(name = "REGLAMENTACION_ID"))
	public List<Reglamentacion> getReglamentaciones() {
		return reglamentaciones;
	}

	public void setReglamentaciones(List<Reglamentacion> reglamentaciones) {
		this.reglamentaciones = reglamentaciones;
	}

	/**
	 * @return el valor de tipoServicioAtributos
	 */
	@OneToMany(targetEntity = TipoServicioAtributo.class, mappedBy = "tipoServicio", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@NotAudited
	public List<TipoServicioAtributo> getTipoServicioAtributos() {
		return tipoServicioAtributos;
	}

	/**
	 * @param setea
	 *            el parametro tipoServicioAtributos al campo
	 *            tipoServicioAtributos
	 */
	public void setTipoServicioAtributos(List<TipoServicioAtributo> tipoServicioAtributos) {
		this.tipoServicioAtributos = tipoServicioAtributos;
	}

	/**
	 * @return el valor de idOld
	 */
	@Column(name = "ID_OLD", nullable = true)
	public Long getIdOld() {
		return idOld;
	}

	/**
	 * @param setea
	 *            el parametro idOld al campo idOld
	 */
	public void setIdOld(Long idOld) {
		this.idOld = idOld;
	}

	/**
	 * @return el valor de tipoVehiculoServicio
	 */
	@ManyToOne(targetEntity = TipoVehiculoServicio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_VEHICULO_SERVICIO", nullable = true)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoVehiculoServicio getTipoVehiculoServicio() {
		return tipoVehiculoServicio;
	}

	/**
	 * @param setea
	 *            el parametro tipoVehiculoServicio al campo
	 *            tipoVehiculoServicio
	 */
	public void setTipoVehiculoServicio(TipoVehiculoServicio tipoVehiculoServicio) {
		this.tipoVehiculoServicio = tipoVehiculoServicio;
	}

	/**
	 * @return el valor de glosa
	 */
	@Column(name = "GLOSA", nullable = true, length = 2000)
	public String getGlosa() {
		return glosa;
	}

	/**
	 * @param setea
	 *            el parametro glosa al campo glosa
	 */
	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	/**
	 * @return el valor de glosaPorServicio
	 */
	@Column(name = "GLOSA_POR_SERVICIO", nullable = true)
	public Boolean getGlosaPorServicio() {
		if(glosaPorServicio==null)
			glosaPorServicio=false;
		return glosaPorServicio;
	}

	/**
	 * @param setea
	 *            el parametro glosaPorServicio al campo glosaPorServicio
	 */
	public void setGlosaPorServicio(Boolean glosaPorServicio) {
		this.glosaPorServicio = glosaPorServicio;
	}

	/**
	 * @return el valor de glosaEnCertificado
	 */
	@Column(name = "GLOSA_EN_CERTIFICADO", nullable = true)
	public Boolean getGlosaEnCertificado() {
		if(glosaEnCertificado==null)
			glosaEnCertificado=false;
		return glosaEnCertificado;
	}

	/**
	 * @param setea
	 *            el parametro glosaEnCertificado al campo glosaEnCertificado
	 */
	public void setGlosaEnCertificado(Boolean glosaEnCertificado) {
		this.glosaEnCertificado = glosaEnCertificado;
	}

	/**
	 * @return el valor de conductoresPorServicio
	 */
	@Column(name = "CONDUCTORES_POR_SERVICIO", nullable = true)
	public Boolean getConductoresPorServicio() {
		if(conductoresPorServicio==null)
			conductoresPorServicio=false;
		return conductoresPorServicio;
	}

	/**
	 * @param setea
	 *            el parametro conductoresPorServicio al campo
	 *            conductoresPorServicio
	 */
	public void setConductoresPorServicio(Boolean conductoresPorServicio) {
		this.conductoresPorServicio = conductoresPorServicio;
	}

	/**
	 * @return el valor de auxiliaresPorServicio
	 */
	@Column(name = "AUXILIARES_POR_SERVICIO", nullable = true)
	public Boolean getAuxiliaresPorServicio() {
		if(auxiliaresPorServicio==null)
			auxiliaresPorServicio=false;
		return auxiliaresPorServicio;
	}

	/**
	 * @param setea
	 *            el parametro auxiliaresPorServicio al campo
	 *            auxiliaresPorServicio
	 */
	public void setAuxiliaresPorServicio(Boolean auxiliaresPorServicio) {
		this.auxiliaresPorServicio = auxiliaresPorServicio;
	}

	/**
	 * @return el valor de glosaAuxiliar
	 */
	@ManyToOne(targetEntity = GlosaAuxiliar.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_GLOSA_AUXILIAR", nullable = true)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public GlosaAuxiliar getGlosaAuxiliar() {
		return glosaAuxiliar;
	}

	/**
	 * @param setea
	 *            el parametro glosaAuxiliar al campo glosaAuxiliar
	 */
	public void setGlosaAuxiliar(GlosaAuxiliar glosaAuxiliar) {
		this.glosaAuxiliar = glosaAuxiliar;
	}

	/**
	 * @return el valor de glosaAlVehiculo
	 */
	@Column(name = "GLOSA_AL_VEHICULO", nullable = true)
	public Boolean getGlosaAlVehiculo() {
		if(glosaAlVehiculo==null)
			glosaAlVehiculo=false;
		return glosaAlVehiculo;
	}

	/**
	 * @param setea
	 *            el parametro glosaAlVehiculo al campo glosaAlVehiculo
	 */
	public void setGlosaAlVehiculo(Boolean glosaAlVehiculo) {
		this.glosaAlVehiculo = glosaAlVehiculo;
	}

	@Transient
	public Boolean getMostrarGlosaAuxiliar() {
		if (this.glosaAuxiliar != null)
			return this.glosaAuxiliar.getGlosa().equals(GlosaAuxiliar.AUXILIAR);
		return true;
	}

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_TIPO_CANCELACION_TIPO_SERVICIO", joinColumns = { @JoinColumn(name = "ID_TIPO_SERVICIO") }, inverseJoinColumns = { @JoinColumn(name = "ID_TIPO_CANCELACION") })
	public List<TipoCancelacion> getTiposCancelacion() {
		return tiposCancelacion;
	}

	public void setTiposCancelacion(List<TipoCancelacion> tiposCancelacion) {
		this.tiposCancelacion = tiposCancelacion;
	}

	@Column(name = "HABILITAR_CONDUCTOR", nullable = true)
	public Boolean getHabilitarConductor() {
		if(habilitarConductor==null)
			habilitarConductor=false;
		return habilitarConductor;
	}

	public void setHabilitarConductor(Boolean habilitarConductor) {
		this.habilitarConductor = habilitarConductor;
	}

	@Column(name = "HABILITAR_AUXILIAR", nullable = true)
	public Boolean getHabilitarAuxiliar() {
		if(habilitarAuxiliar==null)
			habilitarAuxiliar=false;
		return habilitarAuxiliar;
	}

	public void setHabilitarAuxiliar(Boolean habilitarAuxiliar) {
		this.habilitarAuxiliar = habilitarAuxiliar;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cl.mtt.rnt.commons.model.core.GenericModelObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		TipoServicio ts = (TipoServicio) obj;
		try {
			return ts.getId().equals(this.getId());
		} catch (Exception e) {
			return false;
		}

	}

	/**
	 * @return el valor de habilitarPasajero
	 */
	@Column(name = "HABILITAR_PASAJERO", nullable = true)
	public Boolean getHabilitarPasajero() {
		if(habilitarPasajero==null)
			habilitarPasajero=false;
		return habilitarPasajero;
	}

	/**
	 * @param setea el parametro habilitarPasajero al campo habilitarPasajero
	 */
	public void setHabilitarPasajero(Boolean habilitarPasajero) {
		this.habilitarPasajero = habilitarPasajero;
	}

	/**
	 * @return el valor de pasajerosPorServicio
	 */
	@Column(name = "PASAJEROS_POR_SERVICIO", nullable = true)
	public Boolean getPasajerosPorServicio() {
		if(pasajerosPorServicio == null)
			pasajerosPorServicio = false;
		return pasajerosPorServicio;
	}

	/**
	 * @param setea el parametro pasajerosPorServicio al campo pasajerosPorServicio
	 */
	public void setPasajerosPorServicio(Boolean pasajerosPorServicio) {
		this.pasajerosPorServicio = pasajerosPorServicio;
	}

	/**
	 * @return el valor de permiteIngresoPeriodoVig
	 */
	@Column(name = "PERMITE_INGRESO_VIG_PERIODO", nullable = true)
	public Boolean getPermiteIngresoPeriodoVig() {
		if (permiteIngresoPeriodoVig==null)
			permiteIngresoPeriodoVig = false;
		return permiteIngresoPeriodoVig;
	}

	/**
	 * @param setea el parametro permiteIngresoPeriodoVig al campo permiteIngresoPeriodoVig
	 */
	public void setPermiteIngresoPeriodoVig(Boolean permiteIngresoPeriodoVig) {
		this.permiteIngresoPeriodoVig = permiteIngresoPeriodoVig;
	}

	
	// Mejoras 201409 Nro: 9
	/**
	 * @return el valor de permiteOficinaVenta
	 */
	@Column(name = "PERMITE_OFICINA_VENTA", nullable = true)
	public Boolean getPermiteOficinaVenta() {
		if(permiteOficinaVenta==null)
			permiteOficinaVenta=false;
		return permiteOficinaVenta;
	}

	/**
	 * @param setea el parametro permiteOficinaVenta al campo permiteOficinaVenta
	 */
	public void setPermiteOficinaVenta(Boolean permiteOficinaVenta) {
		this.permiteOficinaVenta = permiteOficinaVenta;
	}
    // Mejoras 201409 Nro: 9
	/**
	 * @return el valor de atributos
	 */
	// @ManyToMany(targetEntity= Atributo.class,fetch=FetchType.LAZY)
	// @JoinTable(name="RNT_TIPO_SERVICIO_ATRIBUTO",
	// joinColumns=@JoinColumn(name="ID_TIPO_SERVICIO"),inverseJoinColumns=@JoinColumn(name="ID_ATRIBUTO"))
	// // @Audited (targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	// public List<Atributo> getAtributos() {
	// return atributos;
	// }
	// /**
	// * @param setea el parametro atributos al campo atributos
	// */
	// public void setAtributos(List<Atributo> atributos) {
	// this.atributos = atributos;
	// }

	/**
	 * 
	 * @param tipoServicio
	 * @return
	 */
    public boolean tieneMismaCategoria(TipoServicio tipoServicio) {
        return this.getTipoTransporte().getId().equals(tipoServicio.getTipoTransporte().getId()) &&
                this.getMedioTransporte().getId().equals(tipoServicio.getMedioTransporte().getId()) &&
                this.getCategoriaTransporte().getId().equals(tipoServicio.getCategoriaTransporte().getId());
    }
	/**
	 * 
	 * @param tipoServicio
	 * @return
	 */
    public boolean tieneCategoria(CategoriaTransporteSeleccionble categoria) {
        return this.getTipoTransporte().getId().equals(categoria.getTipoTransporte().getId()) &&
                this.getMedioTransporte().getId().equals(categoria.getMedio().getId()) &&
                this.getCategoriaTransporte().getId().equals(categoria.getCategoria().getId());
    }
    
    @Transient
	public String getNombreCategoriaSeleccionableId() {
		return "" + this.getTipoTransporte().getDescriptor() + this.getMedioTransporte().getDescriptor() + this.getCategoriaTransporte().getDescriptor();
	}
    
    @Transient
    public CategoriaTransporteSeleccionble getNewCategoriaSeleccionable() {
    	CategoriaTransporteSeleccionble cts = new CategoriaTransporteSeleccionble();
    	cts.setCategoria(getCategoriaTransporte());
    	cts.setMedio(getMedioTransporte());
    	cts.setTipoTransporte(getTipoTransporte());
    	return cts;
    }

	/**
	 * @return el valor de conductoresPorAmbos
	 */
	@Column(name = "CONDUCTORES_POR_AMBOS", nullable = true)
	public Boolean getConductoresPorAmbos() {
		if(conductoresPorAmbos==null){
			conductoresPorAmbos=false;
		}
		return conductoresPorAmbos;
	}

	/**
	 * @param setea el parametro conductoresPorAmbos al campo conductoresPorAmbos
	 */
	public void setConductoresPorAmbos(Boolean conductoresPorAmbos) {
		if(conductoresPorAmbos==null){
			conductoresPorAmbos=false;
		}
		this.conductoresPorAmbos = conductoresPorAmbos;
	}
    
}
