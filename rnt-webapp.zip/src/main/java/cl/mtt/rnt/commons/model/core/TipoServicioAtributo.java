package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_TIPO_SERVICIO_ATRIBUTO")
public class TipoServicioAtributo extends GenericModelObject {

	private static final long serialVersionUID = 1384814600687802538L;

	private Boolean obligatorio;
	private Atributo atributo;
	// Mejoras 201409 Nro: 28
	private Boolean principal;
	// Mejoras 201409 Nro: 28
	private TipoServicio tipoServicio;

	/**
	 * @return el valor de obligatorio
	 */
	@Column(name = "OBLIGATORIO", nullable = false)
	public Boolean getObligatorio() {
		return obligatorio;
	}

	/**
	 * @param setea
	 *            el parametro obligatorio al campo obligatorio
	 */
	public void setObligatorio(Boolean obligatorio) {
		this.obligatorio = obligatorio;
	}

	/**
	 * @return el valor de atributo
	 */
	@ManyToOne(targetEntity = Atributo.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_ATRIBUTO")
	public Atributo getAtributo() {
		return atributo;
	}

	/**
	 * @param setea
	 *            el parametro atributo al campo atributo
	 */
	public void setAtributo(Atributo atributo) {
		this.atributo = atributo;
	}

	/**
	 * @return el valor de tipoServicio
	 */
	@ManyToOne(targetEntity = TipoServicio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_SERVICIO")
	public TipoServicio getTipoServicio() {
		return tipoServicio;
	}

	/**
	 * @param setea
	 *            el parametro tipoServicio al campo tipoServicio
	 */
	public void setTipoServicio(TipoServicio tipoServicio) {
		this.tipoServicio = tipoServicio;
	}
	
	// Mejoras 201409 Nro: 28
	@Column(name = "PRINCIPAL", nullable = true)
	public Boolean getPrincipal() {
		if(principal == null)
			principal = false;
		return principal;
	}

	public void setPrincipal(Boolean principal) {
		this.principal = principal;
	}

	
	
	// Mejoras 201409 Nro: 28

}
