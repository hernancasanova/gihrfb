package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_TIPO_TECNOLOGIA_GASES")
public class TipoTecnologiaGases extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private String nombre;
	private String descriptor;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}
}
