package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Transient;

import cl.mtt.rnt.commons.util.Resources;

public class TipoVia {
	
	
	public static TipoVia TIPO_VIA_CALLE = new TipoVia(
			Resources.getString("tipovia.prefijo.calle"),Resources.getString("tipovia.label.calle"));
	
	public static TipoVia TIPO_VIA_AVENIDA = new TipoVia(
			Resources.getString("tipovia.prefijo.av"),Resources.getString("tipovia.label.av"));
	
	public static TipoVia TIPO_VIA_AUTOPISTA = new TipoVia(
			Resources.getString("tipovia.prefijo.aut"),Resources.getString("tipovia.label.aut"));
	
	public static TipoVia TIPO_VIA_RUTA = new TipoVia(
			Resources.getString("tipovia.prefijo.ruta"),Resources.getString("tipovia.label.ruta"));

	public static TipoVia TIPO_VIA_LOCALIDAD = new TipoVia(
			Resources.getString("tipovia.prefijo.localidad"),Resources.getString("tipovia.label.localidad"));
	
	public static TipoVia TIPO_VIA_PASO_FRONTERIZO = new TipoVia(
			Resources.getString("tipovia.prefijo.pasoFronterizo"),Resources.getString("tipovia.label.pasoFronterizo"));
	
	private static List<TipoVia> allTipoVia; 
	private static Map<String,TipoVia> tipoViaMap; 
	
	private String tipoPrefijo;
	private String tipoLabel;
	
	
	public TipoVia() {
		super();
	}
	
	private TipoVia(String tipoPrefijo, String tipoLabel) {
		super();
		this.tipoPrefijo = tipoPrefijo;
		this.tipoLabel = tipoLabel;
	}
	/**
	 * @return el valor de tipoPrefijo
	 */
	public String getTipoPrefijo() {
		return tipoPrefijo;
	}
	/**
	 * @param setea el parametro tipoPrefijo al campo tipoPrefijo
	 */
	public void setTipoPrefijo(String tipoPrefijo) {
		this.tipoPrefijo = tipoPrefijo;
	}
	/**
	 * @return el valor de tipoLabel
	 */
	public String getTipoLabel() {
		return tipoLabel;
	}
	/**
	 * @param setea el parametro tipoLabel al campo tipoLabel
	 */
	public void setTipoLabel(String tipoLabel) {
		this.tipoLabel = tipoLabel;
	}
	
	/**
	 * 
	 * @return
	 */
	public static List<TipoVia> getAll() {
		if (TipoVia.allTipoVia == null) {
			allTipoVia = new ArrayList<TipoVia>();
			allTipoVia.add(TIPO_VIA_CALLE);
			allTipoVia.add(TIPO_VIA_AVENIDA);
			allTipoVia.add(TIPO_VIA_AUTOPISTA);
			allTipoVia.add(TIPO_VIA_RUTA);
			allTipoVia.add(TIPO_VIA_LOCALIDAD);
			allTipoVia.add(TIPO_VIA_PASO_FRONTERIZO);
		}
		return allTipoVia;
	}
	
	/**
	 * 
	 * @return
	 */
	public static Map<String,TipoVia> getTipoViaMap() {
		if (TipoVia.tipoViaMap == null) {
			tipoViaMap = new HashMap<String,TipoVia>();
			for (TipoVia tipoVia : allTipoVia) {
				tipoViaMap.put(tipoVia.tipoLabel, tipoVia);
			}
		}
		return tipoViaMap;
	}
	/**
	 * 
	 * @param calle1
	 * @return
	 */
	public static TipoVia resolve(String calle1) {
		if (calle1 == null) return null;
		String calle = new String(calle1.toUpperCase().trim());
		for (TipoVia tv : getAll()) {
			if (!tv.getTipoPrefijo().equals(TIPO_VIA_CALLE.getTipoPrefijo())) {
				if (calle.startsWith(tv.getTipoPrefijo())) {
					return tv;
				}
			}
		}
		return TIPO_VIA_CALLE;
	}

	@Transient
	public static String getPrefijo(String tipoVia) {
		return getTipoViaMap().get(tipoVia).getTipoPrefijo();
	}
	
	
	
}
