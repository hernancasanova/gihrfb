package cl.mtt.rnt.commons.model.core;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_TRAMITE")
public class Tramite extends GenericModelObject implements Comparable<Tramite> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2483432737649734432L;
	
	private String nombre;
	private Boolean contemplaValor;
	private MarcoGeografico marcoGeografico;
	private List<TipoServicio> tiposServicio;
	private List<Documentacion> documentacion;

	@Column(name = "CONTEMPLA_VALOR")
	public Boolean getContemplaValor() {
		if (contemplaValor==null) {
			contemplaValor=Boolean.FALSE;
		}
		return contemplaValor;
	}

	public void setContemplaValor(Boolean contemplaValor) {
		this.contemplaValor = contemplaValor;
	}

	@Column(name = "NOMBRE")
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	@ManyToOne(targetEntity = MarcoGeografico.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_MARCO_GEOGRAFICO", unique = true)
	public MarcoGeografico getMarcoGeografico() {
		return marcoGeografico;
	}

	public void setMarcoGeografico(MarcoGeografico marcoGeografico) {
		this.marcoGeografico = marcoGeografico;
	}

	@ManyToMany(targetEntity = TipoServicio.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_TRAMITE_TIPO_SERVICIO", joinColumns = @JoinColumn(name = "ID_TRAMITE"), inverseJoinColumns = @JoinColumn(name = "ID_TIPO_SERVICIO"))
	public List<TipoServicio> getTiposServicio() {
		return tiposServicio;
	}

	public void setTiposServicio(List<TipoServicio> tiposServicio) {
		this.tiposServicio = tiposServicio;
	}

	@ManyToMany(targetEntity = Documentacion.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_TRAMITE_DOCUMENTACION", joinColumns = @JoinColumn(name = "ID_TRAMITE"), inverseJoinColumns = @JoinColumn(name = "ID_DOCUMENTACION"))
	public List<Documentacion> getDocumentacion() {
		return documentacion;
	}

	public void setDocumentacion(List<Documentacion> documentacion) {
		this.documentacion = documentacion;
	}

	@Override
	public int compareTo(Tramite o) {
		 return this.getNombre().compareToIgnoreCase(o.getNombre()); 
	} 
}
