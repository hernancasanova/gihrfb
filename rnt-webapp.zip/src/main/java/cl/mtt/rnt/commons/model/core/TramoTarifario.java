package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

@Entity
@Table(name = "RNT_TRAMO_TARIFARIO")
@Audited
public class TramoTarifario extends GenericModelObject implements Anonymizable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3975275865777615553L;
	public static final String TIPO_INGRESO_VALOR = "VALOR";
	public static final String TIPO_INGRESO_RANGO = "RANGO";
	public static final String TIPO_INGRESO_MINIMO = "MINIMO";
	public static final String TIPO_INGRESO_MAXIMO = "MAXIMO";

	private Tarifa tarifa;
	private String nombre;
	private String horaDesde;
	private String horaHasta;
	private List<ItemMatrizTarifaria> itemsMatrizTarifaria;
	private List<ItemTramoTarifario> itemsTramoTarifario;

	private PublicoObjetivo publicoObjetivo;
	private String tipoIngreso;

	private Map<String, ItemMatrizTarifaria> mapaItemMatrizTarifaria;
	
	@ManyToOne(targetEntity = Tarifa.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TARIFA")
	public Tarifa getTarifa() {
		return tarifa;
	}

	public void setTarifa(Tarifa tarifa) {
		this.tarifa = tarifa;
	}

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "HORA_DESDE", nullable = true)
	public String getHoraDesde() {
		return horaDesde;
	}

	public void setHoraDesde(String horaDesde) {
		this.horaDesde = horaDesde;
	}

	@Column(name = "HORA_HASTA", nullable = true)
	public String getHoraHasta() {
		return horaHasta;
	}

	public void setHoraHasta(String horaHasta) {
		this.horaHasta = horaHasta;
	}

	@ManyToOne(targetEntity = PublicoObjetivo.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PUBLICO_OBJETIVO")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public PublicoObjetivo getPublicoObjetivo() {
		return publicoObjetivo;
	}

	public void setPublicoObjetivo(PublicoObjetivo publicoObjetivo) {
		this.publicoObjetivo = publicoObjetivo;
	}

	@Column(name = "TIPO_INGRESO", nullable = true)
	public String getTipoIngreso() {
		return tipoIngreso;
	}

	public void setTipoIngreso(String tipoIngreso) {
		this.tipoIngreso = tipoIngreso;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = ItemMatrizTarifaria.class, mappedBy = "tramoTarifario")
	public List<ItemMatrizTarifaria> getItemsMatrizTarifaria() {
		return itemsMatrizTarifaria;
	}

	public void setItemsMatrizTarifaria(List<ItemMatrizTarifaria> itemsMatrizTarifaria) {
		this.itemsMatrizTarifaria = itemsMatrizTarifaria;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = ItemTramoTarifario.class, mappedBy = "tramoTarifario")
	public List<ItemTramoTarifario> getItemsTramoTarifario() {
		return itemsTramoTarifario;
	}

	public void setItemsTramoTarifario(List<ItemTramoTarifario> itemsTramoTarifario) {
		this.itemsTramoTarifario = itemsTramoTarifario;
	}

	@Override
	public TramoTarifario clone() throws CloneNotSupportedException {
		TramoTarifario tt = new TramoTarifario();
		tt.setCreation(this.getCreation());
		tt.setDbAction(this.getDbAction());
		if (this.getHoraDesde() != null)
			tt.setHoraDesde(new String(this.getHoraDesde()));
		if (this.getHoraHasta() != null)
			tt.setHoraHasta(new String(this.getHoraHasta()));
		tt.setTipoIngreso(new String(this.getTipoIngreso()));
		tt.setPublicoObjetivo(this.getPublicoObjetivo());
		if (this.getId() != null)
			tt.setId(new Long(this.getId()));
		if (this.getItemsMatrizTarifaria() != null) {
			tt.setItemsMatrizTarifaria(new ArrayList<ItemMatrizTarifaria>());
			for (ItemMatrizTarifaria itemMatrizTarifaria : this.getItemsMatrizTarifaria()) {
				ItemMatrizTarifaria imt = itemMatrizTarifaria.clone();
				imt.setTramoTarifario(tt);
				tt.getItemsMatrizTarifaria().add(imt);
			}
		} else
			tt.setItemsMatrizTarifaria(null);
		if (this.getItemsTramoTarifario() != null) {
			tt.setItemsTramoTarifario(new ArrayList<ItemTramoTarifario>());
			for (ItemTramoTarifario itemTramoTarifario : this.getItemsTramoTarifario()) {
				ItemTramoTarifario imt = itemTramoTarifario.clone();
				imt.setTramoTarifario(tt);
				tt.getItemsTramoTarifario().add(imt);
			}
		} else
			tt.setItemsTramoTarifario(null);
		tt.setModified(this.getModified());
		tt.setNombre(new String(this.getNombre()));
		tt.setUserCreation(this.getUserCreation());
		tt.setUserModified(this.getUserModified());

		return tt;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);

		for (ItemMatrizTarifaria item : itemsMatrizTarifaria) {
			item.anonimize();
		}
		for (ItemTramoTarifario item : itemsTramoTarifario) {
			item.anonimize();
		}

	}

	@Transient
	public Map<String, ItemMatrizTarifaria> getMapaItemMatrizTarifaria() {
		return mapaItemMatrizTarifaria;
	}

	public void setMapaItemMatrizTarifaria(
			Map<String, ItemMatrizTarifaria> mapaItemMatrizTarifaria) {
		this.mapaItemMatrizTarifaria = mapaItemMatrizTarifaria;
	}

	
}