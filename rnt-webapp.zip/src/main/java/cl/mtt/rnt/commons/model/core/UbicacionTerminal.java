package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_UBICACION_TERMINAL")
public class UbicacionTerminal extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	// Mejoras 201409 Nro: 93
	public static final String SIGLA_VP="VP";
	public static final String SIGLA_FVP="FVP"; 
	public static final String SIGLA_AEROPUERTO="AEROPUERTO";
	// Mejoras 201409 Nro: 93
	
	private String nombre;
	private String sigla;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	// Mejoras 201409 Nro: 93
	@Column(name = "SIGLA", nullable = false)
	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	// Mejoras 201409 Nro: 93
}