package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.Hibernate;
import org.hibernate.annotations.BatchSize;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import cl.mtt.rnt.commons.model.converter.RutConverter;
import cl.mtt.rnt.commons.util.validator.PPUValidator;

@Entity
@Table(name = "RNT_VEHICULO")
@Audited
public class Vehiculo extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5490009295416841951L;

	private String ppu;	
	private String digitoVerificador;
	private Integer tipoVehiculo;
	private Integer anioFabricacion;
	private String marca;
	private String modelo;
	private String color;
	private String numeroMotor;
	private String numeroChasis;
	private String numeroSerie;
	private String numeroVin;
	private String tipoCombustible;
	private String seguro;
	private String pesoBruto;
	
	private boolean tieneDatosRegistroCivil;
	private boolean tieneDatosRevisionTecnica;
	private Adquisicion adquisicion;
	private RevisionTecnica revisionTecnica;
	private List<SubInscripcionVehiculo> subinscripciones;
	private List<LimitacionVehiculo> limitaciones;
	private List<Adquisicion> adquisicionesAnteriores;

	private String nombreTipoVehiculo;

	private List<AtributoInstancia> atributosInstancia;
	
	// Mejoras 201409 Nro: 51
	private Date fechaIngreso;
	// Mejoras 201409 Nro: 51

	private boolean haCambiadoPropietario;
	private boolean hanCambiadoDatos;
	
	
	private boolean canceladoRc;
	private String cancelacionRc;


	private List<VehiculoServicio> vehiculosServicio;
	
	@Column(name = "PPU", nullable = false)
	public String getPpu() {
		return ppu;
	}

	public void setPpu(String ppu) {
		this.ppu = ppu;
	}
	
	
	@Column(name = "DIGITO_VERIFICADOR", nullable = true)
	public String getDigitoVerificador() {
		return digitoVerificador;
	}

	public void setDigitoVerificador(String digitoVerificador) {
		this.digitoVerificador = digitoVerificador;
	}

	@Column(name = "TIPO_VEHICULO", nullable = false)
	public Integer getTipoVehiculo() {
		return tipoVehiculo;
	}

	public void setTipoVehiculo(Integer tipoVehiculo) {
		this.tipoVehiculo = tipoVehiculo;
	}

	@Column(name = "ANIO_FABRICACION", nullable = true)
	public Integer getAnioFabricacion() {
		return anioFabricacion;
	}

	public void setAnioFabricacion(Integer anioFabricacion) {
		this.anioFabricacion = anioFabricacion;
	}

	@Column(name = "MARCA", nullable = true)
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	@Column(name = "MODELO", nullable = true)
	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	@Column(name = "COLOR", nullable = true)
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Column(name = "NUMERO_MOTOR", nullable = true)
	public String getNumeroMotor() {
		return numeroMotor;
	}

	public void setNumeroMotor(String numeroMotor) {
		this.numeroMotor = numeroMotor;
	}

	@Column(name = "NUMERO_CHASIS", nullable = true)
	public String getNumeroChasis() {
		return numeroChasis;
	}

	public void setNumeroChasis(String numeroChasis) {
		this.numeroChasis = numeroChasis;
	}

	@Column(name = "NUMERO_SERIE", nullable = true)
	public String getNumeroSerie() {
		return numeroSerie;
	}

	public void setNumeroSerie(String numeroSerie) {
		this.numeroSerie = numeroSerie;
	}

	@Column(name = "NUMERO_VIN", nullable = true)
	public String getNumeroVin() {
		return numeroVin;
	}

	public void setNumeroVin(String numeroVin) {
		this.numeroVin = numeroVin;
	}

	@Column(name = "TIPO_COMBUSTIBLE", nullable = true)
	public String getTipoCombustible() {
		return tipoCombustible;
	}

	public void setTipoCombustible(String tipoCombustible) {
		this.tipoCombustible = tipoCombustible;
	}

	@Column(name = "SEGURO", nullable = true)
	public String getSeguro() {
		return seguro;
	}

	public void setSeguro(String seguro) {
		this.seguro = seguro;
	}

	/**
	 * @return el valor de tieneDatosRegistroCivil
	 */
	@Column(name = "DATOS_RC", nullable = true)
	public boolean isTieneDatosRegistroCivil() {
		return tieneDatosRegistroCivil;
	}

	/**
	 * @param setea
	 *            el parametro tieneDatosRegistroCivil al campo
	 *            tieneDatosRegistroCivil
	 */
	public void setTieneDatosRegistroCivil(boolean tieneDatosRegistroCivil) {
		this.tieneDatosRegistroCivil = tieneDatosRegistroCivil;
	}

	/**
	 * @return el valor de tieneDatosRevisionTecnica
	 */
	@Column(name = "DATOS_RT", nullable = true)
	public boolean isTieneDatosRevisionTecnica() {
		return tieneDatosRevisionTecnica;
	}

	/**
	 * @param setea
	 *            el parametro tieneDatosRevisionTecnica al campo
	 *            tieneDatosRevisionTecnica
	 */
	public void setTieneDatosRevisionTecnica(boolean tieneDatosRevisionTecnica) {
		this.tieneDatosRevisionTecnica = tieneDatosRevisionTecnica;
	}

	// /**
	// * @return el valor de propietario
	// */
	// @ManyToOne(targetEntity=Propietario.class,fetch=FetchType.EAGER)
	// @JoinColumn(name="ID_PROPIETARIO")
	// public Propietario getPropietario() {
	// return propietario;
	// }
	// /**
	// * @param setea el parametro propietario al campo propietario
	// */
	// public void setPropietario(Propietario propietario) {
	// this.propietario = propietario;
	// }

	/**
	 * @return el valor de adquisicion
	 */
	@ManyToOne(targetEntity = Adquisicion.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_ADQUISICION")
	@BatchSize (size = 20)
	public Adquisicion getAdquisicion() {
		return adquisicion;
	}

	/**
	 * @param setea
	 *            el parametro adquisicion al campo adquisicion
	 */
	public void setAdquisicion(Adquisicion adquisicion) {
		this.adquisicion = adquisicion;
	}

	/**
	 * @return el valor de revisionTecnica
	 */
	@ManyToOne(targetEntity = RevisionTecnica.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_REVISION_TECNICA")
	public RevisionTecnica getRevisionTecnica() {
		return revisionTecnica;
	}

	/**
	 * @param setea
	 *            el parametro revisionTecnica al campo revisionTecnica
	 */
	public void setRevisionTecnica(RevisionTecnica revisionTecnica) {
		this.revisionTecnica = revisionTecnica;
	}

	/**
	 * @return el valor de subinscripciones
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = SubInscripcionVehiculo.class, mappedBy = "vehiculo", cascade = { CascadeType.ALL }, orphanRemoval = true)
	@NotAudited
	public List<SubInscripcionVehiculo> getSubinscripciones() {
		return subinscripciones;
	}

	/**
	 * @param setea
	 *            el parametro subinscripciones al campo subinscripciones
	 */
	public void setSubinscripciones(List<SubInscripcionVehiculo> subinscripciones) {
		this.subinscripciones = subinscripciones;		
	}

	/**
	 * @return el valor de limitaciones
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = LimitacionVehiculo.class, mappedBy = "vehiculo", cascade = { CascadeType.ALL }, orphanRemoval = true)
	@NotAudited
	public List<LimitacionVehiculo> getLimitaciones() {
		if(limitaciones==null) this.limitaciones = new ArrayList<LimitacionVehiculo>();
		return limitaciones;
	}

	/**
	 * @param setea
	 *            el parametro limitaciones al campo limitaciones
	 */
	public void setLimitaciones(List<LimitacionVehiculo> limitaciones) {
		if(this.limitaciones==null && limitaciones!=null)
			this.limitaciones = limitaciones;		
		else if(this.limitaciones==null && limitaciones==null)
			this.limitaciones = new ArrayList<LimitacionVehiculo>();
		else if(this.limitaciones!=null && limitaciones!=null){
			if (Hibernate.isInitialized(this.limitaciones) && !limitaciones.isEmpty()) {
				this.limitaciones.clear();
				this.limitaciones.addAll(limitaciones);
			}
			else {
				this.limitaciones = limitaciones;
			}
		} else if(this.limitaciones!=null && limitaciones==null)
			if (Hibernate.isInitialized(this.limitaciones)) {
				this.limitaciones.clear();
			}
	}

	// /**
	// * @return el valor de propAnteriores
	// */
	// @Transient
	// public List<Propietario> getPropAnteriores() {
	// return propAnteriores;
	// }
	// /**
	// * @param setea el parametro propAnteriores al campo propAnteriores
	// */
	// public void setPropAnteriores(List<Propietario> propAnteriores) {
	// this.propAnteriores = propAnteriores;
	// }

	@Transient
	/**
	 * @return el valor de adquisicionesAnteriores
	 */
	public List<Adquisicion> getAdquisicionesAnteriores() {
		return adquisicionesAnteriores;
	}

	/**
	 * @param setea
	 *            el parametro adquisicionesAnteriores al campo
	 *            adquisicionesAnteriores
	 */
	public void setAdquisicionesAnteriores(List<Adquisicion> adquisicionesAnteriores) {
		this.adquisicionesAnteriores = adquisicionesAnteriores;
	}

	@Transient
	public String getNombreTipoVehiculo() {
		return nombreTipoVehiculo;
	}

	public void setNombreTipoVehiculo(String nombreTipoVehiculo) {
		this.nombreTipoVehiculo = nombreTipoVehiculo;
	}

	/**
	 * @return el valor de atributosInstancia
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = AtributoInstancia.class, mappedBy = "vehiculo")
	@NotAudited
	public List<AtributoInstancia> getAtributosInstancia() {
		return atributosInstancia;
	}

	/**
	 * @param setea
	 *            el parametro atributosInstancia al campo atributosInstancia
	 */
	public void setAtributosInstancia(List<AtributoInstancia> atributosInstancia) {
		this.atributosInstancia = atributosInstancia;
	}

	@Transient
	public Integer getAntiguedad() {
		return Calendar.getInstance().get(Calendar.YEAR) - this.getAnioFabricacion();
	}


	public Integer getAntiguedadAlaFecha(Date fecha) {
		Calendar c = new GregorianCalendar();
		c.setTime(fecha);
		return c.get(Calendar.YEAR) - this.getAnioFabricacion();
	}
	
	@Transient
	public String getGlosaPropietariosShort() {
		if (getAdquisicion() == null || getAdquisicion().getPropietarios() == null || getAdquisicion().getPropietarios().size() == 0)
			return null;
		if (getAdquisicion().getPropietarios().size() == 1)
			return getAdquisicion().getPropietarios().get(0).getPersona().getRut();
		return getAdquisicion().getPropietarios().get(0).getPersona().getRut() + "...";
	}

	@Transient
	public String getGlosaPropietarios() {
		if (getAdquisicion() == null || getAdquisicion().getPropietarios() == null || getAdquisicion().getPropietarios().size() == 0)
			return null;
		String ret = "<ul>";
		for (Propietario prop : getAdquisicion().getPropietarios()) {
			ret += "<li type=\"none\">" + prop.getPersona().getNombre() + " - " + RutConverter.convertRut(prop.getPersona().getRut()) + "</li>";
		}
		return ret + "</ul>";
	}

	@Transient
	public boolean isEditable() {
		return this.getId() == null && !this.tieneDatosRegistroCivil;
	}
	
	@Transient
	public String getPpuCompleta(){
		if(digitoVerificador==null || "".equals(digitoVerificador))
			digitoVerificador = PPUValidator.getDigitoVerificador(ppu);
		return ppu+"-"+digitoVerificador;
	}
	
	@Column(name = "FECHA_INGRESO", nullable = true)
	public Date getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	@Transient
	public boolean isHaCambiadoPropietario() {
		return haCambiadoPropietario;
	}

	public void setHaCambiadoPropietario(boolean haCambiadoPropietario) {
		this.haCambiadoPropietario = haCambiadoPropietario;
	}

	@Transient
	public boolean isHanCambiadoDatos() {
		return hanCambiadoDatos;
	}

	public void setHanCambiadoDatos(boolean hanCambiadoDatos) {
		this.hanCambiadoDatos = hanCambiadoDatos;
	}

	/**
	 * @return el valor de vehiculoServicio
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = VehiculoServicio.class, mappedBy = "vehiculo")
	public List<VehiculoServicio> getVehiculosServicio() {
		return vehiculosServicio;
	}

	/**
	 * @param setea el parametro vehiculoServicio al campo vehiculoServicio
	 */
	public void setVehiculosServicio(List<VehiculoServicio> vehiculosServicio) {
		this.vehiculosServicio = vehiculosServicio;
	}

    /**
     * @return el valor de canceladoRc
     */
	@Transient
    public boolean isCanceladoRc() {
        return canceladoRc;
    }

    /**
     * @param setea el parametro canceladoRc al campo canceladoRc
     */
    public void setCanceladoRc(boolean canceladoRc) {
        this.canceladoRc = canceladoRc;
    }

    /**
     * @return el valor de cancelacionRc
     */
    @Transient
    public String getCancelacionRc() {
        return cancelacionRc;
    }

    /**
     * @param setea el parametro cancelacionRc al campo cancelacionRc
     */
    public void setCancelacionRc(String cancelacionRc) {
        this.cancelacionRc = cancelacionRc;
    }

	/**
	 * @return el valor de pesoBruto
	 */
	@Column(name = "PESO_BRUTO", nullable = true)
	public String getPesoBruto() {
		return pesoBruto;
	}

	/**
	 * @param setea el parametro pesoBruto al campo pesoBruto
	 */
	public void setPesoBruto(String pesoBruto) {
		this.pesoBruto = pesoBruto;
	}
    

	
}
