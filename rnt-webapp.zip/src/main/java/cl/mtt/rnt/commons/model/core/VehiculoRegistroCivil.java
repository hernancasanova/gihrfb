package cl.mtt.rnt.commons.model.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "REGISTROCIVIL")
public class VehiculoRegistroCivil implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5490009145416841951L;

	private String ppu;
	private String placaDig;
	private String marca;
	private String modelo;
	private String color;
	private String resColor;
	private String tipoVehiculo;
	private String rutProp;
	private String digVerRutProp;
	private String apePaternoProp;  
	private String apeMaternoProp;
	private String nombreProps;
	private Integer anioFabricacion;
	private String motor;
	private String chasis;
	private String fechaNacProp;
	private String nomMadreProp;
	private String ppuColor;
	private String direccionProp;
	private String comunaProp;
	private String fechaUlt;
	private String fecha2;
	private String dirNumeroProp;
	private String dirRestoProp;

   

    /**
     * @return el valor de ppu
     */
    @Id
    @Column(name = "PLACA_PATENTE", updatable=false, insertable=false)
    public String getPpu() {
        return ppu;
    }
    /**
     * @param setea el parametro ppu al campo ppu
     */
    public void setPpu(String ppu) {
        this.ppu = ppu;
    }
    /**
     * @return el valor de placaDig
     */
    @Column(name = "PLACA_DIG", updatable=false, insertable=false)
    public String getPlacaDig() {
        return placaDig;
    }
    /**
     * @param setea el parametro placaDig al campo placaDig
     */
    public void setPlacaDig(String placaDig) {
        this.placaDig = placaDig;
    }
    /**
     * @return el valor de marca
     */
    @Column(name = "MARCA", updatable=false, insertable=false)
    public String getMarca() {
        return marca;
    }
    /**
     * @param setea el parametro marca al campo marca
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }
    /**
     * @return el valor de modelo
     */
    @Column(name = "MODELO", updatable=false, insertable=false)
    public String getModelo() {
        return modelo;
    }
    /**
     * @param setea el parametro modelo al campo modelo
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    /**
     * @return el valor de color
     */
    @Column(name = "COLOR", updatable=false, insertable=false)
    public String getColor() {
        return color;
    }
    /**
     * @param setea el parametro color al campo color
     */
    public void setColor(String color) {
        this.color = color;
    }
    /**
     * @return el valor de resColor
     */
    @Column(name = "RESCOLOR", updatable=false, insertable=false)
    public String getResColor() {
        return resColor;
    }
    /**
     * @param setea el parametro resColor al campo resColor
     */
    public void setResColor(String resColor) {
        this.resColor = resColor;
    }
    /**
     * @return el valor de tipoVehiculo
     */
    @Column(name = "TIPO", updatable=false, insertable=false)
    public String getTipoVehiculo() {
        return tipoVehiculo;
    }
    /**
     * @param setea el parametro tipoVehiculo al campo tipoVehiculo
     */
    public void setTipoVehiculo(String tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }
   
    /**
     * @return el valor de rutProp
     */
    @Column(name = "RUT", updatable=false, insertable=false)
    public String getRutProp() {
        return rutProp;
    }
    /**
     * @param setea el parametro rutProp al campo rutProp
     */
    public void setRutProp(String rutProp) {
        this.rutProp = rutProp;
    }
    /**
     * @return el valor de apePaternoProp
     */
    @Column(name = "PATERNO", updatable=false, insertable=false)
    public String getApePaternoProp() {
        return apePaternoProp;
    }
        
    /**
     * @param setea el parametro apePaternoProp al campo apePaternoProp
     */
    public void setApePaternoProp(String apePaternoProp) {
        this.apePaternoProp = apePaternoProp;
    }
    /**
     * @return el valor de apeMaternoProp
     */
    @Column(name = "MATERNO", updatable=false, insertable=false)
    public String getApeMaternoProp() {
        return apeMaternoProp;
    }
    /**
     * @param setea el parametro apeMaternoProp al campo apeMaternoProp
     */
    public void setApeMaternoProp(String apeMaternoProp) {
        this.apeMaternoProp = apeMaternoProp;
    }
    /**
     * @return el valor de nombreProps
     */
    @Column(name = "NOMBRES", updatable=false, insertable=false)
    public String getNombreProps() {
        return nombreProps;
    }
    /**
     * @param setea el parametro nombreProps al campo nombreProps
     */
    public void setNombreProps(String nombreProps) {
        this.nombreProps = nombreProps;
    }
    /**
     * @return el valor de anioFabricacion
     */
    @Column(name = "YEAR_FABRICACION", updatable=false, insertable=false)
    public Integer getAnioFabricacion() {
        return anioFabricacion;
    }
    /**
     * @param setea el parametro anioFabricacion al campo anioFabricacion
     */
    public void setAnioFabricacion(Integer anioFabricacion) {
        this.anioFabricacion = anioFabricacion;
    }

    
    
    /**
     * @return el valor de motor
     */
    @Column(name = "MOTOR", updatable=false, insertable=false)
    public String getMotor() {
        return motor;
    }
    /**
     * @param setea el parametro motor al campo motor
     */
    public void setMotor(String motor) {
        this.motor = motor;
    }
    /**
     * @return el valor de chasis
     */
    @Column(name = "CHASIS", updatable=false, insertable=false)
    public String getChasis() {
        return chasis;
    }
    /**
     * @param setea el parametro chasis al campo chasis
     */
    public void setChasis(String chasis) {
        this.chasis = chasis;
    }
    /**
     * @return el valor de fechaNacProp
     */
    @Column(name = "FECHA_NAC", updatable=false, insertable=false)
    public String getFechaNacProp() {
        return fechaNacProp;
    }
    /**
     * @param setea el parametro fechaNacProp al campo fechaNacProp
     */
    public void setFechaNacProp(String fechaNacProp) {
        this.fechaNacProp = fechaNacProp;
    }
    /**
     * @return el valor de nomMadreProp
     */
    @Column(name = "NOM_MADRE", updatable=false, insertable=false)
    public String getNomMadreProp() {
        return nomMadreProp;
    }
    /**
     * @param setea el parametro nomMadreProp al campo nomMadreProp
     */
    public void setNomMadreProp(String nomMadreProp) {
        this.nomMadreProp = nomMadreProp;
    }
    /**
     * @return el valor de ppuColor
     */
    @Column(name = "PPU_COLOR", updatable=false, insertable=false)
    public String getPpuColor() {
        return ppuColor;
    }
    /**
     * @param setea el parametro ppuColor al campo ppuColor
     */
    public void setPpuColor(String ppuColor) {
        this.ppuColor = ppuColor;
    }

    /**
     * @return el valor de direccionProp
     */
    @Column(name = "DIR", updatable=false, insertable=false)
    public String getDireccionProp() {
        return direccionProp;
    }
    /**
     * @param setea el parametro direccionProp al campo direccionProp
     */
    public void setDireccionProp(String direccionProp) {
        this.direccionProp = direccionProp;
    }
    /**
     * @return el valor de comunaProp
     */
    @Column(name = "FECHA_ULT", updatable=false, insertable=false)
    public String getComunaProp() {
        return comunaProp;
    }
    /**
     * @param setea el parametro comunaProp al campo comunaProp
     */
    public void setComunaProp(String comunaProp) {
        this.comunaProp = comunaProp;
    }
    /**
     * @return el valor de fechaUlt
     */
    @Column(name = "COMUNA", updatable=false, insertable=false)
    public String getFechaUlt() {
        return fechaUlt;
    }
    /**
     * @param setea el parametro fechaUlt al campo fechaUlt
     */
    public void setFechaUlt(String fechaUlt) {
        this.fechaUlt = fechaUlt;
    }
    /**
     * @return el valor de fecha2
     */
    @Column(name = "FECHA2", updatable=false, insertable=false)
    public String getFecha2() {
        return fecha2;
    }
    /**
     * @param setea el parametro fecha2 al campo fecha2
     */
    public void setFecha2(String fecha2) {
        this.fecha2 = fecha2;
    }
    /**
     * @return el valor de dirNumeroProp
     */
    @Column(name = "DIR_NUMERO", updatable=false, insertable=false)
    public String getDirNumeroProp() {
        return dirNumeroProp;
    }
    /**
     * @param setea el parametro dirNumeroProp al campo dirNumeroProp
     */
    public void setDirNumeroProp(String dirNumeroProp) {
        this.dirNumeroProp = dirNumeroProp;
    }
    /**
     * @return el valor de dirRestoProp
     */
    @Column(name = "DIR_RESTO", updatable=false, insertable=false)
    public String getDirRestoProp() {
        return dirRestoProp;
    }
    /**
     * @param setea el parametro dirRestoProp al campo dirRestoProp
     */
    public void setDirRestoProp(String dirRestoProp) {
        this.dirRestoProp = dirRestoProp;
    }
    
    /**
     * @return el valor de digVerRutProp
     */
     @Column(name = "DIG_VER", updatable=false, insertable=false)
    public String getDigVerRutProp() {
        return digVerRutProp;
    }
    /**
     * @param setea el parametro digVerRutProp al campo digVerRutProp
     */
    public void setDigVerRutProp(String digVerRutProp) {
        this.digVerRutProp = digVerRutProp;
    }
	
	
	
}
