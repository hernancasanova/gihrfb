package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;
import org.hibernate.annotations.BatchSize;
import org.hibernate.envers.AuditMappedBy;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.util.CampoDecorator;
import cl.mtt.rnt.commons.util.ElResolver;
import cl.mtt.rnt.commons.util.GlosaCampoDecorator;
import cl.mtt.rnt.commons.util.PermisoProvisorioTransient;
import cl.mtt.rnt.commons.util.TituloCampoDecorator;
import cl.mtt.rnt.encargado.bean.ServicioPPUBean;

@Entity
@Table(name = "RNT_VEHICULO_SERVICIO")
@Audited
public class VehiculoServicio extends GenericAuditCancellableModelObject implements Anonymizable {

	public static final int GENERAR_CERTIFICADO_NO_ACCION = 0;
	public static final int GENERAR_CERTIFICADO_MODIFICACION = 1;
	public static final int GENERAR_CERTIFICADO_CANCELACION = 2;
	public static final int ELIMINAR_CERTIFICADO_VIGENTE = 3;

	/**
	 * 
	 */
	private static final long serialVersionUID = 5490009295416841951L;

	private Vehiculo vehiculo;
	
	private Vehiculo vehiculoWs;
	
	private TipoIngresoVehiculo tipoIngreso;
	private VehiculoServicio reemplaza;
	private VehiculoServicio reemplazado;
	private Date fechaOtorgamientoLogo;
	private Servicio servicio;
	private String observacion;
	private Boolean cancelarEnReemplazo = false;
	private Boolean cancelarObligatorio = false;
	private Integer respuestaFirmador;
	private String mensajeFirmador;
	private Reglamentacion reglamentacion;
	private String nroLineaAud;
    private Long idVehiculoServicioReemplaza;
    private Long idVehiculoServicioReemplazado;
	// private boolean debeImprimirCertificado = false;
	// private TipoCertificado tipoCertificadoImprimir = null;

	private Date fechaIngreso;

	private List<ConductorVehiculo> conductoresVehiculo;
	private Boolean tieneCertificadoProvisorio;

	private Recorrido recorridoACertificar;

	private Zona zonaVehiculo;

	private PermisoProvisorioTransient permisoProvisorioTransient;
	private int generarCertificado = GENERAR_CERTIFICADO_NO_ACCION;
	private List<Recorrido> recorridosACertificar = new ArrayList<Recorrido>();
	
	private List<Pasajero> pasajeros;
	
	//para el ingreso con autorizacion - transient
	private List<AutorizacionMovimiento> autorizacionesMovimiento;
	private List<String> diferencias;
	private Date fechaVencimiento;
	private Date fechaIngresoServicio;

	private Date fechaOtorgamientoBeneficio;
	private Date fechaPostulacion;
	
	private DocumentoBiblioteca documentoCancelacion;
	private DocumentoBiblioteca documentoInscripcion;
	private DocumentoBiblioteca documentoReversionMovimiento;
	
	private Long idReglamentacion;
	
	private boolean tieneCertificadoMigrado = false;
	private List<PeriodoVigencia> periodosVigencia;

	
	/**
	 * @return el valor de vehiculo
	 */
	@ManyToOne(targetEntity = Vehiculo.class, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_VEHICULO")
	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	/**
	 * @param setea
	 *            el parametro vehiculo al campo vehiculo
	 */
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	/**
	 * @return el valor de tipoIngreso
	 */
	@ManyToOne(targetEntity = TipoIngresoVehiculo.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_INGRESO")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@BatchSize (size = 50)
	public TipoIngresoVehiculo getTipoIngreso() {
		return tipoIngreso;
	}

	/**
	 * @param setea
	 *            el parametro tipoIngreso al campo tipoIngreso
	 */
	public void setTipoIngreso(TipoIngresoVehiculo tipoIngreso) {
		this.tipoIngreso = tipoIngreso;
	}

	/**
	 * @return el valor de reemplaza
	 */
	@ManyToOne(targetEntity = VehiculoServicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_VEHICULO_REEMPLAZA")
	public VehiculoServicio getReemplaza() {
		return reemplaza;
	}

	/**
	 * @param setea
	 *            el parametro reemplaza al campo reemplaza
	 */
	public void setReemplaza(VehiculoServicio reemplaza) {
		this.reemplaza = reemplaza;
	}

	/**
	 * @return el valor de reemplazado
	 */
	@ManyToOne(targetEntity = VehiculoServicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_VEHICULO_REEMPLAZADO")
	public VehiculoServicio getReemplazado() {
		return reemplazado;
	}

	/**
	 * @param setea
	 *            el parametro reemplazado al campo reemplazado
	 */
	public void setReemplazado(VehiculoServicio reemplazado) {
		this.reemplazado = reemplazado;
	}

	/**
	 * @return el valor de fechaOtorgamientoLogo
	 */
	@Column(name = "FECHA_LOGO", nullable = true)
	public Date getFechaOtorgamientoLogo() {
		return fechaOtorgamientoLogo;
	}

	/**
	 * @param setea
	 *            el parametro fechaOtorgamientoLogo al campo
	 *            fechaOtorgamientoLogo
	 */
	public void setFechaOtorgamientoLogo(Date fechaOtorgamientoLogo) {
		this.fechaOtorgamientoLogo = fechaOtorgamientoLogo;
	}

	/**
	 * @return el valor de servicio
	 */
	@ManyToOne(targetEntity = Servicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SERVICIO")
	public Servicio getServicio() {
		return servicio;
	}

	/**
	 * @param setea
	 *            el parametro servicio al campo servicio
	 */
	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}

	/**
	 * @return el valor de nuevotipoIngreso
	 */
	@Transient
	public boolean isNuevotipoIngreso() {
		if (this.getTipoIngreso().getDescriptor().equals(TipoIngresoVehiculo.NUEVO_DESCRIPTOR)) {
			return true;
		}
		return false;
	}

	@OneToMany(targetEntity = ConductorVehiculo.class, mappedBy = "vehiculoServicio", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@BatchSize (size = 50)
	@AuditMappedBy(mappedBy = "vehiculoServicio")
	public List<ConductorVehiculo> getConductoresVehiculo() {
		return conductoresVehiculo;
	}

	public void setConductoresVehiculo(List<ConductorVehiculo> conductoresVehiculo) {
		this.conductoresVehiculo = conductoresVehiculo;
	}

	/**
	 * @return el valor de observacion
	 */
	@Column(name = "OBSERVACION")
	public String getObservacion() {
		return observacion;
	}

	/**
	 * @param setea
	 *            el parametro observacion al campo observacion
	 */
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	/**
	 * @return el valor de cancelarEnReemplazo
	 */
	@Transient
	public Boolean getCancelarEnReemplazo() {
		return cancelarEnReemplazo;
	}

	/**
	 * @param setea
	 *            el parametro cancelarEnReemplazo al campo cancelarEnReemplazo
	 */
	public void setCancelarEnReemplazo(Boolean cancelarEnReemplazo) {
		this.cancelarEnReemplazo = cancelarEnReemplazo;
	}

	/**
	 * @return el valor de cancelarObligatorio
	 */
	@Transient
	public Boolean getCancelarObligatorio() {
		return cancelarObligatorio;
	}

	/**
	 * @param setea
	 *            el parametro cancelarObligatorio al campo cancelarObligatorio
	 */
	public void setCancelarObligatorio(Boolean cancelarObligatorio) {
		this.cancelarObligatorio = cancelarObligatorio;
	}

	@Column(name = "FECHA_INGRESO", nullable = true)
	public Date getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
		if (this.getFechaCambioEstado() == null && fechaIngreso != null)
			this.setFechaCambioEstado(new Date(fechaIngreso.getTime()));
	}

	/**
	 * @return el valor de debeImprimirCertificado
	 */
	// @Transient
	// public boolean isDebeImprimirCertificado() {
	// return debeImprimirCertificado;
	// }
	// /**
	// * @param setea el parametro debeImprimirCertificado al campo
	// debeImprimirCertificado
	// */
	// public void setDebeImprimirCertificado(boolean debeImprimirCertificado) {
	// this.debeImprimirCertificado = debeImprimirCertificado;
	// }
	/**
	 * @return el valor de tipoCertificadoImprimir
	 */
	// @Transient
	// public TipoCertificado getTipoCertificadoImprimir() {
	// return tipoCertificadoImprimir;
	// }
	// /**
	// * @param setea el parametro tipoCertificadoImprimir al campo
	// tipoCertificadoImprimir
	// */
	// @Transient
	// public void setTipoCertificadoImprimir(TipoCertificado
	// tipoCertificadoImprimir) {
	// this.tipoCertificadoImprimir = tipoCertificadoImprimir;
	// }

	@Column(name = "TIENE_CERTIFICADO_PROVISORIO", nullable = true)
	public Boolean getTieneCertificadoProvisorio() {
		if(tieneCertificadoProvisorio==null)
			tieneCertificadoProvisorio=false;
		return tieneCertificadoProvisorio;
	}

	public void setTieneCertificadoProvisorio(Boolean tieneCertificadoProvisorio) {
		this.tieneCertificadoProvisorio = tieneCertificadoProvisorio;
	}

	/**
	 * @return el valor de respuestaFirmador
	 */
	@Column(name = "RESPUESTA_FIRMADOR", nullable = true)
	public Integer getRespuestaFirmador() {
		return respuestaFirmador;
	}

	/**
	 * @param setea
	 *            el parametro respuestaFirmador al campo respuestaFirmador
	 */
	public void setRespuestaFirmador(Integer respuestaFirmador) {
		this.respuestaFirmador = respuestaFirmador;
	}

	/**
	 * @return el valor de mensajeFirmador
	 */
	@Column(name = "MENSAJE_FIRMADOR", nullable = true)
	public String getMensajeFirmador() {
		return mensajeFirmador;
	}

	/**
	 * @param setea
	 *            el parametro mensajeFirmador al campo mensajeFirmador
	 */
	public void setMensajeFirmador(String mensajeFirmador) {
		this.mensajeFirmador = mensajeFirmador;
	}

	@Transient
	public List<ConductorVehiculo> getConductores() {
		List<ConductorVehiculo> conductores = new ArrayList<ConductorVehiculo>();
		if (conductoresVehiculo != null) {
			for (ConductorVehiculo conductorVehiculo : conductoresVehiculo) {
				if (conductorVehiculo.getConductorServicio().getConductor().getTipoConductor().equalsIgnoreCase(Conductor.TIPO_CONDUCTOR)) {
					conductores.add(conductorVehiculo);
				}
			}
		}
		return conductores;
	}

	@Transient
	public List<ConductorVehiculo> getConductoresVigentes() {
		List<ConductorVehiculo> conductores = new ArrayList<ConductorVehiculo>();
		if (conductoresVehiculo != null) {
			for (ConductorVehiculo conductorVehiculo : conductoresVehiculo) {
				if ( ( (conductorVehiculo.getEstado()!=null && ConductorVehiculo.ESTADO_VIGENTE == conductorVehiculo.getEstado().intValue())
						|| (conductorVehiculo.getEstado()==null && conductorVehiculo.getConductorServicio().getEstado()!=null && ConductorVehiculo.ESTADO_VIGENTE == conductorVehiculo.getConductorServicio().getEstado().intValue()) )
						&&
						conductorVehiculo.getConductorServicio().getConductor().getTipoConductor().equalsIgnoreCase(Conductor.TIPO_CONDUCTOR)) {
					conductores.add(conductorVehiculo);
				}
			}
		}
		return conductores;
	}

	@Transient
	public List<ConductorVehiculo> getAuxiliares() {
		List<ConductorVehiculo> auxiliares = new ArrayList<ConductorVehiculo>();
		if (conductoresVehiculo != null) {
			for (ConductorVehiculo conductorVehiculo : conductoresVehiculo) {
				if (conductorVehiculo.getConductorServicio().getConductor().getTipoConductor().equalsIgnoreCase(Conductor.TIPO_AUXILIAR)) {
					auxiliares.add(conductorVehiculo);
				}
			}
		}
		return auxiliares;
	}

	@Transient
	public List<ConductorVehiculo> getAuxiliaresVigentes() {
		List<ConductorVehiculo> auxiliares = new ArrayList<ConductorVehiculo>();
		if (conductoresVehiculo != null) {
			for (ConductorVehiculo conductorVehiculo : conductoresVehiculo) {
				if (  ( (conductorVehiculo.getEstado()!=null && ConductorVehiculo.ESTADO_VIGENTE == conductorVehiculo.getEstado().intValue())
						|| (conductorVehiculo.getEstado()==null && conductorVehiculo.getConductorServicio().getEstado()!=null && ConductorVehiculo.ESTADO_VIGENTE == conductorVehiculo.getConductorServicio().getEstado().intValue()) )
						&&
						conductorVehiculo.getConductorServicio().getConductor().getTipoConductor().equalsIgnoreCase(Conductor.TIPO_AUXILIAR)) {
					auxiliares.add(conductorVehiculo);
				}
			}
		}
		return auxiliares;
	}

	/**
	 * @return el valor de recorridoACertificar
	 */
	@Transient
	public Recorrido getRecorridoACertificar() {
		return recorridoACertificar;
	}

	/**
	 * @param setea
	 *            el parametro recorridoACertificar al campo
	 *            recorridoACertificar
	 */
	public void setRecorridoACertificar(Recorrido recorridoACertificar) {
		this.recorridoACertificar = recorridoACertificar;
	}

	@ManyToOne(targetEntity = Reglamentacion.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_REGLAMENTACION")
	public Reglamentacion getReglamentacion() {
		return reglamentacion;
	}

	public void setReglamentacion(Reglamentacion reglamentacion) {
		this.reglamentacion = reglamentacion;
	}

	/**
	 * @return el valor de zonaServicio
	 */
	@ManyToOne(targetEntity = Zona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_ZONA", nullable = true)
	public Zona getZonaVehiculo() {
		return zonaVehiculo;
	}

	/**
	 * @param setea
	 *            el parametro zonaServicio al campo zonaServicio
	 */
	public void setZonaVehiculo(Zona zonaVehiculo) {
		this.zonaVehiculo = zonaVehiculo;
	}
	
	/**
	 * @return el valor de pasajeros
	 */
	@OneToMany(targetEntity = Pasajero.class, fetch = FetchType.LAZY, mappedBy = "vehiculoServicio")
	public List<Pasajero> getPasajeros() {
		return pasajeros;
	}

	/**
	 * @param setea el parametro pasajeros al campo pasajeros
	 */
	public void setPasajeros(List<Pasajero> pasajeros) {
		this.pasajeros = pasajeros;
	}

	public void copyTo(VehiculoServicio acert) {
		acert.setCancelarEnReemplazo(this.getCancelarEnReemplazo());
		acert.setCancelarObligatorio(this.getCancelarObligatorio());
		acert.setCodigoRegionDestino(this.getCodigoRegionDestino());
		acert.setConductoresVehiculo(this.getConductoresVehiculo());
		acert.setPeriodosVigencia(this.getPeriodosVigencia());
		acert.setEstado(this.getEstado());
		acert.setCreation(this.getCreation());
		acert.setDbAction(this.getDbAction());
		acert.setFechaCambioEstado(this.getFechaCambioEstado());
		acert.setFechaIngreso(this.getFechaIngreso());
		acert.setFechaVencimiento(this.getFechaVencimiento());
		acert.setFechaResolucionCancelacion(this.getFechaResolucionCancelacion());
		acert.setId(this.getId());
		acert.setLinkResolucionCancelacion(this.getLinkResolucionCancelacion());
		acert.setModified(this.getModified());
		acert.setMensajeFirmador(this.getMensajeFirmador());
		acert.setNumeroResolucion(this.getNumeroResolucion());
		acert.setObservacion(this.getObservacion());
		acert.setObservacionCancelacion(this.getObservacionCancelacion());
		acert.setRecorridoACertificar(this.getRecorridoACertificar());
		acert.setReemplaza(this.getReemplaza());
		acert.setReemplazado(this.getReemplazado());
		acert.setReglamentacion(this.getReglamentacion());
		acert.setRespuestaFirmador(this.getRespuestaFirmador());
		acert.setServicio(this.getServicio());
		acert.setTieneCertificadoProvisorio(this.getTieneCertificadoProvisorio());
		acert.setTipoCancelacion(this.getTipoCancelacion());
		acert.setTipoIngreso(this.getTipoIngreso());
		acert.setTipoServicioSaliente(this.getTipoServicioSaliente());
		acert.setUserCreation(this.getUserCreation());
		acert.setUserModified(this.getUserModified());
		acert.setVehiculo(this.getVehiculo());
		acert.setZonaVehiculo(this.getZonaVehiculo());
		acert.setPermisoProvisorioTransient(this.getPermisoProvisorioTransient());
		acert.setTieneCertificadoMigrado(this.isTieneCertificadoMigrado());
		acert.setFechaIngresoServicio(this.getFechaIngresoServicio());
	}

	@Override
	public VehiculoServicio clone() {
		VehiculoServicio vehi = new VehiculoServicio();

		vehi.setCancelarEnReemplazo(this.getCancelarEnReemplazo());
		vehi.setCancelarObligatorio(this.getCancelarObligatorio());
		vehi.setCodigoRegionDestino(this.getCodigoRegionDestino());
		vehi.setConductoresVehiculo(new ArrayList<ConductorVehiculo>());
		vehi.setEstado(this.getEstado());
		vehi.setCreation(this.getCreation());
		vehi.setDbAction(this.getDbAction());
		vehi.setFechaCambioEstado(this.getFechaCambioEstado());
		vehi.setFechaIngreso(this.getFechaIngreso());
		vehi.setFechaVencimiento(this.getFechaVencimiento());
		vehi.setFechaResolucionCancelacion(this.getFechaResolucionCancelacion());
		vehi.setId(this.getId());
		vehi.setLinkResolucionCancelacion(this.getLinkResolucionCancelacion());
		vehi.setModified(this.getModified());
		vehi.setMensajeFirmador(this.getMensajeFirmador());
		vehi.setNumeroResolucion(this.getNumeroResolucion());
		vehi.setObservacion(this.getObservacion());
		vehi.setObservacionCancelacion(this.getObservacionCancelacion());
		// vehi.setRecorridoACertificar(this.getRecorridoACertificar());
		vehi.setReemplaza(this.getReemplaza());
		vehi.setReemplazado(this.getReemplazado());
		vehi.setReglamentacion(this.getReglamentacion());
		vehi.setRespuestaFirmador(this.getRespuestaFirmador());
		vehi.setServicio(this.getServicio());
		vehi.setTieneCertificadoProvisorio(this.getTieneCertificadoProvisorio());
		vehi.setTipoCancelacion(this.getTipoCancelacion());
		vehi.setTipoIngreso(this.getTipoIngreso());
		vehi.setTipoServicioSaliente(this.getTipoServicioSaliente());
		vehi.setUserCreation(this.getUserCreation());
		vehi.setUserModified(this.getUserModified());
		vehi.setVehiculo(this.getVehiculo());
		vehi.setZonaVehiculo(this.getZonaVehiculo());
		vehi.setTieneCertificadoMigrado(this.isTieneCertificadoMigrado());
		vehi.setFechaIngresoServicio(this.getFechaIngresoServicio());
		return vehi;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(ACTION_SAVE);
	}

	@Transient
	public PermisoProvisorioTransient getPermisoProvisorioTransient() {
		return permisoProvisorioTransient;
	}

	public void setPermisoProvisorioTransient(PermisoProvisorioTransient permisoProvisorioTransient) {
		this.permisoProvisorioTransient = permisoProvisorioTransient;
	}

	@Transient
	public int getGenerarCertificado() {
		return generarCertificado;
	}

	public void setGenerarCertificado(int generarCertificado) {
		if (generarCertificado > this.generarCertificado)
			this.generarCertificado = generarCertificado;
	}

	@Transient
	public void resetGenerarCertificado() {
		this.generarCertificado = VehiculoServicio.GENERAR_CERTIFICADO_NO_ACCION;
		if (this.getRecorridoACertificar()!=null){
		    this.getRecorridosACertificar().clear();
		}
	}

	@Transient
	public HashMap<String, CampoDecorator> getModifiersCertificadoInscripcion() {
		HashMap<String, CampoDecorator> modifiers = new HashMap<String, CampoDecorator>();
		if ((this.getTieneCertificadoProvisorio() != null) && (this.getTieneCertificadoProvisorio().booleanValue())) {
			CampoDecorator dc = new TituloCampoDecorator("vehiculo.titulo", Boolean.TRUE);
			modifiers.put("vehiculo.titulo", dc);
		}
		if ((this.getServicio().getTipoServicio().getGlosaEnCertificado()==null)&&(!this.getServicio().getTipoServicio().getGlosaEnCertificado().booleanValue())){
			CampoDecorator gd=new GlosaCampoDecorator("vehiculo.campos.glosa",Boolean.FALSE);
			modifiers.put("vehiculo.campos.glosa", gd);
		}
		return modifiers;
	}

	@Transient
	public HashMap<String, CampoDecorator> getModifiersCertificadoCancelacion() {
		HashMap<String, CampoDecorator> modifiers = new HashMap<String, CampoDecorator>();

		return modifiers;
	}

	@Transient
	public List<Recorrido> getRecorridosACertificar() {
		return recorridosACertificar;
	}

	public void setRecorridosACertificar(List<Recorrido> recorridosACertificar) {
		this.recorridosACertificar = recorridosACertificar;
	}

	/**
	 * @return el valor de autorizacionMovimiento
	 */
	@Transient
	public List<AutorizacionMovimiento> getAutorizacionesMovimiento() {
		return autorizacionesMovimiento;
	}

	/**
	 * @param setea el parametro autorizacionMovimiento al campo autorizacionMovimiento
	 */
	public void setAutorizacionesMovimiento(List<AutorizacionMovimiento> autorizacionesMovimiento) {
		this.autorizacionesMovimiento = autorizacionesMovimiento;
	}

	/**
	 * @return el valor de diferencias
	 */
	@Transient
	public List<String> getDiferencias() {
		return diferencias;
	}

	/**
	 * @param setea el parametro diferencias al campo diferencias
	 */
	public void setDiferencias(List<String> diferencias) {
		this.diferencias = diferencias;
	}

	/**
	 * @return el valor de vehiculoWs
	 */
	@Transient
	public Vehiculo getVehiculoWs() {
		return vehiculoWs;
	}

	/**
	 * @param setea el parametro vehiculoWs al campo vehiculoWs
	 */
	public void setVehiculoWs(Vehiculo vehiculoWs) {
		this.vehiculoWs = vehiculoWs;
	}
	
	@Column(name = "FECHA_VENCIMIENTO", nullable = true)
	public Date getFechaVencimiento() {
		return fechaVencimiento;
	}

	public void setFechaVencimiento(Date fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}
	
	@Transient
	public String getNroLinea()  {
	    if (this.vehiculo.getAtributosInstancia()!=null) {
    	    for (AtributoInstancia ati :this.vehiculo.getAtributosInstancia()) {
    	        if (ati.getAtributo().getDescriptor().equals("numero_linea")) {
    	            return ati.getValor();
    	        }
    	    }
	    }
	    return "";
	}

	public void setNroLineaAud(String nroLineaAud) {
		this.nroLineaAud = nroLineaAud;
	}

	@Transient
	public String getNroLineaAud()  {
	    return nroLineaAud;
	}
	
	/**
	 * Solo para historico
	 * @return
	 */
	@SuppressWarnings("deprecation")
    @Transient
	public boolean isFechaOperacionValida(){
        if (getFechaCambioEstado()==null)
            return true;
        Date year1900=new Date(00,10,10);
        return getFechaCambioEstado().after(year1900);
    }
	
	/**
	 * Solo para historico
	 * @return
	 */
	@SuppressWarnings("deprecation")
    @Transient
	public boolean isFechaModifiedValida(){
        if (getModified()==null)
            return true;
        Date year1900=new Date(00,10,10);
        return getModified().after(year1900);
    }
	
	/**
     * Solo para historico
     * @return
     */
	@Transient
	public String getNombreRegionDestino() {
	    try {
	        ServicioPPUBean managedObject = (ServicioPPUBean) ElResolver.getManagedObject("servicioPPUBean");
	        if (this.getCodigoRegionDestino()!=null) {
	            Region regionById = managedObject.getUbicacionGeograficaManager().getRegionById(this.getCodigoRegionDestino());
	            if (regionById != null) {
	            	return regionById.getNombre();
	            }
	        }
	    }
	    catch (Exception e) {
	        Logger.getLogger(VehiculoServicio.class).error(e.getLocalizedMessage(), e);
	    }
	    return "";
	}
	
	/**
	 * @return el valor de documentoCancelacion
	 */
	@ManyToOne(targetEntity = DocumentoBiblioteca.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_DOCUMENTO_BIBLIOTECA_CANCELACION")
	public DocumentoBiblioteca getDocumentoCancelacion() {
		return documentoCancelacion;
	}

	/**
	 * @param setea el parametro documentoCancelacion al campo documentoCancelacion
	 */
	public void setDocumentoCancelacion(DocumentoBiblioteca documentoCancelacion) {
		this.documentoCancelacion = documentoCancelacion;
	}
	
	/**
	 * @return el valor de documentoInscripcion
	 */
	@ManyToOne(targetEntity = DocumentoBiblioteca.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_DOCUMENTO_BIBLIOTECA_INSCRIPCION")
	public DocumentoBiblioteca getDocumentoInscripcion() {
		return documentoInscripcion;
	}

	/**
	 * @param setea el parametro documentoInscripcion al campo documentoInscripcion
	 */
	public void setDocumentoInscripcion(DocumentoBiblioteca documentoInscripcion) {
		this.documentoInscripcion = documentoInscripcion;
	}
	
	/**
     * @return el valor de idReglamentacion
     */
    @Column(name = "ID_REGLAMENTACION", updatable=false, insertable=false)
    public Long getIdReglamentacion() {
    	if(idReglamentacion==null && reglamentacion!=null){
    		return reglamentacion.getId();
    	}
        return idReglamentacion;
    }

    /**
     * @param setea el parametro idReglamentacion al campo idReglamentacion
     */
    public void setIdReglamentacion(Long idReglamentacion) {
        this.idReglamentacion = idReglamentacion;
    }

	/**
	 * @return el valor de tieneCertificadoMigrado
	 */
    @Transient
	public boolean isTieneCertificadoMigrado() {
		return tieneCertificadoMigrado;
	}

	/**
	 * @param setea el parametro tieneCertificadoMigrado al campo tieneCertificadoMigrado
	 */
	public void setTieneCertificadoMigrado(boolean tieneCertificadoMigrado) {
		this.tieneCertificadoMigrado = tieneCertificadoMigrado;
	}
	@Transient
	public boolean tieneEstadoCancelacion(){
		try{
			if(this.getEstado().equals(GenericCancellableModelObject.ESTADO_CANCELADO) 
					|| this.getEstado().equals(GenericCancellableModelObject.ESTADO_CANCELADO_DEFINITIVO)
					|| this.getEstado().equals(GenericCancellableModelObject.ESTADO_PENDIENTE_CANCELACION)){
				return true;
			}
			else 
				return false;
		}
		catch(Exception ex){
			return false;
		}
	}
	
    /**
     * @return el valor de idVehiculoServicioReemplaza
     */
    @Column(name = "ID_VEHICULO_REEMPLAZA", updatable=false, insertable=false)
    public Long getIdVehiculoServicioReemplaza() {
        return idVehiculoServicioReemplaza;
    }

    /**
     * @param setea el parametro idVehiculoServicioReemplaza al campo idVehiculoServicioReemplaza
     */
    public void setIdVehiculoServicioReemplaza(Long idVehiculoServicioReemplaza) {
        this.idVehiculoServicioReemplaza = idVehiculoServicioReemplaza;
    }

    /**
     * @return el valor de idVehiculoServicioReemplazado
     */
    @Column(name = "ID_VEHICULO_REEMPLAZADO", updatable=false, insertable=false)
    public Long getIdVehiculoServicioReemplazado() {
        return idVehiculoServicioReemplazado;
    }

    /**
     * @param setea el parametro idVehiculoServicioReemplazado al campo idVehiculoServicioReemplazado
     */
    public void setIdVehiculoServicioReemplazado(Long idVehiculoServicioReemplazado) {
        this.idVehiculoServicioReemplazado = idVehiculoServicioReemplazado;
    }

    /**
     * @return el valor de fechaIngresoServicio
     */
    @Column(name = "FECHA_INGRESO_SERVICIO", nullable = true)
    public Date getFechaIngresoServicio() {
        return fechaIngresoServicio;
    }

    /**
     * @param setea el parametro fechaIngresoServicio al campo fechaIngresoServicio
     */
    public void setFechaIngresoServicio(Date fechaIngresoServicio) {
        this.fechaIngresoServicio = fechaIngresoServicio;
    }

	/**
	 * @return el valor de documentoReversionMovimiento
	 */
	@ManyToOne(targetEntity = DocumentoBiblioteca.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_DOCUMENTO_BIBLIOTECA_REVERSION_MOVIMIENTO")
	public DocumentoBiblioteca getDocumentoReversionMovimiento() {
		return documentoReversionMovimiento;
	}

	/**
	 * @param setea el parametro documentoReversionMovimiento al campo documentoReversionMovimiento
	 */
	public void setDocumentoReversionMovimiento(DocumentoBiblioteca documentoReversionMovimiento) {
		this.documentoReversionMovimiento = documentoReversionMovimiento;
	}

	/**
	 * @return el valor de fechaOtorgamientoBeneficio
	 */
    @Column(name = "FECHA_OTORGAMIENTO_BENEFICIO", nullable = true)
	public Date getFechaOtorgamientoBeneficio() {
		return fechaOtorgamientoBeneficio;
	}

	/**
	 * @param setea el parametro fechaOtorgamientoBeneficio al campo fechaOtorgamientoBeneficio
	 */
	public void setFechaOtorgamientoBeneficio(Date fechaOtorgamientoBeneficio) {
		this.fechaOtorgamientoBeneficio = fechaOtorgamientoBeneficio;
	}

	/**
	 * @return el valor de fechaPostulacion
	 */
    @Column(name = "FECHA_POSTULACION", nullable = true)
	public Date getFechaPostulacion() {
		return fechaPostulacion;
	}

	/**
	 * @param setea el parametro fechaPostulacion al campo fechaPostulacion
	 */
	public void setFechaPostulacion(Date fechaPostulacion) {
		this.fechaPostulacion = fechaPostulacion;
	}

	/**
	 * @return el valor de periodosVigencia
	 */
	@OneToMany(targetEntity = PeriodoVigencia.class, fetch = FetchType.LAZY, mappedBy = "vehiculoServicio")
	public List<PeriodoVigencia> getPeriodosVigencia() {
		return periodosVigencia;
	}

	/**
	 * @param setea el parametro periodosVigencia al campo periodosVigencia
	 */
	public void setPeriodosVigencia(List<PeriodoVigencia> periodosVigencia) {
		this.periodosVigencia = periodosVigencia;
	}
	
	@Transient
    public boolean isVigente() {
	    if (this.getEstado()!=null)
	        return this.getEstado() <= 1;
	    return false;
    } 

}


