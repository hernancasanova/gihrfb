package cl.mtt.rnt.commons.model.core;

import java.io.Serializable;

import javax.faces.bean.ViewScoped;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_VEHICULO_SERVICIO_TOP_VIEW")
public class VehiculoServicioTop implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5490009245416841951L;

	private Long id;
	private Long idVehiculo;
	private Long idServicio;
	private Integer estado;
   
	/**
     * @return el valor de id
     */
	@Id
	@Column(name = "ID", updatable=false, insertable=false)
    public Long getId() {
        return id;
    }
    /**
     * @param setea el parametro id al campo id
     */
    public void setId(Long id) {
        this.id = id;
    }
    /**
     * @return el valor de idVehiculo
     */
    @Column(name = "ID_VEHICULO", updatable=false, insertable=false)
    public Long getIdVehiculo() {
        return idVehiculo;
    }
    /**
     * @param setea el parametro idVehiculo al campo idVehiculo
     */
    public void setIdVehiculo(Long idVehiculo) {
        this.idVehiculo = idVehiculo;
    }
    
    /**
     * @return el valor de estado
     */
    @Column(name = "ESTADO", updatable=false, insertable=false)
    public Integer getEstado() {
        return estado;
    }
    /**
     * @param setea el parametro estado al campo estado
     */
    public void setEstado(Integer estado) {
        this.estado = estado;
    }
    /**
     * @return el valor de idServicio
     */
    @Column(name = "ID_SERVICIO", updatable=false, insertable=false)
    public Long getIdServicio() {
        return idServicio;
    }
    /**
     * @param setea el parametro idServicio al campo idServicio
     */
    public void setIdServicio(Long idServicio) {
        this.idServicio = idServicio;
    }
	
	
	
}
