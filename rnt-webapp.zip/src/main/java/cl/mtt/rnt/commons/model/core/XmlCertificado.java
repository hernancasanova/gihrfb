package cl.mtt.rnt.commons.model.core;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_XML_CERTIFICADO")
public class XmlCertificado extends GenericModelObject{
	private static final long serialVersionUID = 404956857658L;
	
	private String xml;
	private Certificado certificado;
	
	/**
	 * @return el valor de xml
	 */
	@Column(name = "XML", nullable = false)
	@Lob
	public String getXml() {
		return xml;
	}
	/**
	 * @param setea el parametro xml al campo xml
	 */
	public void setXml(String xml) {
		this.xml = xml;
	}
	
	/**
	 * @return el valor de certificado
	 */
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "ID_CERTIFICADO")
	public Certificado getCertificado() {
		return certificado;
	}
	/**
	 * @param setea el parametro certificado al campo certificado
	 */
	public void setCertificado(Certificado certificado) {
		this.certificado = certificado;
	}
}