package cl.mtt.rnt.commons.model.core;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.log4j.Logger;
import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.ElResolver;

@Entity
@Table(name = "RNT_ZONA")
@Audited
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class Zona extends GenericModelObject implements Localizable {

	private static final long serialVersionUID = 1L;

	private String nombre;
	private String descriptor;
	private TipoZona tipoZona;
	private String idRegion;
	private Long idOld;
	private Boolean activa;

	private List<ZonaRegion> zonaRegiones;
	private List<ZonaComuna> zonaComunas;
	private List<ZonaLocalidad> zonaLocalidades;

	@Transient
	private String nombresRegiones;
	@Transient
	private String nombresComunas;
	@Transient
	private String nombresLocalidades;

	@Transient
	private Region regionResponsable;

	private TipoSubsidio tipoSubsidio;
	private List<Servicio> servicios;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPTOR", nullable = false)
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	@Column(name = "ID_REGION", nullable = false)
	public String getIdRegion() {
		return idRegion;
	}

	public void setIdRegion(String idRegion) {
		this.idRegion = idRegion;
	}

	@ManyToOne(targetEntity = TipoZona.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_ZONA")
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoZona getTipoZona() {
		return tipoZona;
	}

	public void setTipoZona(TipoZona tipoZona) {
		this.tipoZona = tipoZona;
	}

	@NotAudited
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ZonaRegion.class, mappedBy = "zona")
	public List<ZonaRegion> getZonaRegiones() {
		return zonaRegiones;
	}

	public void setZonaRegiones(List<ZonaRegion> zonaRegiones) {
		this.zonaRegiones = zonaRegiones;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ZonaComuna.class, mappedBy = "zona")
	@NotAudited
	public List<ZonaComuna> getZonaComunas() {
		return zonaComunas;
	}

	public void setZonaComunas(List<ZonaComuna> zonaComunas) {
		this.zonaComunas = zonaComunas;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = ZonaLocalidad.class, mappedBy = "zona")
	@NotAudited
	public List<ZonaLocalidad> getZonaLocalidades() {
		return zonaLocalidades;
	}

	public void setZonaLocalidades(List<ZonaLocalidad> zonaLocalidades) {
		this.zonaLocalidades = zonaLocalidades;
	}

	@Transient
	@Override
	public String getRegionIdentifier() {
		return idRegion;
	}

	@Transient
	@Override
	public String getLabel() {
		return nombre;
	}

	@Transient
	@Override
	public String getLabelLarge() {
		return nombre+" ("+this.tipoZona.getNombre()+")"+((this.tipoSubsidio==null)?"":(" "+this.tipoSubsidio.getNombre()));
	}
	
	@Transient
	@Override
	public String getIdentifier() {
		return String.valueOf(getId());
	}

	@Transient
	public String getNombresRegiones() {
		return nombresRegiones;
	}

	@Transient
	public void setNombresRegiones(String nombresRegiones) {
		this.nombresRegiones = nombresRegiones;
	}

	@Transient
	public String getNombresComunas() {
		return nombresComunas;
	}

	@Transient
	public void setNombresComunas(String nombresComunas) {
		this.nombresComunas = nombresComunas;
	}

	@Transient
	public Region getRegionResponsable() {
		if (regionResponsable == null) {
			try {
				UbicacionGeograficaManager ugm = (UbicacionGeograficaManager) ElResolver.getManagedObject("ubicacionGeograficaManager");
				for (Region reg : ugm.getAllRegiones()) {
					if (reg.getCodigo().equals(this.idRegion)) {
						this.regionResponsable = reg;
						break;
					}
				}
			} catch (Exception e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			}
		}
		return regionResponsable;
	}

	@Transient
	public void setRegionResponsable(Region regionResponsable) {
		this.regionResponsable = regionResponsable;
	}

	@Transient
	public String getNombresLocalidades() {
		return nombresLocalidades;
	}

	@Transient
	public void setNombresLocalidades(String nombresLocalidades) {
		this.nombresLocalidades = nombresLocalidades;
	}

	@Transient
	public String getNombresRegionesCorto() {
		if (this.getNombresRegiones() != null && this.getNombresRegiones().length() > 30)
			return this.getNombresRegiones().substring(0, 30) + "...";

		return nombresRegiones;
	}

	@Transient
	public String getNombresComunasCorto() {
		if (this.getNombresComunas() != null && this.getNombresComunas().length() > 30)
			return this.getNombresComunas().substring(0, 30) + "...";
		return nombresComunas;
	}

	@Transient
	public String getNombresLocalidadesCorto() {
		if (this.getNombresLocalidades() != null && this.getNombresLocalidades().length() > 30)
			return this.getNombresLocalidades().substring(0, 30) + "...";
		return nombresLocalidades;
	}

	@Transient
	public List<String> getIdRegiones() {
		List<String> ret = new ArrayList<String>();
		for (ZonaRegion item : zonaRegiones) {
			ret.add(item.getIdRegion());
		}
		return ret;
	}

	@Transient
	public List<String> getIdComunas() {
		List<String> ret = new ArrayList<String>();
		for (ZonaComuna item : zonaComunas) {
			ret.add(item.getIdComuna());
		}
		return ret;
	}

	@Transient
	public List<Integer> getIdLocalidades() {
		List<Integer> ret = new ArrayList<Integer>();
		for (ZonaLocalidad item : zonaLocalidades) {
			ret.add(item.getIdLocalidad());
		}
		return ret;
	}

	/**
	 * @return el valor de idOld
	 */
	@Column(name = "ID_OLD", nullable = true)
	public Long getIdOld() {
		return idOld;
	}

	/**
	 * @param setea
	 *            el parametro idOld al campo idOld
	 */
	public void setIdOld(Long idOld) {
		this.idOld = idOld;
	}

	@Column(name = "ACTIVA", nullable = true)
	public Boolean getActiva() {
		return activa;
	}

	public void setActiva(Boolean activa) {
		this.activa = activa;
	}

	@OneToOne(targetEntity = TipoSubsidio.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_SUBSIDIO", nullable = true)
	@AuditJoinTable
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public TipoSubsidio getTipoSubsidio() {
		return tipoSubsidio;
	}

	public void setTipoSubsidio(TipoSubsidio tipoSubsidio) {
		this.tipoSubsidio = tipoSubsidio;
	}

	/**
	 * @return el valor de servicios
	 */
	@ManyToMany(mappedBy = "zonasSubsidio")
	public List<Servicio> getServicios() {
		return servicios;
	}

	/**
	 * @param setea
	 *            el parametro servicios al campo servicios
	 */
	public void setServicios(List<Servicio> servicios) {
		this.servicios = servicios;
	}

    /* (non-Javadoc)
     * @see java.lang.Object#clone()
     */
    @Override
    public Zona clone() {
//        Zona clon = new Zona();
//        clon.setActiva(this.getActiva());
//        clon.setCreation(this.getCreation());
//        clon.setDbAction(this.getDbAction());
//        clon.setDescriptor(this.getDescriptor());
//        clon.setId(this.getId());
//        clon.setIdOld(this.idOld);
//        clon.setIdRegion(this.getIdRegion());
//        clon.setModified(this.getModified());
//        clon.setNombre(this.nombre);
//        clon.setNombresComunas(this.nombresComunas);
//        clon.setNombresLocalidades(this.getNombresLocalidades());
//        clon.setNombresRegiones(this.nombresRegiones);
//        clon.setRegionResponsable(this.regionResponsable);
//        if (Hibernate.isInitialized(this.getServicios())) {
//            clon.setServicios(this.getServicios());
//        }
//        clon.setTipoSubsidio(this.getTipoSubsidio());
//        clon.setTipoZona(this.getTipoZona());
//        clon.setUserCreation(this.getUserCreation());
//        clon.setUserModified(this.getUserModified());
//        
//        if (Hibernate.isInitialized(this.getZonaComunas())&& (this.getZonaComunas()!=null)) {
//            clon.setZonaComunas(new ArrayList<ZonaComuna>());
//            for (ZonaComuna zc : this.zonaComunas) {
//                clon.getZonaComunas().add(zc);
//            }
//        }
//        if (Hibernate.isInitialized(this.getZonaLocalidades())&& (this.getZonaLocalidades()!=null)) {
//            clon.setZonaLocalidades(new ArrayList<ZonaLocalidad>());
//            for (ZonaLocalidad zl : this.getZonaLocalidades()) {
//                clon.getZonaLocalidades().add(zl);
//            }
//        }
//        if (Hibernate.isInitialized(this.getZonaRegiones())&& (this.getZonaRegiones()!=null)) {
//            clon.setZonaRegiones(new ArrayList<ZonaRegion>());
//            for (ZonaRegion zr : this.zonaRegiones) {
//                clon.getZonaRegiones().add(zr);
//            }
//        }
        return this;
        
    }
	
	
	
}
