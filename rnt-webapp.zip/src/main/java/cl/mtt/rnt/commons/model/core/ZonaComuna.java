package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_ZONA_COMUNA")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class ZonaComuna extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private Zona zona;
	private String idComuna;
	private Long idZona;

	@ManyToOne(targetEntity = Zona.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ZONA")
	public Zona getZona() {
		return zona;
	}

	public void setZona(Zona zona) {
		this.zona = zona;
	}

	@Column(name = "ID_COLUMNA", nullable = false)
	public String getIdComuna() {
		return idComuna;
	}

	public void setIdComuna(String idComuna) {
		this.idComuna = idComuna;
	}
	
	/**
     * @return el valor de idZona
     */
    @Column(name = "ID_ZONA", updatable=false, insertable=false)
    public Long getIdZona() {
        return idZona;
    }

    /**
     * @param setea el parametro idZona al campo idZona
     */
    public void setIdZona(Long idZona) {
        this.idZona = idZona;
    }

}
