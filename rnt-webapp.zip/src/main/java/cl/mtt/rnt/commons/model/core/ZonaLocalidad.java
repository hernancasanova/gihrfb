package cl.mtt.rnt.commons.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RNT_ZONA_LOCALIDAD")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "generalCache")
public class ZonaLocalidad extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private Zona zona;
	private Integer idLocalidad;
	private Long idZona;

	@ManyToOne(targetEntity = Zona.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ZONA")
	public Zona getZona() {
		return zona;
	}

	public void setZona(Zona zona) {
		this.zona = zona;
	}

	@Column(name = "ID_LOCALIDAD", nullable = false)
	public Integer getIdLocalidad() {
		return idLocalidad;
	}

	public void setIdLocalidad(Integer idLocalidad) {
		this.idLocalidad = idLocalidad;
	}
	
	/**
     * @return el valor de idZona
     */
    @Column(name = "ID_ZONA", updatable=false, insertable=false)
    public Long getIdZona() {
        return idZona;
    }

    /**
     * @param setea el parametro idZona al campo idZona
     */
    public void setIdZona(Long idZona) {
        this.idZona = idZona;
    }

}
