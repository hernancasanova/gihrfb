package cl.mtt.rnt.commons.model.core.autorizacion;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;

import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;



@Entity
@Table(name = "RNT_AUTORIZACION")
public class Autorizacion extends GenericModelObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8615872296179126012L;
	private Normativa normativa;
	private List<Grupo> grupoResponsable;
	private Boolean estado;
	
	
	
	@ManyToMany(targetEntity = Grupo.class, fetch = FetchType.EAGER)
	@JoinTable(name = "RNT_GRUPO_AUTORIZACION", joinColumns = @JoinColumn(name = "ID_AUTORIZACION"), inverseJoinColumns = @JoinColumn(name = "ID_GRUPO_RESPONSABLE"))
	@BatchSize (size = 50)
	public List<Grupo> getGrupoResponsable() {
		return grupoResponsable;
	}
	
	
	public void setGrupoResponsable(List<Grupo> grupoResponsable) {
		this.grupoResponsable = grupoResponsable;
	}

	@Column(name = "ESTADO")
	public Boolean getEstado() {
		if(estado==null)
			estado=false;
		return estado;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}
	
	@OneToOne(targetEntity = Normativa.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_NORMATIVA")
	public Normativa getNormativa() {
		return normativa;
	}


	public void setNormativa(Normativa normativa) {
		this.normativa = normativa;
	}
	
	

}
