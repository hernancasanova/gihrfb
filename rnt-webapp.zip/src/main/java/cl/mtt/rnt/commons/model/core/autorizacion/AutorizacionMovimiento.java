package cl.mtt.rnt.commons.model.core.autorizacion;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cl.mtt.rnt.commons.model.core.Conductor;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.util.Resources;


@Entity
@Table(name = "RNT_AUTORIZACION_MOVIMIENTO")
public class AutorizacionMovimiento extends GenericModelObject{

	/**
	 * 
	 */
	private static final long serialVersionUID = -352877849892366776L;
	
	private Autorizacion autorizacion;
	private Long idMovimiento;
	private Long idMovimientoAux;
	private Integer tipoMovimiento;
	private Integer estado;
	private String comentarioSolicitante;
	private String comentarioAutorizante;
	
	public static final Integer ESTADO_PENDIENTE = 0;
	public static final Integer ESTADO_ACEPTADO = 1;
	public static final Integer ESTADO_CANCELADO = 2;
	
	public static final Integer TIPO_INGESO_AUTOMOVIL = 0;
	public static final Integer TIPO_INGRESO_CONDUCTOR_SERVICIO = 1;
	public static final Integer TIPO_INGRESO_CONDUCTOR_VEHICULO = 2;
	public static final Integer TIPO_MODIFICACION_CONDUCTOR_SERVICIO = 3;
	public static final Integer TIPO_MODIFICACION_CONDUCTOR_VEHICULO = 4;	
	public static final Integer TIPO_REVERSION_MOVIMIENTO_DIGITACION = 5;  
	
	@ManyToOne(targetEntity = Autorizacion.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_AUTORIZACION")
	public Autorizacion getAutorizacion() {
		return autorizacion;
	}
	
	public void setAutorizacion(Autorizacion autorizacion) {
		this.autorizacion = autorizacion;
	}
	
	@Column(name = "ID_MOVIMIENTO")
	public Long getIdMovimiento() {
		return idMovimiento;
	}
	
	public void setIdMovimiento(Long idMovimiento) {
		this.idMovimiento = idMovimiento;
	}
	
	@Column(name = "TIPO_MOVIMIENTO")
	public Integer getTipoMovimiento() {
		return tipoMovimiento;
	}
	
	public void setTipoMovimiento(Integer tipoMovimiento) {
		this.tipoMovimiento = tipoMovimiento;
	}
	
	@Column(name = "ESTADO" )
	public Integer getEstado() {
		return estado;
	}
	
	public void setEstado(Integer estado) {
		this.estado = estado;
	}

	/**
	 * @return el valor de comentarioSolicitante
	 */
	@Column(name = "COMENTARIO_SOLICITANTE" )
	public String getComentarioSolicitante() {
		return comentarioSolicitante;
	}

	/**
	 * @param setea el parametro comentarioSolicitante al campo comentarioSolicitante
	 */
	public void setComentarioSolicitante(String comentarioSolicitante) {
		this.comentarioSolicitante = comentarioSolicitante;
	}

	/**
	 * @return el valor de comentarioAutorizante
	 */
	@Column(name = "COMENTARIO_AUTORIZANTE" )
	public String getComentarioAutorizante() {
		return comentarioAutorizante;
	}

	/**
	 * @param setea el parametro comentarioAutorizante al campo comentarioAutorizante
	 */
	public void setComentarioAutorizante(String comentarioAutorizante) {
		this.comentarioAutorizante = comentarioAutorizante;
	}

	public static String buidDescripcion(Integer tipoMovimiento2,GenericModelObject asociado, Normativa normativa) {
		
		String desc = "";
		if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL) {
			VehiculoServicio vs = (VehiculoServicio) asociado;
			desc = Resources.getString("notificacion.descripcion.vehiculo",
					new String[] {vs.getVehiculo().getPpu(), vs.getServicio().getIdentServicio().toString(),vs.getServicio().getRegion().getNombre(),normativa.getLabel()});
		}else if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO) {
			ConductorServicio cs = (ConductorServicio) asociado;
			desc = Resources.getString("notificacion.descripcion.conductor",
					new String[] {cs.getConductor().getPersona().getRut(), cs.getServicio().getIdentServicio().toString(),
						cs.getServicio().getRegion().getNombre(),normativa.getLabel(),(Conductor.TIPO_CONDUCTOR.equals(cs.getConductor().getTipoConductor()))?"conductor":(cs.getServicio().getTipoServicio().getGlosaAuxiliar().getGlosaSingular())});
		}else if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO) {
			ConductorVehiculo cv = (ConductorVehiculo) asociado;
			desc = Resources.getString("notificacion.descripcion.conductor",
					new String[] {cv.getConductorServicio().getConductor().getPersona().getRut(), cv.getConductorServicio().getServicio().getIdentServicio().toString(),
						cv.getConductorServicio().getServicio().getRegion().getNombre(),normativa.getLabel(),(Conductor.TIPO_CONDUCTOR.equals(cv.getConductorServicio().getConductor().getTipoConductor()))?"conductor":(cv.getConductorServicio().getServicio().getTipoServicio().getGlosaAuxiliar().getGlosaSingular())});
		}else if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_SERVICIO) {
			ConductorServicio cs = (ConductorServicio) asociado;
			desc = Resources.getString("notificacion.descripcion.conductor.modificacion",
					new String[] {cs.getConductor().getPersona().getRut(), cs.getServicio().getIdentServicio().toString(),
						cs.getServicio().getRegion().getNombre(),normativa.getLabel(),(Conductor.TIPO_CONDUCTOR.equals(cs.getConductor().getTipoConductor()))?"conductor":(cs.getServicio().getTipoServicio().getGlosaAuxiliar().getGlosaSingular())});
		}else if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_VEHICULO) {
			ConductorVehiculo cv = (ConductorVehiculo) asociado;
			desc = Resources.getString("notificacion.descripcion.conductor.modificacion",
					new String[] {cv.getConductorServicio().getConductor().getPersona().getRut(), cv.getConductorServicio().getServicio().getIdentServicio().toString(),
						cv.getConductorServicio().getServicio().getRegion().getNombre(),normativa.getLabel(),(Conductor.TIPO_CONDUCTOR.equals(cv.getConductorServicio().getConductor().getTipoConductor()))?"conductor":(cv.getConductorServicio().getServicio().getTipoServicio().getGlosaAuxiliar().getGlosaSingular())});
		}  else if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_REVERSION_MOVIMIENTO_DIGITACION) {
            VehiculoServicio vs = (VehiculoServicio) asociado;
            desc = Resources.getString("notificacion.descripcion.revertirmov",
                    new String[] {vs.getVehiculo().getPpu(), vs.getServicio().getIdentServicio().toString(),vs.getServicio().getRegion().getNombre()});
		}
		
		return desc;
	}

    /**
     * @return el valor de idMovimientoAux
     */
	@Column(name = "ID_MOVIMIENTO_2")
    public Long getIdMovimientoAux() {
        return idMovimientoAux;
    }

    /**
     * @param setea el parametro idMovimientoAux al campo idMovimientoAux
     */
    public void setIdMovimientoAux(Long idMovimientoAux) {
        this.idMovimientoAux = idMovimientoAux;
    }

//	public static String buidTitulo(Integer tipoMovimiento2,	GenericModelObject asociado, Normativa normativa) {
//		String desc = "";
//		if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL) {
//			VehiculoServicio vs = (VehiculoServicio) asociado;
//			desc = Resources.getString("notificacion.descripcion.vehiculo",
//					new String[] {vs.getVehiculo().getPpu(), vs.getServicio().getIdentServicio().toString(),vs.getServicio().getRegion().getNombre(),normativa.getLabel()});
//		}else if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO) {
//			ConductorServicio cs = (ConductorServicio) asociado;
//			desc = Resources.getString("notificacion.descripcion.conductor",
//					new String[] {cs.getConductor().getPersona().getRut(), cs.getServicio().getIdentServicio().toString(),cs.getServicio().getRegion().getNombre(),normativa.getLabel()});
//		}else if (tipoMovimiento2 == AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO) {
//			ConductorVehiculo cv = (ConductorVehiculo) asociado;
//			desc = Resources.getString("notificacion.descripcion.conductor",
//					new String[] {cv.getConductorServicio().getConductor().getPersona().getRut(), cv.getConductorServicio().getServicio().getIdentServicio().toString(),cv.getConductorServicio().getServicio().getRegion().getNombre(),normativa.getLabel()});
//		} 
//
//		return desc;
//	}
//	
	
	

}
