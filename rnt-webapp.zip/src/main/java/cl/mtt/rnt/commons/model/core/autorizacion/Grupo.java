package cl.mtt.rnt.commons.model.core.autorizacion;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;

import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.util.Resources;

@Entity
@Table(name = "RNT_GRUPO")
public class Grupo  extends GenericModelObject implements Comparable<Grupo>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4150597108459205630L;
	
	private String codRegion;
	private String nombre;
	private TipoTransporte tipoTransporte;
	private MedioTransporte medioTransporte;
	private CategoriaTransporte categoriaTransporte;
	private CategoriaTransporteSeleccionble categoriaTransporteSeleccionble;
	private Region Region;
	private List<User> usuarios;
	List<Autorizacion> autorizaciones;
	
	
	@ManyToMany(targetEntity = Autorizacion.class, fetch = FetchType.LAZY)
    @JoinTable(name = "RNT_GRUPO_AUTORIZACION", joinColumns = @JoinColumn(name = "ID_GRUPO_RESPONSABLE"), inverseJoinColumns = @JoinColumn(name = "ID_AUTORIZACION"))
    @BatchSize (size = 50)
    public List<Autorizacion> getAutorizaciones() {
        return autorizaciones;
    }
    
    
    public void setAutorizaciones(List<Autorizacion> autorizaciones) {
        this.autorizaciones = autorizaciones;
    }
	
	
	@Column(name = "COD_REGION", nullable = false)
	public String getCodRegion() {
		return codRegion;
	}
	
	public void setCodRegion(String codRegion) {
		this.codRegion = codRegion;
	}
	
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	@ManyToOne(targetEntity = TipoTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TIPO_TRANSPORTE", nullable = false)
	public TipoTransporte getTipoTransporte() {
		return tipoTransporte;
	}

	public void setTipoTransporte(TipoTransporte tipoTransporte) {
		this.tipoTransporte = tipoTransporte;
	}

	@ManyToOne(targetEntity = MedioTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_MEDIO_TRANSPORTE", nullable = false)
	public MedioTransporte getMedioTransporte() {
		return medioTransporte;
	}

	public void setMedioTransporte(MedioTransporte medioTransporte) {
		this.medioTransporte = medioTransporte;
	}

	@ManyToOne(targetEntity = CategoriaTransporte.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CATEGORIA_TRANSPORTE", nullable = false)
	public CategoriaTransporte getCategoriaTransporte() {
		return categoriaTransporte;
	}

	public void setCategoriaTransporte(CategoriaTransporte categoriaTransporte) {
		this.categoriaTransporte = categoriaTransporte;
	}
	
	@Transient
	public Region getRegion() {
		return Region;
	}

	public void setRegion(Region region) {
		Region = region;
	}

	public void setearRegion(){
		Region r = new Region();
	    if(this.getCodRegion() == null || this.getCodRegion().trim().isEmpty() ){
	    	r.setCodigo("");
	    	r.setNombre(Resources.getString("grupos.aplica.nacion"));
			this.setRegion(r);
		}
		else if(this.getCodRegion().equals("00")){
			r.setCodigo("00");
	    	r.setNombre(Resources.getString("grupos.todas.regiones"));
			this.setRegion(r);
		}
	}
	
	@ManyToMany(targetEntity = User.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_GRUPO_USUARIO", joinColumns = @JoinColumn(name = "ID_GRUPO"), inverseJoinColumns = @JoinColumn(name = "ID_USUARIO"))
	public List<User> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<User> usuarios) {
		this.usuarios = usuarios;
	}

	@Transient
	public CategoriaTransporteSeleccionble getCategoriaTransporteSeleccionble() {
		if(this.categoriaTransporte  == null || this.medioTransporte == null || this.tipoTransporte == null )
			return null;
		categoriaTransporteSeleccionble = new CategoriaTransporteSeleccionble();
		categoriaTransporteSeleccionble.setCategoria(this.categoriaTransporte);
		categoriaTransporteSeleccionble.setMedio(this.medioTransporte);
		categoriaTransporteSeleccionble.setTipoTransporte(this.tipoTransporte);
		return categoriaTransporteSeleccionble;
	}

	public void setCategoriaTransporteSeleccionble(
			CategoriaTransporteSeleccionble categoriaTransporteSeleccionble) {
		if(categoriaTransporteSeleccionble.getCategoria()  == null || categoriaTransporteSeleccionble.getMedio() == null || categoriaTransporteSeleccionble.getTipoTransporte() == null )
			this.categoriaTransporteSeleccionble = null;
		else{
			this.categoriaTransporte = categoriaTransporteSeleccionble.getCategoria();
			this.medioTransporte = categoriaTransporteSeleccionble.getMedio();
			this.tipoTransporte = categoriaTransporteSeleccionble.getTipoTransporte();
			this.categoriaTransporteSeleccionble = categoriaTransporteSeleccionble;
		}
	}

	@Transient
	public String getNameCategoria() {
		try {
			return this.getTipoTransporte().getNombre() + " " + this.getMedioTransporte().getNombre() + " " + this.getCategoriaTransporte().getNombre() ;
		} catch (Exception e) {
			return "";
		}

	}
	
	
	@Override
	public int compareTo(Grupo o) {
		 return this.getNombre().compareToIgnoreCase(o.getNombre()); 
	} 
	
}
