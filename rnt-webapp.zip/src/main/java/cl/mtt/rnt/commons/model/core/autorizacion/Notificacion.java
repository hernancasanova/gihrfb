package cl.mtt.rnt.commons.model.core.autorizacion;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;

import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.util.Resources;


@Entity
@Table(name = "RNT_NOTIFICACION")
public class Notificacion extends GenericModelObject{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7325200764434919748L;
	
	private String titulo;
	private String descripcion;
	private String observacion;
	private Integer tipo;
	private Integer estado;
	private User	usuarioDestino;
	private AutorizacionMovimiento autorizacionMovimiento;
	
	public static final Integer ESTADO_NO_LEIDO=0;
	public static final Integer ESTADO_LEIDO=1;
	
	public static final Integer NOTIFICACION_AUTORIZACION=1;
	public static final Integer NOTIFICACION_MENSAJE_INF=2;
	
	
	@Column(name = "TITULO")
	public String getTitulo() {
		return titulo;
	}
	
	
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
	@Column(name = "DESCRIPCION")
	public String getDescripcion() {
		return descripcion;
	}
	
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	@Column(name = "OBSERVACION")
	public String getObservacion() {
		return observacion;
	}
	
	
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
	@Column(name = "TIPO")
	public Integer getTipo() {
		return tipo;
	}
	
	
	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}
	
	
	
	

	@ManyToOne(targetEntity = AutorizacionMovimiento.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_AUTORIZACION_MOVIMIENTO")
	@BatchSize (size = 100)
	public AutorizacionMovimiento getAutorizacionMovimiento() {
		return autorizacionMovimiento;
	}

	public void setAutorizacionMovimiento(
			AutorizacionMovimiento autorizacionMovimiento) {
		this.autorizacionMovimiento = autorizacionMovimiento;
	}

	@Column(name = "ESTADO")
	public Integer getEstado() {
		return estado;
	}


	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	
	
	@ManyToOne(targetEntity = User.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_USER_DESTINO")
	public User getUsuarioDestino() {
		return usuarioDestino;
	}


	public void setUsuarioDestino(User usuarioDestino) {
		this.usuarioDestino = usuarioDestino;
	}


	@Transient
	public String getTipoNotificacion(){
		if(this.tipo != null){
			if(this.tipo.equals(NOTIFICACION_AUTORIZACION)){
				return Resources.getString("notificaciones.tipo.autorizacion");
			}
			if(this.tipo.equals(NOTIFICACION_MENSAJE_INF)){
				return Resources.getString("notificaciones.tipo.mess.admin");
			}
		}
		return "";
	}

	
	
	
	
	
	
	

}
