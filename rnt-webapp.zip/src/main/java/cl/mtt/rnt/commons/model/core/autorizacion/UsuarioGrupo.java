package cl.mtt.rnt.commons.model.core.autorizacion;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.userrol.User;

@Entity
@Table(name = "RNT_GRUPO_USUARIO")
public class UsuarioGrupo extends GenericModelObject{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6645321523622207862L;
	
	private Grupo grupo;
	private User user;
	
	@ManyToOne(targetEntity = Grupo.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_GRUPO")
	public Grupo getGrupo() {
		return grupo;
	}
	
	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}
	
	@ManyToOne(targetEntity = User.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_USUARIO")
	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	

}
