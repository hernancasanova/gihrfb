package cl.mtt.rnt.commons.model.core.interfaces;

public interface Anonymizable {

	public void anonimize();

}
