package cl.mtt.rnt.commons.model.core.interfaces;

public interface NombrableModelObject {

	public String getNombre();

}
