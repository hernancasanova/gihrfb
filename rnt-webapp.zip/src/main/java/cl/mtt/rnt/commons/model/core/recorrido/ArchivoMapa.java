package cl.mtt.rnt.commons.model.core.recorrido;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.GenericModelObject;

@Entity
@Table(name = "RNT_ARCHIVO_MAPA")
@Audited
public class ArchivoMapa extends GenericModelObject{

	private Recorrido recorrido;
	private String mapContent; 
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ID_RECORRIDO")
	public Recorrido getRecorrido() {
		return recorrido;
	}

	public void setRecorrido(Recorrido recorrido) {
		this.recorrido = recorrido;
	}

	@Column(name = "CONTENT", nullable = false)
	@Lob
	public String getMapContent() {
		return mapContent;
	}

	public void setMapContent(String mapContent) {
		this.mapContent = mapContent;
	} 
}
