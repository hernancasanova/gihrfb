package cl.mtt.rnt.commons.model.core.recorrido;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.util.Resources;

import com.google.gson.annotations.Expose;

@Entity
@Table(name = "RNT_BLOQUE_PREDETERMINADO")
@Audited
public class BloquePredeterminado extends GenericModelObject  implements Mapeable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2251242863588087272L;

	@Expose
	private List<Tramo> tramos;
	@Expose
	private String nombre;
	private String descripcion;
	
	private Boolean usaMapa;

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Tramo.class, mappedBy = "bloquePadre")
	public List<Tramo> getTramos() {
		return tramos;
	}

	public void setTramos(List<Tramo> tramos) {
		this.tramos = tramos;
	}



	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPCION", nullable = true, length = 1000)
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	@Transient
	public String getTramosIdaAsString() {
		String tramosIda = "";
//		for (Tramo tramo : this.getTramos()) {
//			if (tramo.getSentido().equalsIgnoreCase(Tramo.SENTIDO_IDA)) {
//				if (tramosIda.equals("") && tramo.getParaderoOrigen() != null)
//					tramosIda += tramo.getParaderoOrigen().getNombre() + "; ";
//
//				tramosIda += tramo.getCalle() + "; ";
//
//				if (tramo.getParaderoDestino() != null)
//					tramosIda += tramo.getParaderoDestino().getNombre() + "; ";
//			}
//		}
		return tramosIda.equals("") ? tramosIda : tramosIda.substring(0, tramosIda.length() - 2);
	}

	@Transient
	public String getTramosVueltaAsString() {
		String tramosVuelta = "";
//		for (Tramo tramo : this.getTramos()) {
//			if (tramo.getSentido().equalsIgnoreCase(Tramo.SENTIDO_VUELTA)) {
//				if (tramosVuelta.equals("") && tramo.getParaderoOrigen() != null)
//					tramosVuelta += tramo.getParaderoOrigen().getNombre() + "; ";
//
//				tramosVuelta += tramo.getCalle() + "; ";
//
//				if (tramo.getParaderoDestino() != null)
//					tramosVuelta += tramo.getParaderoDestino().getNombre() + "; ";
//			}
//		}
		return tramosVuelta.equals("") ? tramosVuelta : tramosVuelta.substring(0, tramosVuelta.length() - 2);
	}


	@Transient
	public Float getLength() {
		if (!getUsaMapa())
			return null;
		Float ret = 0f;
		for (Tramo tramo : tramos) {
			ret += tramo.getLength();
		}
		return ret;
	}
	
	@Column(name = "USA_MAPA", nullable = true)
	public Boolean getUsaMapa() {
		if(usaMapa==null)
			usaMapa=false;
		return usaMapa;
	}

	public void setUsaMapa(Boolean usaMapa) {
		this.usaMapa = usaMapa;
	}


}
