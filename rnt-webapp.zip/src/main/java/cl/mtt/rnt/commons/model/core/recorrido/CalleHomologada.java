package cl.mtt.rnt.commons.model.core.recorrido;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import cl.mtt.rnt.commons.model.core.GenericModelObject;

@Entity
@Table(name = "RNT_CALLE_HOMOLOGADA")
public class CalleHomologada extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7965748510086223412L;
	private DatoDiccionario datoDiccionario;
	private String codigoComuna;
	private String nombreGoogleMaps;

	@ManyToOne(targetEntity = DatoDiccionario.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_DATO_DICCIONARIO")
	public DatoDiccionario getDatoDiccionario() {
		return datoDiccionario;
	}

	public void setDatoDiccionario(DatoDiccionario datoDiccionario) {
		this.datoDiccionario = datoDiccionario;
	}

	@Column(name = "CODIGO_COMUNA", nullable = false)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "NOMBRE_GOOGLE_MAPS", nullable = false)
	public String getNombreGoogleMaps() {
		return nombreGoogleMaps;
	}

	public void setNombreGoogleMaps(String nombreGoogleMaps) {
		this.nombreGoogleMaps = nombreGoogleMaps;
	}

}
