package cl.mtt.rnt.commons.model.core.recorrido;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.TipoVia;
import cl.mtt.rnt.commons.model.sgprt.Comuna;

@Entity
@Table(name = "RNT_DICCIONARIO_MIGRA")
public class DatoDiccionario extends GenericModelObject {

	private static final long serialVersionUID = 1L;
	
	

	private Long idOld;
	private BigDecimal idComunaOld;
	private String codigoComuna;
	private Comuna comuna;
	private BigDecimal nodo;
	private String calle1;
	private String calle2;
	private BigDecimal tipo;
	private TipoVia tipoVia;
	private String calleSimple;

	private List<CalleHomologada> callesHomologadas; 
	
	/**
	 * @return el valor de idOld
	 */
	@Column(name = "ID_OLD", nullable = true)
	public Long getIdOld() {
		return idOld;
	}

	/**
	 * @param setea
	 *            el parametro idOld al campo idOld
	 */
	public void setIdOld(Long idOld) {
		this.idOld = idOld;
	}

	/**
	 * @return el valor de idComunaOld
	 */
	@Column(name = "ID_COMUNA_OLD", nullable = true, columnDefinition = "decimal", precision = 19, scale = 2)
	public BigDecimal getIdComunaOld() {
		return idComunaOld;
	}

	/**
	 * @param setea
	 *            el parametro idComunaOld al campo idComunaOld
	 */

	public void setIdComunaOld(BigDecimal idComunaOld) {
		this.idComunaOld = idComunaOld;
	}

	/**
	 * @return el valor de codigoComuna
	 */
	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	/**
	 * @param setea
	 *            el parametro codigoComuna al campo codigoComuna
	 */
	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	/**
	 * @return el valor de nodo
	 */
	@Column(name = "NODO", nullable = true, columnDefinition = "decimal")
	public BigDecimal getNodo() {
		return nodo;
	}

	/**
	 * @param setea
	 *            el parametro nodo al campo nodo
	 */
	public void setNodo(BigDecimal nodo) {
		this.nodo = nodo;
	}

	/**
	 * @return el valor de calle1
	 */
	@Column(name = "CALLE1", nullable = true)
	public String getCalle1() {
		if (calle1==null)
			calle1="";
		return calle1;
	}

	/**
	 * @param setea
	 *            el parametro calle1 al campo calle1
	 */
	public void setCalle1(String calle1) {
		if (calle1 == null) {
			this.calle1 = "";
		}
		else {
			this.calle1 = calle1;
		}
	}

	/**
	 * @return el valor de calle2
	 */
	@Column(name = "CALLE2", nullable = true)
	public String getCalle2() {
		return calle2;
	}

	/**
	 * @param setea
	 *            el parametro calle2 al campo calle2
	 */
	public void setCalle2(String calle2) {
		this.calle2 = calle2;
	}

	/**
	 * @return el valor de tipo
	 */
	@Column(name = "TIPO", nullable = true, columnDefinition = "decimal")
	public BigDecimal getTipo() {
		return tipo;
	}

	/**
	 * @param setea
	 *            el parametro tipo al campo tipo
	 */
	public void setTipo(BigDecimal tipo) {
		this.tipo = tipo;
	}

	@Transient
	public Comuna getComuna() {
		return comuna;
	}

	public void setComuna(Comuna comuna) {
		this.comuna = comuna;
	}

	@Transient
	public List<CalleHomologada> getCallesHomologadas() {
		return callesHomologadas;
	}

	public void setCallesHomologadas(List<CalleHomologada> callesHomologadas) {
		this.callesHomologadas = callesHomologadas;
	}

	/**
	 * @return el valor de tipoVia
	 */
	@Transient
	public TipoVia getTipoVia() {
		if (tipoVia == null) {
			tipoVia = TipoVia.resolve(this.getCalle1());
		}
		return tipoVia;
	}

	/**
	 * @param setea el parametro tipoVia al campo tipoVia
	 */
	public void setTipoVia(TipoVia tipoVia) {
		this.tipoVia = tipoVia;
	}

	/**
	 * @return el valor de calleSimple
	 */
	@Transient
	public String getCalleSimple() {
		return calleSimple;
	}

	/**
	 * @param setea el parametro calleSimple al campo calleSimple
	 */
	public void setCalleSimple(String calleSimple) {
		this.calleSimple = calleSimple;
	}

	@Transient
	public static String getNombreCallePersistente(String tipoVia, String calle){
		String prefijo = TipoVia.getPrefijo(tipoVia);
		if (!tipoVia.trim().equals("")) {
			 return prefijo+" " + calle;
		 } else {
			 return calle;
		 }
	}

	public void pisarDatosPersistentes() {
		 if (!tipoVia.getTipoPrefijo().trim().equals("")) {
			 this.calle1 = this.tipoVia.getTipoPrefijo()+" " + this.calleSimple.trim();
		 }
		 else {
			 this.calle1 = this.calleSimple.trim();
		 }
		
	}
	
	public void tomarDatosPersistentes() {
		this.tipoVia = TipoVia.resolve(getCalle1());
		if (!tipoVia.getTipoPrefijo().trim().equals(""))
			this.calleSimple = getCalle1().replace(tipoVia.getTipoPrefijo() + " ", "");
		else 
			this.calleSimple = getCalle1().trim();
	}
	
	

}
