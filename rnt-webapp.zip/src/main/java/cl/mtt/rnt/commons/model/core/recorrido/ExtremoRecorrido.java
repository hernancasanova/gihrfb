package cl.mtt.rnt.commons.model.core.recorrido;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.envers.RelationTargetAuditMode;

import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Paradero;
import cl.mtt.rnt.commons.model.core.SituacionContractual;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;

@Entity
@Table(name = "RNT_EXTREMO_RECORRIDO")
@Audited
public class ExtremoRecorrido extends GenericModelObject implements Anonymizable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8757845957457580171L;
	@Expose
	private Paradero paradero;
	private SituacionContractual situacionContractual;// (Propio, Arriendo … )
	private Date vigenciaDesde;
	private Date vigenciaHasta;
	private Integer estacionamientosAutorizados; // Cantidad de Estacionamientos
													// autorizados (solo en
													// terminal o recinto
													// autorizado)
	private String autorizacionMunicipal;

	@ManyToOne(targetEntity = SituacionContractual.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_SITUACION_CONTRACTUAL")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	public SituacionContractual getSituacionContractual() {
		return situacionContractual;
	}

	public void setSituacionContractual(SituacionContractual situacionContractual) {
		this.situacionContractual = situacionContractual;
	}

	@Column(name = "VIGENCIA_DESDE", nullable = true)
	public Date getVigenciaDesde() {
		return vigenciaDesde;
	}

	public void setVigenciaDesde(Date vigenciaDesde) {
		this.vigenciaDesde = vigenciaDesde;
	}

	@Column(name = "VIGENCIA_HASTA", nullable = true)
	public Date getVigenciaHasta() {
		return vigenciaHasta;
	}

	public void setVigenciaHasta(Date vigenciaHasta) {
		this.vigenciaHasta = vigenciaHasta;
	}

	@Column(name = "ESTACIONAMIENTOS", nullable = true)
	public Integer getEstacionamientosAutorizados() {
		return estacionamientosAutorizados;
	}

	public void setEstacionamientosAutorizados(Integer estacionamientosAutorizados) {
		this.estacionamientosAutorizados = estacionamientosAutorizados;
	}

	@ManyToOne(targetEntity = Paradero.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PARADERO")
	public Paradero getParadero() {
		return paradero;
	}

	public void setParadero(Paradero paradero) {
		if(paradero!=null)
			this.paradero = paradero;
	}

	@Column(name = "AUTORIZACION_MUNICIPAL", nullable = true)
	public String getAutorizacionMunicipal() {
		return autorizacionMunicipal;
	}

	public void setAutorizacionMunicipal(String autorizacionMunicipal) {
		this.autorizacionMunicipal = autorizacionMunicipal;
	}

	@Transient
	@Override
	public ExtremoRecorrido clone() throws CloneNotSupportedException {
		ExtremoRecorrido er = new ExtremoRecorrido();
		er.setCreation(this.getCreation());
		er.setDbAction(this.getDbAction());
		if (this.getEstacionamientosAutorizados() != null)
			er.setEstacionamientosAutorizados(new Integer(this.getEstacionamientosAutorizados()));
		// er.setGeographicPosition(this.getGeographicPosition());
		er.setId(this.getId());
		er.setModified(this.getModified());
		er.setParadero(this.getParadero());
		er.setSituacionContractual(this.getSituacionContractual());
		er.setUserCreation(this.getUserCreation());
		er.setUserModified(this.getUserModified());
		er.setVigenciaDesde(this.getVigenciaDesde());
		er.setVigenciaHasta(this.getVigenciaHasta());
		er.setAutorizacionMunicipal(this.getAutorizacionMunicipal());
		
		return er;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
		// Solo anonimizo las ubicaciones
		if (paradero.getTipoParadero().equals(Paradero.TIPO_UBICACION)) {
			paradero.anonimize();
		}
	}

	@Transient
	public String getParaderoAsJSon() {
		return getParadero().getAsJSon();
	}

}
