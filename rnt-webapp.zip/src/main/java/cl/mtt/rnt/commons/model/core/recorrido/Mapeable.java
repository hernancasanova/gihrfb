package cl.mtt.rnt.commons.model.core.recorrido;

import java.util.List;

public interface Mapeable {

	
	public Boolean getUsaMapa();
	
	public List<Tramo> getTramos();
	
}
