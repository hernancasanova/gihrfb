package cl.mtt.rnt.commons.model.core.recorrido;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.GenericAuditCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.ItemMatrizTarifaria;
import cl.mtt.rnt.commons.model.core.Sector;
import cl.mtt.rnt.commons.model.core.SectorTramoTarifario;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.Tarifa;
import cl.mtt.rnt.commons.model.core.TramoTarifario;
import cl.mtt.rnt.commons.model.core.XmlCertificado;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.util.Resources;

import com.google.gson.annotations.Expose;

@Entity
@Table(name = "RNT_RECORRIDO")
@Audited
public class Recorrido extends GenericAuditCancellableModelObject implements Anonymizable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1061050133874814627L;
	@Expose
	private String nombre;
	private List<Trazado> trazados;
	private Servicio servicio;
	private List<Sector> sectores;
	private List<Sector> sectoresAEliminar;
	@Expose
	private ExtremoRecorrido origen;
	@Expose
	private ExtremoRecorrido destino;

	// private List<DiaTrazado> diasSemanaList;

	// private Float longitud;// del recorrido en Km
	private Tarifa tarifa;

	// private Float frecuencia;
	// private Integer intervaloSalida;

	private Integer respuestaFirmador;
	private String mensajeFirmador;
	private ArchivoMapa mapa;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Trazado.class, mappedBy = "recorrido")
	public List<Trazado> getTrazados() {
		return trazados;
	}

	public void setTrazados(List<Trazado> trazados) {
		this.trazados = trazados;
	}

	@ManyToOne(targetEntity = Servicio.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SERVICIO")
	public Servicio getServicio() {
		return servicio;
	}

	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}

	// @Column(name="LONGITUD", nullable=true,columnDefinition="double")
	// public Float getLongitud() {
	// return longitud;
	// }
	// public void setLongitud(Float longitud) {
	// this.longitud = longitud;
	// }

	@ManyToOne(targetEntity = Tarifa.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_TARIFA", unique = true)
	public Tarifa getTarifa() {
		return tarifa;
	}

	public void setTarifa(Tarifa tarifa) {
		this.tarifa = tarifa;
	}

	@ManyToOne(targetEntity = ExtremoRecorrido.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_ORIGEN", unique = true)
	public ExtremoRecorrido getOrigen() {
		return origen;
	}

	public void setOrigen(ExtremoRecorrido origen) {
		this.origen = origen;
	}

	@ManyToOne(targetEntity = ExtremoRecorrido.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_DESTINO", unique = true)
	public ExtremoRecorrido getDestino() {
		return destino;
	}

	public void setDestino(ExtremoRecorrido destino) {
		this.destino = destino;
	}

	// @Transient
	// public List<DiaTrazado> getDiasSemanaList() {
	// if(diasSemanaList==null)
	// diasSemanaList=new ArrayList<DiaTrazado>();
	// return diasSemanaList;
	// }
	//
	// public void setDiasSemanaList(List<DiaTrazado> diasSemanaList) {
	// this.diasSemanaList = diasSemanaList;
	// }

	@Transient
	@Override
	public Recorrido clone() throws CloneNotSupportedException {
		Recorrido rec = new Recorrido();
		rec.setCreation(this.getCreation());
		rec.setDbAction(this.getDbAction());
		if(this.getDestino()!=null){
			rec.setDestino(this.getDestino().clone());
		}
		// if (this.getDiasSemanaList()!=null) {
		// rec.setDiasSemanaList(this.getDiasSemanaList());
		// }
		rec.setId(this.getId());
		// if (this.getLongitud() != null)
		// rec.setLongitud(new Float(this.getLongitud()));
		if (this.getEstado() != null)
			rec.setEstado(new Integer(this.getEstado()));
		if (this.getFechaCambioEstado() != null)
			rec.setFechaCambioEstado(new Date(this.getFechaCambioEstado().getTime()));
		if (this.getFechaResolucionCancelacion() != null) {
			rec.setFechaResolucionCancelacion(new Date(this.getFechaResolucionCancelacion().getTime()));
		}
		// if (this.getFrecuencia()!=null)
		// rec.setFrecuencia(new Float(this.getFrecuencia()));
		// if (this.getIntervaloSalida()!=null) {
		// rec.setIntervaloSalida(new Integer(this.getIntervaloSalida()));
		// }
		rec.setModified(this.getModified());
		rec.setNombre(new String(this.getNombre()));
		if(this.getOrigen()!=null){
			rec.setOrigen(this.getOrigen().clone());
		}
		rec.setServicio(this.getServicio());
		rec.setSectores(new ArrayList<Sector>());
		if (this.getSectores() != null) {
			for (Sector s : this.getSectores()) {
				Sector sclon = s.clone();
				sclon.setRecorrido(rec);
				rec.getSectores().add(sclon);
			}
		}
		if (this.getTarifa() != null) {
			rec.setTarifa(this.getTarifa().clone());
			for (SectorTramoTarifario stt : rec.getTarifa().getSectoresTramoTarifario()) {
				stt.setTarifa(rec.getTarifa());
				for (Sector sec : rec.getSectores()) {
					if (sec.getNombre().equals(stt.getSector()))
						stt.setSector(sec);
				}
			}
			// Acomodo los sectores
			if (rec.getTarifa().getTramosTarifarios() != null)
				for (TramoTarifario tt : rec.getTarifa().getTramosTarifarios()) {
					if (tt.getItemsMatrizTarifaria() != null)

						for (ItemMatrizTarifaria imt : tt.getItemsMatrizTarifaria()) {

							for (Sector sec : rec.getSectores()) {
								if (sec.getNombre().equals(imt.getSectorInicial()))
									imt.setSectorInicial(sec);
								if (sec.getNombre().equals(imt.getSectorFinal()))
									imt.setSectorFinal(sec);
							}
						}
				}
		}
		rec.setTrazados(new ArrayList<Trazado>());
		for (Trazado t : this.getTrazados()) {
			Trazado tclon = t.clone();
			tclon.setRecorrido(rec);
			rec.getTrazados().add(tclon);
		}
		rec.setMapa(this.getMapa());
		rec.setUserCreation(this.getUserCreation());
		rec.setUserModified(this.getUserModified());
		return rec;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Sector.class, mappedBy = "recorrido")
	public List<Sector> getSectores() {
		return sectores;
	}

	public void setSectores(List<Sector> sectores) {
//		if(this.sectores==null && sectores!=null)
//			this.sectores = sectores;		
//		else if(this.sectores==null && sectores==null)
//			this.sectores = new ArrayList<Sector>();
//		else if(this.sectores!=null && sectores!=null){
//			if (Hibernate.isInitialized(this.sectores)) {
//				this.sectores.clear();
//				this.sectores.addAll(sectores);
//			}
//			else {
//				this.sectores = sectores;
//			}
//		} else if(this.sectores!=null && sectores==null)
//			if (Hibernate.isInitialized(this.sectores)) {
//				this.sectores.clear();
//			}

		this.sectores = sectores;
	}

	// /**
	// * @return el valor de frecuencia
	// */
	// @Transient
	// public Float getFrecuencia() {
	// return frecuencia;
	// }
	// /**
	// * @param setea el parametro frecuencia al campo frecuencia
	// */
	// public void setFrecuencia(Float frecuencia) {
	// this.frecuencia = frecuencia;
	// }
	// /**
	// * @return el valor de intervaloSalida
	// */
	// @Transient
	// public Integer getIntervaloSalida() {
	// return intervaloSalida;
	// }
	// /**
	// * @param setea el parametro intervaloSalida al campo intervaloSalida
	// */
	// public void setIntervaloSalida(Integer intervaloSalida) {
	// this.intervaloSalida = intervaloSalida;
	// }

	/**
	 * @return el valor de respuestaFirmador
	 */
	@Column(name = "RESPUESTA_FIRMADOR", nullable = true)
	public Integer getRespuestaFirmador() {
		return respuestaFirmador;
	}

	/**
	 * @param setea
	 *            el parametro respuestaFirmador al campo respuestaFirmador
	 */
	public void setRespuestaFirmador(Integer respuestaFirmador) {
		this.respuestaFirmador = respuestaFirmador;
	}

	/**
	 * @return el valor de mensajeFirmador
	 */
	@Column(name = "MENSAJE_FIRMADOR", nullable = true)
	public String getMensajeFirmador() {
		return mensajeFirmador;
	}

	/**
	 * @param setea
	 *            el parametro mensajeFirmador al campo mensajeFirmador
	 */
	public void setMensajeFirmador(String mensajeFirmador) {
		this.mensajeFirmador = mensajeFirmador;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
		for (Trazado item : trazados) {
			item.anonimize();
		}
		if (sectores != null) {
			for (Sector item : sectores) {
				item.anonimize();
			}
		}
		if (origen != null){
			origen.anonimize();
		}
		if (destino != null){
			destino.anonimize();
		}
		if (tarifa != null) {
			tarifa.anonimize();
		}
	}

	@Transient
	public boolean getUsaMapaDisabled() {
		try {
			return origen.getParadero().getGeographicPosition() == null || destino.getParadero().getGeographicPosition() == null;
		} catch (Exception e) {
			return true;
		}
	}
	
	@Transient
	public List<Sector> getSectoresAEliminar() {
		return sectoresAEliminar;
	}

	public void setSectoresAEliminar(List<Sector> sectoresAEliminar) {
		this.sectoresAEliminar = sectoresAEliminar;
	}
	
	@Transient
	public boolean isEmpty(){
		if(trazados!=null){
			for (Trazado tr : trazados) {
				if(tr.getTipo().equals(Resources.getString("recorrido.trazado.field.tipo.principal"))){
					if(tr.getTramos()==null || tr.getTramos().size()==0)
						return true;
					else
						return false;
				}
			}
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (super.equals(obj))
			return true;
		if (getClass() != obj.getClass())
			return false;
		Recorrido other = (Recorrido) obj;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		return true;
	}

	@Transient
    public boolean isVigente() {
	    if (this.getEstado()!=null)
	        return this.getEstado() <= 1;
	    return false;
    }

	@OneToOne(targetEntity=ArchivoMapa.class,mappedBy="recorrido",fetch=FetchType.LAZY)
	public ArchivoMapa getMapa() {
		return mapa;
	}

	public void setMapa(ArchivoMapa mapa) {
		this.mapa = mapa;
	} 
	
	
}
