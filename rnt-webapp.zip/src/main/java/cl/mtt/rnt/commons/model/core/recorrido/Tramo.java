package cl.mtt.rnt.commons.model.core.recorrido;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Paradero;
import cl.mtt.rnt.commons.model.core.TipoVia;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.encargado.bean.util.RecorridoUtils;

import com.google.gson.annotations.Expose;

@Entity
@Table(name = "RNT_TRAMO")
@Audited
public class Tramo extends GenericModelObject implements Comparable<Tramo>, Anonymizable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5102218759421174637L;
	// [-]?(0|[1-9][0-9]*)(\.[0-9]+)?,[-]?(0|[1-9][0-9]*)(\.[0-9]+)?

	public static final String SENTIDO_IDA = "IDA";
	public static final String SENTIDO_VUELTA = "REGRESO";
	public static final String TIPO_CALLE ="CALLE";
	public static final String TIPO_PREDETERMINADO ="PREDETERMINADO";
	public static final String TIPO_PARADERO ="PARADERO";
	
	
	@Expose
	protected Integer orden;
	protected Trazado trazado;
	@Expose
	private String tipoTramo;

	private String codigoComuna;
	private TipoVia tipoVia;
	@Expose
	private String calle;
	@Expose
	private String inicio;
	@Expose
	private String fin;
	@Expose
	private List<String> path;

	private String sentido;
	@Expose
	private BloquePredeterminado bloque;
	private BloquePredeterminado bloquePadre;
	private Comuna comuna;

//	@Expose
//	private Paradero paraderoOrigen;
	@Expose
	private Paradero paradero;

	private String calleGoogle = null;
	private DatoDiccionario datoDiccionario;

	@Column(name = "CALLE")
	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}


	@Column(name = "CODIGO_COMUNA", nullable = true)
	public String getCodigoComuna() {
		return codigoComuna;
	}

	public void setCodigoComuna(String codigoComuna) {
		this.codigoComuna = codigoComuna;
	}

	@Column(name = "INICIO", nullable = true)
	public String getInicio() {
		return inicio;
	}

	public void setInicio(String inicio) {
		this.inicio = inicio;
	}

	@Column(name = "FIN", nullable = true)
	public String getFin() {
		return fin;
	}

	public void setFin(String fin) {
		this.fin = fin;
	}

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "RNT_TRAMO_PATH_DATA", joinColumns = @JoinColumn(name = "ID_TRAMO"))
	@Column(name = "LAT_LONG")
	@OrderColumn(name = "ORDER_POSITION")
	@NotAudited
	@BatchSize (size = 3000)
	public List<String> getPath() {
		return path;
	}

	public void setPath(List<String> path) {
		this.path = path;
	}

	@Transient
	public String getPathAsString() {
		String ret = "";
		for (String point : path) {
			ret += point + ";";
		}
		return ret.substring(0, ret.length() - 1);
	}

	public void setPathAsString(String path) {
		this.path = new ArrayList<String>();
		String[] paths = path.split(";");
		this.path.addAll(Arrays.asList(paths));
	}

	// @ManyToOne(targetEntity=Paradero.class,fetch=FetchType.EAGER)
	// @JoinColumn(name="ID_PARADERO")
	// public Paradero getParadero() {
	// return paradero;
	// }
	// public void setParadero(Paradero paradero) {
	// this.paradero = paradero;
	// }

	@ManyToOne(targetEntity = BloquePredeterminado.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_BLOQUE_PREDETERMINADO")
	public BloquePredeterminado getBloque() {
		return bloque;
	}

	public void setBloque(BloquePredeterminado bloque) {
		this.bloque = bloque;
	}

	
	@ManyToOne(targetEntity = BloquePredeterminado.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_BLOQUE_PREDETERMINADO_PADRE")
	public BloquePredeterminado getBloquePadre() {
		return bloquePadre;
	}

	public void setBloquePadre(BloquePredeterminado bloquePadre) {
		this.bloquePadre = bloquePadre;
	}

	@Override
	public Tramo clone() throws CloneNotSupportedException {
		Tramo t = new Tramo();
		t.setTipoTramo(new String(this.getTipoTramo()));
		if (this.getCalle() != null)
			t.setCalle(new String(this.getCalle()));
		if (this.getCodigoComuna() != null)
			t.setCodigoComuna(new String(this.getCodigoComuna()));
		t.setComuna(this.getComuna());
		if (this.getCreation() != null)
			t.setCreation(new Timestamp(this.getCreation().getTime()));
		t.setDbAction(this.getDbAction());
		if (this.getFin() != null)
			t.setFin(new String(this.getFin()));
		if (this.getId() != null)
			t.setId(new Long(this.getId()));
		if (this.getInicio() != null)
			t.setInicio(new String(this.getInicio()));
		if (this.getModified() != null)
			t.setModified(new Timestamp(this.getModified().getTime()));
		if (this.getOrden() != null)
			t.setOrden(new Integer(this.getOrden()));
		if (this.getBloque() != null)
			t.setBloque(bloque);
		//El bloque no se clona
		if (this.getPath() != null)
			t.setPath(new ArrayList<String>(this.getPath()));
		// t.setPathAsString(new String(this.getPathAsString()));
		if (this.getTrazado() != null)
			t.setTrazado(this.getTrazado());
		if (this.getUserCreation() != null)
			t.setUserCreation(this.getUserCreation());
		if (this.getUserModified() != null)
			t.setUserModified(this.getUserModified());
		if (this.getSentido() != null)
			t.setSentido(new String(this.getSentido()));
		if (this.getParadero() != null)
			t.setParadero(this.getParadero());
		return t;
	}

	@Transient
	public Comuna getComuna() {
		if(comuna == null && paradero!=null){
			return paradero.getComuna();
		}
		return comuna;
	}

	public void setComuna(Comuna comuna) {
		this.comuna = comuna;
	}

	@Transient
	public void invertTramo() {
		String newini = this.getInicio();
		this.setInicio(this.getFin());
		this.setFin(newini);
		Collections.reverse(path);
		// List<String> pathNuevos=new ArrayList<String>();
		// for (String loc : path) {
		// pathNuevos.add(0,loc);
		// }
		// this.setPath(pathNuevos);
	}

	@Column(name = "SENTIDO", nullable = false)
	public String getSentido() {
		return sentido;
	}

	public void setSentido(String sentido) {
		this.sentido = sentido;
	}

//	@ManyToOne(targetEntity = Paradero.class, fetch = FetchType.EAGER)
//	@JoinColumn(name = "ID_PARADERO_ORIGEN")
//	public Paradero getParaderoOrigen() {
//		return paraderoOrigen;
//	}
//
//	public void setParaderoOrigen(Paradero paraderoOrigen) {
//		this.paraderoOrigen = paraderoOrigen;
//	}

	@ManyToOne(targetEntity = Paradero.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_PARADERO_DESTINO")
	public Paradero getParadero() {
		return paradero;
	}

	public void setParadero(Paradero paradero) {
		this.paradero = paradero;
	}

	@Override
	public int compareTo(Tramo t) {
		if (t != null && getOrden() != null && t.getOrden() != null)
			return getOrden().compareTo(t.getOrden());
		return 0;
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
	}

	@Transient
	public Float getLength() {
		Float ret = 0f;
		if (path != null && path.size() > 1) {
			String punto1 = path.get(0);
			for (int i = 1; i < path.size(); i++) {
				String punto2 = path.get(i);
				ret += RecorridoUtils.getPointsDistance(punto1, punto2);
				punto1 = punto2;
			}
		}
		return ret;
	}

	@Transient
	public String getCalleGoogle() {
		return calleGoogle;
	}

	public void setCalleGoogle(String calleGoogle) {
		this.calleGoogle = calleGoogle;
	}

	@Transient
	public DatoDiccionario getDatoDiccionario() {
		return datoDiccionario;
	}

	public void setDatoDiccionario(DatoDiccionario datoDiccionario) {
		this.datoDiccionario = datoDiccionario;
	}

	/**
	 * @return el valor de tipoVia
	 */
	@Transient
	public TipoVia getTipoVia() {
		return tipoVia;
	}

	/**
	 * @param setea el parametro tipoVia al campo tipoVia (Solo para agregar calles al diccionario)
	 */
	public void setTipoVia(TipoVia tipoVia) {
		this.tipoVia = tipoVia;
	}


	@Column(name = "ORDEN", nullable = false)
	public Integer getOrden() {
		return orden;
	}

	public void setOrden(Integer orden) {
		this.orden = orden;
	}

	@ManyToOne(targetEntity = Trazado.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TRAZADO")
	public Trazado getTrazado() {
		return trazado;
	}

	public void setTrazado(Trazado trazado) {
		this.trazado = trazado;
	}

	@Column(name = "TIPO_TRAMO", nullable = false)
	public String getTipoTramo() {
		return tipoTramo;
	}

	public void setTipoTramo(String tipoTramo) {
		this.tipoTramo = tipoTramo;
	}

	
	
}
