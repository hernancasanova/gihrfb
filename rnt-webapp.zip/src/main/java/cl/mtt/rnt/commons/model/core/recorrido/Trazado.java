package cl.mtt.rnt.commons.model.core.recorrido;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import cl.mtt.rnt.commons.model.core.DiaTrazado;
import cl.mtt.rnt.commons.model.core.FrecuenciaTrazado;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.interfaces.Anonymizable;
import cl.mtt.rnt.commons.util.Resources;

import com.google.gson.annotations.Expose;

@Entity
@Table(name = "RNT_TRAZADO")
@Audited
public class Trazado extends GenericModelObject implements Anonymizable,Mapeable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2251242863588087272L;

	@Expose
	private List<Tramo> tramos;
	private List<Tramo> tramosEliminados;
	@Expose
	private String nombre;// (Principal, bucle, inyección)
	private String tipo;// (Principal, bucle, inyección)
	private Float frecuencia;// (vehículos/hora)
	private Integer intervaloSalida;
	private List<DiaTrazado> diasSemanaList;
	private List<FrecuenciaTrazado> frecuencias;

	@Expose
	private Recorrido recorrido;
	// private Float tarifa;
	@Expose
	private String color = "FF2A2A"; //rojo por defecto

	private Boolean usaMapa;
	private List<FrecuenciaTrazado> frecuanciasAEliminar;
	private Float longitud;// del trazado en Km

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Tramo.class, mappedBy = "trazado")
	public List<Tramo> getTramos() {
		return tramos;
	}

	public void setTramos(List<Tramo> tramos) {
		this.tramos = tramos;
	}

	@Column(name = "TIPO", nullable = false)
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Column(name = "FRECUENCIA", nullable = true, columnDefinition = "double")
	public Float getFrecuencia() {
		return frecuencia;
	}

	public void setFrecuencia(Float frecuencia) {
		this.frecuencia = frecuencia;
	}

	@ManyToOne(targetEntity = Recorrido.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_RECORRIDO")
	public Recorrido getRecorrido() {
		return recorrido;
	}

	public void setRecorrido(Recorrido recorrido) {
		this.recorrido = recorrido;
	}

	@Column(name = "COLOR", nullable = false)
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Transient
	public List<Tramo> getTramosClone() throws CloneNotSupportedException {
		List<Tramo> ret = new ArrayList<Tramo>();
		for (Tramo tramo : getTramos()) {
			ret.add(tramo.clone());
		}
		return ret;
	}

	public Trazado clone() throws CloneNotSupportedException {
		Trazado tr = new Trazado();
		tr.setColor(new String(this.getColor()));
		if (this.getLongitud() != null)
			tr.setLongitud(new Float(this.getLongitud()));
		if (this.getFrecuencia() != null)
			tr.setFrecuencia(new Float(this.getFrecuencia()));
		if (this.getIntervaloSalida() != null)
			tr.setIntervaloSalida(this.getIntervaloSalida());
		if (this.getDiasSemanaList() != null) {
			tr.setDiasSemanaList(new ArrayList<DiaTrazado>());
			for (DiaTrazado dt : this.getDiasSemanaList()) {
				DiaTrazado dtclon = (DiaTrazado) dt.clone();
				dtclon.setTrazado(tr);
				tr.getDiasSemanaList().add(dtclon);
			}
		}
		if (this.getFrecuencias() != null) {
			tr.setFrecuencias(new ArrayList<FrecuenciaTrazado>());
			for (FrecuenciaTrazado fr : this.getFrecuencias()) {
				FrecuenciaTrazado frclon = fr.clone();
				frclon.setTrazado(tr);
				tr.getFrecuencias().add(frclon);
			}
		}

		if (this.getId() != null)
			tr.setId(new Long(this.getId()));

		tr.setNombre(new String(this.getNombre()));
		tr.setRecorrido(this.getRecorrido());
		tr.setTipo(new String(this.getTipo()));
		tr.setTramos(new ArrayList<Tramo>());
		for (Tramo tramo : getTramos()) {
			Tramo tramoclon = tramo.clone();
			tramoclon.setTrazado(tr);
			tr.getTramos().add(tramoclon);
		}
		return tr;
	}

	@Transient
	public List<Tramo> getTramosEliminados() {
		return tramosEliminados;
	}

	public void setTramosEliminados(List<Tramo> tramosEliminados) {
		this.tramosEliminados = tramosEliminados;
	}

	/**
	 * @return el valor de intervaloSalida
	 */
	@Column(name = "INTERVALO_SALIDA", nullable = true)
	public Integer getIntervaloSalida() {
		return intervaloSalida;
	}

	/**
	 * @param setea
	 *            el parametro intervaloSalida al campo intervaloSalida
	 */
	public void setIntervaloSalida(Integer intervaloSalida) {
		this.intervaloSalida = intervaloSalida;
	}

	/**
	 * @return el valor de diasSemanaList
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = DiaTrazado.class, mappedBy = "trazado", cascade = CascadeType.ALL)
	public List<DiaTrazado> getDiasSemanaList() {
		return diasSemanaList;
	}

	/**
	 * @param setea
	 *            el parametro diasSemanaList al campo diasSemanaList
	 */
	public void setDiasSemanaList(List<DiaTrazado> diasSemanaList) {
		this.diasSemanaList = diasSemanaList;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = FrecuenciaTrazado.class, mappedBy = "trazado", cascade = CascadeType.ALL)
	public List<FrecuenciaTrazado> getFrecuencias() {
		return frecuencias;
	}

	public void setFrecuencias(List<FrecuenciaTrazado> frecuencias) {
		this.frecuencias = frecuencias;
	}

	@Transient
	public String getDiasInfo() {
		List<String> tool = getTooltipDias();
		if (tool.size() == 1) {
			return tool.get(0);
		} else {
			return tool.get(0) + " ... (+)";
		}
	}

	@Transient
	public List<String> getTooltipDias() {
		List<String> diasstr = new ArrayList<String>();
		for (DiaTrazado dt : diasSemanaList) {
			if (dt.isSeleccionado()) {
				String diaStr = dt.getDiaDesc() + " (";
				if (dt.getHoraDesde() != null) {
					diaStr += dt.getHoraDesde() + " - ";
				} else {
					diaStr += "--:-- - ";
				}
				if (dt.getHoraHasta() != null) {
					diaStr += dt.getHoraHasta() + ")";
				} else {
					diaStr += "--:--)";
				}
				diasstr.add(diaStr);
			}
		}
		if (diasstr.isEmpty()) {
			diasstr.add(Resources.getString("recorrido.trazado.dias.nodata"));
		}
		return diasstr;
	}

	@Transient
	public boolean isPrincipal() {
		return this.tipo.equalsIgnoreCase("Principal");
	}

	@Transient
	public String getTramosIdaAsString() {
		return getTramosAsString(Tramo.SENTIDO_IDA);
	}
	
    @Transient
	public String getTramosVueltaAsString() {
		return getTramosAsString(Tramo.SENTIDO_VUELTA);
	}

	/**
	 * @return
	 */
    @Transient
	private String getTramosAsString(String sentido) {
		String tramosAsString = "";
		
		List<Tramo> tr= new ArrayList<Tramo>(this.getTramos());
		Collections.sort(tr);
		
		for (Tramo tramo : tr) {
			if (tramo.getSentido().equalsIgnoreCase(sentido)) {
			    if (tramo.getTipoTramo().equals(Tramo.TIPO_CALLE)) {
			        if (tramo.getCalle()!=null) {
			            tramosAsString += tramo.getCalle() + "; ";
			        }
			    }
			    else {
			        if (tramo.getTipoTramo().equals(Tramo.TIPO_PARADERO)) {
			            if (tramo.getParadero()!=null) {
			                tramosAsString += tramo.getParadero().getNombre() + "; ";
			            }
			        }
			        else {
			            tramosAsString += getDescripcionTramosBloque(tramo);
			        }
			    }


			}
		}
		return tramosAsString.equals("") ? tramosAsString : tramosAsString.substring(0, tramosAsString.length() - 2);
	}

    @Transient
    private String getDescripcionTramosBloque(Tramo tramo) {
	    if (tramo.getTipoTramo().equals(Tramo.TIPO_CALLE)) {
            if (tramo.getCalle()!=null) {
                return tramo.getCalle() + "; ";
            }
            return "";
        }
        else {
            if (tramo.getTipoTramo().equals(Tramo.TIPO_PARADERO)) {
                if (tramo.getParadero()!=null) {
                    return tramo.getParadero().getNombre() + "; ";
                }
                return "";
            }
            else {
                if ((tramo.getBloque()!=null)&&(tramo.getBloque().getTramos()!=null)) {
                    String ret = "";
                    for (Tramo tramoBloque : tramo.getBloque().getTramos()) {
                        ret += getDescripcionTramosBloque(tramoBloque);
                    }
                    return ret;
                }
                return "";
            }
        }
    }


	@Transient
	public String getItinerarioAsString() {
		String itinerario = "";
		for (DiaTrazado dia : this.getDiasSemanaList()) {
			itinerario += dia.getDiaYHorario() + "; ";
		}
		return itinerario.equals("") ? itinerario : itinerario.substring(0, itinerario.length() - 2);
	}

	@Override
	public void anonimize() {
		this.setId(null);
		this.setDbAction(GenericModelObject.ACTION_SAVE);
		for (Tramo item : tramos) {
			item.anonimize();
		}
		for (DiaTrazado item : diasSemanaList) {
			item.anonimize();
		}

	}

	@Column(name = "USA_MAPA", nullable = true)
	public Boolean getUsaMapa() {
		if (usaMapa == null) {
			usaMapa = true;
			for (Tramo tramo : tramos) {
				if (tramo.getTipoTramo().equals(Tramo.TIPO_CALLE) && (tramo.getInicio() == null || tramo.getFin() == null)) {
					usaMapa = false;
					return usaMapa;
				}
			}
		}
		return usaMapa;
	}

	public void setUsaMapa(Boolean usaMapa) {
		this.usaMapa = usaMapa;
	}

	@Transient
	public Float getLength() {
		if (!getUsaMapa())
			return null;
		Float ret = 0f;
		for (Tramo tramo : tramos) {
			ret += tramo.getLength();
		}
		return ret;
	}

	@Transient
	public List<FrecuenciaTrazado> getFrecuanciasAEliminar() {
		return frecuanciasAEliminar;
	}

	public void setFrecuanciasAEliminar(List<FrecuenciaTrazado> frecuanciasAEliminar) {
		this.frecuanciasAEliminar = frecuanciasAEliminar;
	}

	@Column(name = "LONGITUD", nullable = true, columnDefinition = "double")
	public Float getLongitud() {
		return longitud;
	}

	public void setLongitud(Float longitud) {
		this.longitud = longitud;
	}

}
