package cl.mtt.rnt.commons.model.filter;

public class VehiculoCriteria {

	private String ppu;
	private String estado;
	private Long idTipoCancelacion;
	// Mejoras 201409 Nro: 67
	private Integer anioCreacion;
	// Mejoras 201409 Nro: 67

	/**
	 * @return el valor de ppu
	 */

	public String getPpu() {
		return ppu;
	}

	public String getPpuFiltro() {
		if ((ppu != null) && (ppu.trim().equals(""))) {
			return null;
		}

		return ppu;
	}

	/**
	 * @param setea
	 *            el parametro ppu al campo ppu
	 */
	public void setPpu(String ppu) {
		this.ppu = ppu;
	}

	/**
	 * @return el valor de estado
	 */
	public String getEstado() {
		return estado;
	}

	public String getEstadoFiltro() {
		if (estado != null) {
			if (estado.equals("")) {
				return null;
			}
		}
		return estado;
	}

	/**
	 * @param setea
	 *            el parametro estado al campo estado
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}

	/**
	 * @return el valor de idTipoCancelacion
	 */
	public Long getIdTipoCancelacion() {
		return idTipoCancelacion;
	}

	/**
	 * @return el valor de idTipoCancelacion
	 */
	public Long getIdTipoCancelacionFiltro() {
		if (idTipoCancelacion != null) {
			if (idTipoCancelacion < 0) {
				return null;
			}
		}
		return idTipoCancelacion;
	}

	/**
	 * @param setea
	 *            el parametro idTipoCancelacion al campo idTipoCancelacion
	 */
	public void setIdTipoCancelacion(Long idTipoCancelacion) {
		this.idTipoCancelacion = idTipoCancelacion;
	}

	public void reset() {
		this.idTipoCancelacion = -1L;
		this.estado = "";
		this.ppu = "";
		// Mejoras 201409 Nro: 67
		this.anioCreacion=null;
		// Mejoras 201409 Nro: 67
	}

	// Mejoras 201409 Nro: 67
	public Integer getAnioCreacion() {
		return anioCreacion;
	}

	public void setAnioCreacion(Integer anioCreacion) {
		this.anioCreacion = anioCreacion;
	}
	// Mejoras 201409 Nro: 67
	

}
