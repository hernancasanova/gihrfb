package cl.mtt.rnt.commons.model.sgprt;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import cl.mtt.rnt.commons.model.core.Localizable;

import com.google.gson.annotations.Expose;

@Entity
@Table(name = "COMUNA")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "sgprt")
public class Comuna implements Serializable, Localizable {

	private static final long serialVersionUID = -6591162279037377787L;
	private String codigo;
	@Expose
	private String nombre;
	private Provincia provincia;
	private List<Localidad> localidades;

	public Comuna() {
		super();
	}

	public Comuna(String nombre, String codigo) {
		super();
		this.nombre = nombre;
		this.codigo = codigo;
	}

	@Id
	@Column(name = "ID", nullable = false, columnDefinition = "char")
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@ManyToOne(targetEntity = Provincia.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "IDPROVINCIA")
	public Provincia getProvincia() {
		return provincia;
	}

	public void setProvincia(Provincia provincia) {
		this.provincia = provincia;
	}

	@Transient
	@Override
	public String getIdentifier() {
		return codigo;
	}

	@Transient
	@Override
	public String getRegionIdentifier() {
		return getProvincia().getRegion().getCodigo();
	}

	@Transient
	@Override
	public String getLabel() {
		return nombre;
	}

	@Transient
	@Override
	public String getLabelLarge() {
		return nombre;
	}
	
	@Override
	public int hashCode() {
		if (this.codigo == null)
			return super.hashCode();
		return this.codigo.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;
		if (this.getIdentifier() == null)
			return false;
		return this.getIdentifier().equals(((Comuna) obj).getIdentifier());
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Localidad.class, mappedBy = "comuna")
	public List<Localidad> getLocalidades() {
		return localidades;
	}

	public void setLocalidades(List<Localidad> localidades) {
		this.localidades = localidades;
	}

}