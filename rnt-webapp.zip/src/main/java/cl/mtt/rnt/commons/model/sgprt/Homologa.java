package cl.mtt.rnt.commons.model.sgprt;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Objeto de modelo que representa a Homologa
 * 
 * @author Marina Chobadindegui - Bision
 * 
 */

@Entity
@Table(name = "HOMOLOGA")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "sgprt")
public class Homologa implements Serializable {

	private static final long serialVersionUID = 4080428350965557314L;
	private Integer id;
	private TipoVehiculo tipoVehiculo;
	private TipoGPRT tipoGPRT;

	@Id
	@Column(name = "ID", nullable = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@ManyToOne(targetEntity = TipoVehiculo.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "IDTIPOVEHICULO")
	public TipoVehiculo getTipoVehiculo() {
		return tipoVehiculo;
	}

	public void setTipoVehiculo(TipoVehiculo tipoVehiculo) {
		this.tipoVehiculo = tipoVehiculo;
	}

	@ManyToOne(targetEntity = TipoVehiculo.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "IDTIPOSGPRT")
	public TipoGPRT getTipoGPRT() {
		return tipoGPRT;
	}

	public void setTipoGPRT(TipoGPRT tipoGPRT) {
		this.tipoGPRT = tipoGPRT;
	}

}
