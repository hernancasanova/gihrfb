package cl.mtt.rnt.commons.model.sgprt;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import cl.mtt.rnt.commons.model.core.Localizable;

@Entity
@Table(name = "LOCALIDAD")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "sgprt")
public class Localidad implements Serializable, Localizable {

	private static final long serialVersionUID = 3845393099687718041L;

	private Integer codigo;
	private String nombre;
	private Comuna comuna;

	@Id
	@Column(name = "ID", nullable = false)
	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@ManyToOne(targetEntity = Comuna.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "IDCOMUNA", nullable = true)
	public Comuna getComuna() {
		return comuna;
	}

	public void setComuna(Comuna comuna) {
		this.comuna = comuna;
	}

	@Override
	public int hashCode() {
		if (this.codigo == null)
			return super.hashCode();
		return this.codigo.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;
		if (this.getIdentifier() == null)
			return false;
		return this.getIdentifier().equals(((Localidad) obj).getIdentifier());
	}

	@Override
	@Transient
	public String getRegionIdentifier() {
		return getComuna().getRegionIdentifier();
	}

	@Override
	@Transient
	public String getIdentifier() {
		return String.valueOf(codigo);
	}

	@Override
	@Transient
	public String getLabel() {
		return nombre;
	}
	

	@Transient
	@Override
	public String getLabelLarge() {
		return nombre;
	}
	
}
