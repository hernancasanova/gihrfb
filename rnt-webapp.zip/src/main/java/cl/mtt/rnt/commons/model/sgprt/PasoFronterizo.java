package cl.mtt.rnt.commons.model.sgprt;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Objeto de modelo que representa a PasoFronterizo
 * 
 * @author Marina Chobadindegui - Bision
 * 
 */

@Entity
@Table(name = "PASOFRONTERIZO")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "sgprt")
public class PasoFronterizo implements Serializable {

	private static final long serialVersionUID = -4614863026877832378L;
	private Integer id;
	private String nombre;
	private Provincia provincia;

	@Id
	@Column(name = "ID", nullable = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@ManyToOne(targetEntity = Provincia.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "IDPROVINCIA")
	public Provincia getProvincia() {
		return provincia;
	}

	public void setProvincia(Provincia provincia) {
		this.provincia = provincia;
	}

}
