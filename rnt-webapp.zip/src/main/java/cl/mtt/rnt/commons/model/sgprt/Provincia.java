package cl.mtt.rnt.commons.model.sgprt;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "PROVINCIA")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "sgprt")
public class Provincia implements Serializable {

	private static final long serialVersionUID = -5463271519300489859L;
	private String codigo;
	private String nombre;
	private Region region;
	private List<Comuna> comunas;

	public Provincia() {
		super();
	}

	public Provincia(String codigo, String nombre) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
	}

	@Id
	@Column(name = "ID", nullable = false, columnDefinition = "char")
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@ManyToOne(targetEntity = Region.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "IDREGION")
	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Comuna.class, mappedBy = "provincia")
	public List<Comuna> getComunas() {
		return comunas;
	}

	public void setComunas(List<Comuna> comunas) {
		this.comunas = comunas;
	}

}
