package cl.mtt.rnt.commons.model.sgprt;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.beans.factory.annotation.Qualifier;

import cl.mtt.rnt.commons.model.core.Localizable;

import com.google.gson.annotations.Expose;

/**
 * Objeto de modelo que representa a una Region
 * 
 * @author josebision
 * 
 */

@Entity
@Table(name = "REGION")
@Qualifier("sessionFactory")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "sgprt")
public class Region implements Serializable, Localizable, Comparable<Region> {

	private static final long serialVersionUID = 1791568056492748000L;
	@Expose
	private String nombre;
	private String codigo;
	private String prefijo;
	private List<Provincia> provincias;

	public Region() {
		super();
	}

	public Region(String nombre, String codigo, String prefijo) {
		super();
		this.nombre = nombre;
		this.codigo = codigo;
		this.prefijo = prefijo;
	}

	/**
	 * @return el valor de codigo
	 */
	@Id
	@Column(name = "ID", columnDefinition = "char")
	public String getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo
	 *            setea el valor a codigo
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return el valor de name
	 */
	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param name
	 *            setea el valor a name
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@OneToMany(fetch = FetchType.LAZY, targetEntity = Provincia.class, mappedBy = "region")
	public List<Provincia> getProvincias() {
		return provincias;
	}

	public void setProvincias(List<Provincia> provincias) {
		this.provincias = provincias;
	}

	@Transient
	@Override
	public String getRegionIdentifier() {
		return codigo;
	}

	@Transient
	@Override
	public String getIdentifier() {
		return codigo;
	}

	@Transient
	@Override
	public String getLabel() {
		return nombre;
	}

	@Transient
	@Override
	public String getLabelLarge() {
		return nombre;
	}
	
	@Override
	public int hashCode() {
		if (this.codigo == null)
			return super.hashCode();
		return this.codigo.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;
		if (this.getIdentifier() == null)
			return false;
		return this.getIdentifier().equals(((Region) obj).getIdentifier());
	}

	@Override
	public int compareTo(Region o) {
		return this.getCodigo().compareTo(o.getCodigo());
	}

	/**
	 * @return el valor de prefijo
	 */
	@Column(name = "PREFIJO", nullable = false)
	public String getPrefijo() {
		return prefijo;
	}

	/**
	 * @param setea el parametro prefijo al campo prefijo
	 */
	public void setPrefijo(String prefijo) {
		this.prefijo = prefijo;
	}
}
