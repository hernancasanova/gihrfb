package cl.mtt.rnt.commons.model.sgprt;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Objeto de modelo que representa a TipoVehiculo
 * 
 * @author Marina Chobadindegui - Bision
 * 
 */
@Entity
@Table(name = "TIPOVEHICULO")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "sgprt")
public class TipoVehiculo implements Serializable {

	private static final long serialVersionUID = 2149178882576182519L;
	private Integer id;
	private String descripcion;

	@Id
	@Column(name = "ID", nullable = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "DESCRIPCION", nullable = false)
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public int hashCode() {
		if (this.id == null)
			return super.hashCode();
		return this.id.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;
		if (this.getId() == null)
			return false;
		return this.getId().equals(((TipoVehiculo) obj).getId());
	}

}
