package cl.mtt.rnt.commons.model.userrol;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import cl.mtt.rnt.commons.model.core.GenericModelObject;

@Entity
@Table(name = "RNT_ROL")
public class Rol extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private String nombre;
	private String descripcion;
	private String descriptor;
	private String label;
	private List<User> users;

	@Column(name = "NOMBRE", nullable = false)
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Column(name = "DESCRIPCION", nullable = false)
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Column(name = "DESCRIPTOR")
	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	@Column(name = "RNT_LABEL")
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Transient
	public int getCantidadUsuarios() {
		return (users == null) ? 0 : users.size();
	}

}
