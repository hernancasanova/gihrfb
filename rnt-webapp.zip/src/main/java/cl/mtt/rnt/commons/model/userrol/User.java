package cl.mtt.rnt.commons.model.userrol;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;

@Entity
@Table(name = "RNT_USER")
@Transactional
@Audited
public class User extends GenericModelObject {

	private static final long serialVersionUID = 1L;

	private String nombreUsuario;
	private String password;
	private String nombreCompleto;
	private String rut;
	private String email;
	private Timestamp fechaUltimoLogin;
	private Timestamp fechaEstado;
	private Boolean estado;
	private String cargo;
	private UserContext context;
	private List<Grupo> grupos;

	private Boolean aplicaNacion;

	public User() {
		super();
	}

	@Column(name = "NOMBRE_USUARIO", nullable = false, unique = true)
	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	@Column(name = "PASSWORD", updatable=false, insertable=true)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "NOMBRE_COMPLETO", nullable = false)
	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	@Column(name = "RUT")
	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	@Column(name = "EMAIL")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "FECHA_ULTIMO_LOGIN")
	@NotAudited
	public Date getFechaUltimoLogin() {
		return fechaUltimoLogin;
	}

	public void setFechaUltimoLogin(Timestamp fechaUltimoLogin) {
		this.fechaUltimoLogin = fechaUltimoLogin;
	}

	@Column(name = "FECHA_ESTADO")
	public Date getFechaEstado() {
		return fechaEstado;
	}

	public void setFechaEstado(Timestamp fechaEstado) {
		this.fechaEstado = fechaEstado;
	}

	@Column(name = "ESTADO", nullable = false)
	public Boolean getEstado() {
		return estado;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	@Column(name = "CARGO")
	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	@Transient
	public String getTextualState() {
		if (this.getEstado())
			return Resources.getString("user.estado.activo");
		else
			return Resources.getString("user.estado.inactivo");
	}

	@Transient
	public String getFechaEstadoStr() {
		if (fechaEstado != null) {
			return Constants.dateFormat.format(new Date(fechaEstado.getTime()));
		} else {
			return "";
		}
	}

	@Transient
	public String getFechaUltimoLoginStr() {
		if (fechaUltimoLogin != null) {
			return Constants.dateTimeFormat.format(new Date(fechaUltimoLogin.getTime()));
		} else {
			return "";
		}
	}

	/**
	 * @return el valor de aplicaNacion
	 */
	@Column(name = "APLICA_NACION", nullable = true)
	public Boolean getAplicaNacion() {
		return aplicaNacion;
	}

	/**
	 * @param setea
	 *            el parametro aplicaNacion al campo aplicaNacion
	 */
	public void setAplicaNacion(Boolean aplicaNacion) {
		this.aplicaNacion = aplicaNacion;
	}

	/**
	 * @return el valor de context
	 */
	@ManyToOne(targetEntity = UserContext.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_CONTEXT", unique = true)
	@NotAudited
	public UserContext getContext() {
		return context;
	}

	/**
	 * @param setea
	 *            el parametro context al campo context
	 */
	public void setContext(UserContext context) {
		this.context = context;
	}
	// Mejoras 201409 Nro: 75
	@Transient
	public List<Grupo> getGrupos() {
		return grupos;
	}

	public void setGrupos(List<Grupo> grupos) {
		this.grupos = grupos;
	}
	
	// Mejoras 201409 Nro: 75
	
	

}
