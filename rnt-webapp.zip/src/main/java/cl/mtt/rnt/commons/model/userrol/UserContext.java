package cl.mtt.rnt.commons.model.userrol;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.NotAudited;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.CertificadoSeccion;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.util.Constants;

@Entity
@Table(name = "RNT_USER_CONTEXT")
@Transactional
public class UserContext extends GenericModelObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4432105438791480411L;
	private List<Region> regiones;
	private List<Region> regionesDisponibles;
	private Region regionSeleccionada;
	private List<String> roles;
	private List<CategoriaTransporte> categorias;
	private List<TipoTransporte> tiposTransporte;
	private List<MedioTransporte> mediosTransporte;
	private List<UserContextRegion> contextRegiones; 
	
	// Soporte para el cambio de seleccion de categorias con medio y tipo de
	// transporte
	private List<CategoriaTransporte> categoriasAsignadas;

	@Transient
	public List<Region> getRegiones() {
		return regiones;
	}

	public void setRegiones(List<Region> regiones) {
		this.regiones = regiones;
	}

	@Transient
	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	@ManyToMany(targetEntity = CategoriaTransporte.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_USER_CONTEXT_CATEGORIA_TRANSPORTE", joinColumns = @JoinColumn(name = "USER_CONTEXT_ID"), inverseJoinColumns = @JoinColumn(name = "CATEGORIA_TRANSPORTE_ID"))
	@NotAudited
	public List<CategoriaTransporte> getCategorias() {
		return categorias;
	}

	public void setCategorias(List<CategoriaTransporte> categorias) {
		this.categorias = categorias;
	}

	/**
	 * @return el valor de mediosTransporte
	 */
	@ManyToMany(targetEntity = MedioTransporte.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_USER_CONTEXT_MEDIO_TRANSPORTE", joinColumns = @JoinColumn(name = "USER_CONTEXT_ID"), inverseJoinColumns = @JoinColumn(name = "MEDIO_TRANSPORTE_ID"))
	@NotAudited
	public List<MedioTransporte> getMediosTransporte() {
		return mediosTransporte;
	}

	/**
	 * @param setea
	 *            el parametro mediosTransporte al campo mediosTransporte
	 */
	public void setMediosTransporte(List<MedioTransporte> mediosTransporte) {
		this.mediosTransporte = mediosTransporte;
	}

	/**
	 * @return el valor de mediosTransporte
	 */
	@ManyToMany(targetEntity = TipoTransporte.class, fetch = FetchType.LAZY)
	@JoinTable(name = "RNT_USER_CONTEXT_TIPO_TRANSPORTE", joinColumns = @JoinColumn(name = "USER_CONTEXT_ID"), inverseJoinColumns = @JoinColumn(name = "TIPO_TRANSPORTE_ID"))
	@NotAudited
	public List<TipoTransporte> getTiposTransporte() {
		return tiposTransporte;
	}

	/**
	 * @param setea
	 *            el parametro tiposTransporte al campo tiposTransporte
	 */
	public void setTiposTransporte(List<TipoTransporte> tiposTransporte) {
		this.tiposTransporte = tiposTransporte;
	}

	@Transient
	public List<Long> getAllIdsTiposTransportes() {
		List<Long> lista = new ArrayList<Long>();
		if(this.tiposTransporte==null)
			return null;
		for (TipoTransporte tt : this.tiposTransporte)
			lista.add(tt.getId());
		return lista;
	}

	@Transient
	public List<Long> getAllIdsMediosTransporte() {
		List<Long> lista = new ArrayList<Long>();
		if(this.mediosTransporte==null)
			return null;
		for (MedioTransporte mt : this.mediosTransporte)
			lista.add(mt.getId());
		return lista;
	}

	@Transient
	public List<Long> getAllIdsCategoriasTransporte() {
		List<Long> lista = new ArrayList<Long>();
		if(this.categorias==null)
			return null;
		for (CategoriaTransporte c : this.categorias)
			lista.add(c.getId());
		return lista;
	}

	@Transient
	public List<String> getAllCodigosRegiones() {
		List<String> lista = new ArrayList<String>();
		if(this.regiones==null)
			return null;
		for (Region r : this.regiones)
			lista.add(r.getCodigo());
		return lista;
	}

	/**
	 * @return el valor de regionesDisponibles
	 */
	@Transient
	public List<Region> getRegionesDisponibles() {
	    if (regionesDisponibles != null) {
	        Collections.sort(regionesDisponibles);
	    }
		return regionesDisponibles;
	}

	/**
	 * @param setea
	 *            el parametro regionesDisponibles al campo regionesDisponibles
	 */
	public void setRegionesDisponibles(List<Region> regionesDisponibles) {
		this.regionesDisponibles = regionesDisponibles;
	}

	/**
	 * @return el valor de resionSeleccionada
	 */
	@Transient
	public Region getRegionSeleccionada() {
		return regionSeleccionada;
	}

	/**
	 * @param setea
	 *            el parametro resionSeleccionada al campo resionSeleccionada
	 */
	public void setRegionSeleccionada(Region regionSeleccionada) {
		if (this.getRegiones() != null) {
			this.getRegiones().clear();
			this.getRegiones().add(regionSeleccionada);
		}
		this.regionSeleccionada = regionSeleccionada;
	}

	@Transient
	public List<CategoriaTransporte> getCategoriasAsignadas() {
		return categoriasAsignadas;
	}

	/**
	 * @param setea
	 *            el parametro categoriasAsignadas al campo categoriasAsignadas
	 */
	public void setCategoriasAsignadas(List<CategoriaTransporte> categoriasAsignadas) {
		this.categoriasAsignadas = categoriasAsignadas;
	}

	/**
	 * @return el valor de contextRegiones
	 */
	@OneToMany(fetch = FetchType.LAZY, targetEntity = UserContextRegion.class, mappedBy = "context")
	@NotAudited
	public List<UserContextRegion> getContextRegiones() {
		return contextRegiones;
	}

	/**
	 * @param setea el parametro contextRegiones al campo contextRegiones
	 */
	public void setContextRegiones(List<UserContextRegion> contextRegiones) {
		this.contextRegiones = contextRegiones;
	}
	
	@Transient
	public boolean isSoloConsultor(){
		boolean tieneConsultor =false;
		boolean tieneEncargado =false;
		boolean esSoloConsultor=false;
		if(roles != null){
			for(String rol : roles){
				if(rol.equals(Constants.ROLE_USER_CONSULTOR)){
					tieneConsultor = true;
				}
				if(rol.equals(Constants.ROLE_USER_ENCARGADO)){
					tieneEncargado = true;
				}	
			}
			if(tieneConsultor && !tieneEncargado)
				esSoloConsultor =true;
		}
		return esSoloConsultor;
	}

}
