package cl.mtt.rnt.commons.model.userrol;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.transaction.annotation.Transactional;
	
@Entity		   
@Table(name = "RNT_USER_CONTEXT_REGION")
@Transactional
public class UserContextRegion {
	
	private Long id;
	private UserContext context;
	private String codRegion;
	
	@Id
	@Column(name = "ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	@ManyToOne(targetEntity = UserContext.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_CONTEXT_ID")
	public UserContext getContext() {
		return context;
	}
	
	public void setContext(UserContext context) {
		this.context = context;
	}
	
	@Column(name = "COD_REGION", nullable = false)
	public String getCodRegion() {
		return codRegion;
	}
	
	public void setCodRegion(String codRegion) {
		this.codRegion = codRegion;
	}
	
	

}
