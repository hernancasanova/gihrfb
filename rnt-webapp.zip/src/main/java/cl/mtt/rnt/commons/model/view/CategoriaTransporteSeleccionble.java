package cl.mtt.rnt.commons.model.view;

import java.io.Serializable;

import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.TipoTransporte;

public class CategoriaTransporteSeleccionble implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7680799384016945865L;
	private CategoriaTransporte categoria;
	private TipoTransporte tipoTransporte;
	private MedioTransporte medio;

	/**
	 * @return el valor de categoria
	 */
	public CategoriaTransporte getCategoria() {
		return categoria;
	}

	/**
	 * @param setea
	 *            el parametro categoria al campo categoria
	 */
	public void setCategoria(CategoriaTransporte categoria) {
		this.categoria = categoria;
	}

	/**
	 * @return el valor de tipoTransporte
	 */
	public TipoTransporte getTipoTransporte() {
		return tipoTransporte;
	}

	/**
	 * @param setea
	 *            el parametro tipoTransporte al campo tipoTransporte
	 */
	public void setTipoTransporte(TipoTransporte tipoTransporte) {
		this.tipoTransporte = tipoTransporte;
	}

	/**
	 * @return el valor de medio
	 */
	public MedioTransporte getMedio() {
		return medio;
	}

	/**
	 * @param setea
	 *            el parametro medio al campo medio
	 */
	public void setMedio(MedioTransporte medio) {
		this.medio = medio;
	}

	public String getNombre() {
		return "" + this.getTipoTransporte().getNombre() + " " + this.getMedio().getNombre() + " " + this.getCategoria().getNombre();
	}

	public String getNombreId() {
		return "" + this.getTipoTransporte().getDescriptor() + this.getMedio().getDescriptor() + this.getCategoria().getDescriptor();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		try {
			CategoriaTransporteSeleccionble cts = (CategoriaTransporteSeleccionble) obj;
			return cts.getCategoria().getId().equals(this.getCategoria().getId()) && cts.getMedio().getId().equals(this.getMedio().getId())
					&& cts.getTipoTransporte().getId().equals(this.getTipoTransporte().getId());
		} catch (Exception e) {
			return false;
			// TODO: handle exception
		}

	}

}
