package cl.mtt.rnt.commons.model.view;

import java.io.Serializable;

public class IDRevision implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 825306486009089817L;

    private Long revision;
    private Long id;
    /**
     * @return el valor de revision
     */
    public Long getRevision() {
        return revision;
    }
    /**
     * @param setea el parametro revision al campo revision
     */
    public void setRevision(Long revision) {
        this.revision = revision;
    }
    /**
     * @return el valor de id
     */
    public Long getId() {
        return id;
    }
    /**
     * @param setea el parametro id al campo id
     */
    public void setId(Long id) {
        this.id = id;
    }
    
    
    
}
