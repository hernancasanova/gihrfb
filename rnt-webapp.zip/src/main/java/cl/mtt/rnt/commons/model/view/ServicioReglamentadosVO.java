package cl.mtt.rnt.commons.model.view;

import java.util.Date;

import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.sgprt.Region;

public class ServicioReglamentadosVO {

	private Long idTipoServicio;
	private Long identServicio;
	private String codigoRegion;
	private Date vigenciaDesde;
	private Date vigenciaHasta;
	private Integer estado;
	private TipoServicio tipoServicio;
	private Region region;
	
	public String getCodigoRegion() {
		return codigoRegion;
	}
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}
	public Long getIdentServicio() {
		return identServicio;
	}
	public void setIdentServicio(Long identServicio) {
		this.identServicio = identServicio;
	}
	public Date getVigenciaDesde() {
		return vigenciaDesde;
	}
	public void setVigenciaDesde(Date vigenciaDesde) {
		this.vigenciaDesde = vigenciaDesde;
	}
	public Date getVigenciaHasta() {
		return vigenciaHasta;
	}
	public void setVigenciaHasta(Date vigenciaHasta) {
		this.vigenciaHasta = vigenciaHasta;
	}
	public Integer getEstado() {
		return estado;
	}
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	public Long getIdTipoServicio() {
		return idTipoServicio;
	}
	public void setIdTipoServicio(Long idTipoServicio) {
		this.idTipoServicio = idTipoServicio;
	}
	public TipoServicio getTipoServicio() {
		return tipoServicio;
	}
	public void setTipoServicio(TipoServicio tipoServicio) {
		this.tipoServicio = tipoServicio;
	}
	/**
	 * @return el valor de region
	 */
	public Region getRegion() {
		return region;
	}
	/**
	 * @param setea el parametro region al campo region
	 */
	public void setRegion(Region region) {
		this.region = region;
	}
	
	
	
}
