package cl.mtt.rnt.commons.model.view;

import java.util.List;

import cl.mtt.rnt.commons.model.core.TipoDocumento;

public class TipoDocumentoSeleccionable {
    
    TipoDocumento tipoDocumento;
    boolean materiaObligatoria;
    boolean materiaHabilitada;
    
    /**
	 * @return el valor de materiaHabilitada
	 */
	public boolean isMateriaHabilitada() {
		return materiaHabilitada;
	}
	/**
	 * @param setea el parametro materiaHabilitada al campo materiaHabilitada
	 */
	public void setMateriaHabilitada(boolean materiaHabilitada) {
		this.materiaHabilitada = materiaHabilitada;
	}
	List<String> materias;
    /**
     * @return el valor de tipoDocumento
     */
    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }
    /**
     * @param setea el parametro tipoDocumento al campo tipoDocumento
     */
    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
    /**
     * @return el valor de materiaObligatoria
     */
    public boolean isMateriaObligatoria() {
        return materiaObligatoria;
    }
    /**
     * @param setea el parametro materiaObligatoria al campo materiaObligatoria
     */
    public void setMateriaObligatoria(boolean materiaObligatoria) {
        this.materiaObligatoria = materiaObligatoria;
    }
    /**
     * @return el valor de materias
     */
    public List<String> getMaterias() {
        return materias;
    }
    /**
     * @param setea el parametro materias al campo materias
     */
    public void setMaterias(List<String> materias) {
        this.materias = materias;
    }
    
    
    

}
