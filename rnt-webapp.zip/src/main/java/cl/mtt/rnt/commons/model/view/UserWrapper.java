package cl.mtt.rnt.commons.model.view;

import java.util.ArrayList;

import javax.persistence.Transient;

import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.model.core.TipoTransporte;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.userrol.UserContext;

public class UserWrapper extends User {

	private UserContext contextoLimitado;
	private User user;

	public UserWrapper(User user, CategoriaTransporteSeleccionble cat) {
		this.user = user;
		contextoLimitado = new UserContext();
		contextoLimitado.setCategorias(new ArrayList<CategoriaTransporte>());
		contextoLimitado.getCategorias().add(cat.getCategoria());
		contextoLimitado.setMediosTransporte(new ArrayList<MedioTransporte>());
		contextoLimitado.getMediosTransporte().add(cat.getMedio());
		contextoLimitado.setTiposTransporte(new ArrayList<TipoTransporte>());
		contextoLimitado.getTiposTransporte().add(cat.getTipoTransporte());
		contextoLimitado.setRegiones(user.getContext().getRegiones());
		contextoLimitado.setRegionesDisponibles(user.getContext().getRegionesDisponibles());
		contextoLimitado.setRegionSeleccionada(user.getContext().getRegionSeleccionada());
		contextoLimitado.setRoles(user.getContext().getRoles());
		this.setContext(user.getContext());
		this.setAplicaNacion(user.getAplicaNacion());
		this.setCargo(user.getCargo());
		this.setEmail(user.getEmail());
		this.setEstado(user.getEstado());
		this.setNombreCompleto(user.getNombreCompleto());
		this.setNombreUsuario(user.getNombreCompleto());
		this.setRut(user.getRut());
		this.setId(user.getId());
		this.setPassword(user.getPassword());
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1908013154669224038L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see cl.mtt.rnt.commons.model.userrol.User#getContext()
	 */
	@Override
	@Transient
	public UserContext getContext() {

		return contextoLimitado;
	}

	/**
	 * @return el valor de user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param setea
	 *            el parametro user al campo user
	 */
	public void setUser(User user) {
		this.user = user;
	}

}
