package cl.mtt.rnt.commons.model.view;

import java.util.Date;

import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.encargado.dto.VehiculoServicioDTO;

public class VehiculoDataKeeper {
    
    private Integer estado;
    private Date fechaDesde;
    private Date fechaHasta;
    private Date fechaCambioEstado;
    private Reglamentacion reglamentacion;
    private Zona zonaReglamenta;
    private TipoCancelacion tipoCancelacion;
    private int dbaction;
    private Vehiculo vehiculoTransient;
    private Vehiculo vehiculoTransientWS;
    private String observacionesCancelacion;
   
    /**
     * 
     * @param vs
     */
    public VehiculoDataKeeper(VehiculoServicio vs) {
        this.estado = new Integer(vs.getEstado());
        this.fechaDesde = new Date(vs.getFechaIngreso().getTime());
        this.fechaHasta = new Date(vs.getFechaVencimiento().getTime());
        this.reglamentacion = vs.getReglamentacion();
        this.tipoCancelacion = vs.getTipoCancelacion();
        this.observacionesCancelacion = vs.getObservacionCancelacion();
        this.zonaReglamenta = vs.getZonaVehiculo();
        this.fechaCambioEstado = new Date(vs.getFechaCambioEstado().getTime());
        this.vehiculoTransient = new Vehiculo();
        this.vehiculoTransient.setAdquisicion(vs.getVehiculo().getAdquisicion());
        this.vehiculoTransient.setAdquisicionesAnteriores(vs.getVehiculo().getAdquisicionesAnteriores());
        if(vs.getVehiculoWs()!=null){
	        this.vehiculoTransientWS = new Vehiculo();
	        this.vehiculoTransientWS.setAdquisicion(vs.getVehiculoWs().getAdquisicion());
	        this.vehiculoTransientWS.setAdquisicionesAnteriores(vs.getVehiculoWs().getAdquisicionesAnteriores());
        }
        this.dbaction = vs.getDbAction();
    }
    
    /**
     * 
     * @param vsDto
     */
    public void restoreDataKeeped(VehiculoServicioDTO vsDto) {
        vsDto.setEstado(this.estado);
        if (this.reglamentacion!=null) {
            vsDto.setIdReglamentacion(reglamentacion.getId());
        }
        if (this.tipoCancelacion!=null) {
            vsDto.setTipoCancelacionId(this.tipoCancelacion.getId());
        }
        if (vsDto.getVs()!=null) {
            VehiculoServicio vs = vsDto.getVs();
            vs.setEstado(this.estado);
            vs.setFechaIngreso(this.fechaDesde);
            vs.setFechaCambioEstado(this.fechaCambioEstado);
            vs.setFechaVencimiento(this.fechaHasta);
            vs.setReglamentacion(this.reglamentacion);
            vs.setTipoCancelacion(this.tipoCancelacion);
            vs.setZonaVehiculo(this.zonaReglamenta);
            vs.setDbAction(this.dbaction);
            vs.setObservacionCancelacion(this.observacionesCancelacion);
            vs.getVehiculo().setAdquisicion(this.vehiculoTransient.getAdquisicion());
            vs.getVehiculo().setAdquisicionesAnteriores(this.vehiculoTransient.getAdquisicionesAnteriores());
            if(vs.getVehiculoWs()!=null && this.vehiculoTransientWS!=null){
            	vs.getVehiculoWs().setAdquisicion(this.vehiculoTransientWS.getAdquisicion());
            	vs.getVehiculoWs().setAdquisicionesAnteriores(this.vehiculoTransientWS.getAdquisicionesAnteriores());
            }
            
        }
        
    }
    
   
    
    

}
