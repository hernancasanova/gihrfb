package cl.mtt.rnt.commons.model.view;

import java.util.Date;

import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.sgprt.Region;

public class VehiculoHistorico {
	
	private Date fechaOperacion;
	private String region;
	private Long folio; // ident servicio
	private String numeroLinea;
	private String tipoServicio;
	private Integer estadoVehiculo;
	private String tipoOperacion;
	private String regionDestino;
	private String reemplaza;
	private String reemplazado;
	private String reglamentacion;
	
	
	public Date getFechaOperacion() {
		return fechaOperacion;
	}
	public void setFechaOperacion(Date fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}
	public boolean isFechaOperacionValida(){
		if (fechaOperacion==null)
			return true;
		Date year1900=new Date(00,10,10);
		return fechaOperacion.after(year1900);
	}
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Long getFolio() {
		return folio;
	}
	public void setFolio(Long folio) {
		this.folio = folio;
	}
	public String getNumeroLinea() {
		return numeroLinea;
	}
	public void setNumeroLinea(String numeroLinea) {
		this.numeroLinea = numeroLinea;
	}
	public String getTipoServicio() {
		return tipoServicio;
	}
	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}
	public Integer getEstadoVehiculo() {
		return estadoVehiculo;
	}
	public void setEstadoVehiculo(Integer estadoVehiculo) {
		this.estadoVehiculo = estadoVehiculo;
	}
	public String getTipoOperacion() {
		return tipoOperacion;
	}
	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}
	public String getRegionDestino() {
		return regionDestino;
	}
	public void setRegionDestino(String regionDestino) {
		this.regionDestino = regionDestino;
	}
	public String getReemplaza() {
		return reemplaza;
	}
	public void setReemplaza(String reemplaza) {
		this.reemplaza = reemplaza;
	}
	public String getReemplazado() {
		return reemplazado;
	}
	public void setReemplazado(String reemplazado) {
		this.reemplazado = reemplazado;
	}
	public String getReglamentacion() {
		return reglamentacion;
	}
	public void setReglamentacion(String reglamentacion) {
		this.reglamentacion = reglamentacion;
	}
	
	

}
