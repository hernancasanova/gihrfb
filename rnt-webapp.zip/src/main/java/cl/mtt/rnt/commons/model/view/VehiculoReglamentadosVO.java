package cl.mtt.rnt.commons.model.view;

import java.util.Date;

import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.sgprt.Region;

public class VehiculoReglamentadosVO {

	private Long idTipoServicio;
	private Long identServicio;
	private String codigoRegion;
	private Date vigenciaDesde;
	private Date vigenciaHasta;
	private Integer estado;
	private String ppu;
	private TipoServicio tipoServicio;
	private Region region;
	
	/**
	 * @return el valor de idTipoServicio
	 */
	public Long getIdTipoServicio() {
		return idTipoServicio;
	}
	/**
	 * @param setea el parametro idTipoServicio al campo idTipoServicio
	 */
	public void setIdTipoServicio(Long idTipoServicio) {
		this.idTipoServicio = idTipoServicio;
	}
	/**
	 * @return el valor de identServicio
	 */
	public Long getIdentServicio() {
		return identServicio;
	}
	/**
	 * @param setea el parametro identServicio al campo identServicio
	 */
	public void setIdentServicio(Long identServicio) {
		this.identServicio = identServicio;
	}
	/**
	 * @return el valor de codigoRegion
	 */
	public String getCodigoRegion() {
		return codigoRegion;
	}
	/**
	 * @param setea el parametro codigoRegion al campo codigoRegion
	 */
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}
	/**
	 * @return el valor de vigenciaDesde
	 */
	public Date getVigenciaDesde() {
		return vigenciaDesde;
	}
	/**
	 * @param setea el parametro vigenciaDesde al campo vigenciaDesde
	 */
	public void setVigenciaDesde(Date vigenciaDesde) {
		this.vigenciaDesde = vigenciaDesde;
	}
	/**
	 * @return el valor de vigenciaHasta
	 */
	public Date getVigenciaHasta() {
		return vigenciaHasta;
	}
	/**
	 * @param setea el parametro vigenciaHasta al campo vigenciaHasta
	 */
	public void setVigenciaHasta(Date vigenciaHasta) {
		this.vigenciaHasta = vigenciaHasta;
	}
	/**
	 * @return el valor de estado
	 */
	public Integer getEstado() {
		return estado;
	}
	/**
	 * @param setea el parametro estado al campo estado
	 */
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	/**
	 * @return el valor de ppu
	 */
	public String getPpu() {
		return ppu;
	}
	/**
	 * @param setea el parametro ppu al campo ppu
	 */
	public void setPpu(String ppu) {
		this.ppu = ppu;
	}
	/**
	 * @return el valor de tipoServicio
	 */
	public TipoServicio getTipoServicio() {
		return tipoServicio;
	}
	/**
	 * @param setea el parametro tipoServicio al campo tipoServicio
	 */
	public void setTipoServicio(TipoServicio tipoServicio) {
		this.tipoServicio = tipoServicio;
	}
	/**
	 * @return el valor de region
	 */
	public Region getRegion() {
		return region;
	}
	/**
	 * @param setea el parametro region al campo region
	 */
	public void setRegion(Region region) {
		this.region = region;
	}
	
	
}
