package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Atributo;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoServicioAtributo;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.encargado.dto.AtributoServicioLogDTO;

public interface AtributoManager {

    /**
     * 
     * @param aplicaA
     * @return
     * @throws GeneralDataAccessException
     */
	public List<Atributo> getAllAtributosByAplicaA(String aplicaA) throws GeneralDataAccessException;

	/**
	 * 
	 * @param idTipoServicio
	 * @param aplicaA
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Atributo> getAtributosByTipoServicioAplicaA(Long idTipoServicio, String aplicaA) throws GeneralDataAccessException;

	/**
	 * 
	 * @param servicio
	 * @param aplicaA
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Atributo> getAtributosSinIntanciaByAplicaA(Servicio servicio, String aplicaA) throws GeneralDataAccessException;

	/**
	 * 
	 * @param atributosInstancia
	 * @throws GeneralDataAccessException
	 */
	public void preHandle(List<AtributoInstancia> atributosInstancia) throws GeneralDataAccessException;

	/**
	 * 
	 * @param atributoInstancia
	 * @throws GeneralDataAccessException
	 */
	public void saveAtributoInstancia(AtributoInstancia atributoInstancia) throws GeneralDataAccessException;

	/**
	 * 
	 * @param atributoInstancia
	 * @throws GeneralDataAccessException
	 */
	public void updateAtributoInstancia(AtributoInstancia atributoInstancia) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param idAtributo
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Atributo getAtributosById(Long idAtributo) throws GeneralDataAccessException;
	
	// Mejoras 201409 Nro: 69
	/**
	 * 
	 * @param descriptor
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Atributo getAtributoByDescriptor (String descriptor)throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param vehiculosID
	 * @param idAtributo
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<AtributoInstancia> getAtributosInstanciasByVehiculosIdandIdAtributo(List<Long>vehiculosID , Long idAtributo)throws GeneralDataAccessException;
	// Mejoras 201409 Nro: 69
	
	// Mejoras 201409 Nro: 78
	/**
	 * 
	 * @param idServico
	 * @param descriptor
	 * @param aplicaA
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public String getAtributoInstanciaByIdServicioAndDescriptor(Long idServico, String descriptor, String aplicaA) throws GeneralDataAccessException;
	//Mejoras 201409 Nro: 78

	/**
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public List<AtributoInstancia> getAtributoInstanciaByIdServicio(Servicio id) throws GeneralDataAccessException;
    
    /**
     * 
     * @param vs
     * @return
     * @throws GeneralDataAccessException
     */
    public List<AtributoInstancia> getAtributoInstanciaByVehiculo(Vehiculo vs) throws GeneralDataAccessException;

    /**
     * 
     */
    void fillCache();


    /**
     * 
     * @param attr
     * @param tipoServicio
     * @return
     * @throws GeneralDataAccessException
     */
    public boolean estAtributoObligatorio(Atributo attr, TipoServicio tipoServicio) throws GeneralDataAccessException;

    
    
    /**
     * 
     * @param id
     * @return
     * @throws GeneralDataAccessException
     */
    public List<AtributoServicioLogDTO> getAtributosLogInstanciaServicio(Long id) throws GeneralDataAccessException;

    /**
     * 
     * @param id
     * @return
     */
    public List<TipoServicioAtributo> getTipoSevicioAtributoByTsId(Long id) throws GeneralDataAccessException;
    
    
    /**
     * 
     * @param attid
     * @param tsid
     * @return
     * @throws GeneralDataAccessException
     */
    public TipoServicioAtributo getTipoSevicioAtributoByTsAt(Long attid,Long tsid) throws GeneralDataAccessException;

    
    /**
     * 
     * @param id
     * @param aplicaAServicio
     * @return
     */
    public List<TipoServicioAtributo> getTipoSevicioAtributoByTsIdAplica(Long id, String aplicaAServicio)throws GeneralDataAccessException;

    /**
     * 
     * @param valorActualLinea
     * @param servicio
     * @throws GeneralDataAccessException 
     */
	public void updateLineaAud(String valorActualLinea,Servicio servicio) throws GeneralDataAccessException;

	/**
	 * 
	 * @param id
	 * @param string
	 * @param aplicaAServicio
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public String getValorAtributoInstanciaByIdServicioAndDescriptor(Long id,String string, String aplicaAServicio) throws GeneralDataAccessException;
	

}
