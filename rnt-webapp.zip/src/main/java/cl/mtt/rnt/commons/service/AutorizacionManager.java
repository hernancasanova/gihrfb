package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.autorizacion.Autorizacion;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.model.core.autorizacion.Notificacion;
import cl.mtt.rnt.commons.model.userrol.User;

public interface AutorizacionManager {

	/**
	 * 
	 * @param idNormativa
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Autorizacion getAutorizacionByNormativa (Long idNormativa) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param first
	 * @param rows
	 * @param orderFields
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<AutorizacionMovimiento> getAutorizacionesMovimientoPag(User user, int first, int rows, List<String> orderFields) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public long getAutorizacionesMovimientoCount(User user) throws GeneralDataAccessException;

	/**
	 * Genera Autorizacion moviemiento con la notificacion correspondiente
	 * @param autorizacionMovimiento
	 * @param asociado   VehiculoServicio o Conductor (incluye auxiliares)
	 * @throws GeneralDataAccessException
	 */
	public void handle(User currentUser,AutorizacionMovimiento autorizacionMovimiento,GenericModelObject asociado) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param movimiento
	 * @param noti
	 * @param notiRespuesta
	 * @throws GeneralDataAccessException
	 */
	public void aceptarAutorizacionMovimiento(Object movimiento, Notificacion noti, Notificacion notiRespuesta) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param movimiento
	 * @param noti
	 * @param notiRespuesta
	 * @throws GeneralDataAccessException
	 */
	public void rechazarAutorizacionMovimiento(Object movimiento, Notificacion noti, Notificacion notiRespuesta) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param tipoMovimiento
	 * @param idMovimiento
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<AutorizacionMovimiento> getAutorizacionMovimientoByTipoYIdmovimiento (Integer tipoMovimiento, Long idMovimiento) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param idConductor
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Normativa> getAutorizacionMovimientoConductoresServicioAprobadas(Long idConductor) throws GeneralDataAccessException;

	/**
	 * 
	 * @param idConductor
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Normativa> getAutorizacionMovimientoConductoresVehiculoAprobadas(Long idConductor) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public List<Grupo> getGrupoAutorizantesRevertir(Servicio servicio) throws GeneralDataAccessException;

    /**
     * 
     * @return
     */
    public Autorizacion getAutorizacionRevertir()throws GeneralDataAccessException;

}
