package cl.mtt.rnt.commons.service;

import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.richfaces.model.UploadedFile;

import cl.mtt.rnt.commons.bean.BibliotecaDigitalCriteria;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.InvalidUploadAlfrescoException;
import cl.mtt.rnt.commons.model.core.DocumentoBiblioteca;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.TipoDocumentoSeleccionable;
import cl.mtt.rnt.commons.ws.bibliotecadigital.auth.AuthenticationFault_Exception;
import cl.mtt.rnt.commons.ws.bibliotecadigital.content.GetDocumentObjectResponse;

public interface BibliotecaDigitalManager {

	/**
	 * 
	 * @param criteria
	 * @param user
	 * @return
	 * @throws GeneralDataAccessException
	 * @throws AuthenticationFault_Exception
	 * @throws DatatypeConfigurationException
	 * @throws InvalidUploadAlfrescoException
	 */
	public List<GetDocumentObjectResponse> findDocumentos(BibliotecaDigitalCriteria criteria, User user) throws GeneralDataAccessException, AuthenticationFault_Exception, DatatypeConfigurationException, InvalidUploadAlfrescoException;
	
	/**
	 * 
	 * @param documento
	 * @param file
	 * @param user
	 * @throws GeneralDataAccessException
	 * @throws AuthenticationFault_Exception
	 * @throws DatatypeConfigurationException
	 * @throws InvalidUploadAlfrescoException
	 */
	public void saveDocumento(DocumentoBiblioteca documento, UploadedFile file, User user) throws GeneralDataAccessException, AuthenticationFault_Exception, DatatypeConfigurationException, InvalidUploadAlfrescoException;

	public void saveDocumento(DocumentoBiblioteca documento) throws GeneralDataAccessException;

	/**
	 * 
	 * @param nombreDoc
	 * @param codigoRegion
	 * @param materia
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public DocumentoBiblioteca getDocumentoLocal(String nombreDoc,String codigoRegion,String materia)  throws GeneralDataAccessException;

	/**
	 * 
	 * @param documento
	 * @throws GeneralDataAccessException
	 */
	public void registrarDocumentoExistente(DocumentoBiblioteca documento) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
    List<TipoDocumentoSeleccionable> getTiposSeleccionables() throws GeneralDataAccessException;

    /**
     * 
     */
    public void fillCache();
}
