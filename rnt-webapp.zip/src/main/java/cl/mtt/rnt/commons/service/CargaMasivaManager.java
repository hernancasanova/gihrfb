package cl.mtt.rnt.commons.service;

import java.util.List;

import javax.xml.bind.JAXBException;

import cl.mtt.rnt.commons.exception.CertificadoException;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.VehicleWithoutOwnerException;
import cl.mtt.rnt.commons.model.core.CargaMasiva;
import cl.mtt.rnt.commons.model.core.DocumentoBiblioteca;
import cl.mtt.rnt.commons.model.core.TipoCargaMasiva;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.ExecutionResult;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.handsonTable.HandsonRowContent;

public interface CargaMasivaManager {
	
	/**
	 * Obtine el listado de cargas masivas de un usuario
	 * @param user
	 * @param region 
	 * @param categoria 
	 * @return List<CargaMasiva>
	 * @throws GeneralDataAccessException
	 */
	public List<CargaMasiva> getCargasMasivas(User user, CategoriaTransporteSeleccionble categoria, Region region) throws GeneralDataAccessException;
	
	/**
	 * Retorna el listado de tipos de cargas masivas disponibles
	 * @return List<TipoCargaMasiva>
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCargaMasiva> getTiposCargaMasiva() throws GeneralDataAccessException;
	
	/**
	 * Guarda una carga masiva
	 * @param cargaMasivaSel
	 * @throws GeneralDataAccessException
	 */
	public void guardarOActualizarCargaMasiva(CargaMasiva cargaMasivaSel) throws GeneralDataAccessException;

	public void setJobToCargaMasiva(CargaMasiva cargaMasiva) throws GeneralDataAccessException;
	
	/**
	 * Procesa la carga masiva de cambio de vigencia de servicios
	 * Procesa de a un registro para mantener la transaccion por registro
	 * @param unRegistro
	 * @param generarCertNoObligatorios
	 * @throws Exception
	 */
	public void ejecutarCambioVigenciaServicio(HandsonRowContent row) throws Exception;
	
	/**
	 * Procesa la carga masiva de reajuste tarifario
	 * Procesa de a un registro para mantener la transaccion por registro
	 * @param unRegistro
	 * @throws Exception
	 */
	public void ejecutarReajusteTarifarioServicio(HandsonRowContent row,String chengeType) throws Exception;

	public ExecutionResult ejecutarCancelacionServicio(List<HandsonRowContent> contenidoTabla) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException;
	
	/**
	 * Elimina una carga masiva con su job
	 * @param cargaMasivaSel
	 * @throws GeneralDataAccessException
	 */
	public void deleteCargaMasiva(CargaMasiva cargaMasivaSel) throws GeneralDataAccessException;

	public ExecutionResult ejecutarCancelacionVahiculoServicio(List<HandsonRowContent> rows, boolean generarCertNoObligatorios,DocumentoBiblioteca documento) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException;

	public ExecutionResult ejecutarCargaAtributoServicio(List<HandsonRowContent> rows) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException;

	public ExecutionResult ejecutarCargaAtributoVehiculo(List<HandsonRowContent> rows) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException, VehicleWithoutOwnerException;

	public ExecutionResult ejecutarCargaRecorridos(List<HandsonRowContent> rows) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException;

	public ExecutionResult ejecutarCargaTrazado(List<HandsonRowContent> rows) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException;

	public ExecutionResult ejecutarCargaCalles(HandsonRowContent r) throws GeneralDataAccessException;

	public ExecutionResult ejecutarReajusteTarifarioMatrizServicio(List<HandsonRowContent> rows,String changeType) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException;
	
	public ExecutionResult ejecutarReajusteTarifarioMatrizRecorrido(List<HandsonRowContent> rows, String changeType) throws GeneralDataAccessException, JAXBException, EventEvalException;


}
