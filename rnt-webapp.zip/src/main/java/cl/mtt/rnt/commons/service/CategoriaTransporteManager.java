package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;

public interface CategoriaTransporteManager {

	/**
	 * Obtiene todas las categorías de transporte
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 * @author Marina Chobadindegui
	 */
	public List<CategoriaTransporte> getAllCategoriasTrasporte() throws GeneralDataAccessException;

	/**
	 * Obtiene la Categoria de Transporte por el id dado como parámetro
	 * 
	 * @param idCategoriaTransporte
	 * @return
	 * @throws GeneralDataAccessException
	 * @author Marina Chobadindegui
	 */
	public CategoriaTransporte getCategoriaTransporteById(Long idCategoriaTransporte) throws GeneralDataAccessException;

	/**
	 * Guarda el Categoría Transporte dado como parámetro
	 * 
	 * @param tipoTransporte
	 * @throws GeneralDataAccessException
	 * @author Marina Chobadindegui
	 */
	public void saveCategoriaTransporte(CategoriaTransporte categoriaTransporte) throws GeneralDataAccessException, DuplicatedIdException;

	/**
	 * Obtiene una Categoria de Transporte a partir del descriptor dado como
	 * parámetro
	 * 
	 * @param descriptor
	 * @return
	 * @throws GeneralDataAccessException
	 * @author Marina Chobadindegui
	 */
	public CategoriaTransporte getCategoriaTransporteByDescriptor(String descriptor) throws GeneralDataAccessException;

	/**
	 * Guarda un Categoría de Transporte existente
	 * 
	 * @param cateogoriaTransporte
	 * @throws GeneralDataAccessException
	 * @throws DuplicatedIdException
	 * @author Marina Chobadindegui
	 */
	public void updateCategoriaTransporte(CategoriaTransporte cateogoriaTransporte) throws GeneralDataAccessException, DuplicatedIdException;

	/**
	 * Elimina la Categoría de Transporte dada como parámetros si no existe un
	 * Tipo de Servicio relacionado al mismo
	 * 
	 * @param cateogoriaTransporte
	 * @throws GeneralDataAccessException
	 * @throws RemoveNotAllowedException
	 */
	public void removeCategoriaTransporte(CategoriaTransporte cateogoriaTransporte) throws GeneralDataAccessException, RemoveNotAllowedException;
}
