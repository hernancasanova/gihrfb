package cl.mtt.rnt.commons.service;

import java.util.List;
import java.util.Map;

import cl.mtt.rnt.commons.exception.CertificadoException;
import cl.mtt.rnt.commons.exception.CertificadoMigradoException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.InvalidSchemaFirmador;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.CertificadoValorVariable;
import cl.mtt.rnt.commons.model.core.EstadoCertificadoFirma;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.XmlCertificado;
import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.util.filter.CertificadoFilter;
import cl.mtt.rnt.commons.ws.exception.WSException;

public interface CertificadoManager {

	/**
	 * Graba un nuevo certificado
	 * 
	 * @param cert
	 * @throws GeneralDataAccessException
	 */
	public void saveCertificado(Certificado cert) throws GeneralDataAccessException;

	/**
	 * Actualiza un certificado
	 * 
	 * @param cert
	 * @throws GeneralDataAccessException
	 */
	public void updateCertificado(Certificado cert) throws GeneralDataAccessException;

	// Mejoras 201409 Nro: 33
	public void cancelarCertificadoManual(Servicio servicio,Certificado cert,String observacionesCancelacion) throws GeneralDataAccessException;
	// Mejoras 201409 Nro: 33
	
	/**
	 * Consulta los certificados segun filtro
	 * 
	 * @param filtro
	 * @param categoriaTransporte
	 * @param user
	 * @param ids lista de ids para filtrar
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Certificado> getCertificadosFiltrados(CertificadoFilter filtro, CategoriaTransporte categoriaTransporte, User user,List<Long> ids) throws GeneralDataAccessException;
	
	public List<Certificado> getCertificadosFiltrados(CertificadoFilter filtro) throws GeneralDataAccessException;

	public List<Long> getIdsCertificadosByFilter(CertificadoFilter filtro, CategoriaTransporte ct, User user) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param vehiculoServicio
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Certificado> getCertificadoActualByVehiculoServicio(Long vehiculoServicioId) throws GeneralDataAccessException;

	/**
	 * 
	 * @param colaCertificados
	 * @param servicio
	 * @param saveNotRequiredCertificados 
	 * @return
	 * @throws GeneralDataAccessException
	 * @throws CertificadoException
	 */
	public boolean handlerCertificados(List<Certificado> colaCertificados, Servicio servicio) throws GeneralDataAccessException, CertificadoException;

	/**
	 * 
	 * @param colaCertificados
	 * @param servicio
	 * @return
	 * @throws GeneralDataAccessException
	 * @throws CertificadoException
	 */
	public boolean handlerCertificadosInternal(List<Certificado> colaCertificados, Servicio servicio) throws GeneralDataAccessException, CertificadoException;
	
	/**
	 * Retorna el valor variable de un campo de certificado
	 * 
	 * @param descriptor
	 * @param region
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public CertificadoValorVariable getValorVariable(String descriptor, Region region) throws GeneralDataAccessException;

	/**
	 * Retorna el estado de la firma de un certificado
	 * 
	 * @param cert
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public EstadoCertificadoFirma cosultarEstadoCertificado(Certificado cert) throws GeneralDataAccessException;

	/**
	 * Retorna los datos con los que fue llenado un certificado
	 * 
	 * @param cert
	 * @return
	 * @throws GeneralDataAccessException
	 */
//	public List<CertificadoDato> getCertificadoDatoByCertificado(Certificado cert) throws GeneralDataAccessException;

	/**
	 * Retorna certificado de inscripcion vigente para un vehiculo servvicio sin
	 * recorrido
	 * 
	 * @param vehiculoServicio
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Certificado getCertificadoCurrentInscripcionActual_(VehiculoServicio vehiculoServicio) throws GeneralDataAccessException,CertificadoMigradoException;

	public Map<Long,Certificado> getCertificadosCurrentInscripcionActual_(Servicio servicio) throws GeneralDataAccessException,CertificadoMigradoException;

	/**
	 * Retorna el certificado de inscripcion vigente correspondiente a un
	 * vehiculo con un recorrido
	 * 
	 * @param vehiculoServicio
	 * @param acertificar
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Certificado getCertificadoCurrentInscripcionActual_(VehiculoServicio vehiculoServicio, Recorrido acertificar) throws GeneralDataAccessException, CertificadoMigradoException;

	/**
	 * Obtiene los certificados de inscripción de vehículo para un servicio dado
	 * como parámetro
	 * 
	 * @param serv
	 * @param object2 
	 * @param object 
	 * @param rows 
	 * @param first 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Certificado> getCertificadosVehiculoByServicio(Servicio serv, int first, int rows,CertificadoFilter filter, List<String> orderFields,List<Long> idsVS) throws GeneralDataAccessException;

	public long getCertificadosVehiculoByServicioCount(Servicio serv,CertificadoFilter filter,List<Long> idsVS) throws GeneralDataAccessException;

	/**
	 * Obtiene los certificados de recorridos para un servicio dado como
	 * parámetro
	 * 
	 * @param serv
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Certificado> getCertificadosRecorridoByServicio(Servicio serv, int first, int rows,CertificadoFilter filter, List<String> orderFields,List<Long> idsVS) throws GeneralDataAccessException;

	public long getCertificadosRecorridoByServicioCount(Servicio servicio,CertificadoFilter filter,List<Long> idsVS)throws GeneralDataAccessException;

	public XmlCertificado getXmlByCertificado(Long idCertificado) throws GeneralDataAccessException;
	
	public String firmarCertificado(Certificado certificado) throws WSException, GeneralDataAccessException;
	
	public void saveXMLCertificado(Certificado certificado, String xml) throws GeneralDataAccessException;

	public Certificado getCertificadoById(Long idCertSeleccionado) throws GeneralDataAccessException;
	
	public byte[] getPreview(String tipoDocumento, String materia, byte[] xmlBytes) throws WSException, InvalidSchemaFirmador;

	public long getCountCertificadosSinFirmar(Long idTipoCertificado)throws GeneralDataAccessException;
	
	public long getCountCertificadosSinFirmarServicio(Long idServicio)throws GeneralDataAccessException;

	public Certificado getCountCertificadosSinFirmarVehiculo(Long idVehiculo)throws GeneralDataAccessException;

    public boolean existProcesandoCert(Servicio servicio);
    
    public int getTamanioLote();

    public void marcarServicioBatch(Servicio servicio);

}
