package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Conductor;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.GenericAuditCancellableModelObject;
import cl.mtt.rnt.commons.model.core.Poliza;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;

public interface ConductorManager {

	public List<ConductorServicio> getConductoresServicioByServicio(Long id) throws GeneralDataAccessException;

	public GenericAuditCancellableModelObject getConductorCancelable(String rut,Long idServicio) throws GeneralDataAccessException;

	/**
	 * 
	 * @param idVehiculoServicio
	 * @param tipoConductor
	 *            - Si es null trae todos los tipos de conductor
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<ConductorVehiculo> getConductoresVehiculoByVehiculoServicio(Long idVehiculoServicio, String tipoConductor) throws GeneralDataAccessException;

	public List<ConductorVehiculo> getConductoresVehiculoByConductoresServicio(Long idConductorServicio) throws GeneralDataAccessException;

	public List<Conductor> getConductoresByRut(String rut, String tipoConductor) throws GeneralDataAccessException;

	public Conductor getConductorById(Long id) throws GeneralDataAccessException;

	public void saveConductor(Conductor conductor) throws GeneralDataAccessException;

//	public void saveConductor(Conductor conductor, Servicio servicio) throws GeneralDataAccessException;

	public void handle(List<ConductorServicio> conductoresServicio, Servicio servicio) throws GeneralDataAccessException;

	public void postHandle(List<ConductorServicio> conductoresServicio, Servicio servicio) throws GeneralDataAccessException;

	public void recreateList(List<ConductorServicio> conductoresServicio, Servicio servicio) throws GeneralDataAccessException;

	// public void preHandle(List<ConductorServicio> conductoresServicio) throws
	// GeneralDataAccessException;

	public boolean getConductorCanceladoDefinitivoByCategoria(String rut, TipoServicio tipoServicio) throws GeneralDataAccessException;
	
	// Mejoras 201409 Nro: 70
	public ConductorVehiculo getConductorVehiculo(Long id) throws GeneralDataAccessException;
	
	public ConductorServicio getConductorServicio (Long id) throws GeneralDataAccessException;
	
	public void updateConductorServicio(ConductorServicio cs) throws GeneralDataAccessException;
	
	public void deleteConductorServicioRechazada(ConductorServicio cs) throws GeneralDataAccessException;
	
	public void cancelConductorServicioRechazada(ConductorServicio cs) throws GeneralDataAccessException;
	
	public void cancelConductorVehiculoRechazada(ConductorVehiculo cs) throws GeneralDataAccessException;
	
	public void updateConductorVehiculo(ConductorVehiculo cv) throws GeneralDataAccessException;
	
	public void deleteConductorVehiculoRechazada(ConductorVehiculo cv) throws GeneralDataAccessException;
	// Mejoras 201409 Nro: 70

	public List<Poliza> getPolizasByConuctor(Long idConductorServicio) throws GeneralDataAccessException;

}
