package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Contacto;
import cl.mtt.rnt.commons.model.core.Servicio;

public interface ContactoManager {

	/**
	 * Obtiene los contactos dado un rut
	 * 
	 * @return lista de Contactos
	 * @throws GeneralDataAccessException
	 * @author Marina Chobadindegui
	 */
	public List<Contacto> getContactosByRut(String rut) throws GeneralDataAccessException;

	public List<Contacto> getContactosByServicio(Long idServicio) throws GeneralDataAccessException;

	/**
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Contacto getContactoById(Long id) throws GeneralDataAccessException;

	/**
	 * 
	 * @param contacto
	 * @throws GeneralDataAccessException
	 * @throws DuplicatedIdException
	 */
	public void saveContacto(Contacto contacto) throws GeneralDataAccessException, DuplicatedIdException;

	/**
	 * 
	 * @param contacto
	 * @throws GeneralDataAccessException
	 */
	public void updateContacto(Contacto contacto) throws GeneralDataAccessException;

	/**
	 * 
	 * @param contacto
	 * @throws GeneralDataAccessException
	 */
	public void removeContacto(Contacto contacto) throws GeneralDataAccessException;

	/**
	 * 
	 * @param contactos
	 * @param servicio
	 * @throws GeneralDataAccessException
	 * @throws DuplicatedIdException
	 */
	public void preHandle(List<Contacto> contactos, Servicio servicio) throws GeneralDataAccessException, DuplicatedIdException;

	/**
	 * 
	 * @param contactos
	 * @param servicio
	 * @throws GeneralDataAccessException
	 */
	public void postHandle(List<Contacto> contactos, Servicio servicio) throws GeneralDataAccessException;

	/**
	 * 
	 * @param contacto
	 * @return
	 * @throws GeneralDataAccessException
	 */
    public List<Servicio> getServiciosContacto(Contacto contacto) throws GeneralDataAccessException;

}
