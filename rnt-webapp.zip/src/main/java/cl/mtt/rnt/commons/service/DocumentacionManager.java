package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.Documentacion;

public interface DocumentacionManager {
	
	public List<Documentacion> getDocumentaciones() throws GeneralDataAccessException;
	
	public List<Documentacion> getDocumentacionesByName(String name) throws GeneralDataAccessException;
	
	public void saveDocumentacion(Documentacion doc) throws GeneralDataAccessException, DuplicatedIdException;
	
	public void updateDocumentacion(Documentacion doc) throws GeneralDataAccessException;
	
	public void deleteDocumentacion(Documentacion doc) throws GeneralDataAccessException, IntegrityViolationException;

}
