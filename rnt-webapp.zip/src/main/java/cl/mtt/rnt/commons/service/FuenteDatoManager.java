package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.FuenteDato;

public interface FuenteDatoManager {

	public FuenteDato getFuenteDatoById(Long id) throws GeneralDataAccessException;

	public void saveFuenteDato(FuenteDato fuenteDato) throws GeneralDataAccessException;

	public void updateFuenteDato(FuenteDato fuenteDato) throws GeneralDataAccessException;

	public void removeFuenteDato(FuenteDato fuenteDato) throws GeneralDataAccessException;

	public void preHandle(List<FuenteDato> fuentesDatos) throws GeneralDataAccessException;

	public void postHandle(List<FuenteDato> fuenteDeDatos) throws GeneralDataAccessException;
	
	public List<FuenteDato> getFuentesDatoByIdAtributo(Long idAtributo) throws GeneralDataAccessException;

}
