package cl.mtt.rnt.commons.service;

import java.util.HashMap;
import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.CategoriaPersonaJuridica;
import cl.mtt.rnt.commons.model.core.ClaseLicenciaConducir;
import cl.mtt.rnt.commons.model.core.GlosaAuxiliar;
import cl.mtt.rnt.commons.model.core.Gremio;
import cl.mtt.rnt.commons.model.core.GremioRegion;
import cl.mtt.rnt.commons.model.core.Inhabilidad;
import cl.mtt.rnt.commons.model.core.SituacionContractual;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoCobradorVehiculo;
import cl.mtt.rnt.commons.model.core.TipoContrato;
import cl.mtt.rnt.commons.model.core.TipoDocumentoGrupo;
import cl.mtt.rnt.commons.model.core.TipoDocumentoRequerido;
import cl.mtt.rnt.commons.model.core.TipoIngresoVehiculo;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoSubsidio;
import cl.mtt.rnt.commons.model.core.TipoTecnologiaGases;
import cl.mtt.rnt.commons.model.core.recorrido.CalleHomologada;
import cl.mtt.rnt.commons.model.core.recorrido.DatoDiccionario;

public interface GeneralDataManager {

	/**
	 * Obtiene todas las clases de licencia de conducir
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 * @author Federico Dukatz
	 */
	public List<ClaseLicenciaConducir> getAllClasesLicenciaConducir() throws GeneralDataAccessException;

	/**
	 * Obtiene la clase de licencia de conducir por el id dado como parámetro
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 * @author Federico Dukatz
	 */
	public ClaseLicenciaConducir getClaseLicenciaConducirById(Long id) throws GeneralDataAccessException;

	/**
	 * 
	 * @param ids
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<ClaseLicenciaConducir> getClasesLicenciaConducirByIds(List<Long> ids) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Inhabilidad> getAllInhabilidades() throws GeneralDataAccessException;

	/**
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public Inhabilidad getInhabilidadById(Long id) throws GeneralDataAccessException;

	/**
	 * 
	 * @param ids
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Inhabilidad> getInhabilidadesByIds(List<Long> ids) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<CategoriaPersonaJuridica> getCategoriasPersonasJuridicas() throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<SituacionContractual> getAllSituacionesContractuales() throws GeneralDataAccessException;

	/**
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public SituacionContractual getSituacionContractualById(Long id) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoIngresoVehiculo> getAllTiposIngresoVehiculo() throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoTecnologiaGases> getAllTiposTecnologiasGases() throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCobradorVehiculo> getAllTiposCobradorVehiculo() throws GeneralDataAccessException;

	/**
	 * 
	 * @param alcance
	 * @param includeCancelacionServicio
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCancelacion> getAllTiposCancelacion(String alcance,boolean includeCancelacionServicio) throws GeneralDataAccessException;

	/**
	 * 
	 * @param idTipoCancelacion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public TipoCancelacion getTipoCancelacionById(long idTipoCancelacion) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCancelacion> getAllTiposCancelacion() throws GeneralDataAccessException;

	/**
	 * 
	 * @param alcance
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCancelacion> getAllTiposCancelacionTemporales(String alcance) throws GeneralDataAccessException;

	/**
	 * No retorna las cancelaciones de servicio, no restringe por tipo de
	 * servicio
	 * 
	 * @param alcance
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCancelacion> getAllTiposCancelacionPermanentes(String alcance) throws GeneralDataAccessException;

	/**
	 * No retorna las cancelaciones de servicio
	 * 
	 * @param alcance
	 * @param ts
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCancelacion> getAllTiposCancelacionByTipoServicio(String alcance, TipoServicio ts) throws GeneralDataAccessException;

	/**
	 * Solo se usa para cancelacion de servicio
	 * 
	 * @param alcance
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCancelacion> getAllTiposCancelacionDeServicio(String alcance) throws GeneralDataAccessException;

	/**
	 * 
	 * @param alcance
	 * @param ts
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCancelacion> getTiposCancelacionPermanentesByTipoServicio(String alcance, TipoServicio ts) throws GeneralDataAccessException;

	/**
	 * 
	 * @param alcance
	 * @param ts
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoCancelacion> getTiposCancelacionTemporalesByTipoServicio(String alcance, TipoServicio ts) throws GeneralDataAccessException;
	
	/**
	 * 
	 * @param dePortacion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoDocumentoRequerido> getAllTipoDocumentoRequerido(boolean dePortacion) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoDocumentoGrupo> getAllTipoDocumentoGrupo() throws GeneralDataAccessException;

	/**
	 * 
	 * @param id
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoDocumentoRequerido> getAllTipoDocumentoRequeridoByIdGrupo(Long id) throws GeneralDataAccessException;

	/**
	 * 
	 * @param ids
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoDocumentoRequerido> getTiposDocumentoRequeridoByIds(List<Long> ids) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<Gremio> getAllGremios() throws GeneralDataAccessException;
	// Mejoras 201409 Nro: 30
	/**
	 * 
	 * @param codigoRegion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<GremioRegion> getGremiosByRegion (String codigoRegion) throws GeneralDataAccessException;
	// Mejoras 201409 Nro: 30
	
	/**
	 * 
	 * @param nombre
	 * @param codigoRegion
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<DatoDiccionario> findDatosDiccionario(String nombre, String codigoRegion) throws GeneralDataAccessException;

	
	/**
	 * 
	 * @param nombre
	 * @param codigoComuna
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<DatoDiccionario> findDatosDiccionarioByComuna(String nombre, String codigoComuna) throws GeneralDataAccessException;

	/**
	 * 
	 * @param nombre
	 * @param codigoComuna
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public DatoDiccionario getDatosDiccionario(String nombre, String codigoComuna) throws GeneralDataAccessException;

	/**
	 * 
	 * @param codigoComuna
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<DatoDiccionario> findDatosDiccionarioByComuna(String codigoComuna) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<DatoDiccionario> getAllDatosDiccionario() throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<GlosaAuxiliar> getAllGlosasAuxiliar() throws GeneralDataAccessException;

	/**
	 * 
	 * @param idGlosaAuxiliar
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public GlosaAuxiliar getGlosaAuxiliarById(Long idGlosaAuxiliar) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoContrato> getAllTiposContrato() throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<TipoSubsidio> getAllTiposSubsidio() throws GeneralDataAccessException;

	/**
	 * 
	 * @param calleGMap
	 * @param codigoComuna
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public DatoDiccionario getDatoDiccionarioHomologado(String calleGMap, String codigoComuna) throws GeneralDataAccessException;

	/**
	 * 
	 * @param calleGMap
	 * @param datoDiccionario
	 * @throws GeneralDataAccessException
	 */
	public void saveCalleHomologada(String calleGMap, DatoDiccionario datoDiccionario) throws GeneralDataAccessException;

	/**
	 * 
	 * @param calleGMap
	 * @param datoDiccionario
	 * @throws GeneralDataAccessException
	 */
	public void saveCalleHomologadaConDatoDiccionario(String calleGMap, DatoDiccionario datoDiccionario) throws GeneralDataAccessException;

	/**
	 * 
	 * @param datoDiccionario
	 * @throws GeneralDataAccessException
	 */
	public void saveDatoDiccionario(DatoDiccionario datoDiccionario) throws GeneralDataAccessException;

	/**
	 * 
	 * @param calleGMap
	 * @param codigoComuna
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public CalleHomologada getCalleHomologada(String calleGMap, String codigoComuna) throws GeneralDataAccessException;

	/**
	 * 
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public TipoSubsidio getTipoSubsidioNoAplica() throws GeneralDataAccessException;

	/**
	 * 
	 * @param idDatoDiccionario
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public DatoDiccionario getDatoDiccionarioById(Long idDatoDiccionario) throws GeneralDataAccessException;

	/**
	 * 
	 * @param datoDiccionario
	 * @throws GeneralDataAccessException
	 */
	public void eliminarDatoDiccionario(DatoDiccionario datoDiccionario) throws GeneralDataAccessException;

	/**
	 * 
	 * @param datoDiccionario
	 * @throws GeneralDataAccessException
	 */
	public void updateDatoDiccionario(DatoDiccionario datoDiccionario) throws GeneralDataAccessException;

	/**
	 * 
	 * @param filters
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public long getDatosDiccionarioCount(HashMap<String, Object> filters) throws GeneralDataAccessException;

	/**
	 * 
	 * @param first
	 * @param rows
	 * @param filters
	 * @param order
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<DatoDiccionario> getCallesPage(int first, int rows, HashMap<String, Object> filters, List<String> order) throws GeneralDataAccessException;

	/**
	 * 
	 * @param datoDiccionario
	 * @return
	 * @throws GeneralDataAccessException
	 */
	public List<CalleHomologada> getCallesHomologadasByDatoDiccionario(DatoDiccionario datoDiccionario) throws GeneralDataAccessException;

	/**
	 * 
	 */
    public void fillCache();

}
