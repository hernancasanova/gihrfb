package cl.mtt.rnt.commons.service;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GlosaReglamentacion;

public interface GlosaReglamentacionManager {

	public void saveGlosaReglamentacion(GlosaReglamentacion glosaReglamentacion) throws GeneralDataAccessException;

	public void updateGlosaReglamentacion(GlosaReglamentacion glosaReglamentacion) throws GeneralDataAccessException;

	public void removeGlosaReglamentacion(GlosaReglamentacion glosaReglamentacion) throws GeneralDataAccessException;

}
