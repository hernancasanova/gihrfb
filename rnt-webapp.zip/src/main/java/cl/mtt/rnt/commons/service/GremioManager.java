package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.Gremio;
import cl.mtt.rnt.commons.model.core.GremioRegion;


public interface GremioManager {

	
	
	public List<Gremio> getAllGremios() throws GeneralDataAccessException;

	public void saveGremio(Gremio gremio) throws GeneralDataAccessException;

	public void updateGremio(Gremio gremio,List<GremioRegion> aeliminar) throws GeneralDataAccessException;

	public Gremio getGremioById(Long idGremio) throws GeneralDataAccessException;

	public void removeGremio(Gremio g) throws GeneralDataAccessException,RemoveNotAllowedException;

	public List<Gremio> getGremiosByRegion(String idRegionFiltro) throws GeneralDataAccessException;

}
