package cl.mtt.rnt.commons.service;

import java.util.List;

import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.model.core.autorizacion.UsuarioGrupo;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;

public interface GrupoManager {
	
	public List<Grupo> getGrupos() throws GeneralDataAccessException;
	
	public List<Grupo> getGruposByRegionesAndCategorias(List<Region> region,List<Long> tipoTransporte,List<Long> medioTransporte,List<Long> categoriaTransporte) throws GeneralDataAccessException;
	
	public void saveGrupo(Grupo grupo, List<UsuarioGrupo> usuarios) throws GeneralDataAccessException, DuplicatedIdException; 
	
	public void updateGRupo(Grupo grupo, List<UsuarioGrupo> usuarios) throws GeneralDataAccessException;
	
	public void removeGRupo(Grupo grupo, List<UsuarioGrupo> usuarios) throws GeneralDataAccessException, IntegrityViolationException;
	
	public List<UsuarioGrupo> getUsuariosGrupoByIdGrupo(Long idGrupo) throws GeneralDataAccessException ;
	
	public List<Grupo> getGruposByUser(User user) throws GeneralDataAccessException ;

}
