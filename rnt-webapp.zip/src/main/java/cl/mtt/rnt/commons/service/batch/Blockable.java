package cl.mtt.rnt.commons.service.batch;

public class Blockable {

	private boolean istaken = false;

    protected synchronized boolean getToken() {
        if (istaken) {
            return false;
        }
        else {
            istaken = true;
            return true;
        }
    }
    
    protected synchronized void releaseToken() {
        istaken = false;
    }

    protected void obtainToken() throws InterruptedException {
    	while (!getToken()) {
            Thread.sleep(100);
        }		
	}
}
