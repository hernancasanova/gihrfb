package cl.mtt.rnt.commons.service.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.Servicio;

public class ByLoteCertificadoSaver implements Runnable {

	CertificadoHandlerBlock control;
    private static final int LOTE_SIZE = 300;
    
    public ByLoteCertificadoSaver(CertificadoHandlerBlock certificadosControlledGenerator) {
        this.control = certificadosControlledGenerator;
    }

    @Override
    public void run() {
        while (true) {
            try {
                List<CertificadoHandeable> nextLote = control.getNextLote(LOTE_SIZE);
                if (nextLote.isEmpty()) {
                  //cada 5 segundos procesa 300 certificados
                    control.clearServicio();
                    //Logger.getLogger(ByLoteCertificadoSaver.class).error("No hay certificados para generar...");
                    Thread.sleep(5000);
                }
                else {
                    HashMap<Servicio, List<Certificado>> splited = splitPorServicio(nextLote);
                    for (Iterator<Entry<Servicio, List<Certificado>>> it = splited.entrySet().iterator();it.hasNext();) {
                        Entry<Servicio, List<Certificado>> next = it.next();
                        //Logger.getLogger(ByLoteCertificadoSaver.class).error("Envia Lote: serivicio: " + next.getKey().getId() + "  cantidad Cert:" + next.getValue().size());
                        control.getCertificadoManager().handlerCertificadosInternal(next.getValue(), next.getKey());
                        //Logger.getLogger(ByLoteCertificadoSaver.class).error("Lote procesado");
                    }
                    //cada 5 segundos procesa 300 certificados
                    Thread.sleep(500);
                }
                
            }
            catch (Throwable e) {
                //Logger.getLogger(ByLoteCertificadoSaver.class).error("Error procesando Lote");
                Logger.getLogger(ByLoteCertificadoSaver.class).error(e.getLocalizedMessage(), e);
            }
        }

    }

    private HashMap<Servicio, List<Certificado>> splitPorServicio(List<CertificadoHandeable> nextLote) {
        HashMap<Servicio, List<Certificado>> splitted = new HashMap<Servicio, List<Certificado>>();
        for (CertificadoHandeable certificadoHandeable : nextLote) {
            List<Certificado> list = splitted.get(certificadoHandeable.getServicio());
            if (list == null) {
                list = new ArrayList<Certificado>();
            }
            list.add(certificadoHandeable.getCertificado());
            splitted.put(certificadoHandeable.getServicio(), list);
        }
        return splitted;
    }

}
