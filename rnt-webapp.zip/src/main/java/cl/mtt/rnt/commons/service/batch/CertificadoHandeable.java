package cl.mtt.rnt.commons.service.batch;

import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.Servicio;

public class CertificadoHandeable {
    
    private Certificado certificado;
    private Servicio servicio;
    /**
     * @return el valor de certificado
     */
    public Certificado getCertificado() {
        return certificado;
    }
    /**
     * @param setea el parametro certificado al campo certificado
     */
    public void setCertificado(Certificado certificado) {
        this.certificado = certificado;
    }
    /**
     * @return el valor de servicio
     */
    public Servicio getServicio() {
        return servicio;
    }
    /**
     * @param setea el parametro servicio al campo servicio
     */
    public void setServicio(Servicio servicio) {
        this.servicio = servicio;
    }
    
    
    

}
