package cl.mtt.rnt.commons.service.batch;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.autorizacion.Notificacion;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.service.CertificadoManager;
import cl.mtt.rnt.commons.service.impl.CertificadoManagerImpl;

public class CertificadoHandlerBlock extends Blockable {

    private CertificadoManager certificadoManager;

    private int rowId;
    private LinkedList<CertificadoHandeable> cola;
    private LinkedList<ServicioLoteado> servicios;
    private ByLoteCertificadoSaver saver;
    private Thread saverTh;
	
    public CertificadoHandlerBlock(CertificadoManager certificadoManager,int rowId) {
		super();

		this.certificadoManager = certificadoManager;
        this.cola = new LinkedList<CertificadoHandeable>();
        this.servicios = new LinkedList<ServicioLoteado>();
        this.saver = new ByLoteCertificadoSaver(this);
        saverTh = new Thread(saver,"CERTIFICADOS_THREAD_"+rowId);
        saverTh.start();
		this.rowId=rowId;
	}

    
    
    /**
     * @return el valor de certificadoManager
     */
    protected CertificadoManager getCertificadoManager() {
        return certificadoManager;
    }

    public synchronized void addToCola(List<CertificadoHandeable>  handeable,String username) {
        try {
            if (!saverTh.isAlive()) {
                saverTh = new Thread(saver,"CERTIFICADOS_THREAD_"+rowId);
                saverTh.start();
            }
            
            boolean primero = true;
            for (CertificadoHandeable certificadoHandeable : handeable) {
                this.cola.addLast(certificadoHandeable);
                if (primero) {
                    if (!existeEnServicios(servicios,certificadoHandeable.getServicio().getId())) {
                        this.servicios.add(new ServicioLoteado(certificadoHandeable.getServicio().getId(),username));
                    }
                }
            }
        }
        catch (Throwable e) {
            Logger.getLogger(CertificadosControlledGenerator.class).error(e.getLocalizedMessage(), e);
        }
        
    }

    private boolean existeEnServicios(LinkedList<ServicioLoteado> servicios2, Long id) {
        for (ServicioLoteado servicioLoteado : servicios2) {
            if (servicioLoteado.getIdServicio().equals(id)) {
                return true;
            }
        }
        return false;
    }



    protected synchronized List<CertificadoHandeable> getNextLote(int loteSize) {
        try {
            obtainToken();
            
            int i = 0;
            List<CertificadoHandeable> toSave = new ArrayList<CertificadoHandeable>();
            while (i < loteSize) {
                if (this.cola.size()>0) {
                    CertificadoHandeable first = this.cola.removeFirst();
                    toSave.add(first);
                }
                i++;
            }
            for (Iterator<ServicioLoteado> idSerit =  servicios.iterator();idSerit.hasNext();) {
                ServicioLoteado sl = idSerit.next();
                if (noEnCola(sl.getIdServicio())) {
                    idSerit.remove();
                   
                    CertificadoHandeable ch1 = null;
                    for (int j = 0; (j < toSave.size() && ch1==null); j++) {
                    	CertificadoHandeable ch = toSave.get(j);
                    	
                        if ((ch.getServicio().getId().equals(sl.getIdServicio()))) {
                           ch1 = ch;
                        }
                    }
                    if(ch1!=null){
                    	enviarNotificacion(sl,ch1);
                    }
                }
            }
            return toSave;
        }
        catch (Throwable e) {
            Logger.getLogger(CertificadosControlledGenerator.class).error(e.getLocalizedMessage(), e);
            return new ArrayList<CertificadoHandeable>();
        }
        finally {
            releaseToken();
        }
    }

    
    private boolean noEnCola(Long id) {
        for (CertificadoHandeable ch : cola) {
            if (ch.getServicio().getId().equals(id)) {
                return false;
            }
        }
        return true;
    }
    
    public boolean estaProcesandoCert(Servicio servicio) {
    	for (ServicioLoteado servLot : this.servicios) {
			if(servLot.getIdServicio().equals(servicio.getId()) ){
				return true;
			}
		}
	    return false;
    }

    public void clearServicio() {
        servicios.clear();        
    }
    
	public int getEnqueuedQty() {
		return cola.size();
	}
	
	
	
	private void enviarNotificacion(ServicioLoteado sl,CertificadoHandeable ch) {
	    try {
	            User ud = ((CertificadoManagerImpl)certificadoManager).getUsuarioManager().getUsuarioByName(sl.getUsername());
                Notificacion noti = new Notificacion();
                noti.setAutorizacionMovimiento(null);
                noti.setUsuarioDestino(ud);
                noti.setDescripcion("Se han procesados todos los certificados del servicio " + ch.getServicio().getIdentServicio() + " de la " + 
                        ch.getServicio().getRegion().getCodigo() + " " + ch.getServicio().getRegion().getNombre());
                noti.setEstado(Notificacion.ESTADO_NO_LEIDO);
                noti.setTipo(Notificacion.NOTIFICACION_MENSAJE_INF);
                noti.setObservacion(null);
                noti.setTitulo("LOTE CERTIFICADOS PROCESADO - SERVICIO: "  + ch.getServicio().getIdentServicio() + " de la " + 
                        ch.getServicio().getRegion().getCodigo());
                ((CertificadoManagerImpl)certificadoManager).getNotificacionService().saveNotificacion(noti);
               
                String message = noti.getDescripcion();
                message += "\n\n" + "ENVIADO POR RNT"; 
                String subject = "NOTIFICACION RNT - " +noti.getTitulo();
                ((CertificadoManagerImpl)certificadoManager).getNotificacionService().sendEmail(subject, message, ud.getEmail());
            }
            catch (Throwable e) {
                Logger.getLogger(CertificadoHandlerBlock.class).error(e.getLocalizedMessage(), e);
            }
	}
}
