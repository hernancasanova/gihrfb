package cl.mtt.rnt.commons.service.batch;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.service.CertificadoManager;
import cl.mtt.rnt.commons.util.Utils;


public class CertificadosControlledGenerator extends Blockable{
   
    
    private List<CertificadoHandlerBlock> certificadosHandlers;
    private List<Long> serviciosToBatch = new ArrayList<Long>();
    
    public CertificadosControlledGenerator(CertificadoManager certificadoManager) {
        super();
        int certsQty = Integer.parseInt(Utils.getProperty("certificados.batch.cantidadProcesosParalelos"));

        certificadosHandlers=new ArrayList<CertificadoHandlerBlock>(certsQty);
        for (int i = 0; i < certsQty; i++) {
        	CertificadoHandlerBlock chb = new CertificadoHandlerBlock(certificadoManager,i);
        	certificadosHandlers.add(chb);
		}
    }
    
    
    public void addCertificadosToSave(List<Certificado> colaCertificados, Servicio servicio,String username) throws GeneralDataAccessException {
        try {
            List<CertificadoHandeable> toCola = new ArrayList<CertificadoHandeable>();
            if ((colaCertificados != null) && (servicio != null)) {
                for (Certificado certificado : colaCertificados) {
                    CertificadoHandeable handeable = new CertificadoHandeable();
                    handeable.setCertificado(certificado);
                    handeable.setServicio(servicio);
                    toCola.add(handeable);
                }
                this.addToCola(toCola,username);
            }
            removeToBatch(servicio);
        }
        catch (Exception e) {
            Logger.getLogger(CertificadosControlledGenerator.class).error(e.getLocalizedMessage(), e);
            throw new GeneralDataAccessException(e.getMessage());
        }
    }


    private synchronized void addToCola(List<CertificadoHandeable>  handeable,String username) {
        try {
        	obtainToken();
            
        	CertificadoHandlerBlock minChb=certificadosHandlers.get(0);
        	for (int i = 1; i < certificadosHandlers.size(); i++) {
        		CertificadoHandlerBlock chb = certificadosHandlers.get(i);
				if(chb.getEnqueuedQty()<minChb.getEnqueuedQty()){
					minChb=chb;
				}
			}
        	
        	minChb.addToCola(handeable,username);
        }
        catch (Throwable e) {
            Logger.getLogger(CertificadosControlledGenerator.class).error(e.getLocalizedMessage(), e);
        }
        finally {
            releaseToken();
        }
    }
    



//	protected synchronized List<CertificadoHandeable> getNextLote(int loteSize) {
//        try {
//        	
//            int i = 0;
//            List<CertificadoHandeable> toSave = new ArrayList<CertificadoHandeable>();
//            while (i < loteSize) {
//                if (this.cola.size()>0) {
//                    CertificadoHandeable first = this.cola.removeFirst();
//                    toSave.add(first);
//                }
//                i++;
//            }
//            for (Iterator<Long> idSerit =  servicios.iterator();idSerit.hasNext();) {
//                Long id = idSerit.next();
//                if (noEnCola(id)) {
//                    idSerit.remove();***notificacion servicio
//                }
//            }
//            return toSave;
//        }
//        catch (Throwable e) {
//            Logger.getLogger(CertificadosControlledGenerator.class).error(e.getLocalizedMessage(), e);
//            return new ArrayList<CertificadoHandeable>();
//        }
//       
//    }


//    private boolean noEnCola(Long id) {
//        for (CertificadoHandeable ch : cola) {
//            if (ch.getServicio().getId().equals(id)) {
//                return false;
//            }
//        }
//        return true;
//    }


//    /**
//     * @return el valor de certificadoManager
//     */
//    protected CertificadoManager getCertificadoManager() {
//        return certificadoManager;
//    }


    /**
     * 
     * @param servicio
     * @return
     */
    public boolean estaProcesandoCert(Servicio servicio) {
        if (serviciosToBatch.contains(servicio.getId())) {
            return true;
        }
    	for (CertificadoHandlerBlock certificadoHandlerBlock : certificadosHandlers) {
            if (certificadoHandlerBlock.estaProcesandoCert(servicio)){
                return true;
            }
		}
        return false;
    }

    /**
     * 
     */
    public void clearServicio() {
    	for (CertificadoHandlerBlock certificadoHandlerBlock : certificadosHandlers) {
    		certificadoHandlerBlock.clearServicio();
    	}
    }


    public void marcarServicioToBatch(Servicio servicio) {
        serviciosToBatch.add(servicio.getId());
        
    }
    
    public synchronized void removeToBatch(Servicio servicio) {
        for (Iterator<Long> iterator = serviciosToBatch.iterator(); iterator.hasNext();) {
            Long next = iterator.next();
            if (next.equals(servicio.getId())) {
                iterator.remove();
            }
        }
    }
    
}



