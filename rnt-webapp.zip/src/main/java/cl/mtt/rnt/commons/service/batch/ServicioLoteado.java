package cl.mtt.rnt.commons.service.batch;

public class ServicioLoteado {
    
    Long idServicio;
    String username;
    
    
    public ServicioLoteado() {
        super();
    }
    public ServicioLoteado(Long idServicio, String username) {
        super();
        this.idServicio = idServicio;
        this.username = username;
    }
    
    /**
     * @return el valor de idServicio
     */
    protected Long getIdServicio() {
        return idServicio;
    }
    /**
     * @param setea el parametro idServicio al campo idServicio
     */
    protected void setIdServicio(Long idServicio) {
        this.idServicio = idServicio;
    }
    /**
     * @return el valor de username
     */
    protected String getUsername() {
        return username;
    }
    /**
     * @param setea el parametro username al campo username
     */
    protected void setUsername(String username) {
        this.username = username;
    }
    
    

}
