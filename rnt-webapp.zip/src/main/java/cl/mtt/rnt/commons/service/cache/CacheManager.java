package cl.mtt.rnt.commons.service.cache;

import java.util.HashMap;
import java.util.Map;

import cl.mtt.rnt.commons.model.core.TipoServicio;

public class CacheManager {

    private static CacheManager INSTANCE = new CacheManager();
    
    // El constructor privado no permite que se genere un constructor por defecto.
    // (con mismo modificador de acceso que la definición de la clase) 
    private CacheManager() {}
 
    public static CacheManager getInstance() {
        return INSTANCE;
    }
    
  //El método "clone" es sobreescrito por el siguiente que arroja una excepción:
    public Object clone() throws CloneNotSupportedException {
        	throw new CloneNotSupportedException(); 
    }
    
    private Map<Long, TipoServicio> tiposServicio=new HashMap<Long, TipoServicio>();
    
    public TipoServicio getTipoServicio(Long id){
    	return tiposServicio.get(id);
    }
    
    public TipoServicio addTipoServicio(TipoServicio tipoServicio){
    	return tiposServicio.put(tipoServicio.getId(),tipoServicio);
    }

	public void clearTipoServicio(Long id) {
		tiposServicio.remove(id);
		
	}
        
    
}
