package cl.mtt.rnt.commons.service.cache;

import java.util.HashMap;

import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.core.TipoServicio;

public class TipoCertificadoCache {
    
    HashMap<String, TipoCertificado> cache;
    
    /**
     * 
     */
    public TipoCertificadoCache() {
        cache = new HashMap<String, TipoCertificado>();
    }
    
    
    /**
     * Si existe lo sobreescribe
     * @param ts
     * @param movimiento
     * @param nombreObjeto
     * @param reglamentacion
     */
    public void addToCache(TipoCertificado tc,TipoServicio ts, String movimiento, String nombreObjeto, Reglamentacion reglamentacion) {
        cache.put(buildId(ts, movimiento, nombreObjeto, reglamentacion), tc);
    }
    
    /**
     * Si existe lo elimina
     * @param ts
     * @param movimiento
     * @param nombreObjeto
     * @param reglamentacion
     */
    public void removeFromCache(TipoCertificado tc,TipoServicio ts, String movimiento, String nombreObjeto, Reglamentacion reglamentacion) {
        cache.remove(buildId(ts, movimiento, nombreObjeto, reglamentacion));
    }
    
    public TipoCertificado getFromCache(TipoServicio ts, String movimiento, String nombreObjeto, Reglamentacion reglamentacion) {
        return cache.get(buildId(ts,movimiento,nombreObjeto,reglamentacion));
    }


    private String buildId(TipoServicio ts, String movimiento, String nombreObjeto, Reglamentacion reglamentacion) {
        if (reglamentacion == null) {
            return "" + ts.getId() + movimiento + nombreObjeto + "ALL_REG";
        }
        return "" + ts.getId() + movimiento + nombreObjeto + reglamentacion.getId();
    }
}
