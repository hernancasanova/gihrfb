package cl.mtt.rnt.commons.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import cl.mtt.rnt.commons.dao.AtributoDAO;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Atributo;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoServicioAtributo;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.AtributoManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.util.FieldComparator;
import cl.mtt.rnt.encargado.dto.AtributoServicioLogDTO;

@Service("atributoManager")
@Lazy(value = true)
public class AtributoManagerDelegate implements AtributoManager, Serializable {

	private static final long serialVersionUID = 7623748768431928713L;
	
	
	
	List<Atributo> atributosVehiculo = new ArrayList<Atributo>();
    List<Atributo> atributosServicio = new ArrayList<Atributo>();
	
    @Autowired
    @Qualifier("tipoServicioManager")
    private TipoServicioManager tipoServicioManager;
    
	@Autowired
	@Qualifier("AtributoDAO")
	private AtributoDAO atributoDAO;
	
	@Autowired
    @Qualifier("atributoManagerImpl")
    private AtributoManager manager;

	@Autowired
	@Qualifier("AtributoInstanciaDAO")
	private GenericDAO<AtributoInstancia> atributoInstanciaDAO;
	
	@Override
	public void fillCache() {
	    try {
	        List<Atributo> allAtributosByAplicaAVehiculo = manager.getAllAtributosByAplicaA(Atributo.APLICA_A_VEHICULO);
	        for (Atributo atributo : allAtributosByAplicaAVehiculo) {
	           atributosVehiculo.add(atributo);
               
            }

            List<Atributo> allAtributosByAplicaAServicio = manager.getAllAtributosByAplicaA(Atributo.APLICA_A_SERVICIO);
            for (Atributo atributo : allAtributosByAplicaAServicio) {
                atributosServicio.add(atributo);
             }
	            
	            Collections.sort(atributosServicio,new FieldComparator<Atributo>("ordenParcial", FieldComparator.ASC));
	            Collections.sort(atributosVehiculo,new FieldComparator<Atributo>("ordenParcial", FieldComparator.ASC));
	    }
	    catch (Exception ex) {
	        Logger.getLogger(this.getClass()).error(ex.getMessage(),ex);
	    }
	}
	    

   


    @Override
    public List<Atributo> getAllAtributosByAplicaA(String aplicaA) throws GeneralDataAccessException {
        if (this.atributosServicio.isEmpty() || this.atributosVehiculo.isEmpty()) {
            fillCache();
        }
        if (aplicaA.equals(Atributo.APLICA_A_SERVICIO)) {
            return getClonesDeAtributos(atributosServicio);
        }else {
            return getClonesDeAtributos(atributosVehiculo);
        }
    }


	/**
	 * @param attrs
	 * @return
	 */
	private List<Atributo> getClonesDeAtributos(List<Atributo> attrs) {
		List<Atributo> ret = new ArrayList<Atributo>();
		for (Atributo atributo : attrs) {
			ret.add(atributo.clone());
		}
		return ret;
	}
    
    @Override
	public TipoServicioAtributo getTipoSevicioAtributoByTsAt(Long attid,Long tsid) throws GeneralDataAccessException {
        TipoServicio ts = tipoServicioManager.getTipoServicioById(tsid);
        for (TipoServicioAtributo tsa : ts.getTipoServicioAtributos()) {
            if ((tsa != null) && (tsa.getAtributo()!=null)) {
               if (tsa.getAtributo().getId().equals(attid)) {
                   return tsa;
               }   
            }
        }
        return null;
	}
	
    @Override
	public List<TipoServicioAtributo> getTipoSevicioAtributoByTsId(Long id) throws GeneralDataAccessException {
        TipoServicio ts = tipoServicioManager.getTipoServicioById(id);
        return ts.getTipoServicioAtributos();
	}
    
    
    @Override
    public List<TipoServicioAtributo> getTipoSevicioAtributoByTsIdAplica(Long id, String aplicaA) throws GeneralDataAccessException {
        List<TipoServicioAtributo> atributos = new ArrayList<TipoServicioAtributo>();
        TipoServicio ts = tipoServicioManager.getTipoServicioById(id);
        for (TipoServicioAtributo tsa: ts.getTipoServicioAtributos()) {
            if ((tsa != null)&& (tsa.getAtributo()!=null)) {
                if (tsa.getAtributo().getAplicaA().equals(aplicaA)) {
                    atributos.add(tsa);
                }
            }
        }
        return atributos;
    }
	
    @Override
    public List<Atributo> getAtributosByTipoServicioAplicaA(Long idTipoServicio, String aplicaA) throws GeneralDataAccessException {
        List<Atributo> atributos = new ArrayList<Atributo>();
        TipoServicio ts = tipoServicioManager.getTipoServicioById(idTipoServicio);
        for (TipoServicioAtributo tsa: ts.getTipoServicioAtributos()) {
            if ((tsa != null) && (tsa.getAtributo()!=null)) {
                if (tsa.getAtributo().getAplicaA().equals(aplicaA)) {
                    atributos.add(tsa.getAtributo());
                }
            }
        }
        return atributos;
    }

    @Override
    public List<Atributo> getAtributosSinIntanciaByAplicaA(Servicio servicio, String aplicaA) throws GeneralDataAccessException {
        return manager.getAtributosSinIntanciaByAplicaA(servicio, aplicaA);
    }

    @Override
    public void preHandle(List<AtributoInstancia> atributosInstancia) throws GeneralDataAccessException {
        manager.preHandle(atributosInstancia);
        
    }

    @Override
    public void saveAtributoInstancia(AtributoInstancia atributoInstancia) throws GeneralDataAccessException {
        manager.saveAtributoInstancia(atributoInstancia);
        
    }

    @Override
    public void updateAtributoInstancia(AtributoInstancia atributoInstancia) throws GeneralDataAccessException {
        manager.saveAtributoInstancia(atributoInstancia);
        
    }

    @Override
    public Atributo getAtributosById(Long idAtributo) throws GeneralDataAccessException {
        for (Atributo atributo : atributosServicio) {
            if (atributo.getId().equals(idAtributo)) {
                return atributo;
            }
        }
        for (Atributo atributo : atributosVehiculo) {
            if (atributo.getId().equals(idAtributo)) {
                return atributo;
            }
        }
        return null;
    }

    @Override
    public Atributo getAtributoByDescriptor(String descriptor) throws GeneralDataAccessException {
        for (Atributo atributo : atributosServicio) {
            if (atributo.getDescriptor().equals(descriptor)) {
                return atributo;
            }
        }
        for (Atributo atributo : atributosVehiculo) {
            if (atributo.getDescriptor().equals(descriptor)) {
                return atributo;
            }
        }
        return null;
    }

    @Override
    public List<AtributoInstancia> getAtributosInstanciasByVehiculosIdandIdAtributo(List<Long> vehiculosID, Long idAtributo) throws GeneralDataAccessException {
        return manager.getAtributosInstanciasByVehiculosIdandIdAtributo(vehiculosID, idAtributo);
    }

    @Override
    public String getAtributoInstanciaByIdServicioAndDescriptor(Long idServico, String descriptor, String aplicaA) throws GeneralDataAccessException {
        return manager.getAtributoInstanciaByIdServicioAndDescriptor(idServico, descriptor, aplicaA);
    }

    @Override
    public List<AtributoInstancia> getAtributoInstanciaByIdServicio(Servicio servicio) throws GeneralDataAccessException {
        List<AtributoInstancia> atributoInstanciaByIdServicio = manager.getAtributoInstanciaByIdServicio(servicio);
        for (Iterator<AtributoInstancia> iterator = atributoInstanciaByIdServicio.iterator(); iterator.hasNext();) {
            AtributoInstancia atributoInstancia = (AtributoInstancia) iterator.next();
            if (!atributoInstancia.getAtributo().getAplicaA().equals(Atributo.APLICA_A_SERVICIO)) {
                iterator.remove();
            }
        }
        return atributoInstanciaByIdServicio;
    }


    @Override
    public List<AtributoInstancia> getAtributoInstanciaByVehiculo(Vehiculo vs) throws GeneralDataAccessException {
        return manager.getAtributoInstanciaByVehiculo(vs);
    }


    @Override
    public boolean estAtributoObligatorio(Atributo attr, TipoServicio tipoServicio) throws GeneralDataAccessException {
      List<TipoServicioAtributo> tipoServicioAtributos = tipoServicioManager.getTipoServicioById(tipoServicio.getId()).getTipoServicioAtributos();
      for (TipoServicioAtributo tipoServicioAtributo : tipoServicioAtributos) {
          if ((tipoServicioAtributo!=null)&&(tipoServicioAtributo.getObligatorio()!=null)&&(tipoServicioAtributo.getAtributo()!=null)&&(tipoServicioAtributo.getAtributo().equals(attr))) {
              return tipoServicioAtributo.getObligatorio().booleanValue();
          }
      }
      return false;
        
    }
       
       

    public List<AtributoServicioLogDTO> getAtributosLogInstanciaServicio(Long id) throws GeneralDataAccessException{
        return manager.getAtributosLogInstanciaServicio(id);
    }





	@Override
	public void updateLineaAud(String valorActualLinea,Servicio servicio) throws GeneralDataAccessException {
		manager.updateLineaAud(valorActualLinea, servicio);
		
	}





	@Override
	public String getValorAtributoInstanciaByIdServicioAndDescriptor(Long id,String string, String aplicaAServicio)		throws GeneralDataAccessException {
		return manager.getValorAtributoInstanciaByIdServicioAndDescriptor(id, string, aplicaAServicio);
	}

	
}
