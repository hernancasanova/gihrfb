package cl.mtt.rnt.commons.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.AtributoDAO;
import cl.mtt.rnt.commons.dao.AtributoInstanciaDAO;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.OperationDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Atributo;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoServicioAtributo;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.service.AtributoManager;
import cl.mtt.rnt.encargado.dto.AtributoServicioLogDTO;

@Service("atributoManagerImpl")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class AtributoManagerImpl implements AtributoManager, Serializable {

	private static final long serialVersionUID = 7623738768431928713L;

	@Autowired
	@Qualifier("AtributoDAO")
	private AtributoDAO atributoDAO;

	@Autowired
	@Qualifier("AtributoInstanciaDAO")
	private AtributoInstanciaDAO atributoInstanciaDAO;

	@Override
	public List<Atributo> getAllAtributosByAplicaA(String aplicaA) throws GeneralDataAccessException {
		
		return atributoDAO.getAtributosByAplica(aplicaA);

	}

	public List<Atributo> getAtributosByTipoServicioAplicaA(Long idTipoServicio, String aplicaA) throws GeneralDataAccessException {
		return atributoDAO.getAtributosByTipoServicioAplicaA(idTipoServicio, aplicaA);
	}

	@Override
	public List<Atributo> getAtributosSinIntanciaByAplicaA(Servicio servicio, String aplicaA) throws GeneralDataAccessException {
		return atributoDAO.getAtributosSinIntanciaByAplicaA(servicio, aplicaA);
	}

	@Override
	public void preHandle(List<AtributoInstancia> atributosInstancia) throws GeneralDataAccessException {
		if (atributosInstancia != null) {

			for (java.util.Iterator<AtributoInstancia> it = atributosInstancia.iterator(); it.hasNext();) {
				AtributoInstancia atrI = it.next();

				if (atrI.getId() == null) {
					this.saveAtributoInstancia(atrI);
				} else {
					this.updateAtributoInstancia(atrI);
				}
			}
		}

	}

	@Override
	public void saveAtributoInstancia(AtributoInstancia atributoInstancia) throws GeneralDataAccessException {
		this.atributoInstanciaDAO.save(atributoInstancia);
	}

	@Override
	public void updateAtributoInstancia(AtributoInstancia atributoInstancia) throws GeneralDataAccessException {
		this.atributoInstanciaDAO.update(atributoInstancia);
	}

	public Atributo getAtributosById(Long idAtributo) throws GeneralDataAccessException{
		return atributoDAO.getByPrimaryKey(idAtributo);
	}
	
	// Mejoras 201409 Nro: 69
	@Override
	public Atributo getAtributoByDescriptor(String descriptor) throws GeneralDataAccessException{
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put(GenericDAO.CRITERION_PREFIX_ILIKE+".descriptor", descriptor);
		
		List<Atributo> atributos=  atributoDAO.findBySimpleCriteria(criteria);
		if (atributos != null && atributos.size() > 0) {
			return  atributos.get(0);
		}
		else return null;
	}
	

	@Override
	public List<AtributoInstancia> getAtributosInstanciasByVehiculosIdandIdAtributo(
			List<Long> vehiculosID ,Long idAtributo) throws GeneralDataAccessException {
		List<OperationDAO> daos = new ArrayList<OperationDAO>();
		
		OperationDAO dao = new OperationDAO("vehiculo.id", OperationDAO.OPERATION_IN);
		dao.setValue(vehiculosID);
		daos.add(dao);
		
		OperationDAO dao2 = new OperationDAO("atributo.id", OperationDAO.OPERATION_EQUALS);
		dao2.setValue(idAtributo);
		daos.add(dao2);
		
		return this.atributoInstanciaDAO.findBySimpleHQL(daos) ;
	}
	
	// Mejoras 201409 Nro: 69
	
	
	// Mejoras 201409 Nro: 78
	@Override
	public String getAtributoInstanciaByIdServicioAndDescriptor(Long idServico, String descriptor, String aplicaA)throws GeneralDataAccessException {
		return atributoDAO.getValueAtributoInstancia(idServico, descriptor, aplicaA);
	}

    @Override
    public List<AtributoInstancia> getAtributoInstanciaByIdServicio(Servicio servicio) throws GeneralDataAccessException {
        
        return atributoInstanciaDAO.getAtributosInstanciaServicio(servicio);
    }

    
    @Override
    public List<AtributoInstancia> getAtributoInstanciaByVehiculo(Vehiculo v) throws GeneralDataAccessException {
        return atributoInstanciaDAO.getAtributosInstanciaVehiculo(v);
    }
    
    @Override
    public void fillCache() {
        //NO HACER NADA, LO HACE DELEGATE
        
    }

    @Override
    public boolean estAtributoObligatorio(Atributo attr, TipoServicio tipoServicio) throws GeneralDataAccessException {
      //NO HACER NADA, LO HACE DELEGATE
        return false;
    }
    
    
    @Override
    public List<AtributoServicioLogDTO> getAtributosLogInstanciaServicio(Long id) throws GeneralDataAccessException{
        return atributoInstanciaDAO.getAtributosLogInstanciaServicio(id);
    }

    @Override
    public List<TipoServicioAtributo> getTipoSevicioAtributoByTsId(Long id) throws GeneralDataAccessException {
        //resuelto por delegate
        return new ArrayList<TipoServicioAtributo>();
    }

    @Override
    public TipoServicioAtributo getTipoSevicioAtributoByTsAt(Long attid, Long tsid) throws GeneralDataAccessException {
        //resuelto por delegate
        return null;
    }

    @Override
    public List<TipoServicioAtributo> getTipoSevicioAtributoByTsIdAplica(Long id, String aplicaAServicio) throws GeneralDataAccessException {
      //resuelto por delegate
        return new ArrayList<TipoServicioAtributo>();
    }

	@Override
	public void updateLineaAud(String valorActualLinea,Servicio servicio) throws GeneralDataAccessException {
		
				atributoInstanciaDAO.updateLineaVsAud(servicio,valorActualLinea);

		
	}

	@Override
	public String getValorAtributoInstanciaByIdServicioAndDescriptor(Long id,String descriptor, String aplicaAServicio)	throws GeneralDataAccessException {
		return atributoInstanciaDAO.getValorAtributoInstanciaByIdServicioAndDescriptor(id,descriptor, aplicaAServicio);
	}
}
