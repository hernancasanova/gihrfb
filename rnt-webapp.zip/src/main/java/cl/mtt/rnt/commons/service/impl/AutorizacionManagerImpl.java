package cl.mtt.rnt.commons.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.ManagedProperty;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.AutorizacionMovimientoDAO;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.NotificacionDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.autorizacion.Autorizacion;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.model.core.autorizacion.Notificacion;
import cl.mtt.rnt.commons.model.core.autorizacion.UsuarioGrupo;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.service.AutorizacionManager;
import cl.mtt.rnt.commons.service.ConductorManager;
import cl.mtt.rnt.commons.service.GrupoManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.util.Resources;


@Service("autorizacionManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class AutorizacionManagerImpl implements AutorizacionManager {
	
	@Autowired()
	@Qualifier("AutorizacionDao")
	private GenericDAO<Autorizacion> autorizacionDao;
	
	
	@Autowired
	@Qualifier("AutorizacionMovimientoDAO")
	private AutorizacionMovimientoDAO autorizacionMovimientoDao;
	
	@Autowired
	@Qualifier("grupoManager")
	private GrupoManager grupoManager;
	
	@Autowired
	@Qualifier("NotificacionDAO")
	private NotificacionDAO notificacionDAO;
	
	@Autowired
	@Qualifier("mailSenderService")
	private MailSenderImpl mailSender;
	
	@Autowired
	@Qualifier("vehiculoManagerRnt")
	private VehiculoManagerRnt vehiculoManagerRnt;
	
	@Autowired
	@ManagedProperty(value = "#{conductorManager}")
	private ConductorManager conductorManager;
	


	public GenericDAO<Autorizacion> getAutorizacionDao() {
		return autorizacionDao;
	}

	public void setAutorizacionDao(GenericDAO<Autorizacion> autorizacionDao) {
		this.autorizacionDao = autorizacionDao;
	}

	public AutorizacionMovimientoDAO getAutorizacionMovimiento() {
		return autorizacionMovimientoDao;
	}

	public void setAutorizacionMovimiento(
			AutorizacionMovimientoDAO autorizacionMovimiento) {
		this.autorizacionMovimientoDao = autorizacionMovimiento;
	}

	@Override
	public Autorizacion getAutorizacionByNormativa(Long idNormativa)
			throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("normativa.id", idNormativa);
		List<Autorizacion> autorizaciones =  autorizacionDao.findBySimpleCriteria(criteria);
		if (autorizaciones != null && !autorizaciones.isEmpty()){
			return autorizaciones.get(0);
		}
		return null;
	}

	@Override
	public List<AutorizacionMovimiento> getAutorizacionesMovimientoPag(User user ,int first, int rows, List<String> orderFields)  throws GeneralDataAccessException {
		return  autorizacionMovimientoDao.getAutorizacionesMovimientoPag(user, first, rows, orderFields);
	}

	@Override
	public long getAutorizacionesMovimientoCount(User user)throws GeneralDataAccessException {
		return autorizacionMovimientoDao.getAutorizacionesMovimientoCount(user);
	}

	@Override
	public void handle(User currentUser,AutorizacionMovimiento autorizacionMovimiento,GenericModelObject asociado)throws GeneralDataAccessException {
		//siempre se debe llamar para crear
		autorizacionMovimiento.setIdMovimiento(asociado.getId());
		autorizacionMovimientoDao.save(autorizacionMovimiento);
		
		Autorizacion au = autorizacionMovimiento.getAutorizacion();
		for (Grupo gr : au.getGrupoResponsable()) {
			List<UsuarioGrupo> usuariosGrupoByIdGrupo = grupoManager.getUsuariosGrupoByIdGrupo(gr.getId());
			for (UsuarioGrupo ug : usuariosGrupoByIdGrupo) {
				
				Notificacion noti = new Notificacion();
				noti.setAutorizacionMovimiento(autorizacionMovimiento);
				noti.setUsuarioDestino(ug.getUser());
				noti.setDescripcion(AutorizacionMovimiento.buidDescripcion(autorizacionMovimiento.getTipoMovimiento(),asociado,au.getNormativa()));
				noti.setEstado(Notificacion.ESTADO_NO_LEIDO);
				noti.setTipo(Notificacion.NOTIFICACION_AUTORIZACION);
				noti.setObservacion(autorizacionMovimiento.getComentarioSolicitante());
				noti.setTitulo(noti.getDescripcion());
				notificacionDAO.save(noti);
				try {
					String message = "";
					message += "    El usuario " + currentUser.getNombreCompleto() + " " + noti.getDescripcion();
					mailSender.sendEmail(Resources.getString("notificacion.aut.mail.subject"), message, ug.getUser().getEmail());
				}
				catch (AddressException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
				catch (MessagingException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				} 
				catch (UnsupportedEncodingException e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
				catch (Exception e) {
					Logger.getLogger(this.getClass()).error(e.getMessage(),e);
				}
			}
		}
	}

	@Override
	public void aceptarAutorizacionMovimiento(Object movimiento, Notificacion noti, Notificacion notiRespuesta)throws GeneralDataAccessException {
		autorizacionMovimientoDao.update(noti.getAutorizacionMovimiento());
		notificacionDAO.save(notiRespuesta);
		
		List<AutorizacionMovimiento> autorizaciones = this.getAutorizacionMovimientoByTipoYIdmovimiento(noti.getAutorizacionMovimiento().getTipoMovimiento(), noti.getAutorizacionMovimiento().getIdMovimiento());
		boolean autorizada = true;
		for(AutorizacionMovimiento am : autorizaciones){
			if(am.getEstado().equals(AutorizacionMovimiento.ESTADO_PENDIENTE)){
				autorizada = false;
				break;
			}
		}
		
		if(autorizada){
			if(noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL))
				vehiculoManagerRnt.updateVehiculoServicio((VehiculoServicio)movimiento);
			else if(noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO) || noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_SERVICIO))
				conductorManager.updateConductorServicio((ConductorServicio)movimiento);
			else if(noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO) || noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_VEHICULO))
				conductorManager.updateConductorVehiculo((ConductorVehiculo)movimiento);
		}
	}
	
	
	@Override
	public void rechazarAutorizacionMovimiento(Object movimiento, Notificacion noti, Notificacion notiRespuesta)throws GeneralDataAccessException {
		if(noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGESO_AUTOMOVIL)){
			vehiculoManagerRnt.deleteVehiculoServicioRechazada((VehiculoServicio)movimiento);
		}else if(noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO)){
			conductorManager.deleteConductorServicioRechazada((ConductorServicio)movimiento);
		}else if(noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_SERVICIO)){
			conductorManager.cancelConductorServicioRechazada((ConductorServicio)movimiento);
		}else if(noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO)){
			conductorManager.deleteConductorVehiculoRechazada((ConductorVehiculo)movimiento);
		}else if(noti.getAutorizacionMovimiento().getTipoMovimiento().equals(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_VEHICULO)){
			conductorManager.cancelConductorVehiculoRechazada((ConductorVehiculo)movimiento);
		}
		
		List<AutorizacionMovimiento> autorizacionesMovimiento = this.getAutorizacionMovimientoByTipoYIdmovimiento(noti.getAutorizacionMovimiento().getTipoMovimiento(), noti.getAutorizacionMovimiento().getIdMovimiento());
		
		for(AutorizacionMovimiento am :  autorizacionesMovimiento){
			am.setEstado(AutorizacionMovimiento.ESTADO_CANCELADO);
			autorizacionMovimientoDao.update(am);	
		}
		
		notificacionDAO.save(notiRespuesta);
	}

	@Override
	public List<AutorizacionMovimiento> getAutorizacionMovimientoByTipoYIdmovimiento(Integer tipoMovimiento, Long idMovimiento) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("idMovimiento", idMovimiento);
		criteria.put("tipoMovimiento", tipoMovimiento);
		
		return  autorizacionMovimientoDao.findBySimpleCriteria(criteria);
	}

	@Override
	public List<Normativa> getAutorizacionMovimientoConductoresServicioAprobadas(Long idConductor) throws GeneralDataAccessException{
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("idMovimiento", idConductor);
		List<Integer> tipos=new ArrayList<Integer>();
		tipos.add(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_SERVICIO);
		tipos.add(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_SERVICIO);
		criteria.put("tipoMovimiento", tipos);
		criteria.put("estado", AutorizacionMovimiento.ESTADO_ACEPTADO);
		
		List<AutorizacionMovimiento> aut = autorizacionMovimientoDao.findBySimpleCriteria(criteria);
		List<Normativa> ret=new ArrayList<Normativa>();
		for (AutorizacionMovimiento autorizacionMovimiento : aut) {
			Hibernate.initialize(autorizacionMovimiento.getAutorizacion().getNormativa());
			ret.add(autorizacionMovimiento.getAutorizacion().getNormativa());
		}
		return ret;
	}

	@Override
	public List<Normativa> getAutorizacionMovimientoConductoresVehiculoAprobadas(Long idConductor) throws GeneralDataAccessException{
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("idMovimiento", idConductor);
		List<Integer> tipos=new ArrayList<Integer>();
		tipos.add(AutorizacionMovimiento.TIPO_INGRESO_CONDUCTOR_VEHICULO);
		tipos.add(AutorizacionMovimiento.TIPO_MODIFICACION_CONDUCTOR_VEHICULO);
		criteria.put("tipoMovimiento", tipos);
		criteria.put("estado", AutorizacionMovimiento.ESTADO_ACEPTADO);
		
		
		List<AutorizacionMovimiento> aut = autorizacionMovimientoDao.findBySimpleCriteria(criteria);
		List<Normativa> ret=new ArrayList<Normativa>();
		for (AutorizacionMovimiento autorizacionMovimiento : aut) {
			Hibernate.initialize(autorizacionMovimiento.getAutorizacion().getNormativa());
			ret.add(autorizacionMovimiento.getAutorizacion().getNormativa());
		}
		return ret;
	}

    @Override
    public List<Grupo> getGrupoAutorizantesRevertir(Servicio servicio) throws GeneralDataAccessException {
        return autorizacionMovimientoDao.getGrupoAutorizantesRevertir(servicio);
    }

    @Override
    public Autorizacion getAutorizacionRevertir() throws GeneralDataAccessException {
        HashMap<String, Object> criteria = new HashMap<String, Object>();
        criteria.put("normativa", null);
        List<Autorizacion> aut = autorizacionDao.findBySimpleCriteria(criteria);
        if (aut != null) {
            for (Autorizacion autorizacion : aut) {
                return autorizacion;
             }
        }
        return null;
    }
}
