package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;
import org.richfaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.bean.BibliotecaDigitalCriteria;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.InvalidUploadAlfrescoException;
import cl.mtt.rnt.commons.model.core.DocumentoBiblioteca;
import cl.mtt.rnt.commons.model.core.TipoDocumento;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.TipoDocumentoSeleccionable;
import cl.mtt.rnt.commons.service.BibliotecaDigitalManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Utils;
import cl.mtt.rnt.commons.ws.bibliotecadigital.auth.AuthenticationFault_Exception;
import cl.mtt.rnt.commons.ws.bibliotecadigital.content.GetDocumentObjectResponse;
import cl.mtt.rnt.commons.ws.client.BibliotecaDigitalService;

@Service("bibliotecaDigitalManager")
@Transactional(rollbackFor = Exception.class)
@Lazy(value = true)
public class BibliotecaDigitalManagerImpl implements BibliotecaDigitalManager {

	@Autowired
	@Qualifier("DocumentoBibliotecaDAO")
	private GenericDAO<DocumentoBiblioteca> documentoBibliotecaDAO;
	
	@Autowired
	@Qualifier("bibliotecaDigitalService")
	private BibliotecaDigitalService bibliotecaDigitalService;

	@Autowired
	@Qualifier("TipoDocumentoDAO")
	private GenericDAO<TipoDocumento> tipoDocumentoDAO;
	
	@Autowired
	@Qualifier("ubicacionGeograficaManager")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@Override
	public List<GetDocumentObjectResponse> findDocumentos(BibliotecaDigitalCriteria criterio, User user) throws GeneralDataAccessException, AuthenticationFault_Exception, DatatypeConfigurationException, InvalidUploadAlfrescoException {

		List<GetDocumentObjectResponse> ret=null;
		String codigoRegionAux = null;
		boolean codRegionNumero = Utils.isNumeric(criterio.getCodigoRegionCriterio());
		if (codRegionNumero) {
		    codigoRegionAux = criterio.getCodigoRegionCriterio();
		    Region reg = ubicacionGeograficaManager.getRegionById(codigoRegionAux);
		    criterio.setCodigoRegionCriterio(reg.getPrefijo());
		}
		
		//Aqui se llamaría al servicio de Biblioteca Digital
		ret = bibliotecaDigitalService.getDocuments(criterio, user);
		//Aqui se llamaría al servicio de Biblioteca Digital
		
		if (codRegionNumero) {
		    criterio.setCodigoRegionCriterio(codigoRegionAux);
		}
		return ret;
		
	}
	
	
	public DocumentoBiblioteca getDocumentoLocal(String nombreDoc,String codigoRegion,String materia)  throws GeneralDataAccessException {
	    HashMap<String,Object> cri = new HashMap<String, Object>();
	    cri.put("nombre", nombreDoc);
	    cri.put("codigoRegion", codigoRegion);
	    cri.put("materia", materia);
	    List<DocumentoBiblioteca> list = documentoBibliotecaDAO.findBySimpleCriteria(cri);
	    if ((list!=null)&& (!list.isEmpty())) {
	        return list.get(0);
	    }
	    return null;
	}
	

	public void saveDocumento(DocumentoBiblioteca documento, UploadedFile file, User user) throws GeneralDataAccessException, AuthenticationFault_Exception, DatatypeConfigurationException, InvalidUploadAlfrescoException {
		
		String url = bibliotecaDigitalService.uploadFile(documento, file, user);
		documento.setLinkDocumento(url);
		
		documentoBibliotecaDAO.save(documento);
	}
	
	public void saveDocumento(DocumentoBiblioteca documento) throws GeneralDataAccessException{
	    documentoBibliotecaDAO.save(documento);
	}
	
	public void registrarDocumentoExistente(DocumentoBiblioteca documento) throws GeneralDataAccessException {
	    documentoBibliotecaDAO.save(documento);
	}

	
	@Override
	public List<TipoDocumentoSeleccionable> getTiposSeleccionables(){
	    try {
			return bibliotecaDigitalService.getTiposSeleccionables();
		} catch (GeneralDataAccessException e) {
			e.printStackTrace();
		}
	    return new ArrayList<TipoDocumentoSeleccionable>();
	}


    @Override
    public void fillCache() {
        try {
        	List<TipoDocumentoSeleccionable> lista = bibliotecaDigitalService.getTiposSeleccionables();
       		Logger.getLogger(this.getClass()).trace("Tipos Seleccionables: " + lista.size());
        }catch (GeneralDataAccessException e) {
           Logger.getLogger(this.getClass()).error(e.getMessage(),e);
        }catch (Exception e) {
        	Logger.getLogger(this.getClass()).error(e.getMessage(),e);
		}
    }

	

}
