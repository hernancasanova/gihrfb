package cl.mtt.rnt.commons.service.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.admin.reglamentacion.EventManager;
import cl.mtt.rnt.admin.reglamentacion.EventResult;
import cl.mtt.rnt.admin.reglamentacion.GenericEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.CambioTarifaEvent;
import cl.mtt.rnt.admin.reglamentacion.eventImpl.ReimprimirCertificadoVehiculoEvent;
import cl.mtt.rnt.commons.dao.CargaMasivaDAO;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.CertificadoException;
import cl.mtt.rnt.commons.exception.CertificadoMigradoException;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.EventEvalException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.NoTrazadosException;
import cl.mtt.rnt.commons.exception.PendingSaveException;
import cl.mtt.rnt.commons.exception.VehicleWithoutOwnerException;
import cl.mtt.rnt.commons.exception.VehiculoNoReglamentadoException;
import cl.mtt.rnt.commons.model.core.AtributoInstancia;
import cl.mtt.rnt.commons.model.core.CargaMasiva;
import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.DiaTrazado;
import cl.mtt.rnt.commons.model.core.DocumentoBiblioteca;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.ItemMatrizTarifaria;
import cl.mtt.rnt.commons.model.core.ItemTramoTarifario;
import cl.mtt.rnt.commons.model.core.JobCargaMasiva;
import cl.mtt.rnt.commons.model.core.Paradero;
import cl.mtt.rnt.commons.model.core.Persona;
import cl.mtt.rnt.commons.model.core.PublicoObjetivo;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.Sector;
import cl.mtt.rnt.commons.model.core.SectorTramoTarifario;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.Tarifa;
import cl.mtt.rnt.commons.model.core.Terminal;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoCargaMasiva;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.core.TramoTarifario;
import cl.mtt.rnt.commons.model.core.Vehiculo;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.recorrido.DatoDiccionario;
import cl.mtt.rnt.commons.model.core.recorrido.ExtremoRecorrido;
import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.commons.model.core.recorrido.Tramo;
import cl.mtt.rnt.commons.model.core.recorrido.Trazado;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.service.AtributoManager;
import cl.mtt.rnt.commons.service.CargaMasivaManager;
import cl.mtt.rnt.commons.service.CertificadoManager;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.RecorridoManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.ServicioManager;
import cl.mtt.rnt.commons.service.TarifaManager;
import cl.mtt.rnt.commons.service.TerminalManager;
import cl.mtt.rnt.commons.service.TipoCertificadoManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.CertificadoBuilder;
import cl.mtt.rnt.commons.util.CertificadoXMLUtil;
import cl.mtt.rnt.commons.util.Constants;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StringUtil;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.ExecutionResult;
import cl.mtt.rnt.encargado.bean.controller.cargaMasiva.handsonTable.HandsonRowContent;
import cl.mtt.rnt.encargado.dto.RecorridoDTO;
import cl.mtt.rnt.encargado.dto.VehiculoServicioDTO;

@Service("cargaMasivaManager")
@Transactional(rollbackFor = Exception.class)
@Lazy(value = true)
public class CargaMasivaManagerImpl implements CargaMasivaManager {

	@Autowired
	@Qualifier("CargaMasivaDAO")
	private CargaMasivaDAO cargaMasivaDAO;

	@Autowired
	@Qualifier("JobCargaMasivaDAO")
	private GenericDAO<JobCargaMasiva> jobCargaMasivaDAO;

	@Autowired
	@Qualifier("servicioManager")
	private ServicioManager servicioManager;

	@Autowired
	@Qualifier("generalDataManager")
	private GeneralDataManager generalDataManager;

	@Autowired
	@Qualifier("vehiculoManagerRnt")
	private VehiculoManagerRnt vehiculoManagerRnt;

	@Autowired
	@Qualifier("recorridoManager")
	private RecorridoManager recorridoManager;

	@Autowired
	@Qualifier("certificadoManager")
	private CertificadoManager certificadoManager;

	@Autowired
	@Qualifier("tipoCertificadoManager")
	private TipoCertificadoManager tipoCertificadoManager;

	@Autowired
	@Qualifier("reglamentacionManager")
	private ReglamentacionManager reglamentacionManager;

	@Autowired
	@Qualifier("tipoServicioManager")
	private TipoServicioManager tipoServicioManager;

	@Autowired
	@Qualifier("ubicacionGeograficaManager")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@Autowired
	@Qualifier("terminalManager")
	private TerminalManager terminalManager;
	
	@Autowired
	@Qualifier("PublicoObjetivoDAO")
	private GenericDAO<PublicoObjetivo> publicoObjetivoDAO;
	
	@Autowired
	@Qualifier("tarifaManager")
	private TarifaManager tarifaManager;
	
	@Autowired
    @Qualifier("atributoManager")
    private AtributoManager atributoManager;
	
		
	@Override
	public List<CargaMasiva> getCargasMasivas(User user, CategoriaTransporteSeleccionble categoria, Region region) throws GeneralDataAccessException {
		return this.cargaMasivaDAO.getCargasMasivas(user, categoria, region);
	}

	@Override
	public List<TipoCargaMasiva> getTiposCargaMasiva() throws GeneralDataAccessException {
		return this.cargaMasivaDAO.getTiposCargaMasiva();
	}

	@Override
	public void guardarOActualizarCargaMasiva(CargaMasiva cargaMasivaSel) throws GeneralDataAccessException {
		if (cargaMasivaSel.getId() == null) {
			this.jobCargaMasivaDAO.save(cargaMasivaSel.getJob());
			this.cargaMasivaDAO.save(cargaMasivaSel);
		} else {
			this.jobCargaMasivaDAO.update(cargaMasivaSel.getJob());
			this.cargaMasivaDAO.update(cargaMasivaSel);
		}
	}

	public void setJobToCargaMasiva(CargaMasiva cargaMasiva) throws GeneralDataAccessException {
		CargaMasiva cmdb = cargaMasivaDAO.getByPrimaryKey(cargaMasiva.getId());
		Hibernate.initialize(cmdb.getJob());
		cargaMasiva.setJob(cmdb.getJob());
	}

	@Override
	public void ejecutarCambioVigenciaServicio(HandsonRowContent row) throws Exception{
			try {
				// obtengo el servicio y le cambio las fechas de vigencia
				Servicio serv = this.servicioManager.getServicioById((Long) row.getRow().get("id"));
				serv.setVigenciaDesde(Constants.dateFormat.parse((String) row.getRow().get("nFechaVigenciaInicio")));
				serv.setVigenciaHasta(Constants.dateFormat.parse((String) row.getRow().get("nFechaVigenciaFin")));
				// verifico si tengo que generar nuevamente los certificados
				List<Certificado> certificados = validarReimpresionDeCertificados(serv);	
				// actualizo el servicio junto con los certificados
				servicioManager.updateServicio(serv, null, null, certificados);
				// si se actualizo en db cambio el registro que se va a visualizar
				row.getRow().put("aFechaVigenciaInicio", row.getRow().get("nFechaVigenciaInicio"));
				row.getRow().put("aFechaVigenciaFin", row.getRow().get("nFechaVigenciaFin"));
				row.getRow().put("nFechaVigenciaInicio", "");
				row.getRow().put("nFechaVigenciaFin", "");
				row.getRow().put("mensaje", "");
				row.getRow().put("updated", true);
			} catch (Exception e) {
				row.getRow().put("mensaje", e.getMessage());
				row.getRow().put("updated", false);
				throw e;
			}
		
	}

	private boolean cancelarServicio(Servicio servicio, HandsonRowContent row) {
		try {
			TipoCancelacion tipoCancelacionServicio = null;
			for (TipoCancelacion tc : generalDataManager.getAllTiposCancelacionDeServicio(TipoCancelacion.APLICA_SERVICIO)) {
				if (StringUtil.removeDiacriticos(tc.getNombre()).equalsIgnoreCase("Cancelacion de Servicio") && (tc.getTiposServicio().contains(servicio.getTipoServicio()))) {
					tipoCancelacionServicio = tc;
				}
			}
			if (tipoCancelacionServicio == null){
				row.getRow().put("mensaje", "El servicio no tiene tipo de cancelación");
				return false;
			}
			TipoCancelacion tipoCancelacionVehiculo = null;
			for (TipoCancelacion tc : generalDataManager.getAllTiposCancelacionDeServicio(TipoCancelacion.APLICA_VEHICULOS)) {
				if (StringUtil.removeDiacriticos(tc.getNombre()).equalsIgnoreCase("Cancelacion de Servicio")) {
					tipoCancelacionVehiculo = tc;
				}
			}
			Integer nuevoEstado = GenericCancellableModelObject.ESTADO_CANCELADO;
			if (tipoCancelacionServicio.getTipoCancelacion().equals(GenericCancellableModelObject.CANCELACION_DEFINITIVA_KEY)) {
				nuevoEstado = GenericCancellableModelObject.ESTADO_CANCELADO_DEFINITIVO;
			}

			if (servicio.getVehiculosSkeleton() != null) {

				for (VehiculoServicioDTO vsDTO : servicio.getVehiculosSkeleton()) {
					VehiculoServicio vs = vehiculoManagerRnt.getVehiculoServicioById(vsDTO.getId());

					if (vs.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
						vs.setFechaCambioEstado(servicio.getFechaCambioEstado());
						vs.setLinkResolucionCancelacion(servicio.getLinkResolucionCancelacion());
						vs.setFechaResolucionCancelacion(servicio.getFechaResolucionCancelacion());
						vs.setTipoCancelacion(tipoCancelacionVehiculo);
						vs.setObservacion(tipoCancelacionVehiculo.getNombre());
						vs.setObservacionCancelacion(servicio.getObservacionCancelacion());
						vs.setEstado(nuevoEstado);
						vs.setDbAction(GenericModelObject.ACTION_UPDATE);
						vs.setGenerarCertificado(VehiculoServicio.GENERAR_CERTIFICADO_CANCELACION);
					}
				}
			}

			TipoCancelacion tipoCancelacionPersona = null;
			for (TipoCancelacion tc : generalDataManager.getAllTiposCancelacionDeServicio(TipoCancelacion.APLICA_PERSONA)) {
				if (StringUtil.removeDiacriticos(tc.getNombre()).equalsIgnoreCase("Cancelacion de Servicio")) {
					tipoCancelacionPersona = tc;
				}
			}
			if (servicio.getConductoresServicio() != null) {
				for (ConductorServicio cs : servicio.getConductoresServicio()) {
					if (cs.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
						cs.setFechaCambioEstado(servicio.getFechaCambioEstado());
						cs.setLinkResolucionCancelacion(servicio.getLinkResolucionCancelacion());
						cs.setFechaResolucionCancelacion(servicio.getFechaResolucionCancelacion());
						cs.setTipoCancelacion(tipoCancelacionPersona);
						cs.setObservacionCancelacion(servicio.getObservacionCancelacion());
						cs.setEstado(nuevoEstado);
						cs.setDbAction(GenericModelObject.ACTION_UPDATE);
					}
				}
			}
			TipoCancelacion tipoCancelacionRecorrido = null;
			for (TipoCancelacion tc : generalDataManager.getAllTiposCancelacionDeServicio(TipoCancelacion.APLICA_RECORRIDO)) {
				if (StringUtil.removeDiacriticos(tc.getNombre()).equalsIgnoreCase("Cancelacion de Servicio")) {
					tipoCancelacionRecorrido = tc;
				}
			}
			if (servicio.getRecorridosSkeleton() != null) {
				for (RecorridoDTO recoDTO : servicio.getRecorridosSkeleton()) {
					Recorrido reco = recoDTO.getRecorrido();
					if (reco == null) {
						reco = recorridoManager.getRecorridoById(recoDTO.getId());
						recoDTO.setRecorrido(reco);
						// Acomodar secotres de tarifa de recorrido
						reco.setSectores(null);
					}
					if (reco.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
						reco.setFechaCambioEstado(servicio.getFechaCambioEstado());
						reco.setLinkResolucionCancelacion(servicio.getLinkResolucionCancelacion());
						reco.setFechaResolucionCancelacion(servicio.getFechaResolucionCancelacion());
						reco.setTipoCancelacion(tipoCancelacionRecorrido);
						reco.setObservacionCancelacion(servicio.getObservacionCancelacion());
						reco.setEstado(nuevoEstado);
						reco.setDbAction(GenericModelObject.ACTION_UPDATE);
					}

				}

			}
			servicio.setActivo(false);
			servicio.setEstado(nuevoEstado);

			List<Certificado> colaCertificados = generarCertificados(servicio);
			servicioManager.updateServicio(servicio, new ArrayList<Persona>(0), new ArrayList<VehiculoServicioDTO>(0), colaCertificados);
			// servicioManager.postUpdateServicio(servicio);

			return true;

		}

		catch (GeneralDataAccessException ex) {
			Logger.getLogger(this.getClass()).error(ex.getMessage(), ex);
			return false;
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			return false;
		}
	}

	public List<Certificado> generarCertificados(Servicio servicio) {
		List<Certificado> colaCertificados = new ArrayList<Certificado>();
		try {
			for (VehiculoServicioDTO vsDto : servicio.getVehiculosSkeleton()) {
				List<Certificado> certs = cancelarCertificadoActuales(vsDto.getId(), servicio.getFechaCambioEstado());
				if (certs != null)
					colaCertificados.addAll(certs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return colaCertificados;
	}

	private List<Certificado> cancelarCertificadoActuales(Long vehiculoServicioId, Date fechaCanc) throws GeneralDataAccessException {
		List<Certificado> certs = certificadoManager.getCertificadoActualByVehiculoServicio(vehiculoServicioId);
		if (certs != null) {
			for (Certificado cert : certs) {
				cert.setDbAction(GenericModelObject.ACTION_UPDATE);
				cert.setFechaCambioEstado(fechaCanc);
				cert.setEstado(GenericCancellableModelObject.ESTADO_CANCELADO);
			}
		}
		return certs;
	}

	public ExecutionResult ejecutarCancelacionServicio(List<HandsonRowContent> contenidoTabla) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException {
		int actualizados = 0;
		for (HandsonRowContent row : contenidoTabla) {
			Servicio s = servicioManager.getServicioById((Long) row.getRow().get("id"));
			try {
				s.setFechaCambioEstado(Constants.dateFormat.parse((String) row.getRow().get("fechaCancelacion")));
				s.setObservacionCancelacion((String) row.getRow().get("observaciones"));
				Boolean update = cancelarServicio(s,row);

				// si se actualizo en db cambio el registro que se va a
				// visualizar
				if (update != null && update.booleanValue()) {
					row.getRow().put("updated", true);
					actualizados++;
				} else {
					row.getRow().put("updated", false);
				}

			} catch (ParseException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			}
		}
		ExecutionResult resultado = new ExecutionResult();
		resultado.setCantRowSuccess(actualizados);
		resultado.setCantRowFailed(contenidoTabla.size() - actualizados);
		resultado.setProccessedData(contenidoTabla);
		return resultado;
	}

	@Override
	public void deleteCargaMasiva(CargaMasiva cargaMasivaSel) throws GeneralDataAccessException {
		try {
			this.cargaMasivaDAO.remove(cargaMasivaSel);
		} catch (Exception e) {
			throw new GeneralDataAccessException(e.getMessage(), e);
		}

	}

	// cancelación masiva de vehículos
	private boolean cancelarVehiculoServicio(VehiculoServicio vehiculoServicio, Date fechaCancelacion, String observaciones, TipoCancelacion tipoCancelacion, HandsonRowContent row,boolean includeCertificadosNotObligatorios) {
		vehiculoServicio.setFechaCambioEstado(fechaCancelacion);
		vehiculoServicio.setObservacion(tipoCancelacion.getNombre());
		vehiculoServicio.setObservacionCancelacion(observaciones);
		vehiculoServicio.setDbAction(GenericModelObject.ACTION_UPDATE);
		vehiculoServicio.setTipoCancelacion(tipoCancelacion);
		if (TipoCancelacion.TIPO_DEFINITIVA.equals(tipoCancelacion.getTipoCancelacion()))
			vehiculoServicio.setEstado(GenericCancellableModelObject.ESTADO_CANCELADO_DEFINITIVO);
		else
			vehiculoServicio.setEstado(GenericCancellableModelObject.ESTADO_CANCELADO);

		try {
			// cancelar actual
			List<Certificado> colaCertificados = cancelarCertificadoActuales(vehiculoServicio.getId(), fechaCancelacion);
			TipoCertificado tc = tipoCertificadoManager.getTipoCertificadoByTipoServicio(vehiculoServicio.getServicio().getTipoServicio(), TipoCertificado.MOVIMIENTO_CANCEL,
					TipoCertificado.OBJETO_VEHICULO, vehiculoServicio.getReglamentacion());
			if (tc != null && ((tc.getObligatorio()!=null && tc.getObligatorio().booleanValue()) || includeCertificadosNotObligatorios)) {
				colaCertificados.add(CertificadoBuilder.createCertificadoCancelacionVehiculo(vehiculoServicio, tc));
			}
//			else {
//				vehiculoServicio.setRespuestaFirmador(-200);
//				vehiculoServicio.setMensajeFirmador(Resources.getString("certificado.error.tipoCertificadoNoDefinido"));
//				row.getRow().put("mensaje", "No existe un tipo de certificado");
//				return false;
//			}

			// Cancelarlo en la base de datos
			vehiculoServicio.getServicio().setTmpConductoresVehiculo(new HashMap<String, Object>());
			vehiculoServicio.setConductoresVehiculo(new ArrayList<ConductorVehiculo>());
			List<VehiculoServicioDTO> vss = new ArrayList<VehiculoServicioDTO>();
			vss.add(new VehiculoServicioDTO(vehiculoServicio));
			vehiculoManagerRnt.preHandle(vss, vehiculoServicio.getServicio());
			vehiculoManagerRnt.postHandle(vss, vehiculoServicio.getServicio());
			// no estoy evaluando si se hizo o no el certificado
			certificadoManager.handlerCertificados(colaCertificados, vehiculoServicio.getServicio());
		} catch (Exception e) {
			row.getRow().put("mensaje", e.getMessage());
			return false;
		}

		return true;
	}

	public ExecutionResult ejecutarCancelacionVahiculoServicio(List<HandsonRowContent> rows,boolean generarCertNoObligatorios,DocumentoBiblioteca documento) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException {
		int actualizados = 0;
		for (HandsonRowContent row : rows) {
			VehiculoServicio vs = vehiculoManagerRnt.getVehiculoAllData((Long) row.getRow().get("id"),null);
			vs.setDocumentoCancelacion(documento);
			try {
				Boolean update = cancelarVehiculoServicio(vs, Constants.dateFormat.parse((String) row.getRow().get("fechaCancelacion")), (String) row.getRow().get("observaciones"),
						(TipoCancelacion) row.getRow().get("tipoCancelacion"),row,generarCertNoObligatorios);
				// si se actualizo en db cambio el registro que se va a
				// visualizar
				if (update != null && update.booleanValue()) {
					row.getRow().put("updated", true);
					actualizados++;
				} else {
					row.getRow().put("updated", false);
				}

			} catch (ParseException e) {
				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			}
		}
		ExecutionResult resultado = new ExecutionResult();
		resultado.setCantRowSuccess(actualizados);
		resultado.setCantRowFailed(rows.size() - actualizados);
		resultado.setProccessedData(rows);
		return resultado;
	}

	public void prepararVehiculoServicioParaCertificado(VehiculoServicio vs) throws GeneralDataAccessException {
		if (!Hibernate.isInitialized(vs.getConductoresVehiculo())) {
			List<ConductorVehiculo> conductoresVehiculo2 = vehiculoManagerRnt.getConductoresVehiculo(vs);
			if (conductoresVehiculo2 != null) {
				vs.setConductoresVehiculo(conductoresVehiculo2);
			} else {
				vs.setConductoresVehiculo(new ArrayList<ConductorVehiculo>());
			}
		}
		if (!Hibernate.isInitialized(vs.getVehiculo().getAtributosInstancia())) {
			vs.getVehiculo().setAtributosInstancia(atributoManager.getAtributoInstanciaByVehiculo(vs.getVehiculo()));
		}
	}

//	public CertificadoAtributosDataProvider getCertificadoDatoByCertificado(Certificado cert) throws GeneralDataAccessException {
//		CertificadoAtributosDataProvider certificadoAtributosDataProvider;// =
//																			// this.datosCertbyVs.get(cert.getVehiculo().getId());
//		List<CertificadoDato> datos = this.certificadoManager.getCertificadoDatoByCertificado(cert);
//		certificadoAtributosDataProvider = new CertificadoAtributosDataProvider(cert.getVehiculo().getId());
//		if (datos != null) {
//			for (CertificadoDato cd : datos) {
//				certificadoAtributosDataProvider.addCertificadoDato(cd);
//			}
//		}
//		return certificadoAtributosDataProvider;
//	}

	public EventResult evalEvent(Reglamentacion reg, GenericEvent event) throws JAXBException, GeneralDataAccessException, EventEvalException {
		EventManager eventManager = new EventManager(reg);
		return eventManager.evalEvent(event);
	}

	private boolean validarReimpresionDeCertificadosVehiculosSinRecorrido(VehiculoServicioDTO vsDTO) throws GeneralDataAccessException, ParserConfigurationException, JAXBException, EventEvalException {
		boolean ret = false;
		if (!vsDTO.isHavingAllData()) {
			vsDTO.setVs(vehiculoManagerRnt.getVehiculoAllData(vsDTO.getId(),null));
		}
		if (vsDTO.getVs().getGenerarCertificado() == VehiculoServicio.GENERAR_CERTIFICADO_NO_ACCION) {
			// Comparo el vehiculo con su contraparte de acuerdo al certificado
			boolean debeReimprimir = false;
			VehiculoServicio vehiculoServicio = vsDTO.getVs();
			prepararVehiculoServicioParaCertificado(vehiculoServicio);
			Certificado certificado = null;
			try {
				certificado = certificadoManager.getCertificadoCurrentInscripcionActual_(vehiculoServicio);
			} catch (CertificadoMigradoException e) {
				vehiculoServicio.setTieneCertificadoMigrado(true);
			}
			
			debeReimprimir = tieneCertificadoDiferente(vehiculoServicio, certificado);

			if (debeReimprimir) {
				evalEvent(vehiculoServicio.getReglamentacion(), new ReimprimirCertificadoVehiculoEvent(vehiculoServicio));
				ret = true;
				vehiculoServicio.setGenerarCertificado(VehiculoServicio.GENERAR_CERTIFICADO_MODIFICACION);
			}
		}
		return ret;
	}

	/**
	 * @param vehiculoServicio
	 * @param certificado
	 * @return
	 * @throws ParserConfigurationException
	 */
	private boolean tieneCertificadoDiferente(
			VehiculoServicio vehiculoServicio, Certificado certificado)
			throws ParserConfigurationException {
		boolean debeReimprimir;
		if (certificado != null && certificado.getChecksum()!=null) {
			certificado.setVehiculo(vehiculoServicio);
			String md5Certificado =certificado.getChecksum();
			CertificadoXMLUtil certificadoXMLUtil=new CertificadoXMLUtil();
			String md5Actual = StringUtil.getMD5(certificadoXMLUtil.getCertificadoXMLasString(certificado.getTipoCertificado().getSeccion(), certificado.getObjetoAsociado(), certificadoManager , certificado.getModifiers()));
			debeReimprimir = !md5Certificado.equals(md5Actual);
		} else {
			debeReimprimir = true;
		}
		return debeReimprimir;
	}

	private boolean validarReimpresionDeCertificadosVehiculosConRecorrido(VehiculoServicioDTO vsDTO, RecorridoDTO recDTO) throws GeneralDataAccessException, ParserConfigurationException,
			JAXBException, EventEvalException {
		boolean ret = false;
		if (!vsDTO.isHavingAllData()) {
			vsDTO.setVs(vehiculoManagerRnt.getVehiculoAllData(vsDTO.getId(),null));
		}
		if (!recDTO.isHavingAllData()) {
			recDTO.setRecorrido(recorridoManager.getRecorridoById(recDTO.getId()));
			recDTO.getRecorrido().setTrazados(recorridoManager.getTrazadosByRecorridoId(recDTO.getId()));
		}
		if (!recDTO.getRecorrido().getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE))
			return false;
		if (vsDTO.getVs().getGenerarCertificado() == VehiculoServicio.GENERAR_CERTIFICADO_NO_ACCION || !vsDTO.getVs().getRecorridosACertificar().contains(recDTO.getRecorrido())) {
			// Comparo el vehiculo con su contraparte de acuerdo al certificado
			boolean debeReimprimir = false;
			prepararVehiculoServicioParaCertificado(vsDTO.getVs());
			VehiculoServicio vehiculoServicio = new VehiculoServicio();
			vsDTO.getVs().copyTo(vehiculoServicio);
			Recorrido recorrido = recDTO.getRecorrido();
			vehiculoServicio.setRecorridoACertificar(recorrido);
			Certificado certificado = null;
			try {
				certificado = certificadoManager.getCertificadoCurrentInscripcionActual_(vehiculoServicio, recorrido);
			} catch (CertificadoMigradoException e) {
				vehiculoServicio.setTieneCertificadoMigrado(true);
			}
			debeReimprimir = tieneCertificadoDiferente(vehiculoServicio, certificado);

			if (debeReimprimir) {
				evalEvent(vsDTO.getVs().getReglamentacion(), new ReimprimirCertificadoVehiculoEvent(vsDTO.getVs()));
				ret = true;
				vsDTO.getVs().setGenerarCertificado(VehiculoServicio.GENERAR_CERTIFICADO_MODIFICACION);
				vsDTO.getVs().getRecorridosACertificar().add(recorrido);
			}
		}
		return ret;
	}

	private List<Certificado> createCertificadoRecorridos(VehiculoServicio vs, TipoCertificado ts) throws NoTrazadosException, PendingSaveException, GeneralDataAccessException, Exception {
		List<Certificado> certs = new ArrayList<Certificado>();

		// la lista de recorridos depende de si viene de una modificacion o uno
		// nuevo
		List<Recorrido> recos = vs.getRecorridosACertificar();

		for (Recorrido reco : recos) {
			// preparo los datos
			if ((reco.getOrigen().getParadero() != null) && (reco.getOrigen().getParadero().getCodigoComuna() != null)) {
				reco.getOrigen().getParadero().setComuna(ubicacionGeograficaManager.getComunaById(reco.getOrigen().getParadero().getCodigoComuna()));
			}
			if ((reco.getDestino().getParadero() != null) && (reco.getDestino().getParadero().getCodigoComuna() != null)) {
				reco.getDestino().getParadero().setComuna(ubicacionGeograficaManager.getComunaById(reco.getDestino().getParadero().getCodigoComuna()));
			}
			if (!Hibernate.isInitialized(reco.getTrazados())) {
				reco.setTrazados(recorridoManager.getTrazadosByRecorridoId(reco.getId()));
			}
			if ((reco.getTrazados() == null) || (reco.getTrazados().isEmpty())) {
				throw new NoTrazadosException();
			}
			for (Trazado trazado : reco.getTrazados()) {
				if (!Hibernate.isInitialized(trazado.getTramos())) {
					trazado.setTramos(recorridoManager.getTramosByTrazadoId(trazado.getId()));
				}
			}

			VehiculoServicio acert = new VehiculoServicio();
			vs.copyTo(acert);

			acert.setRecorridoACertificar(reco);
			Certificado cert = CertificadoBuilder.createCertificadoVehiculo(acert, ts);

			certs.add(cert);
		}

		return certs;
	}

	public List<Certificado> generarCertificadoModificacion(VehiculoServicio vs) throws Exception {
		List<Certificado> certs = cancelarCertificadoActuales(vs.getId(), new Date());
		TipoCertificado ts = tipoCertificadoManager.getTipoCertificadoByTipoServicio(vs.getServicio().getTipoServicio(), TipoCertificado.MOVIMIENTO_ADD, TipoCertificado.OBJETO_VEHICULO,
				vs.getReglamentacion());
		if (ts != null) {
			if ((vs.getTieneCertificadoProvisorio() != null) && (vs.getTieneCertificadoProvisorio().booleanValue())) {
				if ((vs.getPermisoProvisorioTransient() == null) || (!vs.getPermisoProvisorioTransient().isReglamentado())) {
					vs.setRespuestaFirmador(-600);
					vs.setMensajeFirmador(Resources.getString("servicio.vehiculo.error.noreglamentaprovisorio"));
				}
			}
			if (ts.isCertificadoConRecorrido()) {
				if (vs.getServicio().getRecorridosSkeleton().size() == 0) {
					String msg = Resources.getString("certificado.error.generacionCertificadoSinReorridos");
					vs.setRespuestaFirmador(-100);
					vs.setMensajeFirmador(msg);
				}
				try {
					ArrayList<Recorrido> recos = new ArrayList<Recorrido>();
					for (RecorridoDTO rdto : vs.getServicio().getRecorridosSkeleton()) {
						if (!rdto.isHavingAllDataCert()) {
							rdto.setRecorrido(recorridoManager.getRecorridoById(rdto.getId()));
							rdto.getRecorrido().setTrazados(recorridoManager.getTrazadosConTramoByRecorridoId(rdto.getId()));
						}
						recos.add(rdto.getRecorrido());
					}
					vs.setRecorridosACertificar(recos);
					certs.addAll(createCertificadoRecorridos(vs, ts));
				} catch (NoTrazadosException e) {
					vs.setRespuestaFirmador(-400);
					vs.setMensajeFirmador(Resources.getString("certificado.error.notrazados"));

				} catch (PendingSaveException e) {
					vs.setRespuestaFirmador(-500);
					vs.setMensajeFirmador(Resources.getString("certificado.error.moviemientoPendiente"));
				}

			} else {
				Certificado cert = CertificadoBuilder.createCertificadoVehiculo(vs, ts);
				if (cert == null) {
					vs.setRespuestaFirmador(-700);
					vs.setMensajeFirmador(Resources.getString("certificado.error.generaciondatos"));
					throw new CertificadoException(Resources.getString("certificado.error.generaciondatos"));
				} else {
					certs.add(cert);
				}
			}

		} else {
			vs.setRespuestaFirmador(-200);
			vs.setMensajeFirmador(Resources.getString("certificado.error.tipoCertificadoNoDefinido"));
			throw new CertificadoException(Resources.getString("certificado.error.tipoCertificadoNoDefinido"));
		}
		return certs;
	}

	private List<Certificado> validarReimpresionDeCertificados(Servicio servicio) throws Exception {
		List<Certificado> certs = new ArrayList<Certificado>();
		for (VehiculoServicioDTO vsDTO : servicio.getVehiculosSkeleton()) {
			boolean ret = false;
			VehiculoServicio vs = vehiculoManagerRnt.getVehiculoServicioById(vsDTO.getId());
			if (vsDTO.getEstado().equals(VehiculoServicio.ESTADO_VIGENTE)) {
				if (vsDTO.getIdReglamentacion() == null) {
					throw new VehiculoNoReglamentadoException("Vehiculo sin reglamentacion");
				}
				Reglamentacion reg = reglamentacionManager.getReglamentacionById(vsDTO.getIdReglamentacion());
				TipoCertificado ts = tipoCertificadoManager.getTipoCertificadoByTipoServicio(servicio.getTipoServicio(), TipoCertificado.MOVIMIENTO_ADD, TipoCertificado.OBJETO_VEHICULO, reg);
				if (ts.isCertificadoConRecorrido()) {
					List<RecorridoDTO> recs = new ArrayList<RecorridoDTO>();
					recs.addAll(servicio.getRecorridosSkeleton());
					for (RecorridoDTO recDTO : recs) {
						if (!recDTO.isHavingAllDataCert()) {
							recDTO.setRecorrido(recorridoManager.getRecorridoById(recDTO.getId()));
							recDTO.getRecorrido().setTrazados(recorridoManager.getTrazadosConTramoByRecorridoId(recDTO.getId()));
						}
						ret = ret || validarReimpresionDeCertificadosVehiculosConRecorrido(vsDTO, recDTO);
					}
				} else {
					ret = ret || validarReimpresionDeCertificadosVehiculosSinRecorrido(vsDTO);
				}
			}
			if (ret) {
				certs.addAll(generarCertificadoModificacion(vs));
			}
		}
		return certs;

	}

	public ExecutionResult ejecutarCargaAtributoServicio(List<HandsonRowContent> rows) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException {
		int actualizados = 0;
		Map<Long, Servicio> servicios = new HashMap<Long, Servicio>();
		for (HandsonRowContent row : rows) {
			Long idServicio = (Long) row.getRow().get("idServicio");
			if (!servicios.containsKey(idServicio)) {
				servicios.put(idServicio, servicioManager.getServicioById(idServicio));
			}
			Servicio s = servicios.get(idServicio);
			Long idAtributo = (Long) row.getRow().get("idAtributo");
			List<AtributoInstancia> atributos = s.getAtributosInstancia();
			for (AtributoInstancia atributoInstancia : atributos) {
				if (idAtributo.equals(atributoInstancia.getAtributo().getId())) {
					atributoInstancia.setValor((String) row.getRow().get("valor"));
					atributoInstancia.setDbAction(GenericModelObject.ACTION_UPDATE);
				}
			}
		}
		// para cada servicio
		Iterator<Entry<Long, Servicio>> it = servicios.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<Long, Servicio> ent = (Map.Entry<Long, Servicio>) it.next();
			Servicio s = (Servicio) ent.getValue();
			boolean actualizado = false;
			try {
				List<Certificado> cs = validarReimpresionDeCertificados(s);
				servicioManager.updateServicio(s, new ArrayList<Persona>(0), new ArrayList<VehiculoServicioDTO>(0), cs);
				actualizado = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
			for (HandsonRowContent row : rows) {
				if (row.getRow().get("idServicio").equals(s.getId())) {
					row.getRow().put("updated", actualizado);
					if (actualizado)
						actualizados++;
				}
			}
		}
		ExecutionResult resultado = new ExecutionResult();
		resultado.setCantRowSuccess(actualizados);
		resultado.setCantRowFailed(rows.size() - actualizados);
		resultado.setProccessedData(rows);
		return resultado;
	}

	public ExecutionResult ejecutarCargaAtributoVehiculo(List<HandsonRowContent> rows) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException, VehicleWithoutOwnerException{
		int actualizados = 0;
		Map<Long,Vehiculo> vehiculos = new HashMap<Long, Vehiculo>();
		for(HandsonRowContent row : rows){
			Long idVehiculo = (Long)row.getRow().get("idVehiculo");
			String ppu = (String)row.getRow().get("ppu");
			if(!vehiculos.containsKey(idVehiculo)){
				vehiculos.put(idVehiculo, vehiculoManagerRnt.getVehiculoByPpu(ppu));
			}
			Vehiculo v = vehiculos.get(idVehiculo);
//			try{
				Long idAtributo=(Long)row.getRow().get("idAtributo");
				List<AtributoInstancia> atributos = v.getAtributosInstancia();
				for (AtributoInstancia atributoInstancia : atributos) {
					if(idAtributo.equals(atributoInstancia.getAtributo().getId())){
						atributoInstancia.setValor((String)row.getRow().get("valor"));
						atributoInstancia.setDbAction(GenericModelObject.ACTION_UPDATE);
					}
				}
//			}catch( e){
//				Logger.getLogger(this.getClass()).error(e.getMessage(), e);
//			}
		}
		//para cada vehiculo
		Iterator<Entry<Long, Vehiculo>> it = vehiculos.entrySet().iterator();
        while(it.hasNext()) {
            Map.Entry<Long, Vehiculo> ent = (Map.Entry<Long, Vehiculo>)it.next();
            boolean actualizado=false;

            Vehiculo v = (Vehiculo) ent.getValue();
            List<VehiculoServicio> vsList = vehiculoManagerRnt.getVehiculoServicioByPpu(v.getPpu());
            if(vsList==null || vsList.size()==0){
            	vehiculoManagerRnt.updateAtributosVehiculo(v);
            	actualizado=true;
            } else { 
				actualizado=true;
            	for (VehiculoServicio vehiculoServicio : vsList) {
                    try{
                    	Servicio s = servicioManager.getServicioById(vehiculoServicio.getServicio().getId());
                    	List<Certificado> cs = validarReimpresionDeCertificados(s);
        				servicioManager.updateServicio(vehiculoServicio.getServicio(), new ArrayList<Persona>(0), new ArrayList<VehiculoServicioDTO>(0), cs);
                    }catch(Exception e){
                    	e.printStackTrace();
        				actualizado=false;
        			}   
                 }
			}
            for (HandsonRowContent row : rows) {
            	if(row.getRow().get("idVehiculo").equals(v.getId())){
            		row.getRow().put("updated",actualizado);
            		if(actualizado)
    					actualizados++;
            	}
			}
        }
		ExecutionResult resultado = new ExecutionResult();
		resultado.setCantRowSuccess(actualizados);
		resultado.setCantRowFailed(rows.size()-actualizados);
		resultado.setProccessedData(rows);
		return resultado;
	}


	private Paradero getParadero(String tipo, String nombre, String codigoComuna, String domicilio,String numero, Long id) throws GeneralDataAccessException {
		if(tipo.equals(Paradero.TIPO_TERMINAL)){
			Terminal terminal = terminalManager.getTerminalById(id);
			return terminal;
		} else if(tipo.equals(Paradero.TIPO_PARADERO)){
			Paradero paradero = recorridoManager.getParaderoById(id);
			return paradero;
		} else if(StringUtil.removeDiacriticos(tipo).equals(Paradero.TIPO_UBICACION)){
			Paradero ubicacion = new Paradero();
			ubicacion.setCodigoComuna(codigoComuna);
			ubicacion.setDbAction(GenericModelObject.ACTION_SAVE);
			ubicacion.setDomicilio(domicilio);
			ubicacion.setNombre(nombre);
			ubicacion.setNumeroDomicilio(numero);
			ubicacion.setTipoParadero(Paradero.TIPO_UBICACION);
			return ubicacion;
		}
		return null;
	}

	public ExecutionResult ejecutarCargaRecorridos(List<HandsonRowContent> rows) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException{
		
		int actualizados = 0;
		// se que todas las filas pertenecen al mismo servicio
		Long idServicio = (Long)rows.get(0).getRow().get("idServicio");
		Servicio s = servicioManager.getServicioById(idServicio);
		Map<String,Recorrido> recorridosNuevos = new HashMap<String, Recorrido>();
		//Cargo los recorridos
		for(HandsonRowContent row : rows){
			String key = (String)row.getRow().get("nombreRecorrido")+"%@%"+s.getId() ;
			if(recorridosNuevos.containsKey(key)){
				Recorrido rec = recorridosNuevos.get(key);
				addTrazadoToRecorrido(row, rec);
			}else{
				Recorrido rec = getNewRecorrido(s, row);
				recorridosNuevos.put(key, rec);
				RecorridoDTO recoDTO = new RecorridoDTO();
				recoDTO.setRecorrido(rec);
				((LinkedList<RecorridoDTO>) s.getRecorridosSkeleton()).addFirst(recoDTO);
			}
		}
		boolean actualizado=true;
		try{
			servicioManager.updateServicio(s, new ArrayList<Persona>(0), new ArrayList<VehiculoServicioDTO>(0), new ArrayList<Certificado>(0));
        }catch(Exception e){
        	e.printStackTrace();
        	for (HandsonRowContent row : rows) {
        		row.getRow().put("mensaje",e.getMessage());
	        }
        	actualizado=false;
        }   
        for (HandsonRowContent row : rows) {
       		row.getRow().put("updated",actualizado);
          		if(actualizado)
   					actualizados++;
        }
		ExecutionResult resultado = new ExecutionResult();
		resultado.setCantRowSuccess(actualizados);
		resultado.setCantRowFailed(rows.size()-actualizados);
		resultado.setProccessedData(rows);
		return resultado;
	}

	private Recorrido getNewRecorrido(Servicio s, HandsonRowContent row) throws GeneralDataAccessException {
		Recorrido rec=new Recorrido();
		rec.setDbAction(GenericModelObject.ACTION_SAVE);
		
		Paradero paraderoOrigen=getParadero((String)row.getRow().get("origenTipo"),
											(String)row.getRow().get("origenNombre"),
											(String)row.getRow().get("origenComuna"),
											(String)row.getRow().get("origenDomicilio"),
											(String)row.getRow().get("origenNumero"),
											(Long)row.getRow().get("origenId"));
		ExtremoRecorrido origen = new ExtremoRecorrido();
		origen.setParadero(paraderoOrigen);
		origen.setDbAction(GenericModelObject.ACTION_SAVE);
		rec.setOrigen(origen);
		
		Paradero paraderoDestino=getParadero((String)row.getRow().get("destinoTipo"),
				(String)row.getRow().get("destinoNombre"),
				(String)row.getRow().get("destinoComuna"),
				(String)row.getRow().get("destinoDomicilio"),
				(String)row.getRow().get("destinoNumero"),
				(Long)row.getRow().get("destinoId"));
		ExtremoRecorrido destino = new ExtremoRecorrido();
		destino.setParadero(paraderoDestino);
		destino.setDbAction(GenericModelObject.ACTION_SAVE);
		rec.setDestino(destino);
		
		rec.setEstado(GenericCancellableModelObject.ESTADO_VIGENTE);
		rec.setFechaCambioEstado(new Date());
		rec.setNombre((String)row.getRow().get("nombreRecorrido"));
		rec.setServicio(s);
		rec.setTrazados(new ArrayList<Trazado>());
		
		addTrazadoToRecorrido(row, rec);
		
		rec.setMensajeFirmador(Resources.getString("certificado.error.noenviado"));
		rec.setRespuestaFirmador(-300);

		return rec;
	}

	private void addTrazadoToRecorrido(HandsonRowContent row, Recorrido rec) {
		Trazado tr=new Trazado();
		tr.setNombre((String)row.getRow().get("nombreTrazado"));
		tr.setRecorrido(rec);
		tr.setDbAction(GenericModelObject.ACTION_SAVE);
		tr.setColor("ff0000");
		tr.setUsaMapa(new Boolean(false));
		tr.setTramos(new ArrayList<Tramo>());
		tr.setDiasSemanaList(DiaTrazado.getSemanaClean(tr));		
		tr.setTipo((String)row.getRow().get("tipoTrazado"));
		rec.getTrazados().add(tr);
	}
	
	@Override
	public ExecutionResult ejecutarCargaTrazado(List<HandsonRowContent> rows) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException{
		int actualizados = 0;
		// se que todas las filas pertenecen al mismo servicio
		Long idServicio = (Long)rows.get(0).getRow().get("idServicio");
		Servicio s = servicioManager.getServicioById(idServicio);
		Map<Long,Trazado> trazados = new HashMap<Long, Trazado>();
		//Busco los trazados y les voy cargando las calles
		for(HandsonRowContent row : rows){
			Recorrido rec = obtenerRecorrido(s,(Long)row.getRow().get("idRecorrido"));
			Long idTrazado = (Long)row.getRow().get("idTrazado");
			Trazado trazado = null;
			if(!trazados.containsKey(idTrazado)){//limpio el trazado
				for (Trazado tr : rec.getTrazados()) {
					if (tr.getId().equals(idTrazado)){
						trazado = tr;
					}
				}
				trazado = recorridoManager.getTrazadoById(idTrazado);
				trazado.setUsaMapa(false);
				trazados.put(idTrazado, trazado);
				List<Tramo> tramosEliminados = new ArrayList<Tramo>();
				for (Tramo tramo : trazado.getTramos()) {
					tramo.setDbAction(GenericModelObject.ACTION_DELETE);
					tramosEliminados.add(tramo);
				}
				trazado.getTramos().clear();
				trazado.setTramosEliminados(tramosEliminados);
				trazado.setDbAction(GenericModelObject.ACTION_UPDATE);
			}else{
				trazado=trazados.get(idTrazado);
			}
			//ahora agrego una nueva calle
			trazado.getTramos().add(getNewTramo(row, trazado));
		}
		//Acomodar paraderos origen y destino de los tramos
		Iterator<Entry<Long,Trazado>> it = trazados.entrySet().iterator();
        while(it.hasNext()) {
            Map.Entry ent = (Map.Entry)it.next();
            Trazado trazado = (Trazado)ent.getValue();
//            trazado.getTramos().get(0).setParaderoOrigen(trazado.getRecorrido().getOrigen().getParadero());
//            trazado.getTramos().get(trazado.getTramos().size()-1).setParaderoDestino(trazado.getRecorrido().getDestino().getParadero());
        }
		
		boolean actualizado=true;
		try{
			List<Certificado> certs = getCertificadosRecorridos(s);
			servicioManager.updateServicio(s, new ArrayList<Persona>(0), new ArrayList<VehiculoServicioDTO>(0), certs);
        }catch(Exception e){
        	e.printStackTrace();
        	for (HandsonRowContent row : rows) {
        		row.getRow().put("mensaje",new String(e.getMessage()));
	        }
        	actualizado=false;
        }   
        for (HandsonRowContent row : rows) {
       		row.getRow().put("updated",actualizado);
          		if(actualizado)
   					actualizados++;
        }
		ExecutionResult resultado = new ExecutionResult();
		resultado.setCantRowSuccess(actualizados);
		resultado.setCantRowFailed(rows.size()-actualizados);
		resultado.setProccessedData(rows);
		return resultado;
	}

	private List<Certificado> getCertificadosRecorridos(Servicio s) throws Exception {
		List<Certificado> certs = new ArrayList<Certificado>();
		for (VehiculoServicioDTO vsDTO : s.getVehiculosSkeleton()) {
			VehiculoServicio vs = vehiculoManagerRnt.getVehiculoServicioById(vsDTO.getId());
			if (vsDTO.getEstado().equals(VehiculoServicio.ESTADO_VIGENTE)) {
				if (vsDTO.getIdReglamentacion() == null) {
					throw new VehiculoNoReglamentadoException("Vehiculo sin reglamentacion");
				}
				Reglamentacion reg = reglamentacionManager.getReglamentacionById(vsDTO.getIdReglamentacion());
				TipoCertificado ts = tipoCertificadoManager.getTipoCertificadoByTipoServicio(s.getTipoServicio(), TipoCertificado.MOVIMIENTO_ADD, TipoCertificado.OBJETO_VEHICULO, reg);
				if (ts.isCertificadoConRecorrido()) { //si no es un tipo de certificado con recorrido no hago nada
					certs.addAll(generarCertificadoModificacion(vs));
				} 
			}
		}
		return certs;
	}

	private Recorrido obtenerRecorrido(Servicio s,Long idRecorrido) throws GeneralDataAccessException {
		if (s.getRecorridosSkeleton()==null || s.getRecorridosSkeleton().isEmpty()){
			s.setRecorridosSkeleton(recorridoManager.getRecorridosSkeleton(s, "ESTADO ASC"));
		}
		for (RecorridoDTO recDTO : s.getRecorridosSkeleton()) {
			if(idRecorrido.equals(recDTO.getId())){
				if (!recDTO.isHavingAllData()){
					recDTO.setRecorrido(recorridoManager.getRecorridoById(recDTO.getId()));
					recDTO.getRecorrido().setDbAction(GenericModelObject.ACTION_UPDATE);
				}
				return recDTO.getRecorrido();
			}
		}
		return null;
	}

	private Tramo getNewTramo(HandsonRowContent row, Trazado trazado) {
		Tramo tramo=new Tramo();
		tramo.setCalle((String)row.getRow().get("nombreCalle"));
		tramo.setCodigoComuna((String)row.getRow().get("comuna"));
		tramo.setDbAction(GenericModelObject.ACTION_SAVE);
		tramo.setOrden(trazado.getTramos().size());
		tramo.setSentido((String)row.getRow().get("sentido"));
		tramo.setTrazado(trazado);
		tramo.setTipoTramo(Tramo.TIPO_CALLE);
		return tramo;
	}

	@Override
	public void ejecutarReajusteTarifarioServicio(HandsonRowContent row,String chengeType) throws Exception {
		try {
			row.getRow().put("mensaje", "");
			// obtengo el servicio y verifico si tiene tarifa
			Servicio serv = this.servicioManager.getServicioById((Long) row.getRow().get("id"));
			
			//valido la normativa		
			if(!evaluarEventoCambioTarifa(row,Tarifa.TIPO_MATRIZ,serv.getReglamentacion())){
			} else {			
				//sino tiene tarifa la creo
				if (serv.getTarifa() == null) {
					Tarifa t = new Tarifa();
					t.setTipoTarifa(Tarifa.TIPO_FIJA_VARIABLE);
					t.setDbAction(GenericModelObject.ACTION_SAVE);
					serv.setTarifa(t);
				}
				
				//obtengo los valores ingresados en la tabla
				Float nuevaTasaFija = 0.0f;
				Float nuevaTasaVariable1 = 0.0f;
				Float nuevaTasaVariable2 = 0.0f;
				
				Float paramTasaFija = row.getRow().get("tFija")==null?0:new Float(row.getRow().get("tFija").toString().replace(',','.'));
				Float paramTasaVariable1 = row.getRow().get("tVariable1")==null?0:new Float(row.getRow().get("tVariable1").toString().replace(',','.'));;
				Float paramTasaVariable2 = row.getRow().get("tVariable2")==null?0:new Float(row.getRow().get("tVariable2").toString().replace(',','.'));;
				
				boolean error = false;
				//verifico que tipo de tarifa porcentaje/valor
				if(Constants.PORCENTAJE_CHANGE_METHOD.equals(chengeType)){
					if(serv.getTarifa()!=null && serv.getTarifa().getMontoFijo()!=null){
						nuevaTasaFija = serv.getTarifa().getMontoFijo() * (1 + paramTasaFija/100);
					}else{
						row.getRow().put("mensaje", "No existe tarifa fija para aplicar porcentaje");
						error = true;
					}
					
					if(serv.getTarifa()!=null && serv.getTarifa().getMontoMinimo()!= null){
						nuevaTasaVariable1 = serv.getTarifa().getMontoMinimo() * (1 + paramTasaVariable1/100);
					}else{
						row.getRow().put("mensaje", "No existe tarifa Variable para aplicar porcentaje");
						error = true;
					}
					
					
					if(row.getRow().get("tVariable2")!=null && !row.getRow().get("tVariable2").toString().isEmpty()){
						if(serv.getTarifa()!=null && serv.getTarifa().getMontoMaximo()!= null){
							nuevaTasaVariable2 = serv.getTarifa().getMontoMaximo() * (1 + paramTasaVariable2/100);
						}else{
							row.getRow().put("mensaje", "No existe tarifa Variable para aplicar porcentaje");
							error = true;
						}
					}
					
				}else if(Constants.VALOR_CHANGE_METHOD.equals(chengeType)){
					nuevaTasaFija =  paramTasaFija;
					nuevaTasaVariable1 = paramTasaVariable1;
					nuevaTasaVariable2 = paramTasaVariable2;
				}
				
				if(!error){
					//actualizo el tipo por si tiene sin registro
					serv.getTarifa().setTipoTarifa(Tarifa.TIPO_FIJA_VARIABLE);
					serv.getTarifa().setMontoFijo(nuevaTasaFija);
					serv.getTarifa().setMontoMinimo(nuevaTasaVariable1);
					serv.getTarifa().setMontoMaximo(nuevaTasaVariable2);
					serv.getTarifa().setDbAction(GenericModelObject.ACTION_UPDATE);
					// actualizo el servicio junto con los certificados
					servicioManager.updateServicio(serv, null, null, null);
					// si se actualizo en db cambio el registro que se va a visualizar
					row.getRow().put("tFijaActual", serv.getTarifa().getMontoFijo());
					row.getRow().put("tVariable1Actual", serv.getTarifa().getMontoMinimo());
					row.getRow().put("tVariable2Actual", serv.getTarifa().getMontoMaximo());
					row.getRow().put("mensaje", "");
					row.getRow().put("updated", true);
				}
			}
		} catch (Exception e) {
			row.getRow().put("mensaje", e.getMessage());
			row.getRow().put("updated", false);
			throw e;
		}
		
		
	}

	public ExecutionResult ejecutarCargaCalles(HandsonRowContent row) throws GeneralDataAccessException{
		int actualizado = 1;	
		String codigoComuna = (String)row.getRow().get("comuna");
		String calle = (String)row.getRow().get("calle");
		DatoDiccionario datoDiccionario = new DatoDiccionario();
		datoDiccionario.setCalle1(calle);
		datoDiccionario.setCodigoComuna(codigoComuna);
        try{
        	generalDataManager.saveDatoDiccionario(datoDiccionario);
			row.getRow().put("mensaje", "");
			row.getRow().put("updated", true);
			
        }catch(Exception e){
        	e.printStackTrace();
    		actualizado=0;
			row.getRow().put("mensaje",e.getMessage());
			row.getRow().put("updated", false);
    	}
		ExecutionResult resultado = new ExecutionResult();
		resultado.setCantRowSuccess(actualizado);
		resultado.setCantRowFailed(1-actualizado);
		List<HandsonRowContent> rows = new ArrayList<HandsonRowContent>();
		rows.add(row);
		resultado.setProccessedData(rows);
		return resultado;

	}

	@Override
	public ExecutionResult ejecutarReajusteTarifarioMatrizServicio(List<HandsonRowContent> rows, String chengeType) throws GeneralDataAccessException, DuplicatedIdException, CertificadoException {
		// todos los rows perteneces al mismo servicio del primero obtengo
		// el id y busco el servicio
		Long idServicio = (Long) rows.get(0).getRow().get("id");
		Servicio s = servicioManager.getServicioById(idServicio);
		boolean actualizado=true;
		//valido la normativa		
		if(!evaluarEventoCambioTarifa(rows,Tarifa.TIPO_MATRIZ,s.getReglamentacion())){
			actualizado=false;
		} else {
			for (HandsonRowContent row : rows) {
				String accion = row.getRow().get("accionLabel").toString();
				// si la accion es save es que es un nuevo tramo
				Long idTramo = (Long)row.getRow().get("idTramo");
				String nombreTramo = row.getRow().get("tramo").toString();
				if ("save".equals(accion)) {
					TramoTarifario tramo = null;				
					if (s.getTarifa() == null) {
						Tarifa t = new Tarifa();
						t.setDbAction(GenericModelObject.ACTION_SAVE);
						s.setTarifa(t);
					} else {
						if(idTramo!=null){
							tramo = getTramoFromServicio(idTramo, s);
						}else if(tramo==null && nombreTramo!=null){
							tramo = getTramoFromServicio(nombreTramo, s);
						}
					}
					// si todavia no lo agregue al servicio lo creo y lo agrego
					// sino solo le agrego el nuevo item
					if (tramo == null) {
						tramo = new TramoTarifario();
						tramo.setDbAction(GenericModelObject.ACTION_SAVE);
						tramo.setNombre(nombreTramo);
						HashMap<String, Object> criteria = new HashMap<String, Object>();
						criteria.put("etiqueta", row.getRow().get("publico").toString());
						List<PublicoObjetivo> publicosObjetivo = publicoObjetivoDAO.findBySimpleCriteria(criteria);
						tramo.setPublicoObjetivo(publicosObjetivo.get(0));
						tramo.setTipoIngreso(row.getRow().get("tipoIngreso").toString());
					}else{
						tramo.setDbAction(GenericModelObject.ACTION_UPDATE);
					}
					tramo.setTarifa(s.getTarifa());
					ItemTramoTarifario itt = new ItemTramoTarifario();
					itt.setDbAction(GenericModelObject.ACTION_SAVE);
					itt.setHoraInicial(row.getRow().get("horaDesde").toString());
					itt.setHoraFinal(row.getRow().get("horaHasta").toString());
					itt.setMonto(getNuevoMontoValor(chengeType,itt.getMonto(),row.getRow().get("valor1")));				
					itt.setMontoSecundario(getNuevoMontoValor(chengeType,itt.getMontoSecundario(),row.getRow().get("valor2")));
					row.getRow().put("valor1actual",itt.getMonto());
					row.getRow().put("valor2actual",itt.getMontoSecundario());
					itt.setTramoTarifario(tramo);
					if(tramo.getItemsTramoTarifario()==null)tramo.setItemsTramoTarifario(new ArrayList<ItemTramoTarifario>());
					tramo.getItemsTramoTarifario().add(itt);
					s.getTarifa().getTramosTarifarios().add(tramo);
	
				} else if ("update".equals(accion)) {
					// sino si es update es que actualizo un tramo que existe en
					// el servicio
					TramoTarifario tramo = getTramoFromServicio(idTramo, s);
					tramo.setDbAction(GenericModelObject.ACTION_UPDATE);
					if(tramo!=null){
						String horaInicial = row.getRow().get("horaDesde").toString();
						String horaFinal = row.getRow().get("horaHasta").toString();
						if(!tramo.getPublicoObjetivo().getEtiqueta().equals(row.getRow().get("publico").toString())){
							HashMap<String, Object> criteria = new HashMap<String, Object>();
							criteria.put("etiqueta", row.getRow().get("publico").toString());
							List<PublicoObjetivo> publicosObjetivo = publicoObjetivoDAO.findBySimpleCriteria(criteria);
							tramo.setPublicoObjetivo(publicosObjetivo.get(0));
						}						
						tramo.setTipoIngreso(row.getRow().get("tipoIngreso").toString());
						ItemTramoTarifario itt = getItemFromTramo(tramo, horaInicial, horaFinal);
						if(itt==null){
							itt = new ItemTramoTarifario();
							itt.setHoraInicial(horaInicial);
							itt.setHoraFinal(horaFinal);
							itt.setDbAction(GenericModelObject.ACTION_SAVE);
							itt.setTramoTarifario(tramo);
							tramo.getItemsTramoTarifario().add(itt);
						}else{
							itt.setDbAction(GenericModelObject.ACTION_UPDATE);
						}
						itt.setMonto(getNuevoMontoValor(chengeType,itt.getMonto(),row.getRow().get("valor1")));				
						itt.setMontoSecundario(getNuevoMontoValor(chengeType,itt.getMontoSecundario(),row.getRow().get("valor2")));	
						row.getRow().put("valor1actual",itt.getMonto());
						row.getRow().put("valor2actual",itt.getMontoSecundario());
					
					}
				}
	
			}
			
			try{
				s.getTarifa().setTipoTarifa(Tarifa.TIPO_MATRIZ);
				servicioManager.updateServicio(s, null, null, null);
	        }catch(Exception e){
	        	Logger.getLogger(this.getClass()).error(e.getMessage(), e);
	        	actualizado=false;
	        } 
			
			//actualizo el estado actualizacion de todos los registros
			for (HandsonRowContent row : rows) {
				row.getRow().put("updated", actualizado);
			}
		}
		ExecutionResult resultado = new ExecutionResult();
		if(actualizado){
			resultado.setCantRowSuccess(rows.size());
			resultado.setCantRowFailed(0);
		}else{
			resultado.setCantRowSuccess(0);
			resultado.setCantRowFailed(rows.size());
		}
		resultado.setProccessedData(rows);
		return resultado;
	}
	
	private Float getNuevoMontoValor(String chengeType, Object valorActual, Object porcentajeValor){
		Float vActualFloat = null;
		Float pvFloat = null;
		if(valorActual!=null) vActualFloat = (Float) valorActual;
		if(porcentajeValor!=null) pvFloat = (Float) porcentajeValor;
		
		if(vActualFloat!=null && pvFloat!=null && Constants.PORCENTAJE_CHANGE_METHOD.equals(chengeType)){
			Float montoNuevo = vActualFloat *(1 + pvFloat/100);
			return montoNuevo;					
		}else if(Constants.VALOR_CHANGE_METHOD.equals(chengeType)){
			return pvFloat;
		}
		return null;
	}
	
	private TramoTarifario getTramoFromServicio(Long idTramo, Servicio servicio){
		Tarifa t = servicio.getTarifa();
		List<TramoTarifario> tramos = t.getTramosTarifarios();
		if (tramos != null && !tramos.isEmpty()) {
			for (TramoTarifario tr : tramos) {
				if (tr.getId().equals(idTramo)) {
					return tr;
				}
			}
		}
		return null;
	}
	
	private TramoTarifario getTramoFromServicio(String nombreTramo, Servicio servicio){
		Tarifa t = servicio.getTarifa();
		List<TramoTarifario> tramos = t.getTramosTarifarios();
		if (tramos != null && !tramos.isEmpty()) {
			for (TramoTarifario tr : tramos) {
				if (tr.getNombre().equals(nombreTramo)) {
					return tr;
				}
			}
		}
		return null;
	}
	
	private ItemTramoTarifario getItemFromTramo(TramoTarifario tramo, String horaInicial, String horaFinal){
		List<ItemTramoTarifario> items = tramo.getItemsTramoTarifario();
		if(items!=null && !items.isEmpty()){
			for(ItemTramoTarifario item : items){
				if(item.getHoraInicial()!=null && item.getHoraInicial().equals(horaInicial)
						&& item.getHoraFinal()!=null && item.getHoraFinal().equals(horaFinal)){
					return item;
				}
			}
		}
		return null;
	}
	
	private Sector getSectorByNombre(Recorrido rec,String nombre) {
		for (Sector sector : rec.getSectores()) {
			if(sector.getNombre().equals(nombre))
				return sector;
		}
		return null;
	}

	private SectorTramoTarifario getSectorTramoTarifario(Recorrido rec, Sector sec, int extremo) {
		int count = 0;
		for (SectorTramoTarifario stt : rec.getTarifa().getSectoresTramoTarifario()) {
			if(extremo==stt.getExtremo() && sec.getNombre().equals(stt.getSector().getNombre())){
				return stt;
			}
			if(extremo==stt.getExtremo()){
				count++;
			}
		}
		SectorTramoTarifario sectTT = new SectorTramoTarifario();
		sectTT.setDbAction(GenericModelObject.ACTION_SAVE);
		sectTT.setExtremo(extremo);
		sectTT.setOrden(count+1);
		sectTT.setSector(sec);
		sectTT.setTarifa(rec.getTarifa());
		rec.getTarifa().getSectoresTramoTarifario().add(sectTT);
		return sectTT;
	}
	
	private ItemMatrizTarifaria getItemMatrizTarifaria(TramoTarifario tramoTarifario, SectorTramoTarifario sectTTInicio, SectorTramoTarifario sectTTFin) {
		for (ItemMatrizTarifaria imt : tramoTarifario.getItemsMatrizTarifaria()) {
			if(imt.getSectorInicial().getNombre().equals(sectTTInicio.getSector().getNombre()) && imt.getSectorFinal().getNombre().equals(sectTTFin.getSector().getNombre())){
				imt.setDbAction(GenericModelObject.ACTION_UPDATE);
				return imt;
			}
		}
		ItemMatrizTarifaria imt = new ItemMatrizTarifaria();
		imt.setDbAction(GenericModelObject.ACTION_SAVE);
		imt.setSectorInicial(sectTTInicio.getSector());
		imt.setSectorFinal(sectTTFin.getSector());
		imt.setTramoTarifario(tramoTarifario);
		tramoTarifario.getItemsMatrizTarifaria().add(imt);
		return imt;
	}
	
	public ExecutionResult ejecutarReajusteTarifarioMatrizRecorrido(List<HandsonRowContent> rows, String changeType) throws GeneralDataAccessException, JAXBException, EventEvalException{
		int actualizados = 0;
		// se que todas las filas pertenecen al mismo servicio
		List<Sector> sectoresNuevos=new ArrayList<Sector>();
		Long idServicio = (Long)rows.get(0).getRow().get("idServicio");
		Servicio s = servicioManager.getServicioById(idServicio);
		boolean actualizado=true;

		//valido la normativa		
		if(!evaluarEventoCambioTarifa(rows,Tarifa.TIPO_MATRIZ,s.getReglamentacion())){
			actualizado=false;
		} else {

			Map<String,TramoTarifario> tramoTarifarioMap = new HashMap<String, TramoTarifario>();
			//Busco los trazados y les voy cargando las calles
			for(HandsonRowContent row : rows){
				Recorrido rec = obtenerRecorrido(s,(Long)row.getRow().get("idRecorrido"));
				//Le agrego tarifa si no tiene
				if (rec.getTarifa()==null){
					rec.setTarifa(new Tarifa());
					rec.getTarifa().setTipoTarifa(Tarifa.TIPO_MATRIZ);
					rec.getTarifa().setDbAction(GenericModelObject.ACTION_SAVE);
					rec.getTarifa().setTramosTarifarios(new ArrayList<TramoTarifario>());
					tarifaManager.saveTarifa(rec.getTarifa());
				}else if(rec.getTarifa().getTipoTarifa().equals(Tarifa.TIPO_SIN_REGISTRO)){
					rec.getTarifa().setDbAction(GenericModelObject.ACTION_UPDATE);
					rec.getTarifa().setTipoTarifa(Tarifa.TIPO_MATRIZ);
				}
				
				String nombreTramoTarifario = (String)row.getRow().get("tramoTarifario");
			//	Long idTramoTarifario = (Long)row.getRow().get("idTramoTarifario");
				TramoTarifario tramoTarifario = null;
				if(tramoTarifarioMap.containsKey(nombreTramoTarifario)){
					tramoTarifario = tramoTarifarioMap.get(nombreTramoTarifario);
				}else {
					for (TramoTarifario tr : rec.getTarifa().getTramosTarifarios()) {
						if (tr.getNombre().equals(nombreTramoTarifario)){
							tramoTarifario = tr;
						}
					}
					if(tramoTarifario!=null){
						tramoTarifario.setDbAction(GenericModelObject.ACTION_UPDATE);
						tramoTarifario.setHoraDesde((String)row.getRow().get("horaDesde"));
						tramoTarifario.setHoraHasta((String)row.getRow().get("horaHasta"));
						tramoTarifario.setPublicoObjetivo(tarifaManager.getPublicoObjetivoByLabel((String)row.getRow().get("publico")));
						tramoTarifario.setTipoIngreso((String)row.getRow().get("tipoIngreso"));
						tramoTarifarioMap.put(nombreTramoTarifario, tramoTarifario);
					}else{//el id es null, no existe el tramo tarifario
						tramoTarifario = new TramoTarifario();
						tramoTarifario.setDbAction(GenericModelObject.ACTION_SAVE);
						tramoTarifario.setNombre(nombreTramoTarifario);
						tramoTarifario.setHoraDesde((String)row.getRow().get("horaDesde"));
						tramoTarifario.setHoraHasta((String)row.getRow().get("horaHasta"));
						tramoTarifario.setPublicoObjetivo(tarifaManager.getPublicoObjetivoByLabel((String)row.getRow().get("publico")));
						tramoTarifario.setTipoIngreso((String)row.getRow().get("tipoIngreso"));
						tramoTarifario.setTarifa(rec.getTarifa());
						tramoTarifario.setItemsTramoTarifario(new ArrayList<ItemTramoTarifario>());
						tramoTarifario.setItemsMatrizTarifaria(new ArrayList<ItemMatrizTarifaria>());
						rec.getTarifa().getTramosTarifarios().add(tramoTarifario);
						tramoTarifarioMap.put(nombreTramoTarifario, tramoTarifario);
					}
				}
				//primero agrego los sectores al recorrido
				Sector secInicio = getSectorByNombre(rec,(String)row.getRow().get("tramoInicio"));
				if(secInicio==null){
					secInicio = new Sector();
					secInicio.setDbAction(GenericModelObject.ACTION_NOACTION);
					secInicio.setNombre((String)row.getRow().get("tramoInicio"));
					secInicio.setRecorrido(rec);
					rec.getSectores().add(secInicio);
					sectoresNuevos.add(secInicio);
				}
				//de no estar lo agrego a la matriz base
				SectorTramoTarifario sectTTInicio = getSectorTramoTarifario(rec,secInicio,SectorTramoTarifario.EXTREMO_INICIO);
	
				Sector secFinal= getSectorByNombre(rec,(String)row.getRow().get("tramoFin"));
				if(secFinal==null){
					secFinal = new Sector();
					secFinal.setDbAction(GenericModelObject.ACTION_NOACTION);
					secFinal.setNombre((String)row.getRow().get("tramoFin"));
					secFinal.setRecorrido(rec);
					rec.getSectores().add(secFinal);
					sectoresNuevos.add(secFinal);
				}
				SectorTramoTarifario sectTTFin = getSectorTramoTarifario(rec,secFinal,SectorTramoTarifario.EXTREMO_FIN);
				ItemMatrizTarifaria imt = getItemMatrizTarifaria(tramoTarifario,sectTTInicio, sectTTFin);
				imt.setMonto(getNuevoMontoValor(changeType,imt.getMonto(),row.getRow().get("monto")));				
				imt.setMontoSecundario(getNuevoMontoValor(changeType,imt.getMonto(),row.getRow().get("montoSecundario")));
			}
			
			try{
				//primero pruebo guardar los sectores
				//for (Sector sec:sectoresNuevos)
				recorridoManager.saveSectores(sectoresNuevos);
				
				servicioManager.updateServicio(s, new ArrayList<Persona>(0), new ArrayList<VehiculoServicioDTO>(0), new ArrayList<Certificado>(0));
	        }catch(Exception e){
	        	e.printStackTrace();
	        	for (HandsonRowContent row : rows) {
	        		row.getRow().put("mensaje",e.getMessage());
		        }
	        	actualizado=false;
	        }   
	        for (HandsonRowContent row : rows) {
	       		row.getRow().put("updated",actualizado);
	          		if(actualizado)
	   					actualizados++;
	        }
		}
		ExecutionResult resultado = new ExecutionResult();
		resultado.setCantRowSuccess(actualizados);
		resultado.setCantRowFailed(rows.size()-actualizados);
		resultado.setProccessedData(rows);
		return resultado;

	}
	
	/**
	 * Evalua el evento de cambio de tarifa dentro de la reglamentacion del servicio
	 * y alctualiza la lista de rows afectados
	 * @param rows
	 * @param tipoTarifa
	 * @param reglamentacion
	 * @return
	 */
	private boolean evaluarEventoCambioTarifa(List<HandsonRowContent> rows, String tipoTarifa, Reglamentacion reglamentacion) {
		try {
			Tarifa tar = new Tarifa();
			tar.setTipoTarifa(tipoTarifa);
			EventResult eventRes = evalEvent(reglamentacion, new CambioTarifaEvent(tar));

			if (!eventRes.getResult()) {
				for (HandsonRowContent row : rows) {
					row.getRow().put("mensaje", eventRes.getEventResultItems().get(0).getMessage());
					row.getRow().put("updated", false);
				}
			}
			return eventRes.getResult();
		} catch (JAXBException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (GeneralDataAccessException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		} catch (EventEvalException e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
		}
		return false;
	}
	
	private boolean evaluarEventoCambioTarifa(HandsonRowContent row, String tipoMatriz, Reglamentacion reglamentacion) {
		List<HandsonRowContent> rows = new ArrayList<HandsonRowContent>();
		rows.add(row);
		return evaluarEventoCambioTarifa(rows,tipoMatriz,reglamentacion);
	}
}
