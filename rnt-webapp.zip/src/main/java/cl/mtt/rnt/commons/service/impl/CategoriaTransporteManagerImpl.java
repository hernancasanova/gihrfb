package cl.mtt.rnt.commons.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.service.CategoriaTransporteManager;
import cl.mtt.rnt.commons.util.StringUtil;

@Service("categoriaTransporteManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class CategoriaTransporteManagerImpl implements CategoriaTransporteManager, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3009723571720509839L;
	@Autowired()
	@Qualifier("CategoriaTransporteDAO")
	private GenericDAO<CategoriaTransporte> categoriaTransporteDAO;

	public GenericDAO<CategoriaTransporte> getCategoriaTransporteDAO() {
		return categoriaTransporteDAO;
	}

	public void setCategoriaTransporteDAO(GenericDAO<CategoriaTransporte> categoriaTransporteDAO) {
		this.categoriaTransporteDAO = categoriaTransporteDAO;
	}

	public List<CategoriaTransporte> getAllCategoriasTrasporte() throws GeneralDataAccessException {
		List<String> sortingColumns = new ArrayList<String>();
		sortingColumns.add("nombre");
		return categoriaTransporteDAO.findBySimpleCriteria(new HashMap<String, Object>(), sortingColumns);
	}

	@Override
	public CategoriaTransporte getCategoriaTransporteById(Long idCategoriaTransporte) throws GeneralDataAccessException {
		return categoriaTransporteDAO.getByPrimaryKey(idCategoriaTransporte);
	}

	@Override
	public void saveCategoriaTransporte(CategoriaTransporte categoriaTransporte) throws GeneralDataAccessException, DuplicatedIdException {
		// creo el descriptor
		String desc = StringUtil.makeDescriptor(categoriaTransporte.getNombre());
		if (!existeCategoriaTransporte(desc, null)) {
			categoriaTransporte.setDescriptor(desc);
			this.categoriaTransporteDAO.save(categoriaTransporte);
		}
	}

	@Override
	public CategoriaTransporte getCategoriaTransporteByDescriptor(String descriptor) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put(GenericDAO.CRITERION_PREFIX_EQUALS_IGNORE_CASE+".descriptor", descriptor);
		List<CategoriaTransporte> consulta = categoriaTransporteDAO.findBySimpleCriteria(criteria);
		if (consulta != null && consulta.size() > 0)
			return consulta.get(0);

		return null;
	}

	/**
	 * Verifica si el nombre está disponible. Para esto chequea los
	 * descriptores.
	 * 
	 * @param name
	 * @return
	 */
	private boolean existeCategoriaTransporte(String name, Long id) throws DuplicatedIdException, GeneralDataAccessException {
		CategoriaTransporte cat = getCategoriaTransporteByDescriptor(name);
		if (cat != null && (id == null || cat.getId().longValue() != id.longValue()))
			throw new DuplicatedIdException(DuplicatedIdException.DUPLICATE_CATEGORIA_TRANSPORTE);
		return false;
	}

	@Override
	public void updateCategoriaTransporte(CategoriaTransporte categoriaTransporte) throws GeneralDataAccessException, DuplicatedIdException {
		// creo el descriptor
		String desc = StringUtil.makeDescriptor(categoriaTransporte.getNombre());
		if (!existeCategoriaTransporte(desc, categoriaTransporte.getId())) {
			CategoriaTransporte categoriaTransporteDB = this.getCategoriaTransporteById(categoriaTransporte.getId());
			categoriaTransporteDB.setNombre(categoriaTransporte.getNombre());
			categoriaTransporteDB.setNombreImagen(categoriaTransporte.getNombreImagen());
			categoriaTransporteDB.setDescriptor(desc);
			this.getCategoriaTransporteDAO().update(categoriaTransporteDB);
		}
	}

	@Override
	public void removeCategoriaTransporte(CategoriaTransporte cateogoriaTransporte) throws GeneralDataAccessException, RemoveNotAllowedException {
		try {
			this.categoriaTransporteDAO.remove(cateogoriaTransporte);
		} catch (IntegrityViolationException ex) {
			throw new RemoveNotAllowedException(RemoveNotAllowedException.REMOVE_CATEGORIA_TRANSPORTE_ERROR);
		}

	}

}
