package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import cl.mtt.rnt.commons.exception.CertificadoException;
import cl.mtt.rnt.commons.exception.CertificadoMigradoException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.InvalidSchemaFirmador;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.CertificadoValorVariable;
import cl.mtt.rnt.commons.model.core.EstadoCertificadoFirma;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.XmlCertificado;
import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.service.CertificadoManager;
import cl.mtt.rnt.commons.service.RecorridoManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.util.filter.CertificadoFilter;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;
import cl.mtt.rnt.commons.ws.exception.WSException;
import cl.mtt.rnt.encargado.dto.RecorridoDTO;
import cl.mtt.rnt.encargado.dto.VehiculoServicioDTO;

@Service("certificadoManager")
@Lazy(value = false)
public class CertificadoManagerDelegate implements CertificadoManager {

    
    @Autowired()
    @Qualifier("certificadoManagerTrans")
    private CertificadoManager manager;

	
	
	

	@Autowired
    @Qualifier("vehiculoManagerRnt")
    private VehiculoManagerRnt vehiculoManagerRnt;

    @Autowired
    @Qualifier("recorridoManager")
    private RecorridoManager recorridoManager;

    @Override
    public void saveCertificado(Certificado cert) throws GeneralDataAccessException {
        manager.saveCertificado(cert);
        
    }

    @Override
    public void updateCertificado(Certificado cert) throws GeneralDataAccessException {
        manager.updateCertificado(cert);
        
    }

    @Override
    public void cancelarCertificadoManual(Servicio servicio, Certificado cert, String observacionesCancelacion) throws GeneralDataAccessException {
        manager.cancelarCertificadoManual(servicio, cert, observacionesCancelacion);
    }

    @Override
    public List<Certificado> getCertificadosFiltrados(CertificadoFilter filtro, CategoriaTransporte categoriaTransporte, User user, List<Long> ids) throws GeneralDataAccessException {
        return manager.getCertificadosFiltrados(filtro, categoriaTransporte, user, ids);
    }

    @Override
    public List<Certificado> getCertificadosFiltrados(CertificadoFilter filtro) throws GeneralDataAccessException {
        return manager.getCertificadosFiltrados(filtro);
    }

    @Override
    public List<Long> getIdsCertificadosByFilter(CertificadoFilter filtro, CategoriaTransporte ct, User user) throws GeneralDataAccessException {
        return manager.getIdsCertificadosByFilter(filtro, ct, user);
    }

    @Override
    public List<Certificado> getCertificadoActualByVehiculoServicio(Long vehiculoServicioId) throws GeneralDataAccessException {
        return manager.getCertificadoActualByVehiculoServicio(vehiculoServicioId);
    }

    @Override
    public boolean handlerCertificados(List<Certificado> colaCertificados, Servicio servicio) throws GeneralDataAccessException, CertificadoException {
        return manager.handlerCertificados(colaCertificados, servicio);
    }

    @Override
    public boolean handlerCertificadosInternal(List<Certificado> colaCertificados, Servicio servicio) throws GeneralDataAccessException, CertificadoException {
        return manager.handlerCertificadosInternal(colaCertificados, servicio);
    }

    @Override
    public CertificadoValorVariable getValorVariable(String descriptor, Region region) throws GeneralDataAccessException {
        return manager.getValorVariable(descriptor, region);
    }

    @Override
    public EstadoCertificadoFirma cosultarEstadoCertificado(Certificado cert) throws GeneralDataAccessException {
        return manager.cosultarEstadoCertificado(cert);
    }

    @Override
    public Certificado getCertificadoCurrentInscripcionActual_(VehiculoServicio vehiculoServicio) throws GeneralDataAccessException,
            CertificadoMigradoException {
        return manager.getCertificadoCurrentInscripcionActual_(vehiculoServicio);
    }

    @Override
    public Map<Long, Certificado> getCertificadosCurrentInscripcionActual_(Servicio servicio) throws GeneralDataAccessException, CertificadoMigradoException {
        return manager.getCertificadosCurrentInscripcionActual_(servicio);
    }

    @Override
    public Certificado getCertificadoCurrentInscripcionActual_(VehiculoServicio vehiculoServicio, Recorrido acertificar) throws GeneralDataAccessException,
            CertificadoMigradoException {
       return manager.getCertificadoCurrentInscripcionActual_(vehiculoServicio,acertificar);
    }
    
    
    
    /**
     * @param cert
     * @throws GeneralDataAccessException
     */
    private void updateEstadoCertificado(Certificado cert)
            throws GeneralDataAccessException {
        Date hoy = new Date();
        if (cert.getFechaCambioEstado() == null) {
            if (cert.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE))
                cert.setFechaCambioEstado(cert.getFechaDesde());
            else
                cert.setFechaCambioEstado(cert.getFechaHasta());
        }
        if (cert.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
                if ((cert.getFechaHasta() != null) && (ValidacionHelper.esFechaMayor(hoy, cert.getFechaHasta()))) {
                    cert.setEstado(GenericCancellableModelObject.ESTADO_VENCIDO);
                    this.updateCertificado(cert);
                }
        } else {
        }
    }
    
    
    
    /**
     * @param certificados
     * @throws HibernateException
     * @throws GeneralDataAccessException
     */
    private void initializeCertificados(List<Certificado> certificados,List<Long> idsVs,Servicio servicio) throws HibernateException, GeneralDataAccessException {
        
        for (Certificado cert : certificados) {
            cert.setVehiculo(getVehiculoSkeleton(servicio.getVehiculosSkeleton(),cert.getIdVehiculoServicio()));
            cert.setRecorrido(getRecorridoSkeleton(servicio.getRecorridosSkeleton(),cert.getIdRecorrido(),servicio));
            // Mejoras 201409 Nro: 33
            updateEstadoCertificado(cert);
            // Mejoras 201409 Nro: 33
        }
    }
    
    

    private Recorrido getRecorridoSkeleton(LinkedList<RecorridoDTO> recorridosSkeleton, Long idRecorrido,Servicio serv) throws GeneralDataAccessException {
        if (idRecorrido!=null) {
            for (RecorridoDTO rdto : recorridosSkeleton) {
                if (!rdto.isHavingAllDataCert()) {
                    rdto.setRecorrido(recorridoManager.getRecorridoById(rdto.getId()));
                    rdto.getRecorrido().setTrazados(recorridoManager.getTrazadosConTramoByRecorridoId(rdto.getId()));
                    rdto.getRecorrido().setServicio(serv);
                }
                if (rdto.getId().equals(idRecorrido)) {
                    return rdto.getRecorrido();
                }
            }
        }
        return null;
    }

    private VehiculoServicio getVehiculoSkeleton(LinkedList<VehiculoServicioDTO> vehiculosSkeleton, Long idVehiculoServicio) throws GeneralDataAccessException {
        if (idVehiculoServicio!=null) {
            for (VehiculoServicioDTO vehiculoServicioDTO : vehiculosSkeleton) {
                if (vehiculoServicioDTO.getId()!= null && vehiculoServicioDTO.getId().equals(idVehiculoServicio)) {
                    VehiculoServicio vs = vehiculoServicioDTO.getVs();
                    if(vs==null){
                    	vehiculoServicioDTO.setVs(vehiculoManagerRnt.getVehiculoServicioById(vehiculoServicioDTO.getId()));
                    	return vehiculoServicioDTO.getVs();
                    }
					return vs;
                }
            }
        }
        return null;
    }

    @Override
    public List<Certificado> getCertificadosVehiculoByServicio(Servicio serv, int first, int rows, CertificadoFilter filter, List<String> orderFields, List<Long> idsVS) throws GeneralDataAccessException {
        List<Certificado> certificados = manager.getCertificadosVehiculoByServicio(serv, first, rows, filter, orderFields, idsVS);
        if (certificados == null)
            return new ArrayList<Certificado>();
        initializeCertificados(certificados,idsVS,serv);
        return certificados;
    }

    @Override
    public long getCertificadosVehiculoByServicioCount(Servicio serv, CertificadoFilter filter, List<Long> idsVS) throws GeneralDataAccessException {
        return manager.getCertificadosVehiculoByServicioCount(serv, filter, idsVS);
    }

    @Override
    public List<Certificado> getCertificadosRecorridoByServicio(Servicio serv, int first, int rows, CertificadoFilter filter, List<String> orderFields,List<Long> idsVS) throws GeneralDataAccessException {
        List<Certificado> certificados = manager.getCertificadosRecorridoByServicio(serv, first, rows, filter, orderFields, idsVS);
        if (idsVS == null) {
            ((CertificadoManagerImpl)manager).initializeCertificados(certificados);
        }
        if (certificados == null)
            return new ArrayList<Certificado>();
        initializeCertificados(certificados,idsVS,serv);
        return certificados;
    }

    @Override
    public long getCertificadosRecorridoByServicioCount(Servicio servicio, CertificadoFilter filter, List<Long> idsVS) throws GeneralDataAccessException {
        return manager.getCertificadosRecorridoByServicioCount(servicio, filter, idsVS);
    }

    @Override
    public XmlCertificado getXmlByCertificado(Long idCertificado) throws GeneralDataAccessException {
        return manager.getXmlByCertificado(idCertificado);
    }

    @Override
    public String firmarCertificado(Certificado certificado) throws WSException, GeneralDataAccessException {
        return manager.firmarCertificado(certificado);
    }

    @Override
    public void saveXMLCertificado(Certificado certificado, String xml) throws GeneralDataAccessException {
       manager.saveXMLCertificado(certificado, xml);
    }

    @Override
    public Certificado getCertificadoById(Long idCertSeleccionado) throws GeneralDataAccessException {
        return manager.getCertificadoById(idCertSeleccionado);
    }

    @Override
    public byte[] getPreview(String tipoDocumento, String materia, byte[] xmlBytes) throws WSException, InvalidSchemaFirmador {
        return manager.getPreview(tipoDocumento, materia, xmlBytes);
    }

    @Override
    public long getCountCertificadosSinFirmar(Long idTipoCertificado) throws GeneralDataAccessException {
        return manager.getCountCertificadosSinFirmar(idTipoCertificado);
    }

    @Override
    public long getCountCertificadosSinFirmarServicio(Long idServicio) throws GeneralDataAccessException {
        return manager.getCountCertificadosSinFirmarServicio(idServicio);
    }

	public Certificado getCountCertificadosSinFirmarVehiculo(Long idVehiculo)throws GeneralDataAccessException{
		return manager.getCountCertificadosSinFirmarVehiculo(idVehiculo);
	}

    @Override
    public boolean existProcesandoCert(Servicio servicio) {
        return manager.existProcesandoCert(servicio);
    }

    @Override
    public int getTamanioLote() {
        return manager.getTamanioLote();
    }

    @Override
    public void marcarServicioBatch(Servicio servicio) {
        manager.marcarServicioBatch(servicio);
        
    }
	
    
   

	
}
