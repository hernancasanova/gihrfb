package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.CertificadoDAO;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.CertificadoException;
import cl.mtt.rnt.commons.exception.CertificadoMigradoException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.exception.InvalidSchemaFirmador;
import cl.mtt.rnt.commons.model.core.CategoriaTransporte;
import cl.mtt.rnt.commons.model.core.Certificado;
import cl.mtt.rnt.commons.model.core.CertificadoValorVariable;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.EstadoCertificadoFirma;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.XmlCertificado;
import cl.mtt.rnt.commons.model.core.recorrido.Recorrido;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.service.CertificadoManager;
import cl.mtt.rnt.commons.service.NotificacionService;
import cl.mtt.rnt.commons.service.RecorridoManager;
import cl.mtt.rnt.commons.service.TipoCertificadoManager;
import cl.mtt.rnt.commons.service.UsuarioManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.service.batch.CertificadosControlledGenerator;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.CampoDecorator;
import cl.mtt.rnt.commons.util.CertificadoXMLUtil;
import cl.mtt.rnt.commons.util.Resources;
import cl.mtt.rnt.commons.util.StringUtil;
import cl.mtt.rnt.commons.util.Utils;
import cl.mtt.rnt.commons.util.filter.CertificadoFilter;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;
import cl.mtt.rnt.commons.ws.certificadospreview.EstadoDocumento;
import cl.mtt.rnt.commons.ws.client.CertificadoPreviewService;
import cl.mtt.rnt.commons.ws.client.CertificadoWsService;
import cl.mtt.rnt.commons.ws.exception.WSException;
import cl.mtt.rnt.encargado.dto.VehiculoServicioDTO;

@Service("certificadoManagerTrans")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class CertificadoManagerImpl implements CertificadoManager {

	@Autowired()
	@Qualifier("CertificadoDAO")
	private CertificadoDAO certificadoDAO;
	
	@Autowired
    @Qualifier("notificacionManager")
    private NotificacionService notificacionService;
	
	@Autowired
    @Qualifier("usuarioManager")
    private UsuarioManager usuarioManager;

	@Autowired
    @Qualifier("ubicacionGeograficaManager")
    private UbicacionGeograficaManager ubicacionGeograficaManager;

    private CertificadosControlledGenerator certificadosControlledGenerator;
    
	public CertificadoManagerImpl() {
        super();
        certificadosControlledGenerator = new CertificadosControlledGenerator(this);
    }

    @Autowired()
	@Qualifier("certificadoPreviewService")
	private CertificadoPreviewService certificadoPreviewService;

	@Autowired
	@Qualifier("vehiculoManagerRnt")
	private VehiculoManagerRnt vehiculoManagerRnt;

	@Autowired
	@Qualifier("recorridoManager")
	private RecorridoManager recorridoManager;

	@Autowired
	@Qualifier("CertificadoValorDAO")
	private GenericDAO<CertificadoValorVariable> certificadoValorDAO;


	@Autowired
	@Qualifier("XmlCertificadoDAO")
	private GenericDAO<XmlCertificado> xmlCertificadoDAO;
	
	@Autowired()
	@Qualifier("certificadoWsService")
	private CertificadoWsService certificadoWsService;

	@Autowired
	@Qualifier("tipoCertificadoManager")
	private TipoCertificadoManager tipoCertificadoManager;


    private int tamanioMinimoLote = 0;

	public void saveCertificado(Certificado cert) throws GeneralDataAccessException {
		cert.setChecksum(StringUtil.getMD5(cert.getXml().getXml()));
		if(cert.getRecorrido()==null && cert.getVehiculo()==null){
			throw new GeneralDataAccessException("Se está intentando guardar un certificado sin datos");
		}
		certificadoDAO.save(cert);
	}

	public void updateCertificado(Certificado cert) throws GeneralDataAccessException {
		if(cert.getXml()!=null){
			cert.setChecksum(StringUtil.getMD5(cert.getXml().getXml()));
		}
		if(GenericCancellableModelObject.ESTADO_CANCELADO == cert.getEstado()){
			removeXMLFromCertificado(cert);
		}
		if(cert.getRecorrido()==null && cert.getVehiculo()==null){
			throw new GeneralDataAccessException("Se está intentando modificar un certificado sin datos");
		}		
		certificadoDAO.update(cert);
	}
	
	public void cancelarCertificadoManual(Servicio servicio,Certificado cert,String observacionesCancelacion) throws GeneralDataAccessException{
		cert.setEstado(GenericCancellableModelObject.ESTADO_CANCELADO);
		cert.setEstadoFirma(Certificado.ESTADO_CANCELADO);
		cert.setDbAction(GenericModelObject.ACTION_UPDATE);
		cert.setObservacionCancelacion(observacionesCancelacion);

		removeXMLFromCertificado(cert);
		if(cert.getRecorrido()==null && cert.getVehiculo()==null){
			throw new GeneralDataAccessException("Se está intentando cancelar un certificado sin datos");
		}

		certificadoDAO.update(cert);
		updateMessageOfCertificadoObject(servicio,cert, -100, Resources.getString("certificado.error.canceladoManual"));
	}

	/**
	 * @param cert
	 * @throws GeneralDataAccessException
	 * @throws IntegrityViolationException
	 */
	private void removeXMLFromCertificado(Certificado cert)
			throws GeneralDataAccessException, IntegrityViolationException {
		XmlCertificado xml = cert.getXml();
		if(xml!=null){
			xml.setCertificado(null);
			cert.setXml(null);
			xmlCertificadoDAO.remove(xml);
		}
	}

	public List<Certificado> getCertificadosFiltrados(CertificadoFilter filtro, CategoriaTransporte ct, User user, List<Long> ids) throws GeneralDataAccessException {
		List<Certificado> certificados = certificadoDAO.getCertificadosByFilter(filtro,ct,user,ids);
		if (certificados == null)
			return new ArrayList<Certificado>();
		initializeCertificados(certificados);
		return certificados;
	}

	public List<Certificado> getCertificadosFiltrados(CertificadoFilter filtro) throws GeneralDataAccessException{
		List<Certificado> certificados = certificadoDAO.getCertificadosByFilter(filtro);
		if (certificados == null)
			return new ArrayList<Certificado>();
		initializeCertificados(certificados);
		return certificados;
	
	}

	
	
	
	/**
	 * @param certificados
	 * @throws HibernateException
	 * @throws GeneralDataAccessException
	 */
	void initializeCertificados(List<Certificado> certificados)	throws HibernateException, GeneralDataAccessException {
		for (Certificado cert : certificados) {
			Hibernate.initialize(cert.getRecorrido());
			Hibernate.initialize(cert.getVehiculo());
			if (cert.getVehiculo() != null) {
				Hibernate.initialize(cert.getVehiculo().getVehiculo());
				Hibernate.initialize(cert.getVehiculo().getServicio());
				Hibernate.initialize(cert.getVehiculo().getServicio().getTipoServicio());
				Region reg = ubicacionGeograficaManager.getRegionById(cert.getVehiculo().getServicio().getCodigoRegion());
				cert.getVehiculo().getServicio().setRegion(reg);
			}
			if (cert.getRecorrido() != null) {
				Hibernate.initialize(cert.getRecorrido());
				Hibernate.initialize(cert.getRecorrido().getServicio());
				Hibernate.initialize(cert.getRecorrido().getServicio().getTipoServicio());
				Region reg = ubicacionGeograficaManager.getRegionById(cert.getRecorrido().getServicio().getCodigoRegion());
				cert.getRecorrido().getServicio().setRegion(reg);
			}
			updateEstadoCertificado(cert);
		}
	}

	@Override
	public List<Certificado> getCertificadoActualByVehiculoServicio(Long vehiculoServicioId) throws GeneralDataAccessException {
		List<Certificado> certs = certificadoDAO.getCurrentsCertificadosByVS(vehiculoServicioId);
		Date hoy = new Date();
		List<Certificado> actuales = new ArrayList<Certificado>();
		for (Certificado certificado : certs) {
			if (ValidacionHelper.esFechaMenorIgual(certificado.getFechaDesde(), hoy) && ValidacionHelper.esFechaMenorIgual(hoy, certificado.getFechaHasta())) {
				actuales.add(certificado);
			}
		}
		return actuales;
	}

	
	@Override
    public boolean handlerCertificados(List<Certificado> colaCertificados, Servicio servicio) throws GeneralDataAccessException, CertificadoException {
	    if (colaCertificados!=null) {
	        if (colaCertificados.size() > getTamanioLote()) {
	            this.certificadosControlledGenerator.addCertificadosToSave(colaCertificados, servicio,servicio.getUserModified().getNombreUsuario());
	        }
	        else {
	            boolean handlerCertificadosInternal = handlerCertificadosInternal(colaCertificados, servicio);
				return handlerCertificadosInternal;
	        }
	    }
	    
	    return true;
	}
	
	public int getTamanioLote() {
	    if (this.tamanioMinimoLote != 0) {
	        return this.tamanioMinimoLote;
	    }
        try {
            String propertyTamanio = Utils.getProperty("certificados.batch.tamaniominimolote");
            this.tamanioMinimoLote = Integer.parseInt(propertyTamanio);
        }
        catch (Exception e) {
           Logger.getLogger(CertificadoManagerImpl.class).error(e.getLocalizedMessage(), e); 
           this.tamanioMinimoLote = 1000;
          
        }
        return tamanioMinimoLote;
       
    }

    @Override
	public boolean handlerCertificadosInternal(List<Certificado> colaCertificados, Servicio servicio) throws GeneralDataAccessException, CertificadoException {
		CertificadoXMLUtil xmlUtil = new CertificadoXMLUtil();
		boolean retorno = true;		
		for (Certificado certificado : colaCertificados) {
			XmlCertificado xmlCertificado = null;
			
			if (certificado.getDbAction() == GenericModelObject.ACTION_SAVE ){

				String mensaje = "";
				certificado.setCodigoRegion(servicio.getCodigoRegion());
				
				if(TipoCertificado.OBJETO_VEHICULO.equals(certificado.getNombreObjetoAsociado()) &&
						(certificado.getVehiculo().isTieneCertificadoMigrado()) && servicio.getIncluirCertificadosMigrados() == 0){
					Logger.getLogger(this.getClass()).info("Certificado excluido");
				}else if (TipoCertificado.OBJETO_VEHICULO.equals(certificado.getNombreObjetoAsociado()) && certificado.getTipoCertificado().isCertificadoConRecorrido()
						&& servicio.getRecorridos().size() == 0) {
					mensaje = Resources.getString("certificado.error.generacionCertificadoSinReorridos");
					VehiculoServicio vs = (VehiculoServicio) certificado.getObjetoAsociado();
					vs.setRespuestaFirmador(-100);
					vs.setMensajeFirmador(mensaje);
					vehiculoManagerRnt.updateVehiculoServicioEstadoFirma(servicio,vs);
					retorno = false;
				} else {
				//	Integer ident = null;
					mensaje = Resources.getString("certificado.error.aunNoFirmado");

					try {
						if (certificado.getModifiers() == null) {
							certificado.setModifiers(new HashMap<String, CampoDecorator>());
						}

						// El handler de vehiculos deja bags en las listas
						if (TipoCertificado.OBJETO_VEHICULO.equals(certificado.getNombreObjetoAsociado())) {
							VehiculoServicio vs = (VehiculoServicio) certificado.getObjetoAsociado();
							if (vs.getId()==null){
								for (VehiculoServicioDTO vss : servicio.getVehiculosSkeleton()) {
									if (vss.getPpu().equals(vs.getVehiculo().getPpu()))
										vs.setId(vss.getId());
								}
							}
							
							ajustarObjetoVehiculoHibernizado(vs);
						}
						if (!Hibernate.isInitialized(certificado.getTipoCertificado().getSeccion().getSeccionDefinition())) {
							certificado.getTipoCertificado().getSeccion()
									.setSeccionDefinition(tipoCertificadoManager.getCertificadoSeccionDefinitionBySeccion(certificado.getTipoCertificado().getSeccion()));
						}
						String xml = xmlUtil.getCertificadoXMLasString(certificado.getTipoCertificado().getSeccion(), certificado.getObjetoAsociado(), this, certificado.getModifiers());
//						certificado.setCertificadoDatos(xmlUtil.getCertificadoDatosList());
						if(xml!=null){
							xmlCertificado = new XmlCertificado();
							xmlCertificado.setCertificado(certificado);
							xmlCertificado.setXml(xml);			
							certificado.setXml(xmlCertificado);
						}
					} catch (ParserConfigurationException e) {
						Logger.getLogger(this.getClass()).error(e.getMessage(), e);
					} catch (Exception e) {
						Logger.getLogger(this.getClass()).error(e.getMessage(), e);
					}

						this.saveCertificado(certificado);
						if(xmlCertificado!=null){
							xmlCertificadoDAO.save(xmlCertificado);
							certificado.setXml(xmlCertificado);
						}
					
					updateMessageOfCertificadoObject(servicio,certificado,0, mensaje);

				}
			} else if (certificado.getDbAction() == GenericModelObject.ACTION_UPDATE) {
				updateCertificado(certificado);
			} else if (certificado.getDbAction() == GenericModelObject.ACTION_DELETE) {
				certificadoDAO.remove(certificado);
			}
		}

		this.certificadosControlledGenerator.removeToBatch(servicio);
		return retorno;

	}

	/**
	 * @param certificado
	 * @param mensaje
	 * @throws GeneralDataAccessException
	 */
	private void updateMessageOfCertificadoObject(Servicio servicio,Certificado certificado, Integer respuestaFirmador,String mensaje) throws GeneralDataAccessException {
		if (TipoCertificado.OBJETO_VEHICULO.equals(certificado.getNombreObjetoAsociado())) {
			VehiculoServicio vs = (VehiculoServicio) certificado.getObjetoAsociado();
			vs.setRespuestaFirmador(respuestaFirmador);
			vs.setMensajeFirmador(mensaje);
			vehiculoManagerRnt.updateVehiculoServicioEstadoFirma(servicio,vs);
		} else if (TipoCertificado.OBJETO_RECORRIDO.equals(certificado.getNombreObjetoAsociado())) {
			Recorrido r = (Recorrido) certificado.getObjetoAsociado();
			r.setRespuestaFirmador(respuestaFirmador);
			r.setMensajeFirmador(mensaje);
			recorridoManager.updateRecorridoEstadoFirma(servicio,r);
		}
	}

	private void ajustarObjetoVehiculoHibernizado(VehiculoServicio vs) throws GeneralDataAccessException {

		if (!Hibernate.isInitialized(vs.getConductoresVehiculo())) {
			List<ConductorVehiculo> conductoresVehiculo2 = vehiculoManagerRnt.getConductoresVehiculo(vs);
			if (conductoresVehiculo2 != null) {
				vs.setConductoresVehiculo(conductoresVehiculo2);
			} else {
				vs.setConductoresVehiculo(new ArrayList<ConductorVehiculo>());
			}

		}

	}

	@Override
	public CertificadoValorVariable getValorVariable(String descriptor, Region region) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("descriptor", descriptor);
		criteria.put("codigoRegion", region.getCodigo());
		List<CertificadoValorVariable> consulta = certificadoValorDAO.findBySimpleCriteria(criteria);
		if (consulta != null && consulta.size() > 0)
			return consulta.get(0);

		return null;
	}

	private void cancelarCertificadoActuales(VehiculoServicio vs, Certificado currCert) throws GeneralDataAccessException {
	List<Certificado> certs = getCertificadoActualByVehiculoServicio(vs.getId());
	if (certs != null) {
		for (Certificado cert : certs) {
			if(cert.getVehiculo().getId().equals(vs.getId()) && (currCert.getRecorrido() == null || (cert.getRecorrido()!=null && cert.getRecorrido().getId().equals(currCert.getRecorrido().getId())))){
				if(!currCert.getId().equals(cert.getId())){
					if ((vs.getTieneCertificadoProvisorio() != null) && (vs.getTieneCertificadoProvisorio().booleanValue())
							&& (vs.getPermisoProvisorioTransient()!=null)) {
						if (vs.getPermisoProvisorioTransient().isProrroga()) {
							cert.setFechaHasta(vs.getPermisoProvisorioTransient().getFechaHastaUltimoCertificado());
						} else {
							cert.setFechaHasta(vs.getFechaCambioEstado());
						}
					} else {
						cert.setFechaHasta(vs.getFechaCambioEstado());
					}
					cert.setDbAction(GenericModelObject.ACTION_UPDATE);
					cert.setFechaCambioEstado(new Date());
					cert.setEstado(GenericCancellableModelObject.ESTADO_CANCELADO);
					updateCertificado(cert);
				}
			}
		}
	}
}
	public EstadoCertificadoFirma cosultarEstadoCertificado(Certificado cert) throws GeneralDataAccessException {
		EstadoCertificadoFirma estadoCert = new EstadoCertificadoFirma();
		try {
			EstadoDocumento estado = certificadoWsService.consultarCertificado(cert);
			if (estado.getEstado() == null || "".equals(estado.getEstado())) {
				estadoCert.setFirmado(false);
				estadoCert.setEstado(EstadoCertificadoFirma.ERROR_CONSULTA);
			} else {
				if (Certificado.ESTADO_SIN_FIRMAR_WS.equalsIgnoreCase(estado.getEstado())) {
					estadoCert.setFirmado(false);
					estadoCert.setEstado(Certificado.ESTADO_SIN_FIRMAR);
				} else {
					if (estado.getEstado().toLowerCase().startsWith("rechazado")) {
						if (estado.getEstado().contains(":")) {
						//	String[] split = estado.getEstado().split(":"); comentado luego de cambios en MTT
							estadoCert.setFirmado(false);
							estadoCert.setEstado(Certificado.ESTADO_FIRMA_RECHAZADO);
							estadoCert.setObservacionRechazo(estado.getMotivoRechazo());
						} else {
							estadoCert.setFirmado(false);
							estadoCert.setEstado(Certificado.ESTADO_FIRMA_RECHAZADO);
							estadoCert.setObservacionRechazo(estado.getMotivoRechazo());
						}

					} else {
						if(TipoCertificado.OBJETO_VEHICULO.equalsIgnoreCase(cert.getNombreObjetoAsociado())  && cert.getVehiculo()!=null){						
							cancelarCertificadoActuales(cert.getVehiculo(),cert);
						}
						estadoCert.setLinkDocumento(estado.getLinkDocumento());
						// if no null
						estadoCert.setFolio(estado.getFolio().toString());
						estadoCert.setFechaFirma(estado.getFechaFirma());
						estadoCert.setFirmado(true);
						if(estado.getEstado().equalsIgnoreCase(Certificado.ESTADO_FIRMA_WS_FIRMADO)){
							estadoCert.setEstado(Certificado.ESTADO_FIRMA_FIRMADO);
						}
						else{
							estadoCert.setEstado(Certificado.ESTADO_FIRMA_FIRMADO_MANUAL);
						}
					}
				}

			}
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getMessage(), e);
			estadoCert.setFirmado(false);
			estadoCert.setEstado(EstadoCertificadoFirma.ERROR_CONSULTA);
		}
		return estadoCert;
	}

	@Override
	public Certificado getCertificadoCurrentInscripcionActual_(VehiculoServicio vehiculoServicio) throws GeneralDataAccessException,CertificadoMigradoException{
		if(vehiculoServicio==null){
			return null;
		}
		Certificado currentCertificado = certificadoDAO.getCurrentCertificado(vehiculoServicio.getId());
		// retorna el tipo de certificado con las secciones inicializadas para
		// recorrido
		if (currentCertificado != null) {
			currentCertificado.setTipoCertificado(tipoCertificadoManager.getTipoCertificadoById(currentCertificado.getTipoCertificado().getId()));
			if (ValidacionHelper.esFechaEntreRango(new Date(), currentCertificado.getFechaDesde(), currentCertificado.getFechaHasta())) {
				return currentCertificado;
			}
		}
		return null;
	}

	public Map<Long,Certificado> getCertificadosCurrentInscripcionActual_(Servicio servicio) throws GeneralDataAccessException,CertificadoMigradoException{
		Map<Long,Certificado> ret=new HashMap<Long, Certificado>();
		List<Certificado> currentCertificados = certificadoDAO.getCurrentCertificados(servicio.getId());
		if ((currentCertificados != null) && (!currentCertificados.isEmpty())) {
			for (Certificado certificado : currentCertificados) {
				if (currentCertificados != null) {
					certificado.setTipoCertificado(tipoCertificadoManager.getTipoCertificadoById(certificado.getTipoCertificado().getId()));
					if (ValidacionHelper.esFechaEntreRango(new Date(), certificado.getFechaDesde(), certificado.getFechaHasta())) {
						ret.put(certificado.getVehiculo().getId(), certificado);
					}
				}
			}
		} 
	
		
		return ret;		
	}

	@Override
	public Certificado getCertificadoCurrentInscripcionActual_(VehiculoServicio vehiculoServicio, Recorrido acertificar) throws GeneralDataAccessException,CertificadoMigradoException {
		Certificado currentCertificado = certificadoDAO.getCurrentCertificado(vehiculoServicio.getId(), acertificar.getId());
		// retorna el tipo de certificado con las secciones inicializadas para
		// recorrido
		if (currentCertificado != null) {
			currentCertificado.setTipoCertificado(tipoCertificadoManager.getTipoCertificadoById(currentCertificado.getTipoCertificado().getId()));
			if (ValidacionHelper.esFechaEntreRango(new Date(), currentCertificado.getFechaDesde(), currentCertificado.getFechaHasta())) {
				return currentCertificado;
			}
		}
		return null;
	}
	
	
	

	@Override
	public List<Certificado> getCertificadosVehiculoByServicio(Servicio serv, int first, int rows,CertificadoFilter filter, List<String> orderFields,List<Long> idsVS) throws GeneralDataAccessException {
	    List<Certificado> certificadosByServicio = certificadoDAO.getCertificadosByServicio(serv.getId(), TipoCertificado.OBJETO_VEHICULO,first,rows,filter,orderFields,idsVS);
	    if (certificadosByServicio == null)
            return new ArrayList<Certificado>();
        //initializeCertificados(certificadosByServicio,serv);
	    return certificadosByServicio;
	}

	private void initializeCertificados(List<Certificado> certificados, Servicio serv) {
	    for (Certificado cert : certificados) {
            Hibernate.initialize(cert.getRecorrido());
            Hibernate.initialize(cert.getVehiculo());
            Hibernate.initialize(cert.getVehiculo().getVehiculo());
            if (serv == null) {
                if (cert.getVehiculo() != null) {
                   Hibernate.initialize(cert.getVehiculo().getServicio());
                   Hibernate.initialize(cert.getVehiculo().getServicio().getTipoServicio());
                }
                if (cert.getRecorrido() != null) {
                   Hibernate.initialize(cert.getRecorrido().getServicio());
                   Hibernate.initialize(cert.getRecorrido().getServicio().getTipoServicio());
                }
            }
	    }
        
    }

    public long getCertificadosVehiculoByServicioCount(Servicio servicio,CertificadoFilter filter,List<Long> idsVS) throws GeneralDataAccessException{
		return certificadoDAO.getCertificadosByServicioCount(servicio.getId(), TipoCertificado.OBJETO_VEHICULO,filter,idsVS);

	}
	
	public long getCertificadosRecorridoByServicioCount(Servicio servicio,CertificadoFilter filter,List<Long> idsVS)throws GeneralDataAccessException{
		return certificadoDAO.getCertificadosByServicioCount(servicio.getId(), TipoCertificado.OBJETO_RECORRIDO,filter,idsVS);
	}
	
	public List<Certificado> getCertificadosRecorridoByServicio(Servicio serv, int first, int rows,CertificadoFilter filter, List<String> orderFields,List<Long> idsVS) throws GeneralDataAccessException {
	    return certificadoDAO.getCertificadosByServicio(serv.getId(), TipoCertificado.OBJETO_RECORRIDO, first,  rows, filter, orderFields,idsVS);
	}
	// Mejoras 201409 Nro: 33
	/**
	 * @param cert
	 * @throws GeneralDataAccessException
	 */
	private void updateEstadoCertificado(Certificado cert)
			throws GeneralDataAccessException {
		Date hoy = new Date();
		if (cert.getFechaCambioEstado() == null) {
			if (cert.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE))
				cert.setFechaCambioEstado(cert.getFechaDesde());
			else
				cert.setFechaCambioEstado(cert.getFechaHasta());
		}
		if (cert.getEstado().equals(GenericCancellableModelObject.ESTADO_VIGENTE)) {
				if ((cert.getFechaHasta() != null) && (ValidacionHelper.esFechaMayor(hoy, cert.getFechaHasta()))) {
					cert.setEstado(GenericCancellableModelObject.ESTADO_VENCIDO);
					this.updateCertificado(cert);
				}
		} else {
		}
	}
	@Override
	public List<Long> getIdsCertificadosByFilter(CertificadoFilter filtro, CategoriaTransporte ct, User user) throws GeneralDataAccessException {
		return this.certificadoDAO.getIdsCertificadosByFilter(filtro, ct, user);
	}
	

	public XmlCertificado getXmlByCertificado(Long idCertificado) throws GeneralDataAccessException{
		Map<String,Object> criteria=new HashMap<String, Object>();
		criteria.put("certificado.id", idCertificado);
		List<XmlCertificado> ret = xmlCertificadoDAO.findBySimpleHQL(criteria); 
		if (ret!=null && ret.size()>0)
			return ret.get(0);
		return null;
	}

	@Override
	public String firmarCertificado(Certificado certificado) throws WSException, GeneralDataAccessException{
		String mensaje = "";
		Integer ident = certificadoWsService.firmarCertificado(certificado);
		if (ident == null || ident < 0) {
			if (ident == null) {
				ident = -100;
				mensaje = Resources.getString("certificado.error.generacionCertificado");
			} else {
				mensaje = Resources.getString("certificado.error." + ident);
			}
		} else {
			certificado.setIdentificadorWS(ident);
			certificado.setEstado(GenericCancellableModelObject.ESTADO_VIGENTE);
			certificado.setEstadoFirma(Certificado.ESTADO_ENVIADO_A_FIRMAR);
			
			mensaje = Resources.getString("certificado.ok.generacionCertificado");
			updateCertificado(certificado);
			if (TipoCertificado.OBJETO_VEHICULO.equals(certificado.getNombreObjetoAsociado())) {
				VehiculoServicio vs = (VehiculoServicio) certificado.getObjetoAsociado();
				vs.setRespuestaFirmador(0);
				vs.setMensajeFirmador(mensaje);
				vehiculoManagerRnt.updateVehiculoServicioEstadoFirma(vs.getServicio(),vs);
			} else if (TipoCertificado.OBJETO_RECORRIDO.equals(certificado.getNombreObjetoAsociado())) {
				Recorrido r = (Recorrido) certificado.getObjetoAsociado();
				r.setRespuestaFirmador(0);
				r.setMensajeFirmador(mensaje);
				recorridoManager.updateRecorridoEstadoFirma(r.getServicio(),r);
			}
		}
		return mensaje;
	}

	@Override
	public void saveXMLCertificado(Certificado certificado, String xml) throws GeneralDataAccessException {
		if(xml!=null){
			XmlCertificado xmlCertificado = new XmlCertificado();
			xmlCertificado.setCertificado(certificado);
			xmlCertificado.setXml(xml);
			if(xmlCertificado!=null){
				xmlCertificadoDAO.save(xmlCertificado);
				certificado.setXml(xmlCertificado);
			}

		}
		
	}

	@Override
	public Certificado getCertificadoById(Long idCertSeleccionado) throws GeneralDataAccessException {		
		return certificadoDAO.getByPrimaryKey(idCertSeleccionado);
	}

	@Override
	public byte[] getPreview(String tipoDocumento, String materia,	byte[] xmlBytes) throws WSException, InvalidSchemaFirmador {
		return this.certificadoPreviewService.getPreview(tipoDocumento,materia, xmlBytes);
	}

	public long getCountCertificadosSinFirmar(Long idTipoCertificado)throws GeneralDataAccessException{
		return certificadoDAO.getCountCertificadosByTipoCertificadoAndEstado(Certificado.ESTADO_SIN_FIRMAR, true,idTipoCertificado);
	}

	public long getCountCertificadosSinFirmarServicio(Long idServicio)throws GeneralDataAccessException{
		return certificadoDAO.getCountCertificadosByServicioAndEstado(Certificado.ESTADO_SIN_FIRMAR, idServicio);
	}

	public Certificado getCountCertificadosSinFirmarVehiculo(Long idVehiculo)throws GeneralDataAccessException{
		return certificadoDAO.getCountCertificadosByVehiculoAndEstado(Certificado.ESTADO_SIN_FIRMAR, idVehiculo);
	}

    @Override
    public boolean existProcesandoCert(Servicio servicio) {
       return certificadosControlledGenerator.estaProcesandoCert(servicio);
    }

    @Override
    public void marcarServicioBatch(Servicio servicio) {
        certificadosControlledGenerator.marcarServicioToBatch(servicio);
        
    }
    
	/**
	 * @return el valor de notificacionService
	 */
	public NotificacionService getNotificacionService() {
		return notificacionService;
	}

	/**
	 * @return el valor de usuarioManager
	 */
	public UsuarioManager getUsuarioManager() {
		return usuarioManager;
	}

    

	
}


