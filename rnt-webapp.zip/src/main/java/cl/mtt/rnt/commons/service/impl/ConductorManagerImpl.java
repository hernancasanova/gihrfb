package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.admin.util.ELFacesResolver;
import cl.mtt.rnt.commons.bean.CurrentSessionBean;
import cl.mtt.rnt.commons.dao.ConductorServicioDAO;
import cl.mtt.rnt.commons.dao.ConductorVehiculoDAO;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.ServicioDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Conductor;
import cl.mtt.rnt.commons.model.core.ConductorServicio;
import cl.mtt.rnt.commons.model.core.ConductorVehiculo;
import cl.mtt.rnt.commons.model.core.GenericAuditCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericCancellableModelObject;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Persona;
import cl.mtt.rnt.commons.model.core.Poliza;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.autorizacion.AutorizacionMovimiento;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.service.AutorizacionManager;
import cl.mtt.rnt.commons.service.ConductorManager;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;

@Service("conductorManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class ConductorManagerImpl implements ConductorManager {

	@Autowired()
	@Qualifier("ConductorDAO")
	private GenericDAO<Conductor> conductorDAO;

	@Autowired()
	@Qualifier("PolizaDAO")
	private GenericDAO<Poliza> polizaDAO;

	@Autowired()
	@Qualifier("ConductorServicioDAO")
	private ConductorServicioDAO conductorServicioDAO;

	@Autowired()
	@Qualifier("ubicacionGeograficaManager")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@Autowired()
	@Qualifier("ConductorVehiculoDAO")
	private ConductorVehiculoDAO conductorVehiculoDAO;

//	@Autowired()
//	@Qualifier("PersonaDAO")
//	private GenericDAO<Persona> personaDAO;

	@Autowired()
	@Qualifier("ServicioDAO")
	private ServicioDAO servicioDAO;

	@Autowired
	@Qualifier("autorizacionManager")
	private AutorizacionManager autorizacionManager;
	
	@Autowired
	@Qualifier("generalDataManager")
	private GeneralDataManager generalDataManager;
	
	@Override
	public List<ConductorServicio> getConductoresServicioByServicio(Long id) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("servicio.id", id);
		List<ConductorServicio> conductores = conductorServicioDAO.findBySimpleCriteria(criteria);
		if ((conductores != null) && (!conductores.isEmpty())) {
			for (ConductorServicio conductor: conductores) {
				Hibernate.initialize(conductor.getConductoresVehiculo()); 
				Hibernate.initialize(conductor.getConductor().getPersona().getInhabilidades());
				Hibernate.initialize(conductor.getPolizas());
			}
			return conductores;
		} else {
			return new ArrayList<ConductorServicio>();
		}
	}

	public GenericAuditCancellableModelObject getConductorCancelable(String rut,Long idServicio) throws GeneralDataAccessException{
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("servicio.id", idServicio);
		criteria.put("conductor.persona.rut",rut);
		List<ConductorServicio> conductoresServ = conductorServicioDAO.findBySimpleCriteria(criteria);
		if ((conductoresServ != null) && (!conductoresServ.isEmpty())) {
			for (ConductorServicio conductor: conductoresServ) {
				Hibernate.initialize(conductor.getConductoresVehiculo());
			}
			Map<String, Object> criteriaVeh = new HashMap<String, Object>();
			criteriaVeh.put("conductorServicio.id", conductoresServ.get(0).getId());
//			criteriaVeh.put("conductorServicio.conductor.persona.rut",rut);
			List<ConductorVehiculo> conductoresVeh = conductorVehiculoDAO.findBySimpleCriteria(criteriaVeh);
			if ((conductoresVeh != null) && (!conductoresVeh.isEmpty())) {
				return conductoresVeh.get(0);
			}			
			return conductoresServ.get(0);
		} else {
			return null;
		}
	}

	public List<ConductorVehiculo> getConductoresVehiculoByVehiculoServicio(Long idVehiculoServicio, String tipoConductor) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("vehiculoServicio.id", idVehiculoServicio);
		if (tipoConductor != null)
			criteria.put("conductorServicio.conductor.tipoConductor", tipoConductor);
		List<ConductorVehiculo> conductores = conductorVehiculoDAO.findBySimpleCriteria(criteria);
		if ((conductores != null) && (!conductores.isEmpty())) {
			for (ConductorVehiculo conductorVehiculo : conductores) {
				Hibernate.initialize(conductorVehiculo.getConductorServicio().getConductor().getPersona().getInhabilidades());
				Hibernate.initialize(conductorVehiculo.getConductorServicio().getPolizas());
			}
			return conductores;
		} else {
			return new ArrayList<ConductorVehiculo>();
		}
	}

	public List<ConductorVehiculo> getConductoresVehiculoByConductoresServicio(Long idConductorServicio) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("conductorServicio.id", idConductorServicio);
		List<ConductorVehiculo> conductores = conductorVehiculoDAO.findBySimpleCriteria(criteria);
		if ((conductores != null) && (!conductores.isEmpty())) {
			for (ConductorVehiculo conductorVehiculo : conductores) {
				Hibernate.initialize(conductorVehiculo.getConductorServicio().getConductor().getPersona().getInhabilidades());
				Hibernate.initialize(conductorVehiculo.getConductorServicio().getPolizas());
			}
			return conductores;
		} else {
			return new ArrayList<ConductorVehiculo>();
		}
	}

	@Override
	public void saveConductor(Conductor conductor) throws GeneralDataAccessException {
		conductorDAO.save(conductor);
	}

//	@Override
//	public void saveConductor(Conductor conductor, Servicio servicio) throws GeneralDataAccessException {
//		// TODO
//
//	}

	@Override
	public List<Conductor> getConductoresByRut(String rut, String tipoConductor) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("persona.rut", rut);
		criteria.put("tipoConductor", tipoConductor);
		List<Conductor> conductores = conductorDAO.findBySimpleCriteria(criteria);
		if ((conductores != null) && (!conductores.isEmpty())) {
			Map<String, Comuna> comMap = ubicacionGeograficaManager.getAllComunasAsMap();
			for (Conductor conductor : conductores) {
				if (conductor.getCodigoComuna() != null) {
					conductor.setNombreComuna(comMap.get(conductor.getCodigoComuna()).getNombre());
					conductor.setNombreRegion(comMap.get(conductor.getCodigoComuna()).getProvincia().getRegion().getNombre());
				}
				Hibernate.initialize(conductor.getPersona().getInhabilidades());
			}
			return conductores;
		} else {
			return new ArrayList<Conductor>();
		}
	}

	public Conductor getConductorById(Long id) throws GeneralDataAccessException {
		return conductorDAO.getByPrimaryKey(id);
	}

	public void handle(List<ConductorServicio> conductoresServicio, Servicio servicio) throws GeneralDataAccessException {
		boolean primero = true;
		for (ConductorServicio conductorServicio : conductoresServicio) {
			if (GenericModelObject.ACTION_SAVE == conductorServicio.getConductor().getDbAction()) {
				Conductor cond = conductorServicio.getConductor();
				conductorDAO.save(cond);
				servicio.addLog(Resources.getString("servicio.log.cambio.conductor.nuevo",new String[]{cond.getPersona().getRut()}));
			} else if (GenericModelObject.ACTION_UPDATE == conductorServicio.getConductor().getDbAction()){
				List<Poliza> polizasAEliminar=new ArrayList<Poliza>();
				if(conductorServicio.getPolizas()!=null && Hibernate.isInitialized(conductorServicio.getPolizas())){
					for (Poliza poliza : conductorServicio.getPolizas()) {
						if (GenericModelObject.ACTION_SAVE == poliza.getDbAction()) {
							polizaDAO.save(poliza);
						} else if (GenericModelObject.ACTION_UPDATE == poliza.getDbAction()) {
							polizaDAO.update(poliza);
						} else if (GenericModelObject.ACTION_DELETE == poliza.getDbAction()) {
							polizasAEliminar.add(poliza);
						}
					}
					for (Poliza poliza : polizasAEliminar) {
						conductorServicio.getPolizas().remove(poliza);
						polizaDAO.remove(poliza);
					}
				}
				conductorDAO.update(conductorServicio.getConductor());
				servicio.addLog(Resources.getString("servicio.log.cambio.conductor.cambio",new String[]{conductorServicio.getConductor().getPersona().getRut()}));
			}
		}
		for (ConductorServicio conductorServicio : conductoresServicio) {
			// if (primero) {
			// servicio.setTmpConductoresServicio(new HashMap<Long, Object>());
			// primero = false;
			// }
			 List<ConductorVehiculo> conductoresVehiculo = conductorServicio.getConductoresVehiculo();
			 conductorServicio.setConductoresVehiculo(null);

			if (GenericModelObject.ACTION_SAVE == conductorServicio.getDbAction()) {
				conductorServicioDAO.save(conductorServicio);
			} else if (GenericModelObject.ACTION_UPDATE == conductorServicio.getDbAction()) {
				conductorServicioDAO.update(conductorServicio);
			}
			if (GenericModelObject.ACTION_SAVE == conductorServicio.getDbAction() || GenericModelObject.ACTION_UPDATE == conductorServicio.getDbAction()) {
				if (conductorServicio.getEstado() == GenericCancellableModelObject.ESTADO_PENDIENTE_AUTORIZACION) {
					for (AutorizacionMovimiento autorizacionMovimiento : conductorServicio.getAutorizacionesMovimiento()) {
						CurrentSessionBean csb = (CurrentSessionBean) ELFacesResolver.getManagedObject("currentSessionBean");
						autorizacionManager.handle(csb.getUser(),autorizacionMovimiento,conductorServicio);
					}
				}
			}
			
			conductorServicio.setConductoresVehiculo(conductoresVehiculo);

			if (conductorServicio.getConductoresVehiculo() != null && Hibernate.isInitialized(conductorServicio.getConductoresVehiculo())) {
				for (ConductorVehiculo conductorVehiculo : conductorServicio.getConductoresVehiculo()) {
					conductorVehiculo.setConductorServicio(conductorServicio);
				}
				for (ConductorVehiculo conductorVehiculo : conductorServicio.getConductoresVehiculo()) {
					if (GenericModelObject.ACTION_SAVE == conductorVehiculo.getDbAction()) {
						conductorVehiculoDAO.save(conductorVehiculo);
					} else if (GenericModelObject.ACTION_UPDATE == conductorVehiculo.getDbAction()) {
						conductorVehiculoDAO.update(conductorVehiculo);
					}
					if (GenericModelObject.ACTION_SAVE == conductorVehiculo.getDbAction() || GenericModelObject.ACTION_UPDATE == conductorVehiculo.getDbAction()) {
						if (conductorVehiculo.getEstado()!=null && conductorVehiculo.getEstado().intValue() == GenericCancellableModelObject.ESTADO_PENDIENTE_AUTORIZACION) {
							for (AutorizacionMovimiento autorizacionMovimiento : conductorVehiculo.getAutorizacionesMovimiento()) {
								CurrentSessionBean csb = (CurrentSessionBean) ELFacesResolver.getManagedObject("currentSessionBean");
								autorizacionManager.handle(csb.getUser(),autorizacionMovimiento,conductorVehiculo);
							}
						}
					}
				}
			}

			// servicio.getTmpConductoresServicio().put(conductorServicio.getId(),
			// conductoresVehiculo);
		}
	}

	public void postHandle(List<ConductorServicio> conductoresServicio, Servicio servicio) throws GeneralDataAccessException {
		for (ConductorServicio conductorServicio : conductoresServicio) {
			conductorServicio.getConductor().getPersona().setDbAction(GenericModelObject.ACTION_NOACTION);
			conductorServicio.getConductor().setDbAction(GenericModelObject.ACTION_NOACTION);
			conductorServicio.setDbAction(GenericModelObject.ACTION_NOACTION);
			if (conductorServicio.getConductoresVehiculo() != null && Hibernate.isInitialized(conductorServicio.getConductoresVehiculo())) {
				for (ConductorVehiculo conductorVehiculo : conductorServicio.getConductoresVehiculo()) {
					conductorVehiculo.setDbAction(GenericModelObject.ACTION_NOACTION);
				}
			}

		}
	}

	@Override
	public void recreateList(List<ConductorServicio> conductoresServicio, Servicio servicio) throws GeneralDataAccessException {
		for (ConductorServicio conductorServicio : conductoresServicio) {
			conductorServicio.setConductoresVehiculo((List<ConductorVehiculo>) servicio.getTmpConductoresServicio().get(conductorServicio.getId()));

		}

	}

	// private void preHandle(List<ConductorServicio> conductoresServicio)
	// throws GeneralDataAccessException{
	// for (ConductorServicio conductorServicio : conductoresServicio) {
	// if(conductorServicio.getConductoresVehiculo()!=null &&
	// Hibernate.isInitialized(conductorServicio.getConductoresVehiculo())){
	// for (ConductorVehiculo conductorVehiculo :
	// conductorServicio.getConductoresVehiculo()){
	// if(GenericModelObject.ACTION_SAVE == conductorVehiculo.getDbAction()){
	// conductorVehiculoDAO.save(conductorVehiculo);
	// }else if(GenericModelObject.ACTION_UPDATE ==
	// conductorVehiculo.getDbAction()){
	// conductorVehiculoDAO.update(conductorVehiculo);
	// }
	// }
	// }
	// }
	// }

	public boolean getConductorCanceladoDefinitivoByCategoria(String rut, TipoServicio tipoServicio) throws GeneralDataAccessException {
		return servicioDAO.getConductorTieneCancelacionByCategoria(rut, tipoServicio);
	}

	@Override
	public ConductorVehiculo getConductorVehiculo(Long id)
			throws GeneralDataAccessException {
		
		return conductorVehiculoDAO.getByPrimaryKey(id);
	}

	@Override
	public ConductorServicio getConductorServicio(Long id)
			throws GeneralDataAccessException {
		ConductorServicio cond = conductorServicioDAO.getByPrimaryKey(id);
		Hibernate.initialize(cond.getConductoresVehiculo());
		return cond;
	}
	
	@Override
	public void updateConductorServicio(ConductorServicio cs) throws GeneralDataAccessException{
		conductorServicioDAO.update(cs);
	}
	
	@Override
	public void deleteConductorServicioRechazada(ConductorServicio cs) throws GeneralDataAccessException{
		conductorServicioDAO.deleteConductorServicioRechazada(cs);
	}

	@Override
	public void cancelConductorServicioRechazada(ConductorServicio cs) throws GeneralDataAccessException{
		setCancellDataToConductor(cs);
		conductorServicioDAO.update(cs);
	}

	@Override
	public void cancelConductorVehiculoRechazada(ConductorVehiculo cs) throws GeneralDataAccessException{
		setCancellDataToConductor(cs);
		conductorVehiculoDAO.update(cs);
	}

	/**
	 * @param cs
	 * @throws GeneralDataAccessException
	 */
	private void setCancellDataToConductor(GenericAuditCancellableModelObject cs) throws GeneralDataAccessException {
		cs.setEstado(GenericCancellableModelObject.ESTADO_CANCELADO);
		cs.setFechaCambioEstado(new Date());
		TipoCancelacion tipoCancelacion = null;
		List<TipoCancelacion> tcs = generalDataManager.getAllTiposCancelacion(TipoCancelacion.APLICA_PERSONA,false);
		for (TipoCancelacion tc : tcs) {
			if("RECHAZO DE AUTORIZACIÓN".equalsIgnoreCase(tc.getNombre())){
				tipoCancelacion=tc;
			}
		}
		if(tipoCancelacion==null){
			throw new GeneralDataAccessException("No existe tipo de Cancelación correspondiente");
		}
		cs.setTipoCancelacion(tipoCancelacion);
	}

	@Override
	public void updateConductorVehiculo(ConductorVehiculo cv)
			throws GeneralDataAccessException {
		conductorVehiculoDAO.update(cv);
		
	}

	@Override
	public void deleteConductorVehiculoRechazada(ConductorVehiculo cv)
			throws GeneralDataAccessException {
		conductorVehiculoDAO.deleteConductorVehiculoRechazada(cv);
		
	}
	
	@Override
	public List<Poliza> getPolizasByConuctor(Long idConductorServicio) throws GeneralDataAccessException{
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("conductorServicio.id", idConductorServicio);
		List<Poliza> polizas = polizaDAO.findBySimpleCriteria(criteria);
		return polizas;
	}


}
