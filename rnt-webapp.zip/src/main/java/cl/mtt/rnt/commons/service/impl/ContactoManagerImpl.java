package cl.mtt.rnt.commons.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.ContactoDAO;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.Contacto;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Persona;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.service.ContactoManager;
import cl.mtt.rnt.commons.service.PersonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;

@Service("contactoManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class ContactoManagerImpl implements ContactoManager, Serializable {

	private static final long serialVersionUID = -3054489987590153544L;

	@Autowired()
	@Qualifier("ContactoDAO")
	private ContactoDAO contactoDAO;

	@Autowired
	@Qualifier("personaManager")
	private PersonaManager personaManager;

	@Autowired
	@Qualifier("ubicacionGeograficaManager")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@Override
	public List<Contacto> getContactosByRut(String rut) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("persona.rut", rut);
		criteria.put("persona.tipoPersona", Persona.TIPO_PERSONA_NATURAL);
		List<Contacto> contactos = contactoDAO.findBySimpleCriteria(criteria);
		for (Contacto contacto : contactos) {
			Hibernate.initialize(contacto.getServicios());
			if(contacto.getCodigoRegion()!=null){
				contacto.setNombreRegion(ubicacionGeograficaManager.getRegionById(contacto.getCodigoRegion()).getNombre());
			}
			if(contacto.getCodigoComuna()!=null){
				contacto.setNombreComuna(ubicacionGeograficaManager.getComunaById(contacto.getCodigoComuna()).getNombre());
			}
		}
		return contactos;
	}

	public List<Contacto> getContactosByServicio(Long idServicio) throws GeneralDataAccessException{
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("servicios.id", idServicio);
		List<Contacto> contactos = contactoDAO.findBySimpleCriteria(criteria);
		for (Contacto contacto : contactos) {
			Hibernate.initialize(contacto.getServicios());
			if(contacto.getCodigoRegion()!=null){
				contacto.setNombreRegion(ubicacionGeograficaManager.getRegionById(contacto.getCodigoRegion()).getNombre());
			}
			if(contacto.getCodigoComuna()!=null){
				contacto.setNombreComuna(ubicacionGeograficaManager.getComunaById(contacto.getCodigoComuna()).getNombre());
			}
		}
		return contactos;		
	}

	@Override
	public void saveContacto(Contacto contacto) throws GeneralDataAccessException, DuplicatedIdException {
		contactoDAO.save(contacto);

	}

	@Override
	public void updateContacto(Contacto contacto) throws GeneralDataAccessException {
		contactoDAO.update(contacto);

	}

	@Override
	public void removeContacto(Contacto contacto) throws GeneralDataAccessException {
		contactoDAO.remove(contacto);
	}

	@Override
	public Contacto getContactoById(Long id) throws GeneralDataAccessException {
		return contactoDAO.getByPrimaryKey(id);
	}

	@Override
	public void preHandle(List<Contacto> contactos, Servicio servicio) throws GeneralDataAccessException, DuplicatedIdException {
		List<Contacto> aEliminar = new ArrayList<Contacto>();
		if (contactos != null) {

			for (Iterator<Contacto> it = contactos.iterator(); it.hasNext();) {
				Contacto contacto = it.next();

				if (contacto.getDbAction() == GenericModelObject.ACTION_SAVE) {
					this.saveContacto(contacto);
					servicio.addLog(Resources.getString("servicio.log.cambio.contacto.nuevo",new String[]{contacto.getPersona().getRut()}));
				} else {
					if (contacto.getDbAction() == GenericModelObject.ACTION_UPDATE) {
						this.updateContacto(contacto);
						servicio.addLog(Resources.getString("servicio.log.cambio.contacto.cambio",new String[]{contacto.getPersona().getRut()}));
					} else {
						if (contacto.getDbAction() == GenericModelObject.ACTION_DELETE) {
							it.remove();
							servicio.addLog(Resources.getString("servicio.log.cambio.contacto.eliminado",new String[]{contacto.getPersona().getRut()}));
							if (contactoDAO.getCountServicesByContacto(contacto) == 1)
								aEliminar.add(contacto);

						}
					}
				}
			}
		}

		servicio.getListasEliminar().put(Servicio.LISTA_CONTACTO, aEliminar);

	}

	@Override
	public void postHandle(List<Contacto> contactos, Servicio servicio) throws GeneralDataAccessException {
		List<Contacto> aEliminar = servicio.getListasEliminar().get(Servicio.LISTA_CONTACTO);
		if (aEliminar != null) {
			for (Contacto todel : aEliminar) {
				try {
					// Contacto c = this.getContactoById(todel.getId());
					// Hibernate.initialize(c.getServicios());
					// if(c.getServicios().size()==1)
					this.removeContacto(todel);
				} catch (IntegrityViolationException ex) {
					Logger.getLogger(this.getClass()).error(Resources.getString("modificarServicio.error.eliminarContacto"));
				}

			}
		}

		for (Contacto c : contactos) {
			c.setDbAction(GenericModelObject.ACTION_NOACTION);
		}

	}
	
	@Override
	public List<Servicio> getServiciosContacto(Contacto contacto) throws GeneralDataAccessException { 
	    return contactoDAO.getServiciosDelContacto(contacto);
	}

}
