package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.Documentacion;
import cl.mtt.rnt.commons.model.core.MarcoGeograficoLocalizable;
import cl.mtt.rnt.commons.service.DocumentacionManager;


@Service("documentacionManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class DocumentacionManagerImpl implements DocumentacionManager {
	
	
	@Autowired
	@Qualifier("DocumentacionDAO")
	private GenericDAO<Documentacion> documentacionDAO;
	
	

	@Override
	public List<Documentacion> getDocumentaciones()
			throws GeneralDataAccessException {
		return documentacionDAO.getAll();
	}

	@Override
	public void saveDocumentacion(Documentacion doc)
			throws GeneralDataAccessException, DuplicatedIdException {
		documentacionDAO.save(doc);

	}

	@Override
	public void updateDocumentacion(Documentacion doc)
			throws GeneralDataAccessException {
		documentacionDAO.update(doc);

	}

	@Override
	public void deleteDocumentacion(Documentacion doc)
			throws GeneralDataAccessException,IntegrityViolationException {
		documentacionDAO.remove(doc);
	}

	@Override
	public List<Documentacion> getDocumentacionesByName(String name)
			throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put(GenericDAO.CRITERION_PREFIX_ILIKE+".nombre", name);
		List<Documentacion> list = documentacionDAO.findBySimpleCriteria(criteria);
		return list;
	}

}
