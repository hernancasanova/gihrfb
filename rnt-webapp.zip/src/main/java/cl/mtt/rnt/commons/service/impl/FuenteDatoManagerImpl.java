package cl.mtt.rnt.commons.service.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.FuenteDato;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.service.FuenteDatoManager;

@Service("fuenteDatoManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class FuenteDatoManagerImpl implements FuenteDatoManager, Serializable {

	private static final long serialVersionUID = -2486103344646488245L;

	@Autowired()
	@Qualifier("FuenteDatoDAO")
	private GenericDAO<FuenteDato> fuenteDatoDAO;

	@Override
	public FuenteDato getFuenteDatoById(Long id) throws GeneralDataAccessException {
		return fuenteDatoDAO.getByPrimaryKey(id);
	}

	@Override
	public List<FuenteDato> getFuentesDatoByIdAtributo(Long idAtributo) throws GeneralDataAccessException{
		Map<String,Object> criteria=new HashMap<String, Object>();
		criteria.put("atributo.id", idAtributo);
		return fuenteDatoDAO.findBySimpleCriteria(criteria);
	}

	@Override
	public void saveFuenteDato(FuenteDato fuenteDato) throws GeneralDataAccessException {
		fuenteDatoDAO.save(fuenteDato);
	}

	@Override
	public void updateFuenteDato(FuenteDato fuenteDato) throws GeneralDataAccessException {
		fuenteDatoDAO.update(fuenteDato);
	}

	@Override
	public void removeFuenteDato(FuenteDato fuenteDato) throws GeneralDataAccessException {
		fuenteDatoDAO.remove(fuenteDato);
	}

	@Override
	public void preHandle(List<FuenteDato> fuentesDatos) throws GeneralDataAccessException {
		for (FuenteDato dato : fuentesDatos) {
			if (dato != null) {
				if (dato.getDbAction() == GenericModelObject.ACTION_SAVE) {
					this.saveFuenteDato(dato);
				} else {
					if (dato.getDbAction() == GenericModelObject.ACTION_UPDATE) {
						this.updateFuenteDato(dato);
					} else {
						if (dato.getDbAction() == GenericModelObject.ACTION_DELETE) {
							this.removeFuenteDato(dato);
						}
					}
				}
			}
		}
	}

	@Override
	public void postHandle(List<FuenteDato> fuenteDeDatos) throws GeneralDataAccessException {
		for (Iterator<FuenteDato> it = fuenteDeDatos.iterator(); it.hasNext();) {
			FuenteDato fuenteDato = it.next();
			if (fuenteDato.getDbAction() == GenericModelObject.ACTION_DELETE) {
				it.remove();
			} else {
				fuenteDato.setDbAction(GenericModelObject.ACTION_NOACTION);
			}
		}

	}

}
