package cl.mtt.rnt.commons.service.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.comparator.CalleComunaComparator;
import cl.mtt.rnt.commons.model.core.CategoriaPersonaJuridica;
import cl.mtt.rnt.commons.model.core.ClaseLicenciaConducir;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.GlosaAuxiliar;
import cl.mtt.rnt.commons.model.core.Gremio;
import cl.mtt.rnt.commons.model.core.GremioRegion;
import cl.mtt.rnt.commons.model.core.Inhabilidad;
import cl.mtt.rnt.commons.model.core.SituacionContractual;
import cl.mtt.rnt.commons.model.core.TipoCancelacion;
import cl.mtt.rnt.commons.model.core.TipoCobradorVehiculo;
import cl.mtt.rnt.commons.model.core.TipoContrato;
import cl.mtt.rnt.commons.model.core.TipoDocumentoGrupo;
import cl.mtt.rnt.commons.model.core.TipoDocumentoRequerido;
import cl.mtt.rnt.commons.model.core.TipoIngresoVehiculo;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.TipoSubsidio;
import cl.mtt.rnt.commons.model.core.TipoTecnologiaGases;
import cl.mtt.rnt.commons.model.core.recorrido.CalleHomologada;
import cl.mtt.rnt.commons.model.core.recorrido.DatoDiccionario;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.StringUtil;

@Service("generalDataManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class GeneralDataManagerImpl implements GeneralDataManager, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3009723571720509839L;
	
	List<TipoIngresoVehiculo> tipoIgresoVehiculos = null;
	private List<TipoTecnologiaGases> tipoTecGases = null;
    private List<TipoCobradorVehiculo> tiposCobrador = null;
    
    @Override
    public void fillCache() {
        try {
            getAllTiposCobradorVehiculo();
            getAllTiposTecnologiasGases();
            getAllTiposIngresoVehiculo();
            getAllTiposContrato();
            getAllTiposSubsidio();
        }
        catch (Exception e) {
            Logger.getLogger(this.getClass()).error(e.getMessage(),e);
        }
    }

	@Autowired()
	@Qualifier("ClaseLicenciaConducirDAO")
	private GenericDAO<ClaseLicenciaConducir> claseLicenciaConducirDAO;

	@Autowired()
	@Qualifier("InhabilidadDAO")
	private GenericDAO<Inhabilidad> inhabilidadDAO;

	@Autowired()
	@Qualifier("SituacionContractualDAO")
	private GenericDAO<SituacionContractual> situacionContractualDAO;

	@Autowired()
	@Qualifier("CatPersonaJuridicaDAO")
	private GenericDAO<CategoriaPersonaJuridica> categoriaPersonaJuridicaDAO;

	@Autowired()
	@Qualifier("TipoIngresoVehiculoDAO")
	private GenericDAO<TipoIngresoVehiculo> tipoIngresoVehiculoDao;

	@Autowired()
	@Qualifier("TecnologiaGasesDAO")
	private GenericDAO<TipoTecnologiaGases> tipoTecGasesDAO;

	@Autowired()
	@Qualifier("TipoCobradorDAO")
	private GenericDAO<TipoCobradorVehiculo> tipoCobradorDAO;

	@Autowired()
	@Qualifier("TipoCancelacionDAO")
	private GenericDAO<TipoCancelacion> tipoCancelacionDAO;

	@Autowired()
	@Qualifier("TipoDocumentoRequeridoDAO")
	private GenericDAO<TipoDocumentoRequerido> tipoDocumentoRequeridoDAO;

	@Autowired()
	@Qualifier("TipoDocumentoGrupoDAO")
	private GenericDAO<TipoDocumentoGrupo> tipoDocumentoGrupoDAO;

	@Autowired()
	@Qualifier("GremioDAO")
	private GenericDAO<Gremio> gremioDAO;

	@Autowired()
	@Qualifier("DatoDiccionarioDAO")
	private GenericDAO<DatoDiccionario> datoDiccionarioDAO;

	@Autowired()
	@Qualifier("CalleHomologadaDAO")
	private GenericDAO<CalleHomologada> calleHomologadaDAO;

	@Autowired()
	@Qualifier("ubicacionGeograficaManager")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@Autowired()
	@Qualifier("GlosaAuxiliarDAO")
	private GenericDAO<GlosaAuxiliar> glosaAuxiliarDAO;

	@Autowired()
	@Qualifier("TipoContratoDAO")
	private GenericDAO<TipoContrato> tipoContratoDAO;

	@Autowired()
	@Qualifier("TipoSubsidioDAO")
	private GenericDAO<TipoSubsidio> tipoSubsidioDAO;
	
	// Mejoras 201409 Nro: 30
	@Autowired()
	@Qualifier("GremioRegionDAO")
	private GenericDAO<GremioRegion> gremioRegionDAO;

    private List<TipoContrato> tiposContrato;

    private List<TipoSubsidio> tiposSubsidio;



    
	// Mejoras 201409 Nro: 30

	@Override
	public List<ClaseLicenciaConducir> getAllClasesLicenciaConducir() throws GeneralDataAccessException {
		return claseLicenciaConducirDAO.getAll();
	}

	@Override
	public ClaseLicenciaConducir getClaseLicenciaConducirById(Long id) throws GeneralDataAccessException {
		return claseLicenciaConducirDAO.getByPrimaryKey(id);
	}

	@Override
	public List<ClaseLicenciaConducir> getClasesLicenciaConducirByIds(List<Long> ids) throws GeneralDataAccessException {
		if (ids == null || ids.size() == 0) {
			return new ArrayList<ClaseLicenciaConducir>();
		}
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("id", ids);
		return claseLicenciaConducirDAO.findBySimpleCriteria(criteria);
	}

	@Override
	public List<Inhabilidad> getAllInhabilidades() throws GeneralDataAccessException {
		return inhabilidadDAO.getAll();
	}

	@Override
	public Inhabilidad getInhabilidadById(Long id) throws GeneralDataAccessException {
		return inhabilidadDAO.getByPrimaryKey(id);
	}

	@Override
	public List<Inhabilidad> getInhabilidadesByIds(List<Long> ids) throws GeneralDataAccessException {
		if (ids == null || ids.size() == 0) {
			return new ArrayList<Inhabilidad>();
		}
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("id", ids);
		return inhabilidadDAO.findBySimpleCriteria(criteria);
	}

	/**
	 * @param setea
	 *            el parametro categoriaPersonaJuridicaDAO al campo
	 *            categoriaPersonaJuridicaDAO
	 */
	public void setCategoriaPersonaJuridicaDAO(GenericDAO<CategoriaPersonaJuridica> categoriaPersonaJuridicaDAO) {
		this.categoriaPersonaJuridicaDAO = categoriaPersonaJuridicaDAO;
	}

	@Override
	public List<CategoriaPersonaJuridica> getCategoriasPersonasJuridicas() throws GeneralDataAccessException {
		return categoriaPersonaJuridicaDAO.getAll();
	}

	@Override
	public List<SituacionContractual> getAllSituacionesContractuales() throws GeneralDataAccessException {
		return situacionContractualDAO.getAll();
	}

	@Override
	public SituacionContractual getSituacionContractualById(Long id) throws GeneralDataAccessException {
		return situacionContractualDAO.getByPrimaryKey(id);
	}

	@Override
	public List<TipoIngresoVehiculo> getAllTiposIngresoVehiculo() throws GeneralDataAccessException {
	    if (tipoIgresoVehiculos == null) {
		   tipoIgresoVehiculos = tipoIngresoVehiculoDao.getAll();
	    }
	    return tipoIgresoVehiculos;
	}

	@Override
	public List<TipoTecnologiaGases> getAllTiposTecnologiasGases() throws GeneralDataAccessException {
	    if (tipoTecGases == null) {
	        tipoTecGases = tipoTecGasesDAO.getAll();
	        }
	    return tipoTecGases;
	}

	@Override
	public List<TipoCobradorVehiculo> getAllTiposCobradorVehiculo() throws GeneralDataAccessException {
	    if (tiposCobrador == null) {
	        tiposCobrador = tipoCobradorDAO.getAll();
            }
        return tiposCobrador;
	}

	/**
	 * @return el valor de situacionContractualDAO
	 */
	public GenericDAO<SituacionContractual> getSituacionContractualDAO() {
		return situacionContractualDAO;
	}

	/**
	 * @param setea
	 *            el parametro situacionContractualDAO al campo
	 *            situacionContractualDAO
	 */
	public void setSituacionContractualDAO(GenericDAO<SituacionContractual> situacionContractualDAO) {
		this.situacionContractualDAO = situacionContractualDAO;
	}

	/**
	 * @return el valor de tipoIngresoVehiculoDao
	 */
	public GenericDAO<TipoIngresoVehiculo> getTipoIngresoVehiculoDao() {
		return tipoIngresoVehiculoDao;
	}

	/**
	 * @param setea
	 *            el parametro tipoIngresoVehiculoDao al campo
	 *            tipoIngresoVehiculoDao
	 */
	public void setTipoIngresoVehiculoDao(GenericDAO<TipoIngresoVehiculo> tipoIngresoVehiculoDao) {
		this.tipoIngresoVehiculoDao = tipoIngresoVehiculoDao;
	}

	/**
	 * @return el valor de tipoTecGasesDAO
	 */
	public GenericDAO<TipoTecnologiaGases> getTipoTecGasesDAO() {
		return tipoTecGasesDAO;
	}

	/**
	 * @param setea
	 *            el parametro tipoTecGasesDAO al campo tipoTecGasesDAO
	 */
	public void setTipoTecGasesDAO(GenericDAO<TipoTecnologiaGases> tipoTecGasesDAO) {
		this.tipoTecGasesDAO = tipoTecGasesDAO;
	}

	/**
	 * @return el valor de tipoCobradorDAO
	 */
	public GenericDAO<TipoCobradorVehiculo> getTipoCobradorDAO() {
		return tipoCobradorDAO;
	}

	/**
	 * @param setea
	 *            el parametro tipoCobradorDAO al campo tipoCobradorDAO
	 */
	public void setTipoCobradorDAO(GenericDAO<TipoCobradorVehiculo> tipoCobradorDAO) {
		this.tipoCobradorDAO = tipoCobradorDAO;
	}

	/**
	 * @return el valor de categoriaPersonaJuridicaDAO
	 */
	public GenericDAO<CategoriaPersonaJuridica> getCategoriaPersonaJuridicaDAO() {
		return categoriaPersonaJuridicaDAO;
	}

	public List<TipoCancelacion> getAllTiposCancelacion(String alcance,boolean includeCancelacionServicio) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("aplica", alcance);
		List<TipoCancelacion> tiposCanc = tipoCancelacionDAO.findBySimpleCriteria(criteria);
		if (tiposCanc != null) {
			for (Iterator<TipoCancelacion> it = tiposCanc.iterator(); it.hasNext();) {
				TipoCancelacion tc = it.next();
				if (!includeCancelacionServicio && esPorCancelacionServicio(tc,null) && (!tc.getAplica().equals(TipoCancelacion.APLICA_SERVICIO))) {
					it.remove();
				} else {
					Hibernate.initialize(tc.getTiposServicio());
				}
			}
		}
		return tiposCanc;
	}

	public List<TipoCancelacion> getAllTiposCancelacion() throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		return tipoCancelacionDAO.findBySimpleCriteria(criteria);
	}

	public TipoCancelacion getTipoCancelacionById(long idTipoCancelacion) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("id",idTipoCancelacion);
		List<TipoCancelacion> lr = tipoCancelacionDAO.findBySimpleCriteria(criteria);
		if (lr.size()>0) return lr.get(0);
		return null;
	}

	public List<TipoCancelacion> getAllTiposCancelacionPermanentes(String alcance) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("aplica", alcance);
		criteria.put("tipoCancelacion", "definitiva");
		List<TipoCancelacion> tiposCanc = tipoCancelacionDAO.findBySimpleCriteria(criteria);
		if (tiposCanc != null) {
			for (Iterator<TipoCancelacion> it = tiposCanc.iterator(); it.hasNext();) {
				TipoCancelacion tc = it.next();
				if (esPorCancelacionServicio(tc,null) && (!tc.getAplica().equals(TipoCancelacion.APLICA_SERVICIO))) {
					it.remove();
				} else {
					Hibernate.initialize(tc.getTiposServicio());
				}
			}
		}
		return tiposCanc;
	}

	public List<TipoCancelacion> getAllTiposCancelacionByTipoServicio(String alcance, TipoServicio ts) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("aplica", alcance);
		// criteria.put("tipoCancelacion", "definitiva");
		List<TipoCancelacion> tiposCanc = tipoCancelacionDAO.findBySimpleCriteria(criteria);
		if (tiposCanc != null) {
			for (Iterator<TipoCancelacion> it = tiposCanc.iterator(); it.hasNext();) {
				TipoCancelacion tc = it.next();
				if (esPorCancelacionServicio(tc,ts)) {
					it.remove();
				} else {
					Hibernate.initialize(tc.getTiposServicio());
					if (!tc.getTiposServicio().contains(ts)) {
						it.remove();
					}
				}
			}
		}
		return tiposCanc;

	}

	public List<TipoCancelacion> getTiposCancelacionPermanentesByTipoServicio(String alcance, TipoServicio ts) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("aplica", alcance);
		criteria.put("tipoCancelacion", "definitiva");
		List<TipoCancelacion> tiposCanc = tipoCancelacionDAO.findBySimpleCriteria(criteria);
		if (tiposCanc != null) {
			for (Iterator<TipoCancelacion> it = tiposCanc.iterator(); it.hasNext();) {
				TipoCancelacion tc = it.next();
				if (esPorCancelacionServicio(tc,ts)) {
					it.remove();
				} else {
					Hibernate.initialize(tc.getTiposServicio());
					if (!tc.getTiposServicio().contains(ts)) {
						it.remove();
					}
				}
			}
		}
		return tiposCanc;
	}

	public List<TipoCancelacion> getAllTiposCancelacionTemporales(String alcance) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("aplica", alcance);
		criteria.put("tipoCancelacion", "temporal");
		List<TipoCancelacion> tiposCanc = tipoCancelacionDAO.findBySimpleCriteria(criteria);
		if (tiposCanc != null) {
			for (Iterator<TipoCancelacion> it = tiposCanc.iterator(); it.hasNext();) {
				TipoCancelacion tc = it.next();
				if (esPorCancelacionServicio(tc,null)) {
					it.remove();
				} else {
					Hibernate.initialize(tc.getTiposServicio());
				}
			}
		}
		return tiposCanc;
	}

	public List<TipoCancelacion> getTiposCancelacionTemporalesByTipoServicio(String alcance, TipoServicio ts) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("aplica", alcance);
		criteria.put("tipoCancelacion", "temporal");
		List<TipoCancelacion> tiposCanc = tipoCancelacionDAO.findBySimpleCriteria(criteria);
		if (tiposCanc != null) {
			for (Iterator<TipoCancelacion> it = tiposCanc.iterator(); it.hasNext();) {
				TipoCancelacion tc = it.next();
				if (esPorCancelacionServicio(tc,ts) && (!tc.getAplica().equals(TipoCancelacion.APLICA_SERVICIO))) {
					it.remove();
				} else {
					Hibernate.initialize(tc.getTiposServicio());
					if (!tc.getTiposServicio().contains(ts)) {
						it.remove();
					}
				}

			}
		}
		return tiposCanc;
	}

	private boolean esPorCancelacionServicio(TipoCancelacion tc,TipoServicio ts) {
		//Hardcode para serivicio privado especial escolar bus/minibus
		if(ts!=null && ts.getId().equals(101l)) {
			return false;
		}
		//Fin Hardcode
		return StringUtil.removeDiacriticos(tc.getNombre()).equalsIgnoreCase("Cancelacion de Servicio");
	}

	public List<TipoCancelacion> getAllTiposCancelacionDeServicio(String alcance) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("aplica", alcance);
		criteria.put("tipoCancelacion", "temporal");
		List<TipoCancelacion> tiposCanc = tipoCancelacionDAO.findBySimpleCriteria(criteria);
		if (tiposCanc != null) {
			for (Iterator<TipoCancelacion> it = tiposCanc.iterator(); it.hasNext();) {
				TipoCancelacion tc = it.next();
				if (esPorCancelacionServicio(tc,null)) {
					Hibernate.initialize(tc.getTiposServicio());
				} else {
					it.remove();
				}
			}
		}
		return tiposCanc;
	}

	public List<TipoDocumentoRequerido> getAllTipoDocumentoRequerido(boolean dePortacion) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("dePortacion", dePortacion);
		return tipoDocumentoRequeridoDAO.findBySimpleCriteria(criteria);
	}

	public List<TipoDocumentoGrupo> getAllTipoDocumentoGrupo() throws GeneralDataAccessException {
		return tipoDocumentoGrupoDAO.getAll();

	}

	public List<TipoDocumentoRequerido> getAllTipoDocumentoRequeridoByIdGrupo(Long id) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("grupo.id", id);
		return tipoDocumentoRequeridoDAO.findBySimpleCriteria(criteria);
	}

	public List<TipoDocumentoRequerido> getTiposDocumentoRequeridoByIds(List<Long> ids) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("id", ids);
		return tipoDocumentoRequeridoDAO.findBySimpleCriteria(criteria);
	}

	@Override
	public List<Gremio> getAllGremios() throws GeneralDataAccessException {

		return gremioDAO.getAll();
	}
	
	// Mejoras 201409 Nro: 30
	@Override
	public List<GremioRegion> getGremiosByRegion(String codigoRegion) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("codRegion", codigoRegion);
		List<GremioRegion> gremios = gremioRegionDAO.findBySimpleCriteria(criteria);
		return gremios;
	}
	// Mejoras 201409 Nro: 30
	@Override
	public List<DatoDiccionario> findDatosDiccionario(String nombre, String codigoRegion) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("tipo", new BigDecimal(1));  //elimino de la busqueda las migradas que no participan
		if (codigoRegion != null) {
			criteria.put("codigoComuna", ubicacionGeograficaManager.getAllCodigosComunasByIdRegion(codigoRegion));
		}
		HashMap<String, Object> likeFields = new HashMap<String, Object>();
		likeFields.put("calle1", nombre);
		List<String> sorting = new ArrayList<String>();
		sorting.add("calle1");
		List<DatoDiccionario> datosDiccionario = datoDiccionarioDAO.findBySimpleHQL(criteria, sorting, likeFields, false);
		for (DatoDiccionario datoDiccionario : datosDiccionario) {
			if (datoDiccionario.getCodigoComuna() != null)
				datoDiccionario.setComuna(ubicacionGeograficaManager.getComunaById(datoDiccionario.getCodigoComuna()));
		}
		// Se ordenan por comuna
		Collections.sort(datosDiccionario, new CalleComunaComparator());

		return datosDiccionario;
	}

	public List<DatoDiccionario> findDatosDiccionarioByComuna(String nombre, String codigoComuna) throws GeneralDataAccessException{
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		if (codigoComuna != null) {
			criteria.put("codigoComuna", codigoComuna);
		}
		criteria.put("tipo", new BigDecimal(1));  //elimino de la busqueda las migradas que no participan
		HashMap<String, Object> likeFields = new HashMap<String, Object>();
		likeFields.put("calle1", nombre);
		List<String> sorting = new ArrayList<String>();
		sorting.add("calle1");
		List<DatoDiccionario> datosDiccionario = datoDiccionarioDAO.findBySimpleHQL(criteria, sorting, likeFields, false);
		for (DatoDiccionario datoDiccionario : datosDiccionario) {
			if (datoDiccionario.getCodigoComuna() != null)
				datoDiccionario.setComuna(ubicacionGeograficaManager.getComunaById(datoDiccionario.getCodigoComuna()));
		}
		// Se ordenan por comuna
		Collections.sort(datosDiccionario, new CalleComunaComparator());
	
		return datosDiccionario;
	}

	@Override
	public DatoDiccionario getDatosDiccionario(String nombre, String codigoComuna) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("calle1", nombre);
		criteria.put("codigoComuna", codigoComuna);
		criteria.put("tipo", new BigDecimal(1));  //elimino de la busqueda las migradas que no participan
		List<DatoDiccionario> dds = datoDiccionarioDAO.findBySimpleCriteria(criteria);
		if (dds == null || dds.size() == 0)
			return null;
		return dds.get(0);
	}

	@Override
	public List<DatoDiccionario> findDatosDiccionarioByComuna(String codigoComuna) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("codigoComuna", codigoComuna);
		criteria.put("tipo", new BigDecimal(1));  //elimino de la busqueda las migradas que no participan
		// HashMap<String, Object> likeFields = new HashMap<String, Object>();
		// likeFields.put("calle1", nombre);
		List<String> sorting = new ArrayList<String>();
		sorting.add("calle1");
		List<DatoDiccionario> datosDiccionario = datoDiccionarioDAO.findBySimpleCriteria(criteria, sorting);

		return datosDiccionario;
	}

	@Override
	public List<DatoDiccionario> getAllDatosDiccionario() throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("tipo", new BigDecimal(1));  //elimino de la busqueda las migradas que no participan
		// HashMap<String, Object> likeFields = new HashMap<String, Object>();
		// likeFields.put("calle1", nombre);
		List<String> sorting = new ArrayList<String>();
		sorting.add("calle1");
		List<DatoDiccionario> datosDiccionario = datoDiccionarioDAO.findBySimpleCriteria(criteria, sorting);

		return datosDiccionario;
	}

	@Override
	public DatoDiccionario getDatoDiccionarioById(Long idDatoDiccionario) throws GeneralDataAccessException {
		return datoDiccionarioDAO.getByPrimaryKey(idDatoDiccionario);
	}

	@Override
	public void eliminarDatoDiccionario(DatoDiccionario datoDiccionario) throws GeneralDataAccessException {
		datoDiccionarioDAO.remove(datoDiccionario);
	}

	@Override
	public void updateDatoDiccionario(DatoDiccionario datoDiccionario) throws GeneralDataAccessException {
		if(datoDiccionario.getCallesHomologadas()!=null){
			for (CalleHomologada calleHomologada : datoDiccionario.getCallesHomologadas()) {
				if(GenericModelObject.ACTION_DELETE == calleHomologada.getDbAction() )
					calleHomologadaDAO.remove(calleHomologada);
			}
		}
		datoDiccionarioDAO.update(datoDiccionario);
		
	}

	@Override
	public long getDatosDiccionarioCount(HashMap<String, Object> filters) throws GeneralDataAccessException {
		filters.put("tipo", new BigDecimal(1));  //elimino de la busqueda las migradas que no participan
		return datoDiccionarioDAO.getDataCount(filters);
	}

	@Override
	public List<DatoDiccionario> getCallesPage(int first, int rows, HashMap<String, Object> filters, List<String> order) throws GeneralDataAccessException {
		filters.put("tipo", new BigDecimal(1));  //elimino de la busqueda las migradas que no participan
		List<DatoDiccionario> list = this.datoDiccionarioDAO.getPagedData(filters, order, first, rows);
		for (DatoDiccionario dd : list) {
			dd.setComuna(this.ubicacionGeograficaManager.getComunaById(dd.getCodigoComuna()));
		}
		return list;
	}

	@Override
	public List<CalleHomologada> getCallesHomologadasByDatoDiccionario(DatoDiccionario datoDiccionario) throws GeneralDataAccessException{
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("datoDiccionario.id", datoDiccionario.getId());
		return calleHomologadaDAO.findBySimpleCriteria(criteria);
	}

	@Override
	public List<GlosaAuxiliar> getAllGlosasAuxiliar() throws GeneralDataAccessException {
		return glosaAuxiliarDAO.getAll();
	}

	@Override
	public GlosaAuxiliar getGlosaAuxiliarById(Long idGlosaAuxiliar) throws GeneralDataAccessException {
		return glosaAuxiliarDAO.getByPrimaryKey(idGlosaAuxiliar);
	}

	@Override
	public List<TipoContrato> getAllTiposContrato() throws GeneralDataAccessException {
		if ((tiposContrato==null)||(!tiposContrato.isEmpty())) {
		    tiposContrato = tipoContratoDAO.getAll();
		}
		return tiposContrato;
		
	}

	@Override
	public List<TipoSubsidio> getAllTiposSubsidio() throws GeneralDataAccessException {
	    if ((tiposSubsidio==null)||(!tiposSubsidio.isEmpty())) {
	        tiposSubsidio = tipoSubsidioDAO.getAll();
        }
        return tiposSubsidio;
	}

	@Override
	public TipoSubsidio getTipoSubsidioNoAplica() throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("descriptor", "no_aplica");
		List<TipoSubsidio> findBySimpleCriteria = tipoSubsidioDAO.findBySimpleCriteria(criteria);
		if ((findBySimpleCriteria != null) && (!findBySimpleCriteria.isEmpty())) {
			return findBySimpleCriteria.get(0);
		}
		return null;
	}

	public CalleHomologada getCalleHomologada(String calleGMap, String codigoComuna) throws GeneralDataAccessException {
		calleGMap = calleGMap.toUpperCase();
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("codigoComuna", codigoComuna);
		criteria.put("nombreGoogleMaps", calleGMap);

		List<CalleHomologada> chs = calleHomologadaDAO.findBySimpleCriteria(criteria);

		if (chs == null || chs.size() == 0)
			return null;
		return chs.get(0);
	}

	public DatoDiccionario getDatoDiccionarioHomologado(String calleGMap, String codigoComuna) throws GeneralDataAccessException {
		CalleHomologada ch = getCalleHomologada(calleGMap, codigoComuna);
		if (ch == null)
			return null;
		return ch.getDatoDiccionario();
	}

	public void saveCalleHomologada(String calleGMap, DatoDiccionario datoDiccionario) throws GeneralDataAccessException {
		CalleHomologada ch = getCalleHomologada(calleGMap, datoDiccionario.getCodigoComuna());
		if (ch == null) {
			ch = new CalleHomologada();
			ch.setCodigoComuna(datoDiccionario.getCodigoComuna());
			ch.setDatoDiccionario(datoDiccionario);
			ch.setNombreGoogleMaps(calleGMap);
			calleHomologadaDAO.save(ch);
		} else {
			ch.setDatoDiccionario(datoDiccionario);
			calleHomologadaDAO.update(ch);
		}
	}

	public void saveCalleHomologadaConDatoDiccionario(String calleGMap, DatoDiccionario datoDiccionario) throws GeneralDataAccessException {
		saveDatoDiccionario(datoDiccionario);
		saveCalleHomologada(calleGMap, datoDiccionario);

	}

	public void saveDatoDiccionario(DatoDiccionario datoDiccionario) throws GeneralDataAccessException {
		datoDiccionario.setTipo(new BigDecimal(1)); //todas las calles son tipo 1
		datoDiccionarioDAO.save(datoDiccionario);
	}

}
