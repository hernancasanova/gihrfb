package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.admin.reglamentacion.NormativaAccess;
import cl.mtt.rnt.admin.reglamentacion.util.ItemCupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo.SubGrupo;
import cl.mtt.rnt.admin.reglamentacion.xml.ReglamentacionXML.Grupo.SubGrupo.Norma;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.NormativaDAO;
import cl.mtt.rnt.commons.dao.ReglamentacionDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.GlosaReglamentacion;
import cl.mtt.rnt.commons.model.core.ItemGlosaReglamentacion;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.MarcoGeograficoLocalizable;
import cl.mtt.rnt.commons.model.core.Normativa;
import cl.mtt.rnt.commons.model.core.NormativaItem;
import cl.mtt.rnt.commons.model.core.NormativaRegistro;
import cl.mtt.rnt.commons.model.core.Reglamentacion;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.core.TipoCertificado;
import cl.mtt.rnt.commons.model.core.TipoDocumento;
import cl.mtt.rnt.commons.model.core.TipoReglamentacion;
import cl.mtt.rnt.commons.model.core.TipoServicio;
import cl.mtt.rnt.commons.model.core.VehiculoServicio;
import cl.mtt.rnt.commons.model.core.autorizacion.Autorizacion;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.model.view.ServicioReglamentadosVO;
import cl.mtt.rnt.commons.model.view.TipoDocumentoSeleccionable;
import cl.mtt.rnt.commons.model.view.VehiculoReglamentadosVO;
import cl.mtt.rnt.commons.service.BibliotecaDigitalManager;
import cl.mtt.rnt.commons.service.GeneralDataManager;
import cl.mtt.rnt.commons.service.GlosaReglamentacionManager;
import cl.mtt.rnt.commons.service.MarcoGeograficoManager;
import cl.mtt.rnt.commons.service.ModalidadManager;
import cl.mtt.rnt.commons.service.ReglamentacionManager;
import cl.mtt.rnt.commons.service.ServicioManager;
import cl.mtt.rnt.commons.service.TipoServicioManager;
import cl.mtt.rnt.commons.service.VehiculoManagerRnt;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.FieldComparator;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;
import cl.mtt.rnt.commons.util.validator.ValidacionHelper;
import cl.mtt.rnt.encargado.dto.ReglamentacionDTO;

@Service("glosaReglamentacionManager")
@Transactional(rollbackFor = Exception.class)
@Lazy(value = true)
public class GlosaReglamentacionManagerImpl implements GlosaReglamentacionManager {

	@Autowired
	@Qualifier("GlosaReglamentacionDAO")
	private GenericDAO<GlosaReglamentacion> glosaReglamentacionDAO;

	@Autowired
	@Qualifier("ItemGlosaReglamentacionDAO")
	private GenericDAO<ItemGlosaReglamentacion> itemGlosaReglamentacionDAO;

	@Override
	public void saveGlosaReglamentacion(GlosaReglamentacion glosaReglamentacion) throws GeneralDataAccessException {
		glosaReglamentacionDAO.save(glosaReglamentacion);	
		for (ItemGlosaReglamentacion item : glosaReglamentacion.getItems()) {
			itemGlosaReglamentacionDAO.save(item);
		}
	}

	@Override
	public void updateGlosaReglamentacion(GlosaReglamentacion glosaReglamentacion) throws GeneralDataAccessException {
		itemGlosaReglamentacionDAO.removeAll(glosaReglamentacion.getItemsAEliminar());
		itemGlosaReglamentacionDAO.saveOrUpdateAll(glosaReglamentacion.getItems());
		glosaReglamentacionDAO.update(glosaReglamentacion);		
	}

	@Override
	public void removeGlosaReglamentacion(GlosaReglamentacion glosaReglamentacion) throws GeneralDataAccessException {
		if(glosaReglamentacion!=null){
			GlosaReglamentacion glosaDB = glosaReglamentacionDAO.getByPrimaryKey(glosaReglamentacion.getId());
			itemGlosaReglamentacionDAO.removeAll(glosaDB.getItems());
			glosaReglamentacionDAO.remove(glosaReglamentacion);
		}
	}


}
