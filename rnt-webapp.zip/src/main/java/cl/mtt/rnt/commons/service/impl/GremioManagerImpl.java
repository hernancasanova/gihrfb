package cl.mtt.rnt.commons.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.Gremio;
import cl.mtt.rnt.commons.model.core.GremioRegion;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.service.GremioManager;

@Service("gremioManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class GremioManagerImpl implements GremioManager {

	@Autowired()
	@Qualifier("GremioDAO")
	private GenericDAO<Gremio> gremioDAO;
	@Autowired()
	@Qualifier("GremioRegionDAO")
	private GenericDAO<GremioRegion> gremioRegionDAO;
	
	@Override
	public List<Gremio> getAllGremios() throws GeneralDataAccessException {
		return gremioDAO.getAll();
	}

	public void saveGremio(Gremio gremio) throws GeneralDataAccessException{
		gremioDAO.save(gremio);
		for (GremioRegion gr : gremio.getGremiosRegiones()) {
			gremioRegionDAO.save(gr);
		}
	}
	

	public void updateGremio(Gremio gremio,List<GremioRegion> aeliminar) throws GeneralDataAccessException{
		for (GremioRegion gremioRegion : aeliminar) {
			gremioRegionDAO.remove(gremioRegion);
		}
		gremioDAO.update(gremio);
	}
	
	public Gremio getGremioById(Long idGremio) throws GeneralDataAccessException{
		return gremioDAO.getByPrimaryKey(idGremio);
	}
	

	public void removeGremio(Gremio gremio) throws GeneralDataAccessException,RemoveNotAllowedException{
		try {
			List<GremioRegion> grs = gremio.getGremiosRegiones();
			gremio.setGremiosRegiones(null);
			for (GremioRegion gremioRegion : grs) {
				gremioRegionDAO.remove(gremioRegion);
			}
			gremioDAO.remove(gremio);
		} catch (IntegrityViolationException ex) {
			throw new RemoveNotAllowedException(RemoveNotAllowedException.REMOVE_GREMIO_ERROR);
		}
		
	}
	
	public List<Gremio> getGremiosByRegion(String idRegionFiltro) throws GeneralDataAccessException{
		Map<String,Object> criteria=new HashMap<String,Object>();
		criteria.put("gremiosRegiones.codRegion", idRegionFiltro);
		return gremioDAO.findBySimpleCriteria(criteria);
	}

}
