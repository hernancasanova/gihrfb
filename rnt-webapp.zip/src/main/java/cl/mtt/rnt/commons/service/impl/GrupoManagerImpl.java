package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.AutorizacionMovimientoDAO;
import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.autorizacion.Grupo;
import cl.mtt.rnt.commons.model.core.autorizacion.UsuarioGrupo;
import cl.mtt.rnt.commons.model.sgprt.Region;
import cl.mtt.rnt.commons.model.userrol.User;
import cl.mtt.rnt.commons.service.GrupoManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;

@Service("grupoManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class GrupoManagerImpl  implements GrupoManager {
	
	@Autowired()
	@Qualifier("GrupoDAO")
	private GenericDAO<Grupo> grupoDao;
	
	@Autowired()
	@Qualifier("UsuarioGrupoDao")
	private GenericDAO<UsuarioGrupo> usuarioGrupoDao;
	
	@Autowired
	@Qualifier("ubicacionGeograficaManager")
	private UbicacionGeograficaManager ubicacionGeograficaManager;
	
	@Autowired
	@Qualifier("AutorizacionMovimientoDAO")
	private AutorizacionMovimientoDAO autorizacionMovimientoDAO;
	
	
	public UbicacionGeograficaManager getUbicacionGeograficaManager() {
		return ubicacionGeograficaManager;
	}


	public void setUbicacionGeograficaManager(
			UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}


	public GenericDAO<UsuarioGrupo> getUsuarioGrupoDao() {
		return usuarioGrupoDao;
	}


	public void setUsuarioGrupoDao(GenericDAO<UsuarioGrupo> usuarioGrupoDao) {
		this.usuarioGrupoDao = usuarioGrupoDao;
	}


	public GenericDAO<Grupo> getGrupoDao() {
		return grupoDao;
	}


	public void setGrupoDao(GenericDAO<Grupo> grupoDao) {
		this.grupoDao = grupoDao;
	}


	@Override
	public List<Grupo> getGrupos() throws GeneralDataAccessException {
		List<Grupo> grupos = grupoDao.getAll();
		if(grupos != null){
			for(Grupo g : grupos){
				if(g.getCodRegion() != null && !g.getCodRegion().trim().isEmpty() && !g.getCodRegion().trim().equals("00")){
					g.setRegion(ubicacionGeograficaManager.getRegionById(g.getCodRegion()));
				}
				else{
					g.setearRegion();
				}
			}
		}
		return grupos;
	}


	@Override
	public List<UsuarioGrupo> getUsuariosGrupoByIdGrupo(Long idGrupo)
			throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("grupo.id", idGrupo);
		List<UsuarioGrupo> usuariosGrupo = usuarioGrupoDao.findBySimpleCriteria(criteria);
		return usuariosGrupo;
	}


	@Override
	public void saveGrupo(Grupo grupo, List<UsuarioGrupo> usuarios)throws GeneralDataAccessException, DuplicatedIdException {
		grupoDao.save(grupo);
		if(usuarios != null){
			usuarioGrupoDao.saveOrUpdateAll(usuarios);
		}	
	}


	@Override
	public void updateGRupo(Grupo grupo, List<UsuarioGrupo> usuarios)
			throws GeneralDataAccessException{
		grupoDao.update(grupo);
		if(usuarios != null)
		{
			for(UsuarioGrupo ug  : usuarios){
				if(ug.getDbAction()  == GenericModelObject.ACTION_SAVE){
					usuarioGrupoDao.save(ug);
				}
				else if(ug.getDbAction() == GenericModelObject.ACTION_DELETE){
					usuarioGrupoDao.remove(ug);
				}
			}
		}
	}


	@Override
	public void removeGRupo(Grupo grupo, List<UsuarioGrupo> usuarios) throws GeneralDataAccessException,IntegrityViolationException {
		if(usuarios != null){
			usuarioGrupoDao.removeAll(usuarios);
		}
		grupoDao.remove(grupo);
		
	}



	@Override
	public List<Grupo> getGruposByRegionesAndCategorias(List<Region> regiones,List<Long> tipoTransporte, List<Long> medioTransporte,List<Long> categoriaTransporte) throws GeneralDataAccessException {
		List<Grupo> grupos = autorizacionMovimientoDAO.getGruposByCriteria(regiones,tipoTransporte,medioTransporte,categoriaTransporte);
		return grupos;
	}


	@Override
	public List<Grupo> getGruposByUser(User user) throws GeneralDataAccessException {
		List <Grupo>  grupos = new ArrayList<Grupo>();
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("user.id", user.getId());
		List<UsuarioGrupo> usuariosGrupos = usuarioGrupoDao.findBySimpleCriteria(criteria);
		if(usuariosGrupos != null && !usuariosGrupos.isEmpty()){
			for(UsuarioGrupo ug : usuariosGrupos){
				grupos.add(ug.getGrupo());
			}
		}
		return grupos;
	}

	
}
