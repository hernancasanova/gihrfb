package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.LimitacionVehiculo;
import cl.mtt.rnt.commons.model.core.Tenedor;
import cl.mtt.rnt.commons.service.LimitacionVehiculoManager;

@Service("limitacionVehiculoManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class LimitacionVehiculoManagerImpl implements LimitacionVehiculoManager {

	@Autowired
	@Qualifier("LimitacionVehiculoDAO")
	private GenericDAO<LimitacionVehiculo> limitacionVehiculoDAO;

	@Autowired
	@Qualifier("TenedorDAO")
	private GenericDAO<Tenedor> tenedorDAO;

	/**
	 * @return el valor de limitacionVehiculoDAO
	 */
	public GenericDAO<LimitacionVehiculo> getLimitacionVehiculoDAO() {
		return limitacionVehiculoDAO;
	}

	/**
	 * @param setea
	 *            el parametro limitacionVehiculoDAO al campo
	 *            limitacionVehiculoDAO
	 */
	public void setLimitacionVehiculoDAO(GenericDAO<LimitacionVehiculo> limitacionVehiculoDAO) {
		this.limitacionVehiculoDAO = limitacionVehiculoDAO;
	}

	@Override
	public void saveLimitacionVehiculo(LimitacionVehiculo lv) throws GeneralDataAccessException, DuplicatedIdException {
		List<Tenedor> tenedoresAEliminar = new ArrayList<Tenedor>();
		List<Tenedor> tenedores = lv.getTenedores();
		lv.setTenedores(null);
		limitacionVehiculoDAO.save(lv);
		lv.setTenedores(tenedores);
		if (lv.getTenedores() != null) {
			for (Iterator<Tenedor> itT = lv.getTenedores().iterator(); itT.hasNext();) {
				Tenedor tenedor = itT.next();
				if (tenedor.getDbAction() == GenericModelObject.ACTION_SAVE) {
					tenedorDAO.save(tenedor);
				} else {
					if (tenedor.getDbAction() == GenericModelObject.ACTION_UPDATE) {
						tenedorDAO.update(tenedor);
					} else {
						if (tenedor.getDbAction() == GenericModelObject.ACTION_DELETE) {
							itT.remove();
							tenedoresAEliminar.add(tenedor);
						}
					}
				}
			}
		}
//		limitacionVehiculoDAO.save(lv);
		for (Tenedor tenedor : tenedoresAEliminar) {
			tenedorDAO.remove(tenedor);
		}

	}

	@Override
	public void updateLimitacionVehiculo(LimitacionVehiculo lv) throws GeneralDataAccessException, DuplicatedIdException {
		ArrayList<Tenedor> tenedoresAEliminar = new ArrayList<Tenedor>();
		if (lv.getTenedores() != null) {
			for (Iterator<Tenedor> itT = lv.getTenedores().iterator(); itT.hasNext();) {
				Tenedor tenedor = itT.next();
				if (tenedor.getDbAction() == GenericModelObject.ACTION_SAVE) {
					tenedorDAO.save(tenedor);
				} else {
					if (tenedor.getDbAction() == GenericModelObject.ACTION_UPDATE) {
						tenedorDAO.update(tenedor);
					} else {
						if (tenedor.getDbAction() == GenericModelObject.ACTION_DELETE) {
							itT.remove();
							tenedoresAEliminar.add(tenedor);
						}
					}
				}
			}
		}
		limitacionVehiculoDAO.update(lv);
		for (Tenedor tenedor : tenedoresAEliminar) {
			tenedorDAO.remove(tenedor);
		}

	}

	@Override
	public void removeLimitacionVehiculo(LimitacionVehiculo lv) throws GeneralDataAccessException, RemoveNotAllowedException {
		List<Tenedor> tenedoresAEliminar = lv.getTenedores();
		limitacionVehiculoDAO.remove(lv);
		if (tenedoresAEliminar != null) {
			for (Tenedor tenedor : tenedoresAEliminar) {
				tenedorDAO.remove(tenedor);
			}
		}

	}

	/**
	 * @return el valor de tenedorDAO
	 */
	public GenericDAO<Tenedor> getTenedorDAO() {
		return tenedorDAO;
	}

	/**
	 * @param setea
	 *            el parametro tenedorDAO al campo tenedorDAO
	 */
	public void setTenedorDAO(GenericDAO<Tenedor> tenedorDAO) {
		this.tenedorDAO = tenedorDAO;
	}

}
