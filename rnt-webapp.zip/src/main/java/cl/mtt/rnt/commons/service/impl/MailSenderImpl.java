package cl.mtt.rnt.commons.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Service;

import cl.mtt.rnt.commons.util.Utils;

/**
 * Clase que implementa la accion de envio de emails
 * 
 */
@Service("mailSenderService")
public class MailSenderImpl {
	private Properties properties;
	private String defaultFrom;
	private String defaultFromName;
	private Session session;

	public MailSenderImpl() {
		properties = Utils.getProperties();
		configureAndConnectSMTP();
		setDefaultFrom();
	}

	private void setDefaultFrom() {
		defaultFrom = properties.getProperty("mail.from.address");
		defaultFromName = properties.getProperty("mail.from.name");
	}

	private void configureAndConnectSMTP() {
	    
	    String authentication = properties.getProperty("mail.smtp.auth");
	    if (authentication!=null) {
	        Boolean auth = Boolean.valueOf(authentication.trim());
	        if (auth) {
	            session = Session.getDefaultInstance(properties,
	                    new javax.mail.Authenticator() {
	                        protected PasswordAuthentication getPasswordAuthentication() {
	                            return new PasswordAuthentication(properties.getProperty("mail.from.username"),properties.getProperty("mail.from.password"));
	                        }
	                    });
	            session.setDebug(new Boolean(properties.getProperty("mail.debug")));
	        }
	        else {
	           session = Session.getInstance(properties);
	        }
	    }
		

	}

	public MailSenderImpl(Properties properties) {
		this.properties = properties;
		configureAndConnectSMTP();
		setDefaultFrom();
	}

	public void sendEmail(String subject, String message, String to) throws AddressException, MessagingException, UnsupportedEncodingException {
		MimeMessage mess = new MimeMessage(session);
		mess.setFrom(new InternetAddress(defaultFrom,defaultFromName));
		mess.addRecipient(RecipientType.TO, new InternetAddress(to));
		mess.setContent(message, "text/html; charset=utf-8");
		mess.setSubject(subject);	
		mess.setSentDate(new Date());
		Transport.send(mess);
	}
	
	public void sendEmail(String subject, String message, String to, File attach)
			throws AddressException, MessagingException {
		MimeMessage mess = new MimeMessage(session);
		mess.setFrom(new InternetAddress(defaultFrom));
		mess.addRecipient(RecipientType.TO, new InternetAddress(to));
		mess.setSubject(subject);

		//Creo una parte para el mensaje texto
		MimeBodyPart mbp1 = new MimeBodyPart();
		mbp1.setText(message);
		
		//creo una segunda parte para el attach
		MimeBodyPart mbp2 = new MimeBodyPart();

		//Agrego el attach a la segunda parte
		FileDataSource fds = new FileDataSource(attach);
		mbp2.setDataHandler(new DataHandler(fds));
		mbp2.setFileName(fds.getName());
		
		//Creo un multiparte y agrego el mensaje y el attach
		Multipart mp = new MimeMultipart();
		mp.addBodyPart(mbp1);
		mp.addBodyPart(mbp2);

		//agrego el Multipart al mensaje que se va a enviar
		mess.setContent(mp);

		Transport.send(mess);
	}
	
	public void sendEmail(String subject,String message, String to, String attachmentFileName,
			HSSFWorkbook hssWorkBook) throws AddressException,MessagingException, IOException {
		
			MimeMessage mess = new MimeMessage(session);
			DataSource ds = null;
			mess.setFrom(new InternetAddress(defaultFrom));
			mess.addRecipient(RecipientType.TO, new InternetAddress(to));
			mess.setSubject(subject);			
			mess.setSentDate(new Date());

			//Creo una parte para el mensaje texto
			MimeBodyPart mbp1 = new MimeBodyPart();
			mbp1.setText(message);

			//Agrego el attach a la segunda parte
			MimeBodyPart mbp2 = new MimeBodyPart();

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    hssWorkBook.write(baos);
			byte[] bytes = baos.toByteArray();
			ds = new ByteArrayDataSource(bytes, "application/excel");
			
			DataHandler dh = new DataHandler(ds);
			mbp2.setHeader("Content-Disposition",
					"attachment;filename=" + attachmentFileName + ".xls");
			mbp2.setDataHandler(dh);
			mbp2.setFileName(attachmentFileName);
			
			//Creo un multiparte y agrego el mensaje y el excel
			Multipart multiPart = new MimeMultipart();
			multiPart.addBodyPart(mbp1);
			multiPart.addBodyPart(mbp2);

			//agrego el Multipart al mensaje que se va a enviar
			mess.setContent(multiPart);	

			// send the message
			Transport.send(mess);
	
	}
}