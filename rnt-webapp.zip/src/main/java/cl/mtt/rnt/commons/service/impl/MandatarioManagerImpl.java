package cl.mtt.rnt.commons.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.MandatarioDAO;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.model.core.GenericModelObject;
import cl.mtt.rnt.commons.model.core.Mandatario;
import cl.mtt.rnt.commons.model.core.RepresentanteLegal;
import cl.mtt.rnt.commons.model.core.Servicio;
import cl.mtt.rnt.commons.model.sgprt.Comuna;
import cl.mtt.rnt.commons.service.MandatarioManager;
import cl.mtt.rnt.commons.service.PersonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.Resources;

@Service("mandatarioManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class MandatarioManagerImpl implements MandatarioManager, Serializable {

	private static final long serialVersionUID = 656211595552118361L;

	@Autowired()
	@Qualifier("MandatarioDAO")
	private MandatarioDAO mandatarioDAO;

	@Autowired()
	@Qualifier("RepresentanteLegalDAO")
	private GenericDAO<RepresentanteLegal> representanteLegalDAO;

	@Autowired()
	@Qualifier("ubicacionGeograficaManager")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@Autowired()
	@Qualifier("personaManager")
	private PersonaManager personaManager;

	public List<Mandatario> getMandatarioByRut(String rutMandatario) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("persona.rut", rutMandatario);
		List<Mandatario> mandatarios = mandatarioDAO.findBySimpleCriteria(criteria);
		for (Mandatario mandatario : mandatarios) {
			Comuna comuna = ubicacionGeograficaManager.getComunaById(mandatario.getCodigoComuna());
			if(comuna!=null){
				mandatario.setNombreRegion(comuna.getProvincia().getRegion().getNombre());
				mandatario.setNombreComuna(comuna.getNombre());
			}
		}
		return mandatarios;
	}

	@Override
	public void saveMandatario(Mandatario mandatario) throws GeneralDataAccessException, DuplicatedIdException {
		this.mandatarioDAO.save(mandatario);
	}

	@Override
	public void updateMandatario(Mandatario mandatario) throws GeneralDataAccessException {
		this.mandatarioDAO.update(mandatario);

	}

	@Override
	public void removeMandatario(Mandatario mandatario) throws GeneralDataAccessException {
		this.mandatarioDAO.remove(mandatario);
	}

	@Override
	public void preHandle(List<Mandatario> mandatarios, Servicio servicio) throws GeneralDataAccessException, DuplicatedIdException {
		List<Mandatario> aEliminar = new ArrayList<Mandatario>();
		for (Iterator<Mandatario> it = mandatarios.iterator(); it.hasNext();) {
			Mandatario mandatario = it.next();
			// for (Mandatario mandatario : mandatarios) {
			if (mandatario != null) {
				if (mandatario.getDbAction() == GenericModelObject.ACTION_SAVE){
					this.saveMandatario(mandatario);
					servicio.addLog(Resources.getString("servicio.log.cambio.mandatario.nuevo",new String[]{mandatario.getPersona().getRut()}));
				}else {
					if (mandatario.getDbAction() == GenericModelObject.ACTION_UPDATE){
						this.updateMandatario(mandatario);
						servicio.addLog(Resources.getString("servicio.log.cambio.mandatario.cambio",new String[]{mandatario.getPersona().getRut()}));
					}
					if (mandatario.getDbAction() == GenericModelObject.ACTION_DELETE) {
						it.remove();
						if (mandatarioDAO.getCountServicesByMandatario(mandatario) == 1)
							aEliminar.add(mandatario);
						servicio.addLog(Resources.getString("servicio.log.cambio.mandatario.eliminado",new String[]{mandatario.getPersona().getRut()}));
					}
				}
			}
		}
		servicio.getListasEliminar().put(Servicio.LISTA_MANDATRIO, aEliminar);

	}

	// public void postHandle(Mandatario mandatario,Servicio servicio) throws
	// GeneralDataAccessException{
	// List<Mandatario> aEliminar =
	// (ArrayList<Mandatario>)servicio.getListasEliminar().get(Servicio.LISTA_MANDATRIO);
	// if(aEliminar!=null){
	// for (Mandatario todel : aEliminar) {
	// try{
	// Mandatario c = this.getMandatarioById(todel.getId());
	// //servicio.getMandatarios().remove(c);
	// //Si esta en un solo servicio lo elimino definitivamente de la base de
	// datos
	// if(mandatarioDAO.getCountServicesByMandatario(c)==1);
	// removeMandatario(c);
	// }catch(IntegrityViolationException ex){
	// Logger.getLogger(this.getClass()).error(Resources.getString("modificarServicio.error.eliminarMandatario"));
	// }
	//
	// }
	// aEliminar = new ArrayList<Mandatario>();
	// }
	// if(mandatario!=null)
	// mandatario.setDbAction(GenericModelObject.ACTION_NOACTION);
	// }

	public void postHandle(List<Mandatario> mandatarios, Servicio servicio) throws GeneralDataAccessException {
		List<Mandatario> aEliminar = (ArrayList<Mandatario>) servicio.getListasEliminar().get(Servicio.LISTA_MANDATRIO);
		if (aEliminar != null) {
			for (Mandatario todel : aEliminar) {
				try {
					removeMandatario(todel);
				} catch (IntegrityViolationException ex) {
					Logger.getLogger(this.getClass()).error(Resources.getString("modificarServicio.error.eliminarMandatario"));
				}

			}
			aEliminar = new ArrayList<Mandatario>();
		}
		if (mandatarios != null) {
			for (Mandatario m : mandatarios) {
				m.setDbAction(GenericModelObject.ACTION_NOACTION);
			}
		}
	}

	@Override
	public Mandatario getMandatarioById(Long idMandatario) throws GeneralDataAccessException {
		Mandatario mandatario = this.mandatarioDAO.getByPrimaryKey(idMandatario);
		if(mandatario.getCodigoComuna()!=null){
			Comuna comuna = ubicacionGeograficaManager.getComunaById(mandatario.getCodigoComuna());
			mandatario.setNombreRegion(comuna.getProvincia().getRegion().getNombre());
			mandatario.setNombreComuna(comuna.getNombre());
		}
		return mandatario;
	}

	public List<Mandatario> getMandatariosByIdRepresentanteLegal(Long idRepresentanteLegal) throws GeneralDataAccessException {
		RepresentanteLegal rep = representanteLegalDAO.getByPrimaryKey(idRepresentanteLegal);
		Hibernate.initialize(rep.getMandatarios());
		return rep.getMandatarios();
	}

}
