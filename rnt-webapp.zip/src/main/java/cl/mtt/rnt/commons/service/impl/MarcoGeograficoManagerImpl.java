package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.ServicioDAO;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.model.core.Localizable;
import cl.mtt.rnt.commons.model.core.MarcoGeografico;
import cl.mtt.rnt.commons.model.core.MarcoGeograficoLocalizable;
import cl.mtt.rnt.commons.model.core.Zona;
import cl.mtt.rnt.commons.service.MarcoGeograficoManager;
import cl.mtt.rnt.commons.service.ZonaManager;
import cl.mtt.rnt.commons.service.sgprt.UbicacionGeograficaManager;
import cl.mtt.rnt.commons.util.MarcoGeograficoSource;

@Service("marcoGeograficoManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class MarcoGeograficoManagerImpl implements MarcoGeograficoManager {

	@Autowired
	@Qualifier("ubicacionGeograficaManager")
	private UbicacionGeograficaManager ubicacionGeograficaManager;

	@Autowired
	@Qualifier("MarcoGeograficoDAO")
	private GenericDAO<MarcoGeografico> marcoGeograficoDAO;

	@Autowired
	@Qualifier("MarcoGeograficoLocalizableDAO")
	private GenericDAO<MarcoGeograficoLocalizable> marcoGeograficoLocalizableDAO;

	@Autowired
	@Qualifier("zonaManager")
	private ZonaManager zonaManager;
	@Autowired
	@Qualifier("ServicioDAO")
	private ServicioDAO servicioDAO;

	public GenericDAO<MarcoGeograficoLocalizable> getMarcoGeograficoLocalizableDAO() {
		return marcoGeograficoLocalizableDAO;
	}

	public void setMarcoGeograficoLocalizableDAO(GenericDAO<MarcoGeograficoLocalizable> marcoGeograficoLocalizableDAO) {
		this.marcoGeograficoLocalizableDAO = marcoGeograficoLocalizableDAO;
	}

	public ZonaManager getZonaManager() {
		return zonaManager;
	}

	public void setZonaManager(ZonaManager zonaManager) {
		this.zonaManager = zonaManager;
	}

	public UbicacionGeograficaManager getUbicacionGeograficaManager() {
		return ubicacionGeograficaManager;
	}

	public void setUbicacionGeograficaManager(UbicacionGeograficaManager ubicacionGeograficaManager) {
		this.ubicacionGeograficaManager = ubicacionGeograficaManager;
	}

	public GenericDAO<MarcoGeografico> getMarcoGeograficoDAO() {
		return marcoGeograficoDAO;
	}

	public void setMarcoGeograficoDAO(GenericDAO<MarcoGeografico> marcoGeograficoDAO) {
		this.marcoGeograficoDAO = marcoGeograficoDAO;
	}

	@Override
	public void saveMarcoGeografico(MarcoGeografico marcoGeografico) throws GeneralDataAccessException {
		marcoGeograficoDAO.save(marcoGeografico);
		List<MarcoGeograficoLocalizable> locs = new ArrayList<MarcoGeograficoLocalizable>(marcoGeografico.getMarcosGeograficoslocalizables());
		for (MarcoGeograficoLocalizable marcoGeograficoLocalizable : locs) {
				marcoGeograficoLocalizableDAO.save(marcoGeograficoLocalizable);
		}
	}

	@Override
	public void updateMarcoGeografico(MarcoGeografico marcoGeografico) throws GeneralDataAccessException {
		List<MarcoGeograficoLocalizable> locs = new ArrayList<MarcoGeograficoLocalizable>(marcoGeografico.getMarcosGeograficoslocalizables());
		MarcoGeografico marcoGeograficoDB = marcoGeograficoDAO.getByPrimaryKey(marcoGeografico.getId());
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("marcoGeografico.id", marcoGeografico.getId());
		List<MarcoGeograficoLocalizable> locsDB = marcoGeograficoLocalizableDAO.findBySimpleCriteria(criteria);
		for (MarcoGeograficoLocalizable marcoGeograficoLocalizable : locsDB) {
			if (!locs.contains(marcoGeograficoLocalizable)) {
				marcoGeograficoDB.getMarcosGeograficoslocalizables().remove(marcoGeograficoLocalizable);
				marcoGeograficoLocalizableDAO.remove(marcoGeograficoLocalizable);
				// }else{
				// Long id=marcoGeograficoLocalizable.getId();
				// Collections.replaceAll(marcoGeografico.getMarcosGeograficoslocalizables(),
				// marcoGeograficoLocalizable,
				// marcoGeograficoLocalizableDAO.getByPrimaryKey(id));
			}
		}

		// marcoGeograficoLocalizableDAO.saveOrUpdateAll(locs);
		//
		for (MarcoGeograficoLocalizable marcoGeograficoLocalizable : locs) {
			if (marcoGeograficoLocalizable.getId() == null)
				marcoGeograficoLocalizableDAO.save(marcoGeograficoLocalizable);
		}
		// marcoGeografico.setMarcosGeograficoslocalizables(locs);
		marcoGeograficoDB.setAplicableA(marcoGeografico.getAplicableA());
		marcoGeograficoDAO.update(marcoGeograficoDB);
	}
// Mejoras 201409 Nro: 3
	public void removeMarcoGeografico(MarcoGeografico marcoGeografico) throws GeneralDataAccessException{
		MarcoGeografico marcoGeograficoDB = marcoGeograficoDAO.getByPrimaryKey(marcoGeografico.getId());
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("marcoGeografico.id", marcoGeografico.getId());
		List<MarcoGeograficoLocalizable> locsDB = marcoGeograficoLocalizableDAO.findBySimpleCriteria(criteria);
		for (MarcoGeograficoLocalizable marcoGeograficoLocalizable : locsDB) {
				marcoGeograficoLocalizableDAO.remove(marcoGeograficoLocalizable);
		}
		marcoGeograficoDAO.remove(marcoGeograficoDB);		
	}
	// Mejoras 201409 Nro: 3

	@Override
	public void fillLocalizablesMarcoGeografico(MarcoGeografico marcoGeografico) throws GeneralDataAccessException {
		List<Localizable> items = new ArrayList<Localizable>();
		if (MarcoGeograficoSource.AMBITO_REGIONAL.equals(marcoGeografico.getAplicableA())) {
			for (MarcoGeograficoLocalizable elem : marcoGeografico.getMarcosGeograficoslocalizables()) {
				if (!"nac".equals(elem.getIdLocalizable()))
					items.add(ubicacionGeograficaManager.getRegionById(elem.getIdLocalizable()));
			}
		} else if (MarcoGeograficoSource.AMBITO_COMUNAL.equals(marcoGeografico.getAplicableA())) {
			for (MarcoGeograficoLocalizable elem : marcoGeografico.getMarcosGeograficoslocalizables()) {
				if (!"nac".equals(elem.getIdLocalizable()))
					items.add(ubicacionGeograficaManager.getComunaById(elem.getIdLocalizable()));
			}
		} else if (MarcoGeograficoSource.AMBITO_ZONAL.equals(marcoGeografico.getAplicableA())) {
			for (MarcoGeograficoLocalizable elem : marcoGeografico.getMarcosGeograficoslocalizables()) {
				if (!"nac".equals(elem.getIdLocalizable())){
					Zona zonaById = zonaManager.getZonaById(Long.valueOf(elem.getIdLocalizable()));
					zonaById.setRegionResponsable(ubicacionGeograficaManager.getRegionById(zonaById.getIdRegion()));
					items.add(zonaById);
				}
			}
		}
		marcoGeografico.setLocalizables(items);
	}

	public List<MarcoGeografico> getMarcoGeograficoByZona(Zona zona) throws GeneralDataAccessException {
		Map<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("aplicableA", MarcoGeograficoSource.AMBITO_ZONAL);
		criteria.put("marcosGeograficoslocalizables.idLocalizable", zona.getIdentifier());
		return marcoGeograficoDAO.findBySimpleCriteria(criteria);
	}

	public Boolean getZonaUsada(Zona zona) throws GeneralDataAccessException {
		List<MarcoGeografico> mgs = getMarcoGeograficoByZona(zona);
		if (mgs == null || mgs.size() > 0)
			return true;
		return servicioDAO.getZonaUsada(zona);
	}

}
