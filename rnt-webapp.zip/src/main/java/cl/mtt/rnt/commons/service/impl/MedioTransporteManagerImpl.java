package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.MedioTransporte;
import cl.mtt.rnt.commons.service.MedioTransporteManager;
import cl.mtt.rnt.commons.util.StringUtil;

@Service("medioTransporteManager")
@Lazy(value = true)
@Transactional(rollbackFor = Exception.class)
public class MedioTransporteManagerImpl implements MedioTransporteManager {

	@Autowired
	@Qualifier("MedioTransporteDAO")
	private GenericDAO<MedioTransporte> medioTransporteDAO;

	public GenericDAO<MedioTransporte> getMedioTransporteDAO() {
		return medioTransporteDAO;
	}

	public void setMedioTransporteDAO(GenericDAO<MedioTransporte> medioTransporteDAO) {
		this.medioTransporteDAO = medioTransporteDAO;
	}

	@Override
	public List<MedioTransporte> getAllMediosTrasporte() throws GeneralDataAccessException {
		List<String> sortingColumns = new ArrayList<String>();
		sortingColumns.add("nombre");
		return medioTransporteDAO.findBySimpleCriteria(new HashMap<String, Object>(), sortingColumns);
	}

	@Override
	public MedioTransporte getMedioTransporteById(Long idMedioTransporte) throws GeneralDataAccessException {
		return this.medioTransporteDAO.getByPrimaryKey(idMedioTransporte);
	}

	@Override
	public void saveMedioTransporte(MedioTransporte medioTransporte) throws GeneralDataAccessException, DuplicatedIdException {
		// creo el descriptor
		String desc = StringUtil.makeDescriptor(medioTransporte.getNombre());
		if (!existeMedioTransporte(desc, null)) {
			medioTransporte.setDescriptor(desc);
			this.medioTransporteDAO.save(medioTransporte);
		}
	}

	@Override
	public MedioTransporte getMedioTransporteByDescriptor(String descriptor) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put(GenericDAO.CRITERION_PREFIX_EQUALS_IGNORE_CASE+".descriptor", descriptor);
		List<MedioTransporte> consulta = medioTransporteDAO.findBySimpleCriteria(criteria);
		if (consulta != null && consulta.size() > 0)
			return consulta.get(0);

		return null;
	}

	/**
	 * Verifica si el nombre está disponible. Para esto chequea los
	 * descriptores.
	 * 
	 * @param name
	 * @return
	 */
	private boolean existeMedioTransporte(String name, Long id) throws DuplicatedIdException, GeneralDataAccessException {
		MedioTransporte medio = getMedioTransporteByDescriptor(name);
		if (medio != null && (id == null || medio.getId().longValue() != id.longValue()))
			throw new DuplicatedIdException(DuplicatedIdException.DUPLICATE_MEDIO_TRANSPORTE);
		return false;
	}

	@Override
	public void updateMedioTransporte(MedioTransporte medioTransporte) throws GeneralDataAccessException, DuplicatedIdException {
		// creo el descriptor
		String desc = StringUtil.makeDescriptor(medioTransporte.getNombre());
		if (!existeMedioTransporte(desc, medioTransporte.getId())) {
			MedioTransporte medioTransporteDB = this.getMedioTransporteById(medioTransporte.getId());
			medioTransporteDB.setNombre(medioTransporte.getNombre());
			medioTransporteDB.setDescriptor(desc);
			this.getMedioTransporteDAO().update(medioTransporteDB);
		}
	}

	@Override
	public void removeMedioTransporte(MedioTransporte medioTransporte) throws GeneralDataAccessException, RemoveNotAllowedException {
		try {
			this.medioTransporteDAO.remove(medioTransporte);
		} catch (IntegrityViolationException ex) {
			throw new RemoveNotAllowedException(RemoveNotAllowedException.REMOVE_MEDIO_TRANSPORTE_ERROR);
		}

	}

}
