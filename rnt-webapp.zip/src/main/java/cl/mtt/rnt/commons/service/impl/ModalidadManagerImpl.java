package cl.mtt.rnt.commons.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.mtt.rnt.commons.dao.GenericDAO;
import cl.mtt.rnt.commons.dao.TipoServicioDAO;
import cl.mtt.rnt.commons.exception.DuplicatedIdException;
import cl.mtt.rnt.commons.exception.GeneralDataAccessException;
import cl.mtt.rnt.commons.exception.IntegrityViolationException;
import cl.mtt.rnt.commons.exception.RemoveNotAllowedException;
import cl.mtt.rnt.commons.model.core.Modalidad;
import cl.mtt.rnt.commons.model.view.CategoriaTransporteSeleccionble;
import cl.mtt.rnt.commons.service.ModalidadManager;
import cl.mtt.rnt.commons.util.StringUtil;

@Service("modalidadManager")
@Transactional(rollbackFor = Exception.class)
@Lazy(value = true)
public class ModalidadManagerImpl implements ModalidadManager {

	@Autowired
	@Qualifier("ModalidadDAO")
	private GenericDAO<Modalidad> modalidadDAO;
	
	@Autowired
    @Qualifier("TipoServicioDAO")
    private TipoServicioDAO tipoServicioDAO;

	public GenericDAO<Modalidad> getModalidadDAO() {
		return modalidadDAO;
	}

	public void setModalidadDAO(GenericDAO<Modalidad> modalidadDAO) {
		this.modalidadDAO = modalidadDAO;
	}

	@Override
	public List<Modalidad> getAllModalidades() throws GeneralDataAccessException {
		List<String> sortingColumns = new ArrayList<String>();
		sortingColumns.add("nombre");
		return modalidadDAO.findBySimpleCriteria(new HashMap<String, Object>(), sortingColumns);
	}
	
	@Override
    public List<Modalidad> getAllModalidades(CategoriaTransporteSeleccionble categoria) throws GeneralDataAccessException {
        return tipoServicioDAO.getModalidades(categoria);
    }

	@Override
	public Modalidad getModalidadById(Long idModalidad) throws GeneralDataAccessException {
		return this.modalidadDAO.getByPrimaryKey(idModalidad);
	}

	@Override
	public void saveModalidad(Modalidad modalidad) throws GeneralDataAccessException, DuplicatedIdException {
		// creo el descriptor
		String desc = StringUtil.makeDescriptor(modalidad.getNombre());
		if (!existeModalidad(desc, null)) {
			modalidad.setDescriptor(desc);
			this.modalidadDAO.save(modalidad);
		}
	}

	@Override
	public Modalidad getModalidadByDescriptor(String descriptor) throws GeneralDataAccessException {
		HashMap<String, Object> criteria = new HashMap<String, Object>();
		criteria.put("descriptor", descriptor);
		List<Modalidad> consulta = modalidadDAO.findBySimpleCriteria(criteria);
		if (consulta != null && consulta.size() > 0)
			return consulta.get(0);

		return null;
	}

	/**
	 * Verifica si el nombre está disponible. Para esto chequea los
	 * descriptores.
	 * 
	 * @param name
	 * @return
	 */
	private boolean existeModalidad(String name, Long id) throws DuplicatedIdException, GeneralDataAccessException {
		Modalidad modalidad = getModalidadByDescriptor(name);
		if (modalidad != null && (id == null || modalidad.getId().longValue() != id.longValue()))
			throw new DuplicatedIdException(DuplicatedIdException.DUPLICATE_MODALIDAD);
		return false;
	}

	@Override
	public void updateModalidad(Modalidad modalidad) throws GeneralDataAccessException, DuplicatedIdException {
		// creo el descriptor
		String desc = StringUtil.makeDescriptor(modalidad.getNombre());
		if (!existeModalidad(desc, modalidad.getId())) {
			Modalidad modalidadDB = this.getModalidadById(modalidad.getId());
			modalidadDB.setNombre(modalidad.getNombre());
			modalidadDB.setDescriptor(desc);
			this.getModalidadDAO().update(modalidadDB);
		}
	}

	@Override
	public void removeModalidad(Modalidad modalidad) throws GeneralDataAccessException, RemoveNotAllowedException {
		try {
			this.modalidadDAO.remove(modalidad);
		} catch (IntegrityViolationException ex) {
			throw new RemoveNotAllowedException(RemoveNotAllowedException.REMOVE_MODALIDAD_TRANSPORTE_ERROR);
		}
	}

}
